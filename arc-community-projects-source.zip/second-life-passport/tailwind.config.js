/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        ivory:   { DEFAULT: '#f7f3ec', warm: '#ede8df', deep: '#e4ddd1' },
        forest:  { DEFAULT: '#2d5a3d', 2: '#3d7a52', light: '#edf5f0' },
        terra:   { DEFAULT: '#b84c2c', light: '#f8ede9' },
        brass:   { DEFAULT: '#c9943a', light: '#fdf3e3' },
        ink:     { DEFAULT: '#1a1410', 2: '#3b3229' },
        muted:   '#7a6e62',
        subtle:  '#a09588',
      },
      fontFamily: {
        display: ['Space Grotesk', 'sans-serif'],
        body:    ['DM Sans', 'sans-serif'],
        mono:    ['JetBrains Mono', 'Menlo', 'monospace'],
      },
      borderRadius: {
        workshop: '3px',
        card: '12px',
        pill: '999px',
      },
    },
  },
  plugins: [],
}

