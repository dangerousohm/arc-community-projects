import React, { useState } from 'react';
import type { Screen } from './types';
import Navbar from './components/Navbar';
import Discovery from './screens/Discovery';
import Passport from './screens/Passport';
import CreateRequest from './screens/CreateRequest';
import Proposals from './screens/Proposals';
import Workbench from './screens/Workbench';
import Workshop from './screens/Workshop';
import Completion from './screens/Completion';

interface NavState {
  screen: Screen;
  projectId?: string;
}

export default function App() {
  const [nav, setNav] = useState<NavState>({ screen: 'discovery' });

  const navigate = (screen: Screen, projectId?: string) => {
    setNav({ screen, projectId });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const { screen, projectId } = nav;

  return (
    <div className="min-h-dvh" style={{ background: 'var(--ivory)' }}>
      <Navbar screen={screen} onNavigate={navigate} />

      <main id="main-content" tabIndex={-1}>
        {screen === 'discovery' && (
          <Discovery onNavigate={navigate} />
        )}
        {screen === 'passport' && projectId && (
          <Passport projectId={projectId} onNavigate={navigate} />
        )}
        {screen === 'passport' && !projectId && (
          <Discovery onNavigate={navigate} />
        )}
        {screen === 'create' && (
          <CreateRequest draftId={projectId} onNavigate={navigate} />
        )}
        {screen === 'proposals' && projectId && (
          <Proposals projectId={projectId} onNavigate={navigate} />
        )}
        {screen === 'proposals' && !projectId && (
          <Discovery onNavigate={navigate} />
        )}
        {screen === 'workbench' && projectId && (
          <Workbench projectId={projectId} onNavigate={navigate} />
        )}
        {screen === 'workbench' && !projectId && (
          <Workshop onNavigate={navigate} />
        )}
        {screen === 'workshop' && (
          <Workshop onNavigate={navigate} />
        )}
        {screen === 'completion' && projectId && (
          <Completion projectId={projectId} onNavigate={navigate} />
        )}
        {screen === 'completion' && !projectId && (
          <Discovery onNavigate={navigate} />
        )}
      </main>

      {/* Skip to content link (keyboard accessibility) */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[9999] focus:px-4 focus:py-2 focus:rounded-lg focus:text-sm focus:font-semibold"
        style={{ background: 'var(--forest)', color: '#f7f3ec' }}
      >
        Skip to content
      </a>
    </div>
  );
}
