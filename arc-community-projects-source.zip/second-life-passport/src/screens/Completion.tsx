import React from 'react';
import { ArrowLeft, Check, Info, Share2 } from 'lucide-react';
import type { Screen } from '../types';
import { DEMO_PROJECT_MAP } from '../data';
import { CategoryBadge, DemoBadge } from '../components/Badges';
import { getIllustration } from '../components/Illustrations';

interface CompletionProps {
  projectId: string;
  onNavigate: (s: Screen, id?: string) => void;
}

export default function Completion({ projectId, onNavigate }: CompletionProps) {
  const project = DEMO_PROJECT_MAP.get(projectId);

  if (!project) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Project not found</p>
        <button onClick={() => onNavigate('discovery')} className="text-sm underline" style={{ color: 'var(--forest)' }}>Back to Discovery</button>
      </div>
    );
  }

  const accepted = project.acceptedProposalId
    ? project.proposals.find(p => p.id === project.acceptedProposalId)
    : null;

  const isComplete = project.status === 'completed';

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button
        onClick={() => onNavigate('passport', projectId)}
        className="inline-flex items-center gap-1.5 text-sm mb-6 hover:opacity-70 transition-opacity"
        style={{ color: 'var(--forest)' }}
      >
        <ArrowLeft size={14} />
        Object Passport
      </button>

      {/* Passport card */}
      <div
        className="rounded-card card-shadow overflow-hidden mb-6 relative"
        style={{ background: 'var(--surface-strong)' }}
      >
        {/* Paper texture */}
        <div className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: 'repeating-linear-gradient(0deg,transparent,transparent 28px,rgba(26,20,16,0.02) 28px,rgba(26,20,16,0.02) 29px)',
            borderRadius: 'inherit',
          }}
        />

        {/* Header band */}
        <div className="relative px-6 py-5 border-b flex items-start justify-between gap-4 flex-wrap"
          style={{ borderColor: 'var(--border)', background: 'var(--forest)' }}>
          <div>
            <p className="chip mb-1" style={{ background: 'rgba(247,243,236,0.18)', color: '#f7f3ec', border: '1px solid rgba(247,243,236,0.25)' }}>
              Completion Passport
            </p>
            <h1 className="display text-2xl font-bold text-balance" style={{ color: '#f7f3ec', letterSpacing: '-0.025em' }}>
              {project.title}
            </h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <DemoBadge />
            <CategoryBadge category={project.category} />
          </div>
        </div>

        {/* Before / After */}
        <div className="relative grid grid-cols-2 divide-x divide-[var(--border)]">
          <div className="p-4 flex flex-col items-center gap-2 border-r" style={{ borderColor: 'var(--border)', background: 'var(--ivory-warm)' }}>
            <p className="chip" style={{ background: 'var(--terra-light)', color: 'var(--terra)' }}>Before</p>
            {getIllustration(project.photos[0], { width: 140, height: 100 })}
            <p className="text-xs text-center" style={{ color: 'var(--muted)' }}>{project.condition === 'poor' ? 'Broken / non-functional' : 'Worn / damaged'}</p>
          </div>
          <div className="p-4 flex flex-col items-center gap-2" style={{ background: 'var(--forest-light)' }}>
            <p className="chip" style={{ background: 'var(--forest)', color: '#f7f3ec' }}>After</p>
            {getIllustration(project.photos[0], { width: 140, height: 100 })}
            <p className="text-xs text-center" style={{ color: 'var(--forest)' }}>
              {isComplete ? 'Transformed' : 'In progress'}
            </p>
          </div>
        </div>

        {/* Body */}
        <div className="relative p-6">
          {/* Work performed */}
          {project.workPerformed && (
            <section className="mb-5">
              <h2 className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--subtle)' }}>
                Work Performed
              </h2>
              <p className="text-sm leading-relaxed text-pretty" style={{ color: 'var(--ink-2)' }}>
                {project.workPerformed}
              </p>
            </section>
          )}

          {/* Materials reused */}
          {project.materialsReused && project.materialsReused.length > 0 && (
            <section className="mb-5">
              <h2 className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--subtle)' }}>
                Materials Reused
              </h2>
              <ul className="flex flex-col gap-1.5">
                {project.materialsReused.map((m, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm" style={{ color: 'var(--ink-2)' }}>
                    <Check size={12} style={{ color: 'var(--forest)', flexShrink: 0 }} />
                    {m}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Project facts */}
          <section className="grid grid-cols-2 gap-x-6 gap-y-3 mb-5 text-sm border-t pt-4" style={{ borderColor: 'var(--border)' }}>
            {project.completedAt && (
              <div>
                <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Completed</dt>
                <dd style={{ color: 'var(--ink)' }}>{project.completedAt}</dd>
              </div>
            )}
            {accepted && (
              <div>
                <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Repairer</dt>
                <dd style={{ color: 'var(--ink)' }}>{accepted.repairerName}</dd>
              </div>
            )}
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Project started</dt>
              <dd style={{ color: 'var(--ink)' }}>{project.createdAt}</dd>
            </div>
            {accepted && (
              <div>
                <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Approach</dt>
                <dd style={{ color: 'var(--ink)' }}>
                  {accepted.approach === 'restore' ? 'Restored original function' : 'Transformed into something new'}
                </dd>
              </div>
            )}
          </section>

          {/* Repair timeline */}
          {project.chapters.length > 0 && (
            <section className="mb-5">
              <h2 className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: 'var(--subtle)' }}>
                Project History
              </h2>
              <ol className="flex flex-col gap-2">
                {project.chapters.map((ch, i) => (
                  <li key={ch.id} className="flex gap-3 items-start text-sm">
                    <span
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                      style={{ background: i === project.chapters.length - 1 ? 'var(--forest)' : 'var(--ivory-deep)', color: i === project.chapters.length - 1 ? '#f7f3ec' : 'var(--muted)' }}
                    >
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-semibold" style={{ color: 'var(--ink)' }}>{ch.title}</p>
                      <p className="text-xs" style={{ color: 'var(--muted)' }}>{ch.date} · {ch.by}</p>
                      <p className="text-xs mt-0.5 text-pretty" style={{ color: 'var(--ink-2)' }}>{ch.description}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </section>
          )}

          {/* Disclaimer */}
          <div className="flex items-start gap-2 p-3 rounded-lg text-xs"
            style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
            <Info size={12} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--brass)' }} />
            <p style={{ color: 'var(--muted)' }}>
              This passport documents the project as recorded by the owner and repairer. Information is not independently verified.
              Environmental impact claims are not made. This is a demo project for illustration purposes.
            </p>
          </div>
        </div>
      </div>

      {/* Share notice */}
      <div className="flex items-start gap-3 p-4 rounded-card mb-4"
        style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
        <Share2 size={14} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--subtle)' }} />
        <p className="text-sm" style={{ color: 'var(--muted)' }}>
          Public sharing of completion passports requires a published backend and is not yet available.
          This passport exists only in this browser session.
        </p>
      </div>

      <div className="flex gap-3 flex-wrap">
        <button
          onClick={() => onNavigate('discovery')}
          className="px-5 py-2.5 rounded-pill font-semibold text-sm border"
          style={{ borderColor: 'var(--border-mid)', color: 'var(--ink-2)', background: 'transparent' }}
        >
          Back to Discovery
        </button>
        <button
          onClick={() => onNavigate('workbench', projectId)}
          className="px-5 py-2.5 rounded-pill font-semibold text-sm"
          style={{ background: 'var(--forest)', color: '#f7f3ec' }}
        >
          View Workbench
        </button>
      </div>
    </div>
  );
}
