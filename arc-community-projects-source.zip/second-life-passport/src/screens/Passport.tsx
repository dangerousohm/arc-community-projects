import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Info, ChevronDown, ChevronUp, Clock } from 'lucide-react';
import type { Screen } from '../types';
import { DEMO_PROJECT_MAP } from '../data';
import { CategoryBadge, ConditionBadge, StatusBadge, DemoBadge } from '../components/Badges';
import { getIllustration } from '../components/Illustrations';

interface PassportProps {
  projectId: string;
  onNavigate: (s: Screen, id?: string) => void;
}

export default function Passport({ projectId, onNavigate }: PassportProps) {
  const project = DEMO_PROJECT_MAP.get(projectId);
  const [beforeAfter, setBeforeAfter] = useState<'before' | 'after'>('before');
  const [expandedChapter, setExpandedChapter] = useState<string | null>(null);

  if (!project) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Project not found</p>
        <button onClick={() => onNavigate('discovery')}
          className="text-sm underline" style={{ color: 'var(--forest)' }}>
          Back to Discovery
        </button>
      </div>
    );
  }

  const accepted = project.acceptedProposalId
    ? project.proposals.find(p => p.id === project.acceptedProposalId)
    : null;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* Back */}
      <button
        onClick={() => onNavigate('discovery')}
        className="inline-flex items-center gap-1.5 text-sm mb-6 hover:opacity-70 transition-opacity"
        style={{ color: 'var(--forest)' }}
        aria-label="Back to Discovery"
      >
        <ArrowLeft size={14} />
        Discovery
      </button>

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 flex-wrap mb-2">
            <DemoBadge />
            <StatusBadge status={project.status} />
          </div>
          <h1 className="display text-2xl md:text-3xl font-bold text-balance" style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}>
            {project.title}
          </h1>
        </div>
        <div className="flex gap-2 flex-wrap mt-1">
          <CategoryBadge category={project.category} />
          <ConditionBadge condition={project.condition} />
        </div>
      </div>

      {/* Notice */}
      <div className="flex items-start gap-2 p-3 rounded-lg mb-6 text-sm"
        style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
        <Info size={14} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--brass)' }} />
        <p style={{ color: 'var(--muted)' }}>
          This is a project record documenting the object's condition and repair history as reported by the owner. Information is not independently verified.
          {project.isDemo ? ' This is a demo project.' : ''}
        </p>
      </div>

      {/* Before / After comparison */}
      <section className="rounded-card card-shadow overflow-hidden mb-6" style={{ background: 'var(--surface-strong)' }}
        aria-label="Before and after comparison">
        <div className="flex border-b" style={{ borderColor: 'var(--border)' }}
          role="tablist" aria-label="View before or after">
          {(['before', 'after'] as const).map(side => (
            <button
              key={side}
              role="tab"
              id={`ba-tab-${side}`}
              aria-controls={`ba-panel-${side}`}
              onClick={() => setBeforeAfter(side)}
              className="flex-1 py-3 text-sm font-semibold capitalize transition-colors"
              style={{
                background: beforeAfter === side
                  ? (side === 'before' ? 'var(--terra-light)' : 'var(--forest-light)')
                  : 'transparent',
                color: beforeAfter === side
                  ? (side === 'before' ? 'var(--terra)' : 'var(--forest)')
                  : 'var(--muted)',
                borderBottom: beforeAfter === side
                  ? `2px solid ${side === 'before' ? 'var(--terra)' : 'var(--forest)'}`
                  : '2px solid transparent',
              }}
              aria-selected={beforeAfter === side}
            >
              {side === 'before' ? 'Before' : project.status === 'completed' ? 'After' : 'Envisioned Outcome'}
            </button>
          ))}
        </div>
        <div id={`ba-panel-${beforeAfter}`} role="tabpanel" aria-labelledby={`ba-tab-${beforeAfter}`}
          className="flex flex-col sm:flex-row items-center gap-0">
          <div className="flex-1 p-8 flex items-center justify-center"
            style={{ background: beforeAfter === 'before' ? 'var(--ivory-warm)' : 'var(--forest-light)' }}>
            {getIllustration(project.photos[0], { width: 180, height: 130 })}
          </div>
          <div className="flex-1 p-6 flex flex-col gap-3">
            {beforeAfter === 'before' ? (
              <>
                <p className="display text-base font-semibold" style={{ color: 'var(--terra)' }}>
                  Current Condition
                </p>
                <ConditionBadge condition={project.condition} />
                <p className="text-sm leading-relaxed text-pretty" style={{ color: 'var(--ink-2)' }}>
                  {project.description}
                </p>
              </>
            ) : (
              <>
                <p className="display text-base font-semibold" style={{ color: 'var(--forest)' }}>
                  Desired Outcome
                </p>
                <p className="text-sm leading-relaxed text-pretty" style={{ color: 'var(--ink-2)' }}>
                  {project.desiredOutcome}
                </p>
                {project.status === 'completed' && project.workPerformed && (
                  <div className="mt-1 p-3 rounded-lg text-sm" style={{ background: 'var(--forest-light)', color: 'var(--forest)' }}>
                    <strong>Work completed:</strong> {project.workPerformed}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </section>

      {/* Project details */}
      <section className="rounded-card card-shadow p-5 mb-6" style={{ background: 'var(--surface-strong)' }}>
        <h2 className="display text-base font-semibold mb-4" style={{ color: 'var(--ink)' }}>Project Details</h2>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Budget</dt>
            <dd className="tabular font-medium" style={{ color: 'var(--ink)' }}>${project.estimatedBudget}</dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Target Date</dt>
            <dd style={{ color: 'var(--ink)' }}>{project.targetDate}</dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Listed</dt>
            <dd style={{ color: 'var(--ink)' }}>{project.createdAt}</dd>
          </div>
          {project.completedAt && (
            <div>
              <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Completed</dt>
              <dd style={{ color: 'var(--success)' }}>{project.completedAt}</dd>
            </div>
          )}
          {accepted && (
            <div className="col-span-2">
              <dt className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ color: 'var(--subtle)' }}>Repairer</dt>
              <dd style={{ color: 'var(--ink)' }}>{accepted.repairerName}</dd>
            </div>
          )}
        </dl>
      </section>

      {/* Repair History */}
      {project.chapters.length > 0 && (
        <section className="mb-6">
          <h2 className="display text-lg font-semibold mb-4" style={{ color: 'var(--ink)' }}>
            Repair History
          </h2>
          <div className="flex flex-col gap-0">
            {project.chapters.map((ch, i) => (
              <div key={ch.id} className="flex gap-4">
                {/* Timeline spine */}
                <div className="flex flex-col items-center flex-shrink-0">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                    style={{ background: i === project.chapters.length - 1 ? 'var(--forest)' : 'var(--ivory-deep)', color: i === project.chapters.length - 1 ? '#f7f3ec' : 'var(--muted)' }}
                  >
                    {i + 1}
                  </div>
                  {i < project.chapters.length - 1 && (
                    <div className="w-0.5 flex-1 my-1" style={{ background: 'var(--border-mid)' }} />
                  )}
                </div>
                {/* Chapter card */}
                <div className="flex-1 pb-4">
                  <button
                    onClick={() => setExpandedChapter(expandedChapter === ch.id ? null : ch.id)}
                    className="w-full text-left rounded-card p-4 mb-0 transition-colors hover:bg-[#ede8df]"
                    style={{ background: 'var(--surface-strong)', border: '1px solid var(--border)' }}
                    aria-expanded={expandedChapter === ch.id}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="display text-sm font-semibold mb-0.5" style={{ color: 'var(--ink)' }}>{ch.title}</p>
                        <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--subtle)' }}>
                          <Clock size={10} />
                          <span>{ch.date}</span>
                          <span>·</span>
                          <span>{ch.by}</span>
                        </div>
                      </div>
                      {expandedChapter === ch.id
                        ? <ChevronUp size={14} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
                        : <ChevronDown size={14} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
                      }
                    </div>
                    {expandedChapter === ch.id && (
                      <p className="text-sm mt-3 text-pretty leading-relaxed" style={{ color: 'var(--ink-2)' }}>
                        {ch.description}
                      </p>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Actions */}
      <div className="flex gap-3 flex-wrap">
        {project.status === 'awaiting_proposals' && (
          <button
            onClick={() => onNavigate('proposals', project.id)}
            className="px-5 py-2.5 rounded-pill font-semibold text-sm"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            View Proposals
            <ArrowRight size={14} className="inline ml-1.5" />
          </button>
        )}
        {['proposal_accepted', 'funded', 'in_progress', 'submitted_for_review'].includes(project.status) && (
          <button
            onClick={() => onNavigate('workbench', project.id)}
            className="px-5 py-2.5 rounded-pill font-semibold text-sm"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            View Workbench
          </button>
        )}
        {project.status === 'completed' && (
          <button
            onClick={() => onNavigate('completion', project.id)}
            className="px-5 py-2.5 rounded-pill font-semibold text-sm"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            View Completion Passport
          </button>
        )}
        {project.proposals.length > 0 && project.status !== 'completed' && (
          <button
            onClick={() => onNavigate('proposals', project.id)}
            className="px-5 py-2.5 rounded-pill font-semibold text-sm border"
            style={{ borderColor: 'var(--border-mid)', color: 'var(--ink-2)', background: 'transparent' }}
          >
            {project.proposals.length} Proposal{project.proposals.length !== 1 ? 's' : ''}
          </button>
        )}
      </div>
    </div>
  );
}
