import React, { useState } from 'react';
import { ArrowLeft, Check, Clock, AlertTriangle, ChevronRight } from 'lucide-react';
import type { ProjectStatus, Milestone, Screen } from '../types';
import { DEMO_PROJECT_MAP } from '../data';
import { StatusBadge, DemoBadge, SimulationBadge } from '../components/Badges';

interface WorkbenchProps {
  projectId: string;
  onNavigate: (s: Screen, id?: string) => void;
}

const TIMELINE_STEPS: { status: ProjectStatus; label: string; description: string }[] = [
  { status: 'draft', label: 'Draft', description: 'Project saved as a draft' },
  { status: 'awaiting_proposals', label: 'Open for Proposals', description: 'Repairers can submit proposals' },
  { status: 'proposal_accepted', label: 'Proposal Accepted', description: 'Owner has accepted a repairer\'s proposal' },
  { status: 'funded', label: 'Funded', description: 'Funds locked in escrow' },
  { status: 'in_progress', label: 'In Progress', description: 'Repair work underway' },
  { status: 'submitted_for_review', label: 'Submitted for Review', description: 'Repairer submitted completed work' },
  { status: 'accepted', label: 'Accepted', description: 'Owner accepted the work' },
  { status: 'completed', label: 'Completed', description: 'Funds released, project complete' },
];

const STATUS_ORDER = TIMELINE_STEPS.map(s => s.status);

function getStepIndex(status: ProjectStatus): number {
  const idx = STATUS_ORDER.indexOf(status);
  return idx >= 0 ? idx : 0;
}

export default function Workbench({ projectId, onNavigate }: WorkbenchProps) {
  const project = DEMO_PROJECT_MAP.get(projectId);
  // simulatedAction is session-only in-memory state — it resets when you navigate away.
  // This is intentional: no contract is deployed, so nothing persists between visits.
  const [simulatedAction, setSimulatedAction] = useState<string | null>(null);

  if (!project) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Project not found</p>
        <button onClick={() => onNavigate('discovery')} className="text-sm underline" style={{ color: 'var(--forest)' }}>
          Back to Discovery
        </button>
      </div>
    );
  }

  const accepted = project.acceptedProposalId
    ? project.proposals.find(p => p.id === project.acceptedProposalId)
    : null;

  const currentStep = getStepIndex(project.status);

  const isSpecialStatus = ['cancelled', 'disputed', 'revision_requested'].includes(project.status);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button
        onClick={() => onNavigate('passport', projectId)}
        className="inline-flex items-center gap-1.5 text-sm mb-6 hover:opacity-70 transition-opacity"
        style={{ color: 'var(--forest)' }}
      >
        <ArrowLeft size={14} />
        Object Passport
      </button>

      <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
        <div>
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <DemoBadge />
            <StatusBadge status={project.status} />
          </div>
          <h1 className="display text-2xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}>
            Project Workbench
          </h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>{project.title}</p>
        </div>
        {accepted && (
          <div className="text-right">
            <p className="text-xs uppercase tracking-wide font-semibold mb-0.5" style={{ color: 'var(--subtle)' }}>Repairer</p>
            <p className="text-sm font-medium" style={{ color: 'var(--ink-2)' }}>{accepted.repairerName}</p>
          </div>
        )}
      </div>

      {/* Special state banners */}
      {project.status === 'cancelled' && (
        <div className="flex items-start gap-2 p-4 rounded-card mb-6"
          style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
          <AlertTriangle size={15} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
          <p className="text-sm" style={{ color: 'var(--muted)' }}>
            This project was cancelled. Any funded amounts would be refunded according to the escrow contract rules.
          </p>
        </div>
      )}
      {project.status === 'disputed' && (
        <div className="flex items-start gap-2 p-4 rounded-card mb-6"
          style={{ background: 'var(--terra-light)', border: '1px solid rgba(184,76,44,0.25)' }}>
          <AlertTriangle size={15} style={{ color: 'var(--terra)', flexShrink: 0 }} />
          <p className="text-sm" style={{ color: 'var(--terra)' }}>
            This project is in dispute. A designated dispute resolver would review evidence and determine fund allocation.
            Parties should not act unilaterally until the dispute is resolved.
          </p>
        </div>
      )}
      {project.status === 'revision_requested' && (
        <div className="flex items-start gap-2 p-4 rounded-card mb-6"
          style={{ background: 'var(--brass-light)', border: '1px solid rgba(201,148,58,0.3)' }}>
          <AlertTriangle size={15} style={{ color: 'var(--brass)', flexShrink: 0 }} />
          <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
            Revision requested. The owner has reviewed the submission and requested changes. The repairer should respond.
          </p>
        </div>
      )}

      {/* Timeline */}
      {!isSpecialStatus && (
        <section className="rounded-card card-shadow p-5 mb-6" style={{ background: 'var(--surface-strong)' }}
          aria-label="Project timeline">
          <h2 className="display text-sm font-semibold mb-4" style={{ color: 'var(--ink)' }}>Project Timeline</h2>
          <ol className="flex flex-col gap-0">
            {TIMELINE_STEPS.map((step, i) => {
              const state: 'past' | 'current' | 'future' =
                i < currentStep ? 'past' : i === currentStep ? 'current' : 'future';
              return (
                <li key={step.status} className="flex gap-3 items-start">
                  <div className="flex flex-col items-center flex-shrink-0">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{
                        background:
                          state === 'past' ? 'var(--forest)' :
                          state === 'current' ? 'var(--brass)' :
                          'var(--ivory-deep)',
                        color:
                          state === 'past' ? '#f7f3ec' :
                          state === 'current' ? '#1a1410' :
                          'var(--subtle)',
                      }}
                      aria-hidden="true"
                    >
                      {state === 'past' ? <Check size={13} strokeWidth={2.5} /> : (
                        <span className="text-xs font-bold">{i + 1}</span>
                      )}
                    </div>
                    {i < TIMELINE_STEPS.length - 1 && (
                      <div className="w-0.5 h-5 my-0.5" style={{
                        background: state === 'past' ? 'var(--forest)' : 'var(--ivory-deep)'
                      }} />
                    )}
                  </div>
                  <div className="flex-1 pb-1 pt-0.5">
                    <p className="text-sm font-semibold" style={{
                      color:
                        state === 'past' ? 'var(--muted)' :
                        state === 'current' ? 'var(--ink)' :
                        'var(--subtle)',
                    }}>
                      {step.label}
                      {state === 'current' && (
                        <span className="ml-2 chip"
                          style={{ background: 'var(--brass-light)', color: 'var(--brass)' }}>
                          Current
                        </span>
                      )}
                    </p>
                    {state !== 'future' && (
                      <p className="text-xs" style={{ color: 'var(--subtle)' }}>{step.description}</p>
                    )}
                  </div>
                </li>
              );
            })}
          </ol>
        </section>
      )}

      {/* Milestones */}
      {accepted && accepted.milestones.length > 0 && (
        <section className="mb-6">
          <h2 className="display text-lg font-semibold mb-4" style={{ color: 'var(--ink)' }}>
            Payment Milestones
          </h2>
          <SimulationBadge label="Payment simulation — contract integration pending" />
          <div className="flex flex-col gap-3 mt-3">
            {accepted.milestones.map((m, i) => (
              <MilestoneCard
                key={m.id}
                milestone={m}
                index={i}
                isOwner={project.isOwner}
                onAction={(action) => setSimulatedAction(`${m.id}:${action}`)}
                simulatedAction={simulatedAction}
              />
            ))}
          </div>

          {/* Total */}
          <div className="flex items-center justify-between p-4 rounded-lg mt-3 border"
            style={{ borderColor: 'var(--border)', background: 'var(--ivory-warm)' }}>
            <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Total</p>
            <p className="display text-lg font-bold tabular" style={{ color: 'var(--ink)' }}>
              ${(accepted.milestones.reduce((s, m) => s + m.amount, 0) / 100).toFixed(0)}
            </p>
          </div>

          {/* Escrow notice */}
          <div className="flex items-start gap-2 p-3 rounded-lg mt-3 text-sm"
            style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
            <AlertTriangle size={13} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--brass)' }} />
            <p style={{ color: 'var(--muted)' }}>
              <strong style={{ color: 'var(--ink)' }}>Contract integration pending.</strong>{' '}
              A milestone escrow contract is required to lock, release, and refund funds. Milestone amounts shown are for illustration only.
              Actual payment uses USDC on Arc Testnet. Funds are released only after the owner explicitly approves each milestone submission.
            </p>
          </div>
        </section>
      )}

      {/* Navigation */}
      <div className="flex gap-3 flex-wrap">
        {project.status === 'completed' && (
          <button
            onClick={() => onNavigate('completion', projectId)}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-pill font-semibold text-sm"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            View Completion Passport
            <ChevronRight size={14} />
          </button>
        )}
        <button
          onClick={() => onNavigate('workshop')}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-pill text-sm border font-medium"
          style={{ borderColor: 'var(--border-mid)', color: 'var(--ink-2)', background: 'transparent' }}
        >
          Back to Workshop
        </button>
      </div>
    </div>
  );
}

function MilestoneCard({
  milestone,
  index,
  isOwner,
  onAction,
  simulatedAction,
}: {
  milestone: Milestone;
  index: number;
  isOwner: boolean;
  onAction: (action: string) => void;
  simulatedAction: string | null;
}) {
  const wasActed = simulatedAction?.startsWith(milestone.id);

  const statusColor: Record<Milestone['status'], string> = {
    pending: 'var(--subtle)',
    funded: 'var(--brass)',
    submitted: 'var(--terra)',
    approved: 'var(--forest)',
    released: 'var(--success)',
    disputed: 'var(--danger)',
  };

  const statusLabel: Record<Milestone['status'], string> = {
    pending: 'Pending',
    funded: 'Funded',
    submitted: 'Submitted for review',
    approved: 'Approved',
    released: 'Released',
    disputed: 'Disputed',
  };

  const whoMustAct: Record<Milestone['status'], string> = {
    pending: 'Awaiting funding',
    funded: 'Awaiting repairer submission',
    submitted: isOwner ? 'Awaiting your review' : 'Awaiting owner review',
    approved: 'Awaiting fund release',
    released: 'Complete',
    disputed: 'Awaiting dispute resolution',
  };

  return (
    <div
      className="rounded-card card-shadow overflow-hidden"
      style={{
        background: 'var(--surface-strong)',
        borderLeft: `3px solid ${statusColor[milestone.status]}`,
      }}
    >
      <div className="p-4 flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
              style={{ background: 'var(--ivory-deep)', color: 'var(--muted)' }}>
              {index + 1}
            </span>
            <p className="display text-sm font-semibold" style={{ color: 'var(--ink)' }}>{milestone.title}</p>
            <span className="chip" style={{ background: 'var(--ivory-warm)', color: statusColor[milestone.status] }}>
              {statusLabel[milestone.status]}
            </span>
          </div>
          <p className="text-xs mb-1" style={{ color: 'var(--muted)' }}>{milestone.deliverables}</p>
          <p className="text-xs flex items-center gap-1" style={{ color: 'var(--subtle)' }}>
            <Clock size={10} /> Due: {milestone.dueDate}
          </p>
          <p className="text-xs mt-1 font-medium" style={{ color: 'var(--ink-2)' }}>
            Next: {whoMustAct[milestone.status]}
          </p>
        </div>
        <p className="display text-lg font-bold tabular flex-shrink-0" style={{ color: 'var(--ink)' }}>
          ${(milestone.amount / 100).toFixed(0)}
        </p>
      </div>

      {/* Action buttons (simulation) */}
      {!wasActed && milestone.status === 'submitted' && isOwner && (
        <div className="px-4 pb-4 flex gap-2">
          <button
            onClick={() => onAction('approve')}
            className="px-4 py-2 rounded-pill text-xs font-semibold transition-opacity hover:opacity-80"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            Approve (Demo)
          </button>
          <button
            onClick={() => onAction('request_revision')}
            className="px-4 py-2 rounded-pill text-xs font-semibold border"
            style={{ borderColor: 'var(--brass)', color: 'var(--brass)', background: 'transparent' }}
          >
            Request Revision (Demo)
          </button>
        </div>
      )}
      {wasActed && (
        <div className="px-4 pb-3 flex flex-col gap-1.5">
          <SimulationBadge label="Simulated action — no transaction submitted" />
          <p className="text-xs" style={{ color: 'var(--subtle)' }}>
            This simulated action resets when you navigate away. No funds have moved and no message was sent.
          </p>
        </div>
      )}
    </div>
  );
}
