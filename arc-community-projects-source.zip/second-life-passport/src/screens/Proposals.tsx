import React, { useState } from 'react';
import { ArrowLeft, Check, Clock, Package, AlertCircle } from 'lucide-react';
import type { Proposal, Screen } from '../types';
import { DEMO_PROJECT_MAP } from '../data';
import { DemoBadge, SimulationBadge } from '../components/Badges';

interface ProposalsProps {
  projectId: string;
  onNavigate: (s: Screen, id?: string) => void;
}

export default function Proposals({ projectId, onNavigate }: ProposalsProps) {
  const project = DEMO_PROJECT_MAP.get(projectId);
  const [selected, setSelected] = useState<string | null>(
    project?.acceptedProposalId ?? null
  );
  // simulated is in-memory only — resets when you navigate away.
  // No contract is deployed so acceptance state never persists across visits.
  const [simulated, setSimulated] = useState(false);

  if (!project) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <p className="display text-xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Project not found</p>
        <button onClick={() => onNavigate('discovery')} className="text-sm underline" style={{ color: 'var(--forest)' }}>
          Back to Discovery
        </button>
      </div>
    );
  }

  const hasAccepted = !!project.acceptedProposalId;
  const selectedProposal = project.proposals.find(p => p.id === selected);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button
        onClick={() => onNavigate('passport', projectId)}
        className="inline-flex items-center gap-1.5 text-sm mb-6 hover:opacity-70 transition-opacity"
        style={{ color: 'var(--forest)' }}
      >
        <ArrowLeft size={14} />
        Object Passport
      </button>

      <div className="flex items-center gap-3 flex-wrap mb-1">
        <h1 className="display text-2xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}>
          Repair Proposals
        </h1>
        <DemoBadge />
      </div>
      <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
        for <strong style={{ color: 'var(--ink-2)' }}>{project.title}</strong>
      </p>

      {/* Notice */}
      <div className="flex items-start gap-2 p-3 rounded-lg mb-6 text-sm"
        style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
        <AlertCircle size={14} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--brass)' }} />
        <p style={{ color: 'var(--muted)' }}>
          These are demo proposals for illustration purposes. Repairer profiles, credentials, and availability are not verified.
        </p>
      </div>

      {project.proposals.length === 0 ? (
        <div className="text-center py-16 rounded-card border"
          style={{ borderColor: 'var(--border)', background: 'var(--ivory-warm)' }}>
          <p className="display text-lg font-semibold mb-2" style={{ color: 'var(--ink)' }}>No proposals yet</p>
          <p className="text-sm" style={{ color: 'var(--muted)' }}>Repairers will appear here once they submit their proposals.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4 mb-6">
          {project.proposals.map(proposal => (
            <ProposalCard
              key={proposal.id}
              proposal={proposal}
              isSelected={selected === proposal.id}
              isAccepted={hasAccepted && project.acceptedProposalId === proposal.id}
              onSelect={() => !hasAccepted && setSelected(proposal.id)}
              showSelect={!hasAccepted}
            />
          ))}
        </div>
      )}

      {/* Comparison table (2+ proposals) */}
      {project.proposals.length >= 2 && (
        <section className="rounded-card card-shadow overflow-hidden mb-6" style={{ background: 'var(--surface-strong)' }}>
          <div className="p-4 border-b" style={{ borderColor: 'var(--border)' }}>
            <h2 className="display text-sm font-semibold" style={{ color: 'var(--ink)' }}>Side-by-Side Comparison</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm" aria-label="Proposal comparison">
              <thead>
                <tr style={{ background: 'var(--ivory-warm)' }}>
                  <th className="text-left p-3 text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--subtle)' }}>
                    Detail
                  </th>
                  {project.proposals.map(p => (
                    <th key={p.id} className="text-left p-3" style={{ color: 'var(--ink-2)', minWidth: 150 }}>
                      {p.repairerName}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  { label: 'Approach', getValue: (p: Proposal) => p.approach === 'restore' ? 'Restore original function' : 'Transform into something new' },
                  { label: 'Price', getValue: (p: Proposal) => `$${p.totalPrice}` },
                  { label: 'Duration', getValue: (p: Proposal) => `${p.estimatedDays} days` },
                  { label: 'Milestones', getValue: (p: Proposal) => `${p.milestones.length}` },
                ].map((row, i) => (
                  <tr key={row.label} style={{ background: i % 2 === 0 ? 'transparent' : 'var(--ivory-warm)' }}>
                    <td className="p-3 text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--subtle)' }}>
                      {row.label}
                    </td>
                    {project.proposals.map(p => (
                      <td key={p.id} className="p-3 tabular" style={{ color: 'var(--ink-2)' }}>
                        {row.getValue(p)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Accept action */}
      {!hasAccepted && selectedProposal && (
        <div className="rounded-card p-5 mb-4"
          style={{ background: 'var(--forest-light)', border: '1px solid rgba(45,90,61,0.2)' }}>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="display text-sm font-semibold mb-0.5" style={{ color: 'var(--forest)' }}>
                Accept proposal from {selectedProposal.repairerName}?
              </p>
              <p className="text-xs" style={{ color: 'var(--muted)' }}>
                Total: ${selectedProposal.totalPrice} over {selectedProposal.milestones.length} milestone{selectedProposal.milestones.length !== 1 ? 's' : ''}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <SimulationBadge label="Contract integration pending" />
              <button
                onClick={() => setSimulated(true)}
                className="px-4 py-2 rounded-pill text-sm font-semibold transition-opacity hover:opacity-80"
                style={{ background: 'var(--forest)', color: '#f7f3ec' }}
                disabled={simulated}
              >
                {simulated ? 'Simulated' : 'Accept Proposal (Demo)'}
              </button>
            </div>
          </div>
          {simulated && (
            <div className="mt-3 flex items-start gap-2 p-3 rounded-lg text-sm"
              style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
              <AlertCircle size={13} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--brass)' }} />
              <p style={{ color: 'var(--muted)' }}>
                This is a payment simulation only. No transaction has been submitted and no message has been sent to the repairer.
                A real acceptance requires a deployed escrow contract and a connected wallet.
                This simulated state resets if you navigate away — it is not stored anywhere.
              </p>
            </div>
          )}
        </div>
      )}

      {hasAccepted && (
        <div className="flex items-center gap-3 p-4 rounded-card"
          style={{ background: 'var(--forest-light)', border: '1px solid rgba(45,90,61,0.25)' }}>
          <Check size={16} style={{ color: 'var(--forest)' }} />
          <p className="text-sm font-medium" style={{ color: 'var(--forest)' }}>
            Proposal accepted. View the workbench to track progress.
          </p>
          <button
            onClick={() => onNavigate('workbench', projectId)}
            className="ml-auto text-sm font-semibold underline"
            style={{ color: 'var(--forest)' }}
          >
            Workbench →
          </button>
        </div>
      )}
    </div>
  );
}

function ProposalCard({
  proposal,
  isSelected,
  isAccepted,
  onSelect,
  showSelect,
}: {
  proposal: Proposal;
  isSelected: boolean;
  isAccepted: boolean;
  onSelect: () => void;
  showSelect: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className="rounded-card card-shadow overflow-hidden"
      style={{
        background: 'var(--surface-strong)',
        border: isAccepted
          ? '1.5px solid var(--forest)'
          : isSelected
          ? '1.5px solid var(--brass)'
          : '1px solid var(--border)',
      }}
    >
      {/* Header */}
      <div className="p-5 flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <p className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>{proposal.repairerName}</p>
            {isAccepted && (
              <span className="chip" style={{ background: 'var(--forest-light)', color: 'var(--forest)' }}>
                Accepted
              </span>
            )}
            <DemoBadge />
          </div>
          <p className="text-xs mb-2 italic" style={{ color: 'var(--muted)' }}>{proposal.repairerBio}</p>
          <div className="flex items-center gap-3 text-sm flex-wrap">
            <span
              className="chip"
              style={{
                background: proposal.approach === 'restore' ? 'var(--ivory-warm)' : 'var(--brass-light)',
                color: proposal.approach === 'restore' ? 'var(--ink-2)' : 'var(--brass)',
              }}
            >
              {proposal.approach === 'restore' ? 'Restore original function' : 'Transform into something new'}
            </span>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="display text-xl font-bold tabular" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>
            ${proposal.totalPrice}
          </p>
          <p className="text-xs flex items-center gap-1 justify-end" style={{ color: 'var(--muted)' }}>
            <Clock size={10} />
            {proposal.estimatedDays} days
          </p>
        </div>
      </div>

      {/* Approach detail */}
      <div className="px-5 pb-3">
        <p className="text-sm text-pretty leading-relaxed" style={{ color: 'var(--ink-2)' }}>
          {proposal.approachDetail}
        </p>
      </div>

      {/* Deliverables toggle */}
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full text-left px-5 py-3 flex items-center gap-2 text-sm border-t border-b transition-colors hover:bg-[#f7f3ec]"
        style={{ borderColor: 'var(--border)', color: 'var(--forest)' }}
        aria-expanded={expanded}
      >
        <Package size={13} />
        <span className="font-medium">Deliverables & Milestones</span>
        <span className="ml-auto text-xs" style={{ color: 'var(--subtle)' }}>{expanded ? 'Collapse' : 'Expand'}</span>
      </button>

      {expanded && (
        <div className="px-5 py-4" style={{ background: 'var(--ivory-warm)' }}>
          <p className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--subtle)' }}>
            Deliverables
          </p>
          <ul className="flex flex-col gap-1 mb-4">
            {proposal.deliverables.map((d, i) => (
              <li key={i} className="flex items-start gap-2 text-sm" style={{ color: 'var(--ink-2)' }}>
                <Check size={13} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--forest)' }} />
                {d}
              </li>
            ))}
          </ul>
          <p className="text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--subtle)' }}>
            Payment Milestones
          </p>
          {proposal.milestones.map((m, i) => (
            <div key={m.id} className="flex items-start gap-3 py-2 border-t text-sm" style={{ borderColor: 'var(--border)' }}>
              <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5"
                style={{ background: 'var(--forest)', color: '#f7f3ec' }}>
                {i + 1}
              </span>
              <div className="flex-1">
                <p className="font-medium" style={{ color: 'var(--ink)' }}>{m.title}</p>
                <p className="text-xs" style={{ color: 'var(--muted)' }}>{m.deliverables}</p>
                <p className="text-xs" style={{ color: 'var(--muted)' }}>Due: {m.dueDate}</p>
              </div>
              <p className="font-semibold tabular flex-shrink-0" style={{ color: 'var(--ink)' }}>
                ${(m.amount / 100).toFixed(0)}
              </p>
            </div>
          ))}
          <p className="text-xs mt-3 flex items-center gap-1" style={{ color: 'var(--subtle)' }}>
            <AlertCircle size={11} />
            Payment amounts shown in USD for illustration. Actual settlement would use USDC on Arc Testnet.
          </p>
        </div>
      )}

      {/* Select button */}
      {showSelect && (
        <div className="px-5 py-3">
          <button
            onClick={onSelect}
            className="w-full py-2.5 rounded-pill text-sm font-semibold border transition-colors"
            style={{
              background: isSelected ? 'var(--brass-light)' : 'transparent',
              borderColor: isSelected ? 'var(--brass)' : 'var(--border-mid)',
              color: isSelected ? 'var(--brass)' : 'var(--ink-2)',
            }}
            aria-pressed={isSelected}
          >
            {isSelected ? 'Selected for acceptance' : 'Select this proposal'}
          </button>
        </div>
      )}
    </div>
  );
}
