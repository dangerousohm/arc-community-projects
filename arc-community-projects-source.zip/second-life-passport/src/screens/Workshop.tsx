import React, { useState, useEffect, useRef } from 'react';
import { Plus, Pencil, Trash2, AlertCircle } from 'lucide-react';
import type { LocalDraft, Screen, Project } from '../types';
import { DEMO_PROJECTS } from '../data';
import { StatusBadge, DemoBadge } from '../components/Badges';
import { getIllustration } from '../components/Illustrations';
import { getDrafts, deleteDraft } from '../storage';

interface WorkshopProps {
  onNavigate: (s: Screen, id?: string) => void;
}

function loadDrafts(): { drafts: LocalDraft[]; error: string } {
  try {
    return { drafts: getDrafts(), error: '' };
  } catch {
    return { drafts: [], error: 'Could not load drafts from browser storage.' };
  }
}

export default function Workshop({ onNavigate }: WorkshopProps) {
  const [{ drafts: initialDrafts, error: initialError }] = useState(loadDrafts);
  const [drafts, setDrafts] = useState<LocalDraft[]>(initialDrafts);
  const [draftsError] = useState(initialError);
  const [tab, setTab] = useState<'owner' | 'repairer'>('owner');
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const modalFirstRef = useRef<HTMLButtonElement>(null);

  // Close delete modal on Escape; move focus to first modal button on open
  useEffect(() => {
    if (!deleteTarget) return;
    modalFirstRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setDeleteTarget(null);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [deleteTarget]);

  const handleDeleteDraft = (id: string) => {
    deleteDraft(id);
    setDrafts(prev => prev.filter(d => d.id !== id));
    setDeleteTarget(null);
  };

  const ownerProjects = DEMO_PROJECTS.filter(p => p.isOwner);
  const repairerProjects = DEMO_PROJECTS.filter(p => !p.isOwner);

  const activeOwner = ownerProjects.filter(p => !['completed', 'cancelled', 'draft'].includes(p.status));
  const completedOwner = ownerProjects.filter(p => p.status === 'completed');

  const activeRepairer = repairerProjects.filter(p => !['completed', 'cancelled'].includes(p.status));
  const completedRepairer = repairerProjects.filter(p => p.status === 'completed');

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="display text-2xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}>
            My Workshop
          </h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>
            Your repair projects and drafts
          </p>
        </div>
        <button
          onClick={() => onNavigate('create')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-pill text-sm font-semibold"
          style={{ background: 'var(--forest)', color: '#f7f3ec' }}
        >
          <Plus size={14} />
          List an Object
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b mb-6" style={{ borderColor: 'var(--border)' }}
        role="tablist" aria-label="Workshop sections">
        {[
          { id: 'owner', label: 'My Objects', count: ownerProjects.length + drafts.length },
          { id: 'repairer', label: 'I\'m the Repairer', count: repairerProjects.length },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id as typeof tab)}
            className="px-4 py-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors"
            style={{
              borderColor: tab === t.id ? 'var(--forest)' : 'transparent',
              color: tab === t.id ? 'var(--forest)' : 'var(--muted)',
            }}
            aria-selected={tab === t.id}
            role="tab"
            id={`tab-${t.id}`}
            aria-controls={`tabpanel-${t.id}`}
          >
            {t.label}
            <span
              className="w-5 h-5 rounded-full text-xs flex items-center justify-center font-semibold"
              style={{
                background: tab === t.id ? 'var(--forest-light)' : 'var(--ivory-deep)',
                color: tab === t.id ? 'var(--forest)' : 'var(--muted)',
              }}
            >
              {t.count}
            </span>
          </button>
        ))}
      </div>

      {tab === 'owner' && (
        <div id="tabpanel-owner" role="tabpanel" aria-labelledby="tab-owner">
          {/* Local Drafts */}
          <section className="mb-8">
            <h2 className="display text-base font-semibold mb-3" style={{ color: 'var(--ink)' }}>
              Drafts <span className="text-xs font-normal" style={{ color: 'var(--muted)' }}>(saved in this browser)</span>
            </h2>
            {draftsError ? (
              <div className="flex items-start gap-2 p-3 rounded-lg text-sm"
                style={{ background: 'var(--terra-light)', border: '1px solid rgba(184,76,44,0.2)' }}>
                <AlertCircle size={14} style={{ color: 'var(--terra)', flexShrink: 0 }} />
                <p style={{ color: 'var(--terra)' }}>{draftsError}</p>
              </div>
            ) : drafts.length === 0 ? (
              <div className="text-center py-8 rounded-card border border-dashed"
                style={{ borderColor: 'var(--border)' }}>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  No drafts yet. Start listing an object to create one.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {drafts.map(draft => (
                  <div key={draft.id}
                    className="flex items-center gap-3 p-3 rounded-card border"
                    style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}>
                    <div className="flex-1 min-w-0">
                      <p className="display text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>
                        {draft.title || <em style={{ color: 'var(--subtle)' }}>Untitled draft</em>}
                      </p>
                      <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                        Saved in this browser · {new Date(draft.savedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onNavigate('create', draft.id)}
                        className="p-2 rounded-lg transition-colors hover:bg-[#edf5f0]"
                        style={{ color: 'var(--forest)' }}
                        aria-label={`Edit draft: ${draft.title || 'Untitled draft'}`}
                      >
                        <Pencil size={13} />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(draft.id)}
                        className="p-2 rounded-lg transition-colors hover:bg-[#f8ede9]"
                        style={{ color: 'var(--terra)' }}
                        aria-label={`Delete draft: ${draft.title || 'Untitled draft'}`}
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Active projects (demo) */}
          <section className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>
                Active Projects
              </h2>
              <DemoBadge />
            </div>
            {activeOwner.length === 0 ? (
              <div className="text-center py-8 rounded-card border border-dashed"
                style={{ borderColor: 'var(--border)' }}>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>No active projects yet.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {activeOwner.map(p => <ProjectRow key={p.id} project={p} onNavigate={onNavigate} />)}
              </div>
            )}
          </section>

          {/* Completed (demo) */}
          {completedOwner.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-3">
                <h2 className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>
                  Completed Transformations
                </h2>
                <DemoBadge />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {completedOwner.map(p => <ProjectRow key={p.id} project={p} onNavigate={onNavigate} />)}
              </div>
            </section>
          )}
        </div>
      )}

      {tab === 'repairer' && (
        <div>
          {/* Active repairer projects */}
          <section className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <h2 className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>
                Active Repairs
              </h2>
              <DemoBadge />
            </div>
            {activeRepairer.length === 0 ? (
              <div className="text-center py-8 rounded-card border border-dashed"
                style={{ borderColor: 'var(--border)' }}>
                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  No active repair jobs. Browse the discovery page to find objects to repair.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {activeRepairer.map(p => <ProjectRow key={p.id} project={p} onNavigate={onNavigate} asRepairer />)}
              </div>
            )}
          </section>

          {completedRepairer.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-3">
                <h2 className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>
                  Completed Repairs
                </h2>
                <DemoBadge />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {completedRepairer.map(p => <ProjectRow key={p.id} project={p} onNavigate={onNavigate} asRepairer />)}
              </div>
            </section>
          )}
        </div>
      )}

      {/* Delete confirm modal */}
      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(26,20,16,0.5)' }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="workshop-delete-heading"
        >
          <div className="rounded-card card-shadow p-6 max-w-sm w-full" style={{ background: 'var(--surface-strong)' }}>
            <h2 id="workshop-delete-heading" className="display text-base font-semibold mb-2" style={{ color: 'var(--ink)' }}>
              Delete this draft?
            </h2>
            <p className="text-sm mb-4" style={{ color: 'var(--muted)' }}>
              This will permanently remove the draft from your browser and cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                ref={modalFirstRef}
                onClick={() => handleDeleteDraft(deleteTarget)}
                className="px-4 py-2 rounded-pill text-sm font-semibold"
                style={{ background: 'var(--terra)', color: '#f7f3ec' }}
              >
                Delete
              </button>
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-pill text-sm font-semibold border"
                style={{ borderColor: 'var(--border-mid)', color: 'var(--ink-2)', background: 'transparent' }}
              >
                Keep it
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ProjectRow({
  project,
  onNavigate,
  asRepairer,
}: {
  project: Project;
  onNavigate: (s: Screen, id?: string) => void;
  asRepairer?: boolean;
}) {
  const targetScreen: Screen = project.status === 'completed' ? 'completion'
    : ['in_progress', 'proposal_accepted', 'funded', 'submitted_for_review'].includes(project.status) ? 'workbench'
    : project.proposals.length > 0 ? 'proposals'
    : 'passport';

  return (
    <button
      onClick={() => onNavigate(targetScreen, project.id)}
      className="flex items-center gap-3 p-3 rounded-card text-left transition-colors hover:bg-[#ede8df] border"
      style={{ background: 'var(--surface-strong)', borderColor: 'var(--border)' }}
      aria-label={`Open ${project.title}`}
    >
      <div className="w-12 h-12 rounded-lg overflow-hidden flex items-center justify-center flex-shrink-0"
        style={{ background: 'var(--ivory-warm)' }}>
        {getIllustration(project.photos[0], { width: 44, height: 38 })}
      </div>
      <div className="flex-1 min-w-0">
        <p className="display text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{project.title}</p>
        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
          <StatusBadge status={project.status} />
          {asRepairer && <span className="chip" style={{ background: 'var(--brass-light)', color: 'var(--brass)' }}>Repairer</span>}
        </div>
      </div>
    </button>
  );
}
