import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, ArrowRight, Clock, DollarSign } from 'lucide-react';
import type { Category, Project, Screen } from '../types';
import { DEMO_PROJECTS } from '../data';
import { CategoryBadge, ConditionBadge, StatusBadge, DemoBadge } from '../components/Badges';
import { getIllustration } from '../components/Illustrations';
import { WorkbenchIllustration } from '../components/Illustrations';

interface DiscoveryProps {
  onNavigate: (s: Screen, projectId?: string) => void;
}

const CATEGORIES: { id: Category | 'all'; label: string }[] = [
  { id: 'all', label: 'All Objects' },
  { id: 'furniture', label: 'Furniture' },
  { id: 'electronics', label: 'Electronics' },
  { id: 'clothing', label: 'Clothing' },
  { id: 'everyday', label: 'Everyday' },
];

export default function Discovery({ onNavigate }: DiscoveryProps) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<Category | 'all'>('all');

  const featured = DEMO_PROJECTS[0]; // completed radio project

  const filtered = useMemo(() => {
    return DEMO_PROJECTS.filter(p => {
      const matchCat = category === 'all' || p.category === category;
      const q = query.toLowerCase();
      const matchQ =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.desiredOutcome.toLowerCase().includes(q);
      return matchCat && matchQ;
    });
  }, [query, category]);

  const awaiting = DEMO_PROJECTS.filter(p => p.status === 'awaiting_proposals');
  const inProgress = DEMO_PROJECTS.filter(
    p => ['in_progress', 'proposal_accepted', 'funded', 'submitted_for_review'].includes(p.status)
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Hero */}
      <div
        className="relative rounded-card overflow-hidden mb-10 card-shadow"
        style={{ background: 'var(--forest)', minHeight: 260 }}
      >
        {/* Paper texture */}
        <div className="absolute inset-0 pointer-events-none" style={{
          backgroundImage: 'repeating-linear-gradient(0deg,transparent,transparent 28px,rgba(247,243,236,0.04) 28px,rgba(247,243,236,0.04) 29px)'
        }}/>
        <div className="relative z-10 p-6 md:p-10 flex flex-col md:flex-row items-start md:items-center gap-8">
          <div className="flex-1 min-w-0">
            <p
              className="chip mb-3 inline-flex"
              style={{ background: 'rgba(247,243,236,0.15)', color: '#f7f3ec', border: '1px solid rgba(247,243,236,0.2)' }}
            >
              Community Repair
            </p>
            <h1
              className="display text-3xl md:text-4xl font-bold mb-3 text-balance"
              style={{ color: '#f7f3ec', letterSpacing: '-0.03em' }}
            >
              What could this become?
            </h1>
            <p className="text-base mb-6 max-w-md text-pretty" style={{ color: 'rgba(247,243,236,0.8)', lineHeight: 1.6 }}>
              Give broken or unused objects a second story. Connect with local repairers and makers who can transform them.
            </p>
            <button
              onClick={() => onNavigate('create')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-pill font-semibold text-sm transition-opacity hover:opacity-90"
              style={{ background: 'var(--brass)', color: '#1a1410' }}
            >
              List your object
              <ArrowRight size={15} />
            </button>
          </div>
          <div className="flex-shrink-0 opacity-90">
            <WorkbenchIllustration width={280} height={160} />
          </div>
        </div>
      </div>

      {/* Featured transformation */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="display text-xl font-semibold" style={{ color: 'var(--ink)' }}>
            A New Beginning
          </h2>
          <DemoBadge />
        </div>
        <button
          onClick={() => onNavigate('completion', featured.id)}
          className="w-full text-left rounded-card card-shadow overflow-hidden transition-transform hover:scale-[1.005] active:scale-[0.998]"
          style={{ background: 'var(--surface-strong)' }}
          aria-label={`View completed transformation: ${featured.title}`}
        >
          <div className="flex flex-col sm:flex-row">
            {/* Before */}
            <div className="flex-1 p-6 flex flex-col items-center justify-center gap-2"
              style={{ background: 'var(--ivory-warm)' }}>
              <p className="chip" style={{ background: 'var(--terra-light)', color: 'var(--terra)' }}>Before</p>
              {getIllustration('radio', { width: 160, height: 110 })}
              <p className="text-xs font-medium" style={{ color: 'var(--muted)' }}>Broken tuner, failed transformer</p>
            </div>
            {/* Arrow */}
            <div className="hidden sm:flex items-center justify-center px-4"
              style={{ background: 'var(--ivory)' }}>
              <ArrowRight size={24} style={{ color: 'var(--forest)' }} />
            </div>
            {/* After */}
            <div className="flex-1 p-6 flex flex-col items-center justify-center gap-2"
              style={{ background: 'var(--forest-light)' }}>
              <p className="chip" style={{ background: 'var(--forest)', color: '#f7f3ec' }}>A new beginning</p>
              {getIllustration('radio', { width: 160, height: 110 })}
              <p className="text-xs font-medium" style={{ color: 'var(--forest)' }}>Bluetooth 5.0 speaker, original cabinet</p>
            </div>
            {/* Info */}
            <div className="sm:w-56 p-6 flex flex-col justify-center gap-2 border-l"
              style={{ borderColor: 'var(--border)' }}>
              <p className="display text-base font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
                {featured.title}
              </p>
              <CategoryBadge category={featured.category} />
              <p className="text-sm" style={{ color: 'var(--muted)' }}>Budget: ${featured.estimatedBudget}</p>
              <p className="text-sm font-medium" style={{ color: 'var(--forest)' }}>View passport →</p>
            </div>
          </div>
        </button>
      </section>

      {/* Search + Filters */}
      <section className="mb-8">
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="relative flex-1">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              style={{ color: 'var(--subtle)' }}
            />
            <input
              type="search"
              placeholder="Search objects, materials, outcomes..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 rounded-card text-sm border"
              style={{
                background: 'var(--surface-strong)',
                borderColor: 'var(--border)',
                color: 'var(--ink)',
                fontFamily: "'DM Sans',sans-serif",
                outline: 'none',
              }}
              aria-label="Search repair projects"
            />
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            <SlidersHorizontal size={14} style={{ color: 'var(--subtle)' }} />
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className="px-3 py-1.5 rounded-pill text-xs font-semibold transition-colors"
                style={{
                  background: category === cat.id ? 'var(--forest)' : 'var(--ivory-warm)',
                  color: category === cat.id ? '#f7f3ec' : 'var(--ink-2)',
                  border: `1px solid ${category === cat.id ? 'var(--forest)' : 'var(--border)'}`,
                }}
                aria-pressed={category === cat.id}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        {filtered.length === 0 ? (
          <div
            className="text-center py-16 rounded-card border"
            style={{ borderColor: 'var(--border)', background: 'var(--ivory-warm)' }}
          >
            <p className="display text-lg font-semibold mb-2" style={{ color: 'var(--ink)' }}>
              No objects found
            </p>
            <p className="text-sm" style={{ color: 'var(--muted)' }}>
              Try a different search or filter, or list your own object.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(project => (
              <ProjectCard
                key={project.id}
                project={project}
                onClick={() => onNavigate('passport', project.id)}
              />
            ))}
          </div>
        )}

        {filtered.length > 0 && (
          <p className="text-xs mt-3 text-center" style={{ color: 'var(--subtle)' }}>
            All {filtered.length} result{filtered.length !== 1 ? 's' : ''} are demo projects for illustration purposes.
          </p>
        )}
      </section>

      {/* Awaiting proposals */}
      {awaiting.length > 0 && (
        <section className="mb-8">
          <h2 className="display text-xl font-semibold mb-4" style={{ color: 'var(--ink)' }}>
            Awaiting a Repairer
          </h2>
          <div className="flex gap-4 overflow-x-auto pb-2">
            {awaiting.map(p => (
              <button
                key={p.id}
                onClick={() => onNavigate('passport', p.id)}
                className="flex-shrink-0 w-52 rounded-card card-shadow overflow-hidden text-left transition-transform hover:scale-[1.02]"
                style={{ background: 'var(--surface-strong)' }}
                aria-label={`View project: ${p.title}`}
              >
                <div className="h-32 flex items-center justify-center"
                  style={{ background: 'var(--ivory-warm)' }}>
                  {getIllustration(p.photos[0], { width: 120, height: 90 })}
                </div>
                <div className="p-3">
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <DemoBadge />
                    <CategoryBadge category={p.category} />
                  </div>
                  <p className="display text-sm font-semibold leading-tight mb-1" style={{ color: 'var(--ink)' }}>
                    {p.title}
                  </p>
                  <div className="flex items-center gap-1 text-xs" style={{ color: 'var(--muted)' }}>
                    <DollarSign size={11} />
                    <span className="tabular">Up to ${p.estimatedBudget}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* In progress */}
      {inProgress.length > 0 && (
        <section>
          <h2 className="display text-xl font-semibold mb-4" style={{ color: 'var(--ink)' }}>
            Transformations in Progress
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {inProgress.map(p => (
              <button
                key={p.id}
                onClick={() => onNavigate('workbench', p.id)}
                className="rounded-card card-shadow p-4 text-left flex items-center gap-4 transition-colors hover:bg-[#ede8df]"
                style={{ background: 'var(--surface-strong)' }}
                aria-label={`View workbench: ${p.title}`}
              >
                <div className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden flex items-center justify-center"
                  style={{ background: 'var(--ivory-warm)' }}>
                  {getIllustration(p.photos[0], { width: 58, height: 50 })}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="display text-sm font-semibold leading-tight truncate" style={{ color: 'var(--ink)' }}>
                    {p.title}
                  </p>
                  <div className="flex items-center gap-1.5 mt-1">
                    <StatusBadge status={p.status} />
                    <DemoBadge />
                  </div>
                </div>
                <Clock size={14} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function ProjectCard({ project, onClick }: { project: Project; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="rounded-card card-shadow overflow-hidden text-left flex flex-col transition-transform hover:scale-[1.015] active:scale-[0.99]"
      style={{ background: 'var(--surface-strong)' }}
      aria-label={`Open project: ${project.title}`}
    >
      {/* Illustration */}
      <div className="h-40 flex items-center justify-center relative"
        style={{ background: 'var(--ivory-warm)' }}>
        {getIllustration(project.photos[0], { width: 150, height: 110 })}
        <div className="absolute top-2 left-2 flex gap-1">
          <DemoBadge />
        </div>
        <div className="absolute top-2 right-2">
          <StatusBadge status={project.status} />
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col gap-2 flex-1">
        <div className="flex items-center gap-1.5 flex-wrap">
          <CategoryBadge category={project.category} />
          <ConditionBadge condition={project.condition} />
        </div>
        <h3 className="display text-base font-semibold leading-tight text-balance" style={{ color: 'var(--ink)' }}>
          {project.title}
        </h3>
        <p className="text-sm leading-relaxed text-pretty line-clamp-2" style={{ color: 'var(--muted)' }}>
          {project.desiredOutcome}
        </p>
        <div className="flex items-center justify-between mt-auto pt-2 border-t" style={{ borderColor: 'var(--border)' }}>
          <span className="flex items-center gap-1 text-xs tabular" style={{ color: 'var(--muted)' }}>
            <DollarSign size={11} />
            Budget: ${project.estimatedBudget}
          </span>
          <span className="text-xs font-medium" style={{ color: 'var(--forest)' }}>
            View passport →
          </span>
        </div>
      </div>
    </button>
  );
}
