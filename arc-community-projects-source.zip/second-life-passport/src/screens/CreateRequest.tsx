import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ArrowLeft, Save, Trash2, AlertCircle, CheckCircle, Info } from 'lucide-react';
import type { Category, Condition, LocalDraft, Screen } from '../types';
import { getDraft, saveDraft, deleteDraft, newDraftId } from '../storage';

interface CreateRequestProps {
  draftId?: string;
  onNavigate: (s: Screen, id?: string) => void;
}

const CATEGORIES: { id: Category; label: string }[] = [
  { id: 'furniture', label: 'Furniture' },
  { id: 'electronics', label: 'Electronics' },
  { id: 'clothing', label: 'Clothing' },
  { id: 'everyday', label: 'Everyday Objects' },
];

const CONDITIONS: { id: Condition; label: string; desc: string }[] = [
  { id: 'poor', label: 'Needs Work', desc: 'Broken, non-functional, or heavily worn' },
  { id: 'fair', label: 'Fair', desc: 'Functional but visibly damaged or incomplete' },
  { id: 'good', label: 'Good', desc: 'Minor wear, mostly functional' },
];

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error';

const EMPTY_DRAFT: Omit<LocalDraft, 'id' | 'savedAt'> = {
  title: '',
  category: '',
  condition: '',
  desiredOutcome: '',
  estimatedBudget: '',
  targetDate: '',
  description: '',
};

function validate(d: typeof EMPTY_DRAFT) {
  const errors: Partial<Record<keyof typeof EMPTY_DRAFT, string>> = {};
  if (!d.title.trim()) errors.title = 'Title is required';
  if (!d.category) errors.category = 'Please select a category';
  if (!d.condition) errors.condition = 'Please select a condition';
  if (!d.desiredOutcome.trim()) errors.desiredOutcome = 'Desired outcome is required';
  if (d.estimatedBudget && isNaN(Number(d.estimatedBudget))) errors.estimatedBudget = 'Must be a number';
  if (Number(d.estimatedBudget) < 0) errors.estimatedBudget = 'Must be positive';
  return errors;
}

export default function CreateRequest({ draftId, onNavigate }: CreateRequestProps) {
  const [id] = useState(() => draftId ?? newDraftId());
  const [form, setForm] = useState<typeof EMPTY_DRAFT>(() => {
    if (draftId) {
      const existing = getDraft(draftId);
      if (existing) {
        const { id: _id, savedAt: _savedAt, ...rest } = existing;
        return rest;
      }
    }
    return EMPTY_DRAFT;
  });
  const [errors, setErrors] = useState<Partial<Record<keyof typeof EMPTY_DRAFT, string>>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof typeof EMPTY_DRAFT, boolean>>>({});
  const [saveStatus, setSaveStatus] = useState<SaveStatus>('idle');
  const [saveError, setSaveError] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const deleteModalFirstRef = useRef<HTMLButtonElement>(null);

  // Close delete modal on Escape; focus first button on open
  useEffect(() => {
    if (!showDeleteConfirm) return;
    deleteModalFirstRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowDeleteConfirm(false);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [showDeleteConfirm]);

  // Auto-save on change (debounced)
  useEffect(() => {
    if (Object.values(form).every(v => v === '')) return;
    const timer = setTimeout(() => {
      if (!form.title.trim()) return; // require at least a title to auto-save
      const draft: LocalDraft = {
        id,
        ...form,
        savedAt: new Date().toISOString(),
      };
      setSaveStatus('saving');
      const result = saveDraft(draft);
      if (result.ok) {
        setSaveStatus('saved');
        setSaveError('');
        setTimeout(() => setSaveStatus('idle'), 2500);
      } else {
        setSaveStatus('error');
        setSaveError(result.error ?? 'Save failed');
      }
    }, 900);
    return () => clearTimeout(timer);
  }, [form, id]);

  const set = useCallback(<K extends keyof typeof EMPTY_DRAFT>(key: K, value: string) => {
    setForm(prev => ({ ...prev, [key]: value }));
    setTouched(prev => ({ ...prev, [key]: true }));
    setErrors(prev => ({ ...prev, [key]: undefined }));
  }, []);

  const handleManualSave = () => {
    const errs = validate(form);
    setTouched(Object.fromEntries(Object.keys(EMPTY_DRAFT).map(k => [k, true])));
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const draft: LocalDraft = { id, ...form, savedAt: new Date().toISOString() };
    setSaveStatus('saving');
    const result = saveDraft(draft);
    if (result.ok) {
      setSaveStatus('saved');
      setSaveError('');
      setTimeout(() => setSaveStatus('idle'), 2500);
    } else {
      setSaveStatus('error');
      setSaveError(result.error ?? 'Save failed');
    }
  };

  const handleDelete = () => {
    deleteDraft(id);
    onNavigate('workshop');
  };

  const fieldClass = (key: keyof typeof EMPTY_DRAFT) =>
    `w-full px-3 py-2.5 rounded-lg border text-sm transition-colors ${
      touched[key] && errors[key] ? 'border-red-400' : 'border-[var(--border)]'
    }`;

  const fieldStyle = {
    background: 'var(--surface-strong)',
    color: 'var(--ink)',
    fontFamily: "'DM Sans',sans-serif",
    outline: 'none',
  } as React.CSSProperties;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      {/* Back */}
      <button
        onClick={() => onNavigate('workshop')}
        className="inline-flex items-center gap-1.5 text-sm mb-6 hover:opacity-70 transition-opacity"
        style={{ color: 'var(--forest)' }}
      >
        <ArrowLeft size={14} />
        My Workshop
      </button>

      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="display text-2xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}>
          List an Object
        </h1>
        {/* Save status */}
        <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--muted)' }}>
          {saveStatus === 'saving' && <span>Saving...</span>}
          {saveStatus === 'saved' && (
            <span className="flex items-center gap-1" style={{ color: 'var(--success)' }}>
              <CheckCircle size={12} /> Saved in this browser
            </span>
          )}
          {saveStatus === 'error' && (
            <span className="flex items-center gap-1" style={{ color: 'var(--danger)' }}>
              <AlertCircle size={12} /> {saveError}
            </span>
          )}
        </div>
      </div>

      {/* Storage notice */}
      <div className="flex items-start gap-2 p-3 rounded-lg mb-6 text-sm"
        style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
        <Info size={14} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--brass)' }} />
        <p style={{ color: 'var(--muted)' }}>
          Drafts are saved only in this browser. They are not published or visible to others. Clearing your browser data will remove them.
        </p>
      </div>

      <form
        onSubmit={e => { e.preventDefault(); handleManualSave(); }}
        className="flex flex-col gap-5"
        noValidate
        aria-label="Repair request form"
      >
        {/* Title */}
        <div>
          <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--ink)' }}
            htmlFor="req-title">
            Object title <span style={{ color: 'var(--danger)' }} aria-label="required">*</span>
          </label>
          <input
            id="req-title"
            type="text"
            value={form.title}
            onChange={e => set('title', e.target.value)}
            placeholder="e.g. 1960s Zenith portable radio"
            className={fieldClass('title')}
            style={fieldStyle}
            aria-describedby={errors.title ? 'err-title' : undefined}
            aria-invalid={!!(touched.title && errors.title)}
          />
          {touched.title && errors.title && (
            <p id="err-title" className="text-xs mt-1" style={{ color: 'var(--danger)' }}>{errors.title}</p>
          )}
        </div>

        {/* Category */}
        <fieldset>
          <legend className="text-sm font-semibold mb-2" style={{ color: 'var(--ink)' }}>
            Category <span style={{ color: 'var(--danger)' }} aria-label="required">*</span>
          </legend>
          <div className="grid grid-cols-2 gap-2">
            {CATEGORIES.map(cat => (
              <label
                key={cat.id}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg border cursor-pointer transition-colors"
                style={{
                  background: form.category === cat.id ? 'var(--forest-light)' : 'var(--surface-strong)',
                  borderColor: form.category === cat.id ? 'var(--forest)' : 'var(--border)',
                  color: form.category === cat.id ? 'var(--forest)' : 'var(--ink-2)',
                }}
              >
                <input
                  type="radio"
                  name="category"
                  value={cat.id}
                  checked={form.category === cat.id}
                  onChange={() => set('category', cat.id)}
                  className="sr-only"
                />
                <span className="text-sm font-medium">{cat.label}</span>
              </label>
            ))}
          </div>
          {touched.category && errors.category && (
            <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>{errors.category}</p>
          )}
        </fieldset>

        {/* Condition */}
        <fieldset>
          <legend className="text-sm font-semibold mb-2" style={{ color: 'var(--ink)' }}>
            Condition <span style={{ color: 'var(--danger)' }} aria-label="required">*</span>
          </legend>
          <div className="flex flex-col gap-2">
            {CONDITIONS.map(cond => (
              <label
                key={cond.id}
                className="flex items-start gap-3 px-3 py-2.5 rounded-lg border cursor-pointer transition-colors"
                style={{
                  background: form.condition === cond.id ? 'var(--forest-light)' : 'var(--surface-strong)',
                  borderColor: form.condition === cond.id ? 'var(--forest)' : 'var(--border)',
                }}
              >
                <input
                  type="radio"
                  name="condition"
                  value={cond.id}
                  checked={form.condition === cond.id}
                  onChange={() => set('condition', cond.id)}
                  className="mt-0.5"
                  style={{ accentColor: 'var(--forest)' }}
                />
                <div>
                  <p className="text-sm font-semibold" style={{ color: form.condition === cond.id ? 'var(--forest)' : 'var(--ink)' }}>
                    {cond.label}
                  </p>
                  <p className="text-xs" style={{ color: 'var(--muted)' }}>{cond.desc}</p>
                </div>
              </label>
            ))}
          </div>
          {touched.condition && errors.condition && (
            <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>{errors.condition}</p>
          )}
        </fieldset>

        {/* Desired outcome */}
        <div>
          <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--ink)' }}
            htmlFor="req-outcome">
            Desired outcome <span style={{ color: 'var(--danger)' }} aria-label="required">*</span>
          </label>
          <textarea
            id="req-outcome"
            value={form.desiredOutcome}
            onChange={e => set('desiredOutcome', e.target.value)}
            placeholder="Describe what you'd like done — restore original function, transform into something new, etc."
            rows={3}
            className={fieldClass('desiredOutcome')}
            style={{ ...fieldStyle, resize: 'vertical' }}
            aria-describedby={errors.desiredOutcome ? 'err-outcome' : undefined}
            aria-invalid={!!(touched.desiredOutcome && errors.desiredOutcome)}
          />
          {touched.desiredOutcome && errors.desiredOutcome && (
            <p id="err-outcome" className="text-xs mt-1" style={{ color: 'var(--danger)' }}>{errors.desiredOutcome}</p>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--ink)' }}
            htmlFor="req-desc">
            Object story <span className="text-xs font-normal" style={{ color: 'var(--subtle)' }}>(optional)</span>
          </label>
          <textarea
            id="req-desc"
            value={form.description}
            onChange={e => set('description', e.target.value)}
            placeholder="Where did it come from? Why does it matter? Any sentimental value?"
            rows={3}
            className={fieldClass('description')}
            style={{ ...fieldStyle, resize: 'vertical' }}
          />
        </div>

        {/* Budget + Date row */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--ink)' }}
              htmlFor="req-budget">
              Budget (USD) <span className="text-xs font-normal" style={{ color: 'var(--subtle)' }}>(optional)</span>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: 'var(--subtle)' }}>$</span>
              <input
                id="req-budget"
                type="number"
                min="0"
                step="1"
                value={form.estimatedBudget}
                onChange={e => set('estimatedBudget', e.target.value)}
                placeholder="100"
                className={`${fieldClass('estimatedBudget')} pl-7`}
                style={{ ...fieldStyle }}
                aria-describedby={errors.estimatedBudget ? 'err-budget' : undefined}
                aria-invalid={!!(touched.estimatedBudget && errors.estimatedBudget)}
              />
            </div>
            {touched.estimatedBudget && errors.estimatedBudget && (
              <p id="err-budget" className="text-xs mt-1" style={{ color: 'var(--danger)' }}>{errors.estimatedBudget}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--ink)' }}
              htmlFor="req-date">
              Target date <span className="text-xs font-normal" style={{ color: 'var(--subtle)' }}>(optional)</span>
            </label>
            <input
              id="req-date"
              type="date"
              value={form.targetDate}
              onChange={e => set('targetDate', e.target.value)}
              className={fieldClass('targetDate')}
              style={fieldStyle}
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 pt-2 flex-wrap">
          <button
            type="submit"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-pill font-semibold text-sm transition-opacity hover:opacity-90"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            <Save size={14} />
            Save Draft
          </button>

          <button
            type="button"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-pill font-semibold text-sm border transition-colors hover:bg-[#ede8df]"
            style={{ borderColor: 'var(--border-mid)', color: 'var(--muted)', background: 'transparent' }}
            onClick={() => onNavigate('workshop')}
          >
            Cancel
          </button>

          <button
            type="button"
            className="ml-auto inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-colors hover:bg-[#f8ede9]"
            style={{ borderColor: 'rgba(184,76,44,0.3)', color: 'var(--terra)', background: 'transparent' }}
            onClick={() => setShowDeleteConfirm(true)}
            aria-label="Delete this draft"
          >
            <Trash2 size={12} />
            Delete draft
          </button>
        </div>

        {/* Submit notice */}
        <div className="p-3 rounded-lg text-sm" style={{ background: 'var(--ivory-warm)', border: '1px solid var(--border)' }}>
          <p style={{ color: 'var(--muted)' }}>
            <strong style={{ color: 'var(--ink)' }}>Contract integration pending.</strong>{' '}
            Publishing and receiving proposals requires a smart contract, which is not yet deployed.
            You can save your draft here and it will be waiting when the integration is ready.
          </p>
        </div>
      </form>

      {/* Delete confirm */}
      {showDeleteConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(26,20,16,0.5)' }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="create-delete-heading"
        >
          <div className="rounded-card card-shadow p-6 max-w-sm w-full"
            style={{ background: 'var(--surface-strong)' }}>
            <h2 id="create-delete-heading" className="display text-base font-semibold mb-2" style={{ color: 'var(--ink)' }}>
              Delete this draft?
            </h2>
            <p className="text-sm mb-4" style={{ color: 'var(--muted)' }}>
              This will permanently remove the draft from your browser. This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                ref={deleteModalFirstRef}
                onClick={handleDelete}
                className="px-4 py-2 rounded-pill text-sm font-semibold"
                style={{ background: 'var(--terra)', color: '#f7f3ec' }}
              >
                Yes, delete
              </button>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 rounded-pill text-sm font-semibold border"
                style={{ borderColor: 'var(--border-mid)', color: 'var(--ink-2)', background: 'transparent' }}
              >
                Keep it
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
