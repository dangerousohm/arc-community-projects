import React from 'react';
import type { Category, Condition, ProjectStatus } from '../types';

export function CategoryBadge({ category }: { category: Category }) {
  const map: Record<Category, { label: string; bg: string; color: string }> = {
    furniture:   { label: 'Furniture',   bg: '#fdf3e3', color: '#8a5c18' },
    electronics: { label: 'Electronics', bg: '#edf5f0', color: '#2d5a3d' },
    clothing:    { label: 'Clothing',    bg: '#f8ede9', color: '#7a2c14' },
    everyday:    { label: 'Everyday',    bg: '#ede8df', color: '#5a4a38' },
  };
  const { label, bg, color } = map[category];
  return (
    <span className="chip" style={{ background: bg, color }}>
      {label}
    </span>
  );
}

export function ConditionBadge({ condition }: { condition: Condition }) {
  const map: Record<Condition, { label: string; bg: string; color: string }> = {
    poor: { label: 'Needs work', bg: '#f8ede9', color: '#7a2c14' },
    fair: { label: 'Fair',       bg: '#fdf3e3', color: '#8a5c18' },
    good: { label: 'Good',       bg: '#edf5f0', color: '#2d5a3d' },
  };
  const { label, bg, color } = map[condition];
  return (
    <span className="chip" style={{ background: bg, color }}>
      {label}
    </span>
  );
}

export function StatusBadge({ status }: { status: ProjectStatus }) {
  const map: Record<ProjectStatus, { label: string; bg: string; color: string }> = {
    draft:                { label: 'Draft',              bg: '#ede8df', color: '#5a4a38' },
    awaiting_proposals:   { label: 'Open for Proposals', bg: '#fdf3e3', color: '#8a5c18' },
    proposal_accepted:    { label: 'Proposal Accepted',  bg: '#edf5f0', color: '#2d5a3d' },
    funded:               { label: 'Funded',             bg: '#edf5f0', color: '#1a8047' },
    in_progress:          { label: 'In Progress',        bg: '#edf5f0', color: '#2d5a3d' },
    submitted_for_review: { label: 'Under Review',       bg: '#fdf3e3', color: '#8a5c18' },
    revision_requested:   { label: 'Revision Requested', bg: '#f8ede9', color: '#7a2c14' },
    accepted:             { label: 'Accepted',           bg: '#edf5f0', color: '#1a8047' },
    completed:            { label: 'Completed',          bg: '#edf5f0', color: '#1a8047' },
    cancelled:            { label: 'Cancelled',          bg: '#ede8df', color: '#7a6e62' },
    disputed:             { label: 'Disputed',           bg: '#f8ede9', color: '#b84c2c' },
  };
  const { label, bg, color } = map[status] ?? { label: status, bg: '#ede8df', color: '#5a4a38' };
  return (
    <span className="chip" style={{ background: bg, color }}>
      {label}
    </span>
  );
}

export function DemoBadge() {
  return (
    <span
      className="chip"
      style={{ background: 'var(--brass-light)', color: 'var(--brass)', border: '1px solid rgba(201,148,58,0.3)' }}
      title="This is sample demo content"
    >
      Demo
    </span>
  );
}

export function SimulationBadge({ label = 'Payment simulation' }: { label?: string }) {
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium"
      style={{ background: 'var(--terra-light)', color: 'var(--terra)', border: '1px dashed rgba(184,76,44,0.35)' }}
    >
      {label}
    </span>
  );
}
