import React, { useState, useEffect, useRef } from 'react';
import { Wrench, Menu, X, ChevronRight } from 'lucide-react';
import type { Screen } from '../types';

interface NavbarProps {
  screen: Screen;
  onNavigate: (s: Screen) => void;
}

const NAV_ITEMS: { id: Screen; label: string }[] = [
  { id: 'discovery', label: 'Discover' },
  { id: 'workshop', label: 'My Workshop' },
  { id: 'create', label: 'List an Object' },
];

export default function Navbar({ screen, onNavigate }: NavbarProps) {
  const [open, setOpen] = useState(false);
  const burgerRef = useRef<HTMLButtonElement>(null);

  // Close mobile menu on Escape
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        burgerRef.current?.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <header
      className="sticky top-0 z-50"
      style={{
        background: 'rgba(247,243,236,0.92)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(26,20,16,0.1)',
      }}
    >
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        {/* Logo */}
        <button
          onClick={() => onNavigate('discovery')}
          className="flex items-center gap-2 group"
          aria-label="Second Life Passport home"
        >
          <div
            className="w-8 h-8 rounded-workshop flex items-center justify-center"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          >
            <Wrench size={15} strokeWidth={2.5} />
          </div>
          <span
            className="display font-semibold text-base hidden sm:block"
            style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
          >
            Second Life Passport
          </span>
        </button>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1" aria-label="Main navigation">
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors"
              style={{
                color: screen === item.id ? 'var(--forest)' : 'var(--ink-2)',
                background: screen === item.id ? 'var(--forest-light)' : 'transparent',
                fontFamily: "'DM Sans', sans-serif",
              }}
              aria-current={screen === item.id ? 'page' : undefined}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Desktop CTA */}
        <button
          className="hidden md:flex items-center gap-1.5 px-4 py-1.5 rounded-pill text-sm font-semibold transition-opacity hover:opacity-80"
          style={{ background: 'var(--forest)', color: '#f7f3ec' }}
          onClick={() => onNavigate('create')}
          aria-label="List an object for repair"
        >
          <Wrench size={13} />
          List an Object
        </button>

        {/* Mobile burger */}
        <button
          ref={burgerRef}
          className="md:hidden p-2 rounded-lg"
          style={{ color: 'var(--ink)' }}
          onClick={() => setOpen(o => !o)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          aria-controls="mobile-nav"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div
          id="mobile-nav"
          className="md:hidden border-t px-4 py-3 flex flex-col gap-1"
          style={{ borderColor: 'var(--border)', background: 'var(--ivory)' }}
          role="navigation"
          aria-label="Mobile navigation"
        >
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); setOpen(false); }}
              className="flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium text-left"
              style={{
                color: screen === item.id ? 'var(--forest)' : 'var(--ink)',
                background: screen === item.id ? 'var(--forest-light)' : 'transparent',
              }}
              aria-current={screen === item.id ? 'page' : undefined}
            >
              {item.label}
              <ChevronRight size={14} style={{ color: 'var(--subtle)' }} />
            </button>
          ))}
          <button
            className="mt-1 flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-semibold"
            style={{ background: 'var(--forest)', color: '#f7f3ec' }}
            onClick={() => { onNavigate('create'); setOpen(false); }}
          >
            <Wrench size={13} />
            List an Object
          </button>
        </div>
      )}
    </header>
  );
}
