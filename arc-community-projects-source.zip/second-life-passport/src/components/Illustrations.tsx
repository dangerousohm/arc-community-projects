// ── Second Life Passport — SVG Illustrations ─────────────────────
// Original inline SVGs. All sizes are controlled by width/height props.

import React from 'react';

interface IllustrationProps {
  className?: string;
  width?: number;
  height?: number;
}

export function RadioIllustration({ className, width = 200, height = 140 }: IllustrationProps) {
  return (
    <svg viewBox="0 0 200 140" width={width} height={height} className={className} aria-label="Vintage radio illustration" role="img">
      {/* Cabinet */}
      <rect x="20" y="30" width="160" height="95" rx="8" fill="#c9943a" stroke="#a07828" strokeWidth="1.5"/>
      <rect x="28" y="38" width="144" height="79" rx="5" fill="#b07020"/>
      {/* Speaker grille */}
      <rect x="32" y="44" width="80" height="65" rx="4" fill="#8a5c18"/>
      {/* Grille lines */}
      {[50,58,66,74,82,90,98].map(y => (
        <line key={y} x1="36" y1={y} x2="108" y2={y} stroke="#c9943a" strokeWidth="1" opacity="0.5"/>
      ))}
      {/* Dial face */}
      <rect x="120" y="44" width="44" height="28" rx="3" fill="#f7f3ec"/>
      <rect x="122" y="46" width="40" height="24" rx="2" fill="#ede8df"/>
      <text x="142" y="62" textAnchor="middle" fontSize="7" fill="#7a6e62" fontFamily="'Space Grotesk',sans-serif">AM • FM</text>
      {/* Knobs */}
      <circle cx="130" cy="87" r="9" fill="#3b3229" stroke="#1a1410" strokeWidth="1"/>
      <circle cx="130" cy="87" r="5" fill="#2d2018"/>
      <line x1="130" y1="82" x2="130" y2="86" stroke="#c9943a" strokeWidth="1.5"/>
      <circle cx="152" cy="87" r="9" fill="#3b3229" stroke="#1a1410" strokeWidth="1"/>
      <circle cx="152" cy="87" r="5" fill="#2d2018"/>
      <line x1="152" y1="82" x2="152" y2="86" stroke="#c9943a" strokeWidth="1.5"/>
      {/* Feet */}
      <rect x="35" y="122" width="12" height="6" rx="2" fill="#8a5c18"/>
      <rect x="153" y="122" width="12" height="6" rx="2" fill="#8a5c18"/>
      {/* Antenna */}
      <line x1="170" y1="30" x2="180" y2="5" stroke="#3b3229" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

export function TableIllustration({ className, width = 200, height = 140 }: IllustrationProps) {
  return (
    <svg viewBox="0 0 200 140" width={width} height={height} className={className} aria-label="Dining table illustration" role="img">
      {/* Tabletop — warped */}
      <path d="M15 45 Q60 42 100 48 Q140 54 185 45 L185 62 Q140 71 100 65 Q60 59 15 62 Z" fill="#c9943a" stroke="#a07828" strokeWidth="1"/>
      <path d="M15 45 Q60 42 100 48 Q140 54 185 45 L185 55 Q140 62 100 56 Q60 50 15 53 Z" fill="#b07020"/>
      {/* Grain lines */}
      {[48,52,56,60].map((y, i) => (
        <path key={i} d={`M20 ${y+i} Q100 ${y+i+3} 180 ${y+i-2}`} stroke="#c9943a" strokeWidth="0.5" opacity="0.4" fill="none"/>
      ))}
      {/* Legs */}
      <rect x="30" y="62" width="10" height="68" rx="3" fill="#8a5c18"/>
      <rect x="160" y="62" width="10" height="68" rx="3" fill="#8a5c18"/>
      {/* Plant pot on top */}
      <ellipse cx="100" cy="40" rx="16" ry="6" fill="#b84c2c"/>
      <rect x="84" y="34" width="32" height="12" rx="3" fill="#b84c2c"/>
      <ellipse cx="100" cy="34" rx="16" ry="5" fill="#c55a36"/>
      <path d="M100 30 Q90 22 80 18 M100 30 Q110 22 120 18 M100 30 Q95 20 100 10" stroke="#2d5a3d" strokeWidth="2" fill="none" strokeLinecap="round"/>
    </svg>
  );
}

export function BackpackIllustration({ className, width = 200, height = 140 }: IllustrationProps) {
  return (
    <svg viewBox="0 0 200 140" width={width} height={height} className={className} aria-label="Hiking backpack illustration" role="img">
      {/* Main body */}
      <rect x="50" y="20" width="100" height="105" rx="14" fill="#3d7a52"/>
      {/* Torn seam */}
      <path d="M120 20 L120 65" stroke="#f7f3ec" strokeWidth="2" strokeDasharray="3 2" opacity="0.6"/>
      <path d="M120 22 Q125 35 118 50 Q122 58 120 65" stroke="#b84c2c" strokeWidth="2" fill="none"/>
      {/* Front pocket */}
      <rect x="60" y="70" width="80" height="40" rx="8" fill="#2d5a3d"/>
      {/* Pocket zipper */}
      <line x1="65" y1="70" x2="135" y2="70" stroke="#c9943a" strokeWidth="2"/>
      <circle cx="100" cy="70" r="3" fill="#c9943a"/>
      {/* Shoulder straps */}
      <path d="M65 22 Q45 40 48 90" stroke="#2d5a3d" strokeWidth="12" strokeLinecap="round" fill="none"/>
      <path d="M135 22 Q155 40 152 90" stroke="#2d5a3d" strokeWidth="12" strokeLinecap="round" fill="none"/>
      {/* Buckle — broken */}
      <rect x="88" y="50" width="24" height="12" rx="3" fill="#a07828" stroke="#c9943a" strokeWidth="1.5"/>
      <line x1="98" y1="50" x2="103" y2="62" stroke="#b84c2c" strokeWidth="2"/>
      {/* Top handle */}
      <path d="M88 20 Q100 10 112 20" stroke="#2d5a3d" strokeWidth="8" fill="none" strokeLinecap="round"/>
    </svg>
  );
}

export function LampIllustration({ className, width = 200, height = 140 }: IllustrationProps) {
  return (
    <svg viewBox="0 0 200 140" width={width} height={height} className={className} aria-label="Desk lamp illustration" role="img">
      {/* Base */}
      <ellipse cx="100" cy="130" rx="40" ry="8" fill="#b07020"/>
      <rect x="85" y="110" width="30" height="22" rx="4" fill="#c9943a"/>
      {/* Arm lower */}
      <line x1="100" y1="110" x2="100" y2="80" stroke="#c9943a" strokeWidth="6" strokeLinecap="round"/>
      {/* Elbow joint */}
      <circle cx="100" cy="78" r="6" fill="#a07828"/>
      {/* Arm upper — angled */}
      <line x1="100" y1="78" x2="140" y2="50" stroke="#c9943a" strokeWidth="6" strokeLinecap="round"/>
      {/* Head joint */}
      <circle cx="140" cy="50" r="6" fill="#a07828"/>
      {/* Shade */}
      <path d="M118 50 Q140 30 162 50 L155 72 Q140 62 125 72 Z" fill="#2d5a3d"/>
      <path d="M118 50 Q140 30 162 50" stroke="#1a3d28" strokeWidth="1.5" fill="none"/>
      {/* Light beam */}
      <path d="M125 72 Q140 90 155 72" stroke="#fdf3e3" strokeWidth="1" fill="rgba(253,243,227,0.3)"/>
      {/* Frayed wire detail */}
      <path d="M100 110 Q97 95 100 80" stroke="#3b3229" strokeWidth="2" fill="none" strokeDasharray="3 2"/>
      <path d="M102 95 Q108 93 110 96" stroke="#b84c2c" strokeWidth="1.5" fill="none"/>
      {/* Switch */}
      <circle cx="95" cy="100" r="4" fill="#3b3229" stroke="#c9943a" strokeWidth="1"/>
    </svg>
  );
}

export function VaseIllustration({ className, width = 200, height = 140 }: IllustrationProps) {
  return (
    <svg viewBox="0 0 200 140" width={width} height={height} className={className} aria-label="Ceramic vase illustration" role="img">
      {/* Vase body */}
      <path d="M75 125 Q60 100 65 70 Q68 45 100 35 Q132 45 135 70 Q140 100 125 125 Z" fill="#b84c2c"/>
      {/* Glaze highlight */}
      <path d="M80 120 Q72 95 76 68 Q79 50 100 42" stroke="rgba(255,255,255,0.25)" strokeWidth="6" fill="none" strokeLinecap="round"/>
      {/* Kintsugi cracks — gold */}
      <path d="M100 70 Q90 85 82 100" stroke="#c9943a" strokeWidth="2.5" fill="none"/>
      <path d="M100 70 Q112 90 108 112" stroke="#c9943a" strokeWidth="2" fill="none"/>
      <path d="M100 70 Q100 55 105 45" stroke="#c9943a" strokeWidth="1.5" fill="none" opacity="0.7"/>
      {/* Crack glow */}
      <path d="M100 70 Q90 85 82 100" stroke="#fdf3e3" strokeWidth="1" fill="none" opacity="0.6"/>
      {/* Neck */}
      <ellipse cx="100" cy="35" rx="18" ry="7" fill="#c55a36"/>
      <ellipse cx="100" cy="35" rx="14" ry="5" fill="#1a1410" opacity="0.3"/>
      {/* Base */}
      <ellipse cx="100" cy="125" rx="26" ry="5" fill="#8a2c14"/>
    </svg>
  );
}

export function WorkbenchIllustration({ className, width = 320, height = 180 }: IllustrationProps) {
  return (
    <svg viewBox="0 0 320 180" width={width} height={height} className={className} aria-label="Workshop workbench illustration" role="img">
      {/* Workbench surface */}
      <rect x="10" y="110" width="300" height="15" rx="3" fill="#b07020"/>
      <rect x="10" y="113" width="300" height="8" rx="2" fill="#a07020" opacity="0.4"/>
      {/* Bench legs */}
      <rect x="20" y="125" width="12" height="50" rx="2" fill="#8a5c18"/>
      <rect x="288" y="125" width="12" height="50" rx="2" fill="#8a5c18"/>
      {/* Tool shadow */}
      <ellipse cx="100" cy="112" rx="30" ry="4" fill="rgba(26,20,16,0.1)"/>
      <ellipse cx="220" cy="112" rx="25" ry="4" fill="rgba(26,20,16,0.1)"/>
      {/* Mini radio on bench */}
      <rect x="72" y="82" width="56" height="30" rx="4" fill="#c9943a"/>
      <rect x="78" y="88" width="28" height="18" rx="2" fill="#8a5c18"/>
      <circle cx="116" cy="96" r="6" fill="#3b3229"/>
      {/* Mini lamp on bench */}
      <line x1="220" y1="110" x2="220" y2="88" stroke="#c9943a" strokeWidth="4" strokeLinecap="round"/>
      <line x1="220" y1="88" x2="240" y2="76" stroke="#c9943a" strokeWidth="4" strokeLinecap="round"/>
      <path d="M226 76 Q240 66 254 76 L250 88 Q240 82 230 88 Z" fill="#2d5a3d"/>
      {/* Wall shadow background */}
      <rect x="0" y="0" width="320" height="110" fill="#ede8df" opacity="0.5" rx="8"/>
      {/* Wall pegboard dots */}
      {[30,50,70,90].map(y =>
        [30,60,90,120,150,180,210,240,270,300].map(x => (
          <circle key={`${x}-${y}`} cx={x} cy={y} r="1.5" fill="rgba(26,20,16,0.12)"/>
        ))
      )}
      {/* Hanging tools */}
      <path d="M60 10 L60 50 Q60 56 66 56 L72 56 Q78 56 78 50 L78 10" stroke="#7a6e62" strokeWidth="2" fill="none"/>
      <rect x="56" y="50" width="26" height="8" rx="2" fill="#7a6e62"/>
      <path d="M150 8 L158 8 L162 40 L146 40 Z" fill="#7a6e62"/>
      <rect x="148" y="6" width="12" height="4" rx="1" fill="#7a6e62"/>
      {/* Arrow — transformation */}
      <path d="M108 96 L172 96" stroke="#2d5a3d" strokeWidth="2" strokeDasharray="4 2"/>
      <polygon points="172,92 180,96 172,100" fill="#2d5a3d"/>
    </svg>
  );
}

export function getIllustration(id: string, props?: IllustrationProps) {
  switch (id) {
    case 'radio': return <RadioIllustration {...props} />;
    case 'table': return <TableIllustration {...props} />;
    case 'backpack': return <BackpackIllustration {...props} />;
    case 'lamp': return <LampIllustration {...props} />;
    case 'vase': return <VaseIllustration {...props} />;
    default: return <WorkbenchIllustration {...props} />;
  }
}
