// ── Second Life Passport — Core Types ─────────────────────────────

export type Category = 'furniture' | 'electronics' | 'clothing' | 'everyday';

export type Condition = 'poor' | 'fair' | 'good';

export type ProjectStatus =
  | 'draft'
  | 'awaiting_proposals'
  | 'proposal_accepted'
  | 'funded'
  | 'in_progress'
  | 'submitted_for_review'
  | 'revision_requested'
  | 'accepted'
  | 'completed'
  | 'cancelled'
  | 'disputed';

export type RepairApproach = 'restore' | 'upcycle';

export interface RepairChapter {
  id: string;
  date: string;
  title: string;
  description: string;
  by: string;
  photos?: string[]; // placeholder SVG ids
}

export interface Milestone {
  id: string;
  title: string;
  amount: number; // USDC cents (6 decimal units * 100 = dollar * 100)
  dueDate: string;
  deliverables: string;
  status: 'pending' | 'funded' | 'submitted' | 'approved' | 'released' | 'disputed';
  evidence?: string;
}

export interface Proposal {
  id: string;
  repairerName: string;
  repairerBio: string;
  approach: RepairApproach;
  approachDetail: string;
  totalPrice: number; // USD display
  estimatedDays: number;
  deliverables: string[];
  milestones: Milestone[];
  isDemo: true;
}

export interface Project {
  id: string;
  title: string;
  category: Category;
  condition: Condition;
  desiredOutcome: string;
  estimatedBudget: number; // USD display
  targetDate: string;
  description: string;
  status: ProjectStatus;
  isDemo: boolean;
  isOwner: boolean; // true = current user is owner; false = current user is repairer (demo)
  photos: string[]; // SVG illustration ids
  chapters: RepairChapter[];
  proposals: Proposal[];
  acceptedProposalId?: string;
  activeProjectId?: string;
  createdAt: string;
  completedAt?: string;
  // Passport summary
  materialsReused?: string[];
  workPerformed?: string;
}

// Draft — saved locally only
export interface LocalDraft {
  id: string;
  title: string;
  category: Category | '';
  condition: Condition | '';
  desiredOutcome: string;
  estimatedBudget: string;
  targetDate: string;
  description: string;
  savedAt: string;
}

export type Screen =
  | 'discovery'
  | 'passport'
  | 'create'
  | 'proposals'
  | 'workbench'
  | 'workshop'
  | 'completion';
