// ── Second Life Passport — Local Draft Storage ────────────────────
// Drafts are saved only in the current browser's localStorage.
// Clearing browser data removes them. They are never visible to other users.

import type { LocalDraft } from './types';

const STORAGE_KEY = 'slp_drafts_v1';

function readAll(): LocalDraft[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // Validate each entry has at minimum an id and title
    return parsed.filter(
      (d): d is LocalDraft =>
        d !== null &&
        typeof d === 'object' &&
        typeof (d as Record<string, unknown>).id === 'string' &&
        typeof (d as Record<string, unknown>).title === 'string'
    );
  } catch {
    return [];
  }
}

function writeAll(drafts: LocalDraft[]): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(drafts));
    return true;
  } catch {
    return false;
  }
}

export function getDrafts(): LocalDraft[] {
  return readAll();
}

export function saveDraft(draft: LocalDraft): { ok: boolean; error?: string } {
  const drafts = readAll();
  const idx = drafts.findIndex(d => d.id === draft.id);
  if (idx >= 0) {
    drafts[idx] = draft;
  } else {
    drafts.unshift(draft);
  }
  const ok = writeAll(drafts);
  return ok ? { ok: true } : { ok: false, error: 'Browser storage unavailable. Draft not saved.' };
}

export function deleteDraft(id: string): boolean {
  const drafts = readAll().filter(d => d.id !== id);
  return writeAll(drafts);
}

export function getDraft(id: string): LocalDraft | undefined {
  return readAll().find(d => d.id === id);
}

export function newDraftId(): string {
  return `draft-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}
