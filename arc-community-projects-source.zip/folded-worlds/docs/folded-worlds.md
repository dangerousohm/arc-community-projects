# Folded Worlds — Technical Documentation

## Overview

Folded Worlds is a pass-and-play collaborative story relay app. Contributors take turns writing panels; each writer sees only the previous panel's handoff sentence, then seals their panel. Once all panels are sealed the complete story unfolds with a printable zine layout and contributor credits.

**No backend, no accounts, no blockchain integration.** All state lives in browser localStorage.

---

## Architecture

```
src/
  types.ts           Relay, Panel, View interfaces + SCHEMA_VERSION
  storage.ts         localStorage load/save with validation and recovery
  split.ts           Integer micro-USDC split calculator
  seedData.ts        Three fictional demo relays
  useRelays.ts       React state hook (createRelay, sealPanel, deleteRelay, resetDemos)
  App.tsx            Routing root: library | desk | reveal
  components/
    Library.tsx      View 1: relay cards, create form, demo reset
    WritingDesk.tsx  View 2: writing UI, preview, privacy cover
    RevealCredits.tsx  View 3: unfold animation, credits, split calc, JSON export
  tests/
    split.test.ts    24 tests — parsing, formatting, arithmetic
    storage.test.ts  10 tests — malformed JSON, validation, round-trip
    relayState.test.ts  17 tests — state machine, wrong-contributor, form validation
```

---

## Data model

```typescript
interface Panel {
  index: number
  contributor: string
  body: string        // 30-600 chars
  handoff: string     // 5-160 chars — shown to the next writer only
  sealed: boolean
}

interface Relay {
  id: string
  title: string
  prompt: string
  contributors: string[]
  shares: number[]    // equal, one per contributor
  panels: Panel[]
  status: 'demo' | 'draft' | 'active' | 'complete'
  createdAt: string   // ISO-8601
  schemaVersion: number
}
```

Storage key: `foldedWorlds_relays_v1`. On load, malformed records are filtered and a warning is logged; valid records are preserved. Storage quota or write errors surface as a sonner toast.

---

## USDC split calculator

All arithmetic uses `bigint` in integer micro-USDC (1 USDC = 1,000,000 micro-USDC). Division is integer floor; the remainder (0 to n-1 micro-USDC) is distributed deterministically to the first `remainder` contributors by index order, so the sum always equals the input exactly.

**This is a simulation.** No wallet connection, no onchain transaction, no Circle API call is made.

---

## Running tests

```bash
bun test src/tests/
```

51 tests across 3 files, covering:
- `parseUsdcInput` / `formatMicroUsdc` edge cases
- `calculateSplit` validation and arithmetic (0, 1 micro, uneven, large)
- `loadRelays` / `saveRelays` with malformed JSON
- Relay state transitions (no early reveal, no double-seal)
- Form validation (duplicate names, limits)

---

## Planned features (NOT YET BUILT)

The current prototype is a local, single-browser demo. The following features are **planned** but require significant additional work outside of Arc Studio's current scope:

### Online invitations and real authorisation
- Each relay would have a unique shareable URL.
- Contributors would authenticate (e.g. social login or wallet signature) before seeing or submitting a panel.
- Invite-only relay with verified contributor identity.

### Shared database
- Relay state would be stored server-side (e.g. Postgres via Circle developer-controlled wallets or a conventional API).
- Real-time or polling updates so contributors can participate from different devices and browsers.

### Arc Testnet USDC split settlement (Planned)
- The split calculator would become a real transaction.
- Each contributor's wallet address would be collected.
- A multisig or smart contract would escrow the total USDC amount.
- Each contributor would receive their share via an onchain USDC transfer on Arc Testnet.
- **This requires:** wallet connection for every contributor, explicit transaction consent, gas fees in USDC (Arc Testnet), and integration with Circle's Smart Contract Platform or a custom Solidity contract.
- **This does NOT exist in the current build.** The current split calculator is labelled "Simulation only" and performs no wallet requests.

---

## Security and privacy notes

- Local storage is **not encrypted**. Contributors who share a device can read each panel body via browser devtools or localStorage inspection.
- The privacy cover screen between contributors is a UI affordance, not a cryptographic boundary. This is stated clearly in the app.
- No HTML injection: all contributor and story text is rendered as plain text nodes via React's default escaping. No `dangerouslySetInnerHTML` is used.
- Attribution in the export JSON does not prove copyright ownership. Contributors should only share content they have permission to use.
- No legal licence agreements are generated or implied.
