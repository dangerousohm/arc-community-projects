// Folded Worlds — localStorage layer with validation + recovery
import type { Relay } from './types'
import { SCHEMA_VERSION } from './types'

const KEY = 'foldedWorlds_relays_v1'

function isValidPanel(p: unknown): boolean {
  if (!p || typeof p !== 'object') return false
  const panel = p as Record<string, unknown>
  return (
    typeof panel.index === 'number' &&
    typeof panel.contributor === 'string' &&
    typeof panel.body === 'string' &&
    typeof panel.handoff === 'string' &&
    typeof panel.sealed === 'boolean'
  )
}

function isValidRelay(r: unknown): boolean {
  if (!r || typeof r !== 'object') return false
  const relay = r as Record<string, unknown>
  if (
    typeof relay.id !== 'string' ||
    typeof relay.title !== 'string' ||
    typeof relay.prompt !== 'string' ||
    !Array.isArray(relay.contributors) ||
    !Array.isArray(relay.shares) ||
    !Array.isArray(relay.panels) ||
    typeof relay.status !== 'string' ||
    typeof relay.createdAt !== 'string' ||
    typeof relay.schemaVersion !== 'number'
  )
    return false
  if (!relay.panels.every(isValidPanel)) return false
  if (!relay.contributors.every((c: unknown) => typeof c === 'string')) return false
  if (!relay.shares.every((s: unknown) => typeof s === 'number')) return false
  return true
}

export function loadRelays(): Relay[] {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return []
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    // Filter out malformed; log but don't crash
    const valid = parsed.filter((item) => {
      if (isValidRelay(item)) return true
      console.warn('[FoldedWorlds] Skipped malformed relay record', item)
      return false
    })
    return valid as Relay[]
  } catch (err) {
    console.warn('[FoldedWorlds] Failed to parse relay storage', err)
    return []
  }
}

export type SaveResult = 'ok' | 'quota' | 'error'

export function saveRelays(relays: Relay[]): SaveResult {
  try {
    localStorage.setItem(KEY, JSON.stringify(relays))
    return 'ok'
  } catch (err) {
    if (err instanceof DOMException && err.name === 'QuotaExceededError') {
      return 'quota'
    }
    console.warn('[FoldedWorlds] Storage save error', err)
    return 'error'
  }
}

export function generateId(): string {
  // crypto.randomUUID is available in all modern browsers
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

export function migrateRelays(relays: Relay[]): Relay[] {
  return relays.map((r) => ({
    ...r,
    schemaVersion: SCHEMA_VERSION,
  }))
}
