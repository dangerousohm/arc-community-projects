// Folded Worlds — shared types
// Schema version for localStorage forward-compat
export const SCHEMA_VERSION = 1

export interface Panel {
  /** index 0-based */
  index: number
  contributor: string
  /** Full story text for this panel (30-600 chars) */
  body: string
  /** Handoff sentence (5-160 chars) shown to the next writer */
  handoff: string
  sealed: boolean
}

export interface Relay {
  id: string
  title: string
  prompt: string
  contributors: string[]
  /** Revenue share weights — equal splits, one entry per contributor */
  shares: number[]
  panels: Panel[]
  /** demo | draft | active | complete */
  status: 'demo' | 'draft' | 'active' | 'complete'
  createdAt: string
  schemaVersion: number
}

export type View =
  | { name: 'library' }
  | { name: 'desk'; relayId: string }
  | { name: 'reveal'; relayId: string }
