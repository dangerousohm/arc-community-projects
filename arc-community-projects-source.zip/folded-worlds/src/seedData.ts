// Folded Worlds — fictional seed data (family-friendly, original)
import type { Relay } from './types'
import { SCHEMA_VERSION } from './types'

export const SEED_RELAYS: Relay[] = [
  // 1. Complete — ready to reveal
  {
    id: 'demo-complete',
    title: 'The Cartographer Who Forgot the Sea',
    prompt:
      'A mapmaker discovers that the ocean has disappeared from every chart she owns, but outside her window it still glitters in the morning sun.',
    contributors: ['Mira', 'Fen', 'Theodora'],
    shares: [1, 1, 1],
    status: 'complete',
    createdAt: '2026-10-10T09:00:00Z',
    schemaVersion: SCHEMA_VERSION,
    panels: [
      {
        index: 0,
        contributor: 'Mira',
        body: 'Sable Orin spread the largest chart across her table and traced the coastlines she had drawn ten years ago. Every bay, every reef, every crossing route — gone. The parchment showed only land stretching into blank nothing, as though the world had decided overnight to swallow its own tides. She pressed her ear to the windowpane and heard waves.',
        handoff: 'She folded the chart once, tucked it under her arm, and went to find whoever had stolen the sea.',
        sealed: true,
      },
      {
        index: 1,
        contributor: 'Fen',
        body: 'The harbour master had not stolen the sea, but he had noticed the same absence in his ledgers: every depth sounding, every tide table, every pilot book — blank. He offered Sable a cup of cold tea and the rumour that a child on Spinner Street was trading futures in "waterless maps" for half a copper a sheet. They walked there together, the real sea whispering behind them all the way.',
        handoff: "The child's name was Corvin, and he was nine years old and absolutely certain this was the best business he had ever started.",
        sealed: true,
      },
      {
        index: 2,
        contributor: 'Theodora',
        body: "Corvin had not meant to erase the sea — he had only wished, very quietly, that maps would stop frightening his father into long voyages. The wish, landing on the wrong kind of silence, had taken all the maps at once. Sable sat cross-legged on the cobblestones and taught Corvin to draw a simple coastline: a curve, a delta, a row of tiny waves. He copied her hand stroke for stroke. When he finished, the ocean flooded back into every chart in the city, all at the same moment, and the harbour master had to rescue his tea.",
        handoff: 'Corvin kept one blank map, folded in quarters, in case he ever needed to forget somewhere safe.',
        sealed: true,
      },
    ],
  },

  // 2. Mid-relay — one panel sealed, two waiting
  {
    id: 'demo-active',
    title: 'Night Train to Nowhere in Particular',
    prompt:
      'The last train of the evening carries three passengers who each believe they are the only person on board.',
    contributors: ['Aldous', 'Priya', 'Tomke'],
    shares: [1, 1, 1],
    status: 'active',
    createdAt: '2026-10-12T19:30:00Z',
    schemaVersion: SCHEMA_VERSION,
    panels: [
      {
        index: 0,
        contributor: 'Aldous',
        body: "Aldous moved through the carriages one by one, convinced the train was his alone. He had purchased three seats as a precaution and arranged his coat, his hat, and his empty lunchbox on them like fellow travellers. The lights flickered once at each tunnel and he felt, pleasantly, that the darkness was something he and the train had agreed on together. He did not notice the shadow of a woman sitting perfectly still two carriages back.",
        handoff: 'At the next stop, something slid under the door of his carriage: a single page, folded into thirds.',
        sealed: true,
      },
      {
        index: 1,
        contributor: 'Priya',
        body: '',
        handoff: '',
        sealed: false,
      },
      {
        index: 2,
        contributor: 'Tomke',
        body: '',
        handoff: '',
        sealed: false,
      },
    ],
  },

  // 3. Empty draft — prompt set, no panels written
  {
    id: 'demo-draft',
    title: 'The Museum of Things Almost Said',
    prompt:
      'An unusual museum holds exhibits of conversations that were interrupted before their most important word.',
    contributors: ['You', 'A Friend', 'Another Friend'],
    shares: [1, 1, 1],
    status: 'draft',
    createdAt: '2026-10-15T08:00:00Z',
    schemaVersion: SCHEMA_VERSION,
    panels: [
      {
        index: 0,
        contributor: 'You',
        body: '',
        handoff: '',
        sealed: false,
      },
      {
        index: 1,
        contributor: 'A Friend',
        body: '',
        handoff: '',
        sealed: false,
      },
      {
        index: 2,
        contributor: 'Another Friend',
        body: '',
        handoff: '',
        sealed: false,
      },
    ],
  },
]
