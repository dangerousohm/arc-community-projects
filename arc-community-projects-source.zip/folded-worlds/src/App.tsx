// Folded Worlds — main app router
import { useState } from 'react'
import type { View } from './types'
import { useRelays } from './useRelays'
import { Library } from './components/Library'
import { WritingDesk } from './components/WritingDesk'
import { RevealCredits } from './components/RevealCredits'

export default function App() {
  const [view, setView] = useState<View>({ name: 'library' })

  const {
    relays,
    getRelay,
    createRelay,
    deleteRelay,
    sealPanel,
    resetDemos,
  } = useRelays()

  if (view.name === 'desk') {
    const relay = getRelay(view.relayId)
    if (!relay) {
      setView({ name: 'library' })
      return null
    }
    return (
      <WritingDesk
        relay={relay}
        onNavigate={setView}
        onSealPanel={sealPanel}
      />
    )
  }

  if (view.name === 'reveal') {
    const relay = getRelay(view.relayId)
    if (!relay) {
      setView({ name: 'library' })
      return null
    }
    return (
      <RevealCredits
        relay={relay}
        onNavigate={setView}
      />
    )
  }

  return (
    <Library
      relays={relays}
      onNavigate={setView}
      onCreateRelay={createRelay}
      onDeleteRelay={deleteRelay}
      onResetDemos={resetDemos}
    />
  )
}
