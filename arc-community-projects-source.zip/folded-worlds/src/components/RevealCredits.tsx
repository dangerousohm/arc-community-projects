// Folded Worlds — Reveal & Credits view
import { useState, useRef } from 'react'
import type { Relay, View } from '../types'
import { calculateSplit, formatMicroUsdc } from '../split'
import { SCHEMA_VERSION } from '../types'

/* ──────────────────────────── Zine panel card ───────────────── */
function ZinePanel({
  index,
  contributor,
  body,
  handoff,
  isLast,
  delayClass,
}: {
  index: number
  contributor: string
  body: string
  handoff: string
  isLast: boolean
  delayClass: string
}) {
  return (
    <article
      className={`fw-panel-card fw-unfold ${delayClass}`}
      style={{
        background: 'var(--fw-cream)',
        border: '1px solid var(--fw-lavender-mid)',
        borderRadius: 12, overflow: 'hidden',
        boxShadow: '0 2px 12px rgba(45,27,61,0.08)',
      }}
    >
      {/* Panel header */}
      <div style={{
        background: 'var(--fw-aubergine)', color: 'white',
        padding: '10px 18px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{
          fontSize: 11, fontWeight: 700, letterSpacing: '0.1em',
          textTransform: 'uppercase',
        }}>Panel {index + 1}</span>
        <span style={{
          fontSize: 13, fontFamily: 'var(--fw-font-serif)',
          fontStyle: 'italic', color: 'rgba(255,255,255,0.85)',
        }}>{contributor}</span>
      </div>

      {/* Body */}
      <div style={{ padding: '20px 20px 0' }}>
        <p style={{
          margin: 0, fontSize: 15, lineHeight: 1.8,
          color: 'var(--fw-aubergine)', fontFamily: 'var(--fw-font-serif)',
        }}>{body}</p>
      </div>

      {/* Handoff — shown for all except last */}
      {!isLast && (
        <div style={{
          margin: '16px 20px 16px',
          borderTop: '1px solid var(--fw-lavender-mid)',
          paddingTop: 12,
          fontSize: 12, color: 'var(--fw-cobalt)', fontStyle: 'italic', lineHeight: 1.55,
        }}>
          <span style={{
            fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
            textTransform: 'uppercase', display: 'block', marginBottom: 4, color: 'var(--fw-muted)',
          }}>Handoff</span>
          {handoff}
        </div>
      )}
      {isLast && <div style={{ paddingBottom: 20 }} />}
    </article>
  )
}

/* ──────────────────────────── Credits card ──────────────────── */
function CreditsCard({ relay }: { relay: Relay }) {
  return (
    <div style={{
      background: 'var(--fw-lavender-light)',
      border: '1px solid var(--fw-lavender-mid)',
      borderRadius: 12, padding: '20px 20px 16px',
    }}>
      <h3 style={{
        margin: '0 0 14px', fontFamily: 'var(--fw-font-serif)',
        fontSize: 18, color: 'var(--fw-aubergine)',
      }}>Contributors</h3>
      <ol style={{ margin: 0, paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 6 }}>
        {relay.contributors.map((c, i) => (
          <li key={i} style={{ fontSize: 14, color: 'var(--fw-aubergine)' }}>
            <strong>{c}</strong>
            <span style={{ color: 'var(--fw-muted)', marginLeft: 8, fontSize: 12 }}>Panel {i + 1}</span>
          </li>
        ))}
      </ol>
      <p style={{
        margin: '14px 0 0', fontSize: 11, color: 'var(--fw-muted)', lineHeight: 1.55,
      }}>
        Attribution acknowledges authorship but does not prove copyright ownership. Contributors should only share content they have permission to use.
      </p>
    </div>
  )
}

/* ──────────────────────────── Split calculator ──────────────── */
function SplitCalculator({ contributors }: { contributors: string[] }) {
  const [amount, setAmount] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const result = submitted && amount !== '' ? calculateSplit(amount, contributors) : null

  function handleInput(e: React.ChangeEvent<HTMLInputElement>) {
    // Allow only digits and at most one dot with ≤6 decimal places
    const val = e.target.value
    if (val === '' || /^\d*\.?\d{0,6}$/.test(val)) {
      setAmount(val)
      setSubmitted(false)
    }
  }

  return (
    <div style={{
      background: 'var(--fw-lavender-light)',
      border: '1px solid var(--fw-lavender-mid)',
      borderRadius: 12, padding: '20px 20px 16px',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, flexWrap: 'wrap',
      }}>
        <h3 style={{ margin: 0, fontFamily: 'var(--fw-font-serif)', fontSize: 18, color: 'var(--fw-aubergine)' }}>
          USDC split
        </h3>
        <span style={{
          fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
          textTransform: 'uppercase', padding: '2px 8px',
          background: 'var(--fw-tangerine-light)', color: 'var(--fw-tangerine)',
          borderRadius: 20,
        }}>Simulation only</span>
      </div>
      <p style={{ margin: '0 0 14px', fontSize: 12, color: 'var(--fw-muted)', lineHeight: 1.55 }}>
        Calculate how a USDC amount would be split equally among contributors. No wallet, no transaction, no onchain action.
      </p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <div style={{ flex: 1 }}>
          <label htmlFor="split-amount" style={{ display: 'block', fontWeight: 600, fontSize: 13, marginBottom: 5, color: 'var(--fw-aubergine)' }}>
            Amount (USDC)
          </label>
          <input
            id="split-amount"
            type="text"
            inputMode="decimal"
            value={amount}
            onChange={handleInput}
            placeholder="e.g. 10.00"
            style={{
              width: '100%', padding: '10px 12px',
              background: 'var(--fw-cream)', border: '1px solid var(--fw-lavender-mid)',
              borderRadius: 8, fontFamily: 'var(--fw-font-body)', fontSize: 14,
              color: 'var(--fw-aubergine)', outline: 'none',
              fontVariantNumeric: 'tabular-nums',
            }}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-end' }}>
          <button
            onClick={() => setSubmitted(true)}
            style={{
              padding: '10px 18px',
              background: 'var(--fw-cobalt)', color: 'white',
              border: 'none', borderRadius: 8,
              fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 13,
              cursor: 'pointer',
            }}
          >Calculate</button>
        </div>
      </div>

      {result && !result.valid && (
        <p role="alert" style={{ margin: '0 0 8px', color: '#B8371A', fontSize: 13, fontWeight: 500 }}>
          {result.message}
        </p>
      )}

      {result && result.valid && (
        <div style={{
          background: 'var(--fw-cream)', borderRadius: 8,
          border: '1px solid var(--fw-lavender-mid)', padding: '14px',
        }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between',
            padding: '6px 0', borderBottom: '1px solid var(--fw-lavender-mid)',
            marginBottom: 8,
          }}>
            <span style={{ fontSize: 13, color: 'var(--fw-muted)' }}>Total</span>
            <span style={{ fontSize: 13, fontWeight: 600, fontVariantNumeric: 'tabular-nums', color: 'var(--fw-aubergine)' }}>
              {formatMicroUsdc(result.totalMicroUsdc)} USDC
            </span>
          </div>
          <div style={{
            display: 'flex', justifyContent: 'space-between',
            padding: '4px 0', marginBottom: 10,
          }}>
            <span style={{ fontSize: 12, color: 'var(--fw-muted)' }}>Platform fee</span>
            <span style={{ fontSize: 12, color: '#1A7A4A', fontWeight: 600 }}>None</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
            {result.shares.map((s) => (
              <div key={s.contributor} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <span style={{ fontSize: 13, color: 'var(--fw-aubergine)' }}>{s.contributor}</span>
                <span style={{
                  fontSize: 13, fontWeight: 600,
                  fontVariantNumeric: 'tabular-nums', color: 'var(--fw-aubergine)',
                }}>{s.display} USDC</span>
              </div>
            ))}
          </div>

          <p style={{ margin: 0, fontSize: 11, color: 'var(--fw-muted)', lineHeight: 1.55 }}>
            {result.remainderExplanation}
          </p>
          <p style={{ margin: '6px 0 0', fontSize: 11, color: 'var(--fw-muted)' }}>
            <strong>Planned:</strong> Arc Testnet USDC split settlement will require real wallet consent and an onchain transaction.
          </p>
        </div>
      )}
    </div>
  )
}

/* ──────────────────────────── JSON export ───────────────────── */
function buildExportJson(relay: Relay): string {
  const data = {
    schemaVersion: SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    relay: {
      id: relay.id,
      title: relay.title,
      prompt: relay.prompt,
      contributors: relay.contributors,
      shares: relay.shares,
      createdAt: relay.createdAt,
      panels: relay.panels.map((p) => ({
        index: p.index,
        contributor: p.contributor,
        body: p.body,
        handoff: p.handoff,
      })),
    },
  }
  return JSON.stringify(data, null, 2)
}

function downloadJson(relay: Relay) {
  const json = buildExportJson(relay)
  const blob = new Blob([json], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `folded-worlds-${relay.id.slice(0, 8)}.json`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

/* ──────────────────────────── Reveal & Credits ──────────────── */
interface RevealProps {
  relay: Relay
  onNavigate: (view: View) => void
}

const DELAY_CLASSES = ['fw-unfold-d0', 'fw-unfold-d1', 'fw-unfold-d2', 'fw-unfold-d3', 'fw-unfold-d4', 'fw-unfold-d5']

export function RevealCredits({ relay, onNavigate }: RevealProps) {
  const [revealed, setRevealed] = useState(false)
  const panelsRef = useRef<HTMLDivElement>(null)

  function handleReveal() {
    setRevealed(true)
    setTimeout(() => {
      panelsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }, 100)
  }

  const backToLib = () => onNavigate({ name: 'library' })
  const sealedPanels = relay.panels.filter((p) => p.sealed)

  return (
    <div style={{ minHeight: '100dvh', background: 'var(--fw-lavender)', paddingBottom: 80 }}>
      <header style={{
        background: 'var(--fw-aubergine)', color: 'white',
        padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button
          onClick={backToLib}
          aria-label="Back to library"
          style={{
            background: 'none', border: 'none', color: 'white',
            cursor: 'pointer', fontSize: 22, padding: '0 4px', lineHeight: 1,
          }}
        >←</button>
        <div>
          <h2 style={{
            margin: 0, fontFamily: 'var(--fw-font-serif)',
            fontSize: 18, fontStyle: 'italic', color: 'white',
          }}>{relay.title}</h2>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', marginTop: 2 }}>
            {sealedPanels.length} panels · {relay.contributors.join(', ')}
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 560, margin: '0 auto', padding: '32px 16px 0' }}>
        {/* Prompt recap */}
        <div style={{
          background: 'var(--fw-cobalt-light)',
          borderLeft: '3px solid var(--fw-cobalt)',
          borderRadius: '0 8px 8px 0',
          padding: '14px 16px', marginBottom: 28,
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, letterSpacing: '0.08em',
            textTransform: 'uppercase', color: 'var(--fw-cobalt)', marginBottom: 4,
          }}>The original prompt</div>
          <p style={{ margin: 0, fontSize: 14, lineHeight: 1.65, color: 'var(--fw-aubergine)' }}>
            {relay.prompt}
          </p>
        </div>

        {!revealed ? (
          <div style={{ textAlign: 'center', padding: '40px 20px' }}>
            {/* Big sealed envelope */}
            <svg width="120" height="100" viewBox="0 0 120 100" fill="none" aria-hidden="true" style={{ marginBottom: 24 }}>
              <rect x="2" y="12" width="116" height="80" rx="6" fill="var(--fw-aubergine)" stroke="#4A2D63" strokeWidth="1.5" />
              <path d="M2 12 L60 58 L118 12" stroke="#C9BCE0" strokeWidth="2" fill="none" />
              <path d="M2 92 L48 56" stroke="#4A2D63" strokeWidth="1.5" strokeDasharray="4 3" />
              <path d="M118 92 L72 56" stroke="#4A2D63" strokeWidth="1.5" strokeDasharray="4 3" />
              {/* Wax seal */}
              <circle cx="60" cy="66" r="18" fill="#E8650A" />
              <path d="M60 50 L63 62 H75 L65 70 L68 82 L60 74 L52 82 L55 70 L45 62 H57 Z" fill="#FBE9D8" />
            </svg>

            <h2 style={{
              margin: '0 0 10px',
              fontFamily: 'var(--fw-font-serif)', fontSize: 28,
              color: 'var(--fw-aubergine)', fontStyle: 'italic',
            }}>All panels sealed</h2>
            <p style={{
              margin: '0 0 28px', fontSize: 15, color: 'var(--fw-muted)', lineHeight: 1.6,
            }}>
              {sealedPanels.length} writers, {sealedPanels.length} hidden panels — ready to unfold.
            </p>
            <button
              onClick={handleReveal}
              autoFocus
              style={{
                padding: '14px 40px',
                background: 'var(--fw-tangerine)', color: 'white',
                border: 'none', borderRadius: 10,
                fontFamily: 'var(--fw-font-display)', fontWeight: 700, fontSize: 16,
                cursor: 'pointer', letterSpacing: '0.01em',
              }}
            >Unfold the story</button>
          </div>
        ) : (
          <div ref={panelsRef} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {/* Story panels */}
            <h2 style={{
              margin: '0 0 4px', fontFamily: 'var(--fw-font-serif)',
              fontSize: 26, color: 'var(--fw-aubergine)', fontStyle: 'italic',
            }}>{relay.title}</h2>
            <p style={{ margin: '0 0 4px', fontSize: 13, color: 'var(--fw-muted)' }}>
              A collaborative story by {relay.contributors.join(', ')}
            </p>

            {sealedPanels.map((p, i) => (
              <ZinePanel
                key={p.index}
                index={p.index}
                contributor={p.contributor}
                body={p.body}
                handoff={p.handoff}
                isLast={i === sealedPanels.length - 1}
                delayClass={DELAY_CLASSES[i % DELAY_CLASSES.length]}
              />
            ))}

            {/* Credits */}
            <CreditsCard relay={relay} />

            {/* Split calculator */}
            <SplitCalculator contributors={relay.contributors} />

            {/* Actions */}
            <div className="fw-no-print" style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button
                onClick={() => window.print()}
                style={{
                  flex: 1, padding: '12px 18px',
                  background: 'var(--fw-aubergine)', color: 'white',
                  border: 'none', borderRadius: 8,
                  fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 13,
                  cursor: 'pointer',
                }}
              >Print zine</button>
              <button
                onClick={() => downloadJson(relay)}
                style={{
                  flex: 1, padding: '12px 18px',
                  background: 'none', color: 'var(--fw-cobalt)',
                  border: '1px solid var(--fw-cobalt)', borderRadius: 8,
                  fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 13,
                  cursor: 'pointer',
                }}
              >Export JSON</button>
              <button
                onClick={backToLib}
                style={{
                  flex: 1, padding: '12px 18px',
                  background: 'none', color: 'var(--fw-muted)',
                  border: '1px solid var(--fw-lavender-mid)', borderRadius: 8,
                  fontWeight: 500, fontSize: 13, cursor: 'pointer',
                }}
              >Library</button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
