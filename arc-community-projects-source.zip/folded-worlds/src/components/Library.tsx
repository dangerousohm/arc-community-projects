// Folded Worlds — Library view
import { useState, useId } from 'react'
import type { Relay, View } from '../types'
import type { CreateRelayInput } from '../useRelays'
import { validateCreateForm } from '../relayLogic'

/* ──────────────────────────── SVG envelope mark ─────────────── */
function EnvelopeSVG({ sealed = false }: { sealed?: boolean }) {
  const fill = sealed ? '#2D1B3D' : '#E8E0F0'
  const stroke = sealed ? '#4A2D63' : '#C9BCE0'
  return (
    <svg
      width="56"
      height="48"
      viewBox="0 0 56 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect x="1" y="6" width="54" height="38" rx="3" fill={fill} stroke={stroke} strokeWidth="1.5" />
      {/* Flap */}
      <path d="M1 6 L28 28 L55 6" stroke={stroke} strokeWidth="1.5" fill="none" />
      {/* Fold lines */}
      <path d="M1 44 L22 26" stroke={stroke} strokeWidth="1" strokeDasharray="2 2" />
      <path d="M55 44 L34 26" stroke={stroke} strokeWidth="1" strokeDasharray="2 2" />
      {/* Tangerine stamp */}
      {sealed && (
        <>
          <rect x="38" y="10" width="14" height="14" rx="2" fill="#E8650A" />
          <line x1="41" y1="13" x2="49" y2="13" stroke="#FBE9D8" strokeWidth="1.5" />
          <line x1="41" y1="16" x2="49" y2="16" stroke="#FBE9D8" strokeWidth="1.5" />
          <line x1="41" y1="19" x2="46" y2="19" stroke="#FBE9D8" strokeWidth="1.5" />
        </>
      )}
    </svg>
  )
}

/* ──────────────────────────── Hero SVG ──────────────────────── */
function HeroIllustration() {
  return (
    <svg
      width="320"
      height="200"
      viewBox="0 0 320 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Stacked folded paper panels representing a collaborative story"
      style={{ maxWidth: '100%' }}
    >
      {/* Background panel */}
      <rect x="30" y="40" width="200" height="130" rx="4" fill="#C9BCE0" />
      <path d="M30 40 L130 100 L230 40" stroke="#B3A5CE" strokeWidth="1.5" fill="none" />
      {/* Middle panel */}
      <rect x="55" y="30" width="200" height="130" rx="4" fill="#D9D0EC" />
      <path d="M55 30 L155 90 L255 30" stroke="#C4B8DC" strokeWidth="1.5" fill="none" />
      {/* Front panel */}
      <rect x="80" y="20" width="200" height="130" rx="4" fill="#E8E0F0" stroke="#C9BCE0" strokeWidth="1" />
      <path d="M80 20 L180 80 L280 20" stroke="#C9BCE0" strokeWidth="1.5" fill="none" />
      {/* Tangerine stamp on front */}
      <rect x="240" y="28" width="22" height="22" rx="3" fill="#E8650A" />
      <line x1="244" y1="34" x2="258" y2="34" stroke="#FBE9D8" strokeWidth="1.5" />
      <line x1="244" y1="38" x2="258" y2="38" stroke="#FBE9D8" strokeWidth="1.5" />
      <line x1="244" y1="42" x2="254" y2="42" stroke="#FBE9D8" strokeWidth="1.5" />
      {/* Fold crease lines */}
      <line x1="80" y1="150" x2="140" y2="105" stroke="#C9BCE0" strokeWidth="1" strokeDasharray="3 3" />
      <line x1="280" y1="150" x2="220" y2="105" stroke="#C9BCE0" strokeWidth="1" strokeDasharray="3 3" />
      {/* Cobalt accent: handwritten-style lines */}
      <line x1="100" y1="95" x2="200" y2="95" stroke="#1B4FCC" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
      <line x1="100" y1="108" x2="180" y2="108" stroke="#1B4FCC" strokeWidth="1.5" strokeLinecap="round" opacity="0.3" />
      <line x1="100" y1="121" x2="160" y2="121" stroke="#1B4FCC" strokeWidth="1.5" strokeLinecap="round" opacity="0.2" />
    </svg>
  )
}

/* ──────────────────────────── Progress bar ──────────────────── */
function ProgressBar({ sealed, total }: { sealed: number; total: number }) {
  const pct = total === 0 ? 0 : Math.round((sealed / total) * 100)
  return (
    <div role="progressbar" aria-valuenow={sealed} aria-valuemin={0} aria-valuemax={total}
      aria-label={`${sealed} of ${total} panels sealed`}
      style={{ height: 6, background: 'var(--fw-lavender-mid)', borderRadius: 3, overflow: 'hidden' }}>
      <div style={{
        height: '100%', width: `${pct}%`, borderRadius: 3,
        background: pct === 100 ? 'var(--fw-tangerine)' : 'var(--fw-cobalt)',
        transition: 'width 0.4s ease',
      }} />
    </div>
  )
}

/* ──────────────────────────── Status chip ───────────────────── */
function StatusChip({ status }: { status: Relay['status'] }) {
  const map: Record<Relay['status'], { label: string; bg: string; color: string }> = {
    demo: { label: 'Demo', bg: 'var(--fw-lavender-mid)', color: 'var(--fw-muted)' },
    draft: { label: 'Draft', bg: 'var(--fw-cobalt-light)', color: 'var(--fw-cobalt)' },
    active: { label: 'In relay', bg: 'var(--fw-tangerine-light)', color: 'var(--fw-tangerine)' },
    complete: { label: 'Ready to reveal', bg: '#E6F9F0', color: '#1A7A4A' },
  }
  const s = map[status]
  return (
    <span style={{
      display: 'inline-block', fontSize: 11, fontWeight: 600,
      letterSpacing: '0.07em', textTransform: 'uppercase',
      padding: '2px 8px', borderRadius: 20,
      background: s.bg, color: s.color,
    }}>{s.label}</span>
  )
}

/* ──────────────────────────── Relay card ────────────────────── */
function RelayCard({
  relay, onOpen, onDelete,
}: {
  relay: Relay
  onOpen: (id: string) => void
  onDelete?: (id: string) => void
}) {
  const [confirmDelete, setConfirmDelete] = useState(false)
  const sealedCount = relay.panels.filter((p) => p.sealed).length
  const isDemo = relay.id.startsWith('demo-')

  const destination = relay.status === 'complete' ? 'reveal' : 'desk'

  return (
    <article style={{
      background: 'var(--fw-lavender-light)', borderRadius: 12,
      border: '1px solid var(--fw-lavender-mid)',
      padding: '20px 20px 16px',
      display: 'flex', flexDirection: 'column', gap: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        <EnvelopeSVG sealed={relay.status === 'complete'} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
            <StatusChip status={relay.status} />
            {isDemo && (
              <span style={{
                fontSize: 10, fontWeight: 600, letterSpacing: '0.08em',
                textTransform: 'uppercase', color: 'var(--fw-muted)',
                background: 'var(--fw-lavender-mid)', padding: '1px 6px', borderRadius: 10,
              }}>Sample</span>
            )}
          </div>
          <h3 style={{
            margin: 0, fontFamily: 'var(--fw-font-serif)',
            fontSize: 18, color: 'var(--fw-aubergine)', lineHeight: 1.3,
          }}>{relay.title}</h3>
        </div>
      </div>

      <p style={{
        margin: 0, fontSize: 13, color: 'var(--fw-muted)',
        lineHeight: 1.55, display: '-webkit-box',
        WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
      }}>{relay.prompt}</p>

      <div style={{ fontSize: 12, color: 'var(--fw-muted)' }}>
        {relay.contributors.length} contributor{relay.contributors.length !== 1 ? 's' : ''}&nbsp;&middot;&nbsp;
        {sealedCount}/{relay.panels.length} sealed
      </div>

      <ProgressBar sealed={sealedCount} total={relay.panels.length} />

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 2 }}>
        <button
          onClick={() => onOpen(relay.id)}
          aria-label={`${destination === 'reveal' ? 'Reveal story' : 'Open writing desk for'} "${relay.title}"`}
          style={{
            flex: 1, padding: '10px 16px',
            background: relay.status === 'complete' ? 'var(--fw-tangerine)' : 'var(--fw-aubergine)',
            color: 'white', border: 'none', borderRadius: 8,
            fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 13,
            cursor: 'pointer', letterSpacing: '0.01em',
          }}
        >
          {relay.status === 'complete' ? 'Unfold story' : relay.status === 'draft' ? 'Start writing' : 'Continue relay'}
        </button>

        {!isDemo && onDelete && (
          confirmDelete ? (
            <div style={{ display: 'flex', gap: 6 }}>
              <button
                onClick={() => onDelete(relay.id)}
                style={{
                  padding: '10px 14px', background: '#B8371A', color: 'white',
                  border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13,
                  cursor: 'pointer', fontFamily: 'var(--fw-font-display)',
                }}
              >Delete</button>
              <button
                onClick={() => setConfirmDelete(false)}
                style={{
                  padding: '10px 14px',
                  background: 'none', color: 'var(--fw-muted)',
                  border: '1px solid var(--fw-lavender-mid)', borderRadius: 8,
                  fontWeight: 500, fontSize: 13, cursor: 'pointer',
                }}
              >Cancel</button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmDelete(true)}
              aria-label={`Delete draft "${relay.title}"`}
              style={{
                padding: '10px 14px',
                background: 'none', color: 'var(--fw-muted)',
                border: '1px solid var(--fw-lavender-mid)', borderRadius: 8,
                fontWeight: 500, fontSize: 13, cursor: 'pointer',
              }}
            >Delete</button>
          )
        )}
      </div>
    </article>
  )
}

// validateCreateForm is imported from ../relayLogic

/* ──────────────────────────── Create form ───────────────────── */
function CreateRelayForm({
  onCancel,
  onCreate,
}: {
  onCancel: () => void
  onCreate: (input: CreateRelayInput) => void
}) {
  const titleId = useId()
  const promptId = useId()

  const [title, setTitle] = useState('')
  const [prompt, setPrompt] = useState('')
  const [contributors, setContributors] = useState(['', '', ''])
  const [error, setError] = useState<string | null>(null)

  function setContributor(idx: number, val: string) {
    const next = [...contributors]
    next[idx] = val
    setContributors(next)
  }

  function addContributor() {
    if (contributors.length < 6) setContributors([...contributors, ''])
  }

  function removeContributor(idx: number) {
    if (contributors.length <= 2) return
    setContributors(contributors.filter((_, i) => i !== idx))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const filled = contributors.filter((c) => c.trim())
    const result = validateCreateForm(title, prompt, filled)
    if (!result.valid) { setError(result.error); return }
    setError(null)
    onCreate({ title, prompt, contributors: filled })
  }

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '10px 12px',
    background: 'var(--fw-cream)', border: '1px solid var(--fw-lavender-mid)',
    borderRadius: 8, fontFamily: 'var(--fw-font-body)', fontSize: 14,
    color: 'var(--fw-aubergine)', outline: 'none',
  }

  return (
    <div style={{
      background: 'var(--fw-lavender-light)', borderRadius: 14,
      border: '2px solid var(--fw-lavender-mid)',
      padding: '24px 24px 20px',
    }}>
      <h2 style={{
        margin: '0 0 20px', fontFamily: 'var(--fw-font-serif)',
        fontSize: 22, color: 'var(--fw-aubergine)',
      }}>New relay</h2>

      <form onSubmit={handleSubmit} noValidate style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div>
          <label htmlFor={titleId} style={{ display: 'block', fontWeight: 600, fontSize: 13, marginBottom: 6, color: 'var(--fw-aubergine)' }}>
            Story title
          </label>
          <input
            id={titleId}
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. The Last Lighthouse Keeper"
            maxLength={120}
            required
            style={inputStyle}
          />
          <div style={{ fontSize: 11, color: 'var(--fw-muted)', marginTop: 3, textAlign: 'right' }}>{title.length}/120</div>
        </div>

        <div>
          <label htmlFor={promptId} style={{ display: 'block', fontWeight: 600, fontSize: 13, marginBottom: 6, color: 'var(--fw-aubergine)' }}>
            Opening prompt <span style={{ color: 'var(--fw-muted)', fontWeight: 400 }}>(sets the scene — not in a sealed panel)</span>
          </label>
          <textarea
            id={promptId}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g. A lighthouse keeper discovers the light has started speaking in Morse code…"
            maxLength={600}
            required
            rows={3}
            style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.55 }}
          />
          <div style={{ fontSize: 11, color: 'var(--fw-muted)', marginTop: 3, textAlign: 'right' }}>{prompt.length}/600</div>
        </div>

        <fieldset style={{ border: 'none', padding: 0, margin: 0 }}>
          <legend style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, color: 'var(--fw-aubergine)', float: 'left', width: '100%' }}>
            Contributors (2 – 6) <span style={{ color: 'var(--fw-muted)', fontWeight: 400 }}>· equal shares</span>
          </legend>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
            {contributors.map((c, i) => (
              <div key={i} style={{ display: 'flex', gap: 8 }}>
                <input
                  type="text"
                  value={c}
                  aria-label={`Contributor ${i + 1} name`}
                  onChange={(e) => setContributor(i, e.target.value)}
                  placeholder={`Contributor ${i + 1}`}
                  maxLength={40}
                  style={{ ...inputStyle, flex: 1 }}
                />
                {contributors.length > 2 && (
                  <button
                    type="button"
                    onClick={() => removeContributor(i)}
                    aria-label={`Remove contributor ${i + 1}`}
                    style={{
                      padding: '0 14px', background: 'none',
                      border: '1px solid var(--fw-lavender-mid)',
                      borderRadius: 8, cursor: 'pointer', color: 'var(--fw-muted)',
                      fontSize: 18, lineHeight: 1,
                    }}
                  >×</button>
                )}
              </div>
            ))}
          </div>
          {contributors.length < 6 && (
            <button
              type="button"
              onClick={addContributor}
              style={{
                marginTop: 8, padding: '6px 14px',
                background: 'none', border: '1px dashed var(--fw-lavender-mid)',
                borderRadius: 8, cursor: 'pointer', color: 'var(--fw-cobalt)',
                fontSize: 13, fontWeight: 500,
              }}
            >+ Add contributor</button>
          )}
        </fieldset>

        {error && (
          <p role="alert" style={{ margin: 0, color: '#B8371A', fontSize: 13, fontWeight: 500 }}>
            {error}
          </p>
        )}

        <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
          <button
            type="submit"
            style={{
              flex: 1, padding: '12px 20px',
              background: 'var(--fw-aubergine)', color: 'white',
              border: 'none', borderRadius: 8,
              fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 14,
              cursor: 'pointer',
            }}
          >Create relay</button>
          <button
            type="button"
            onClick={onCancel}
            style={{
              padding: '12px 20px',
              background: 'none', color: 'var(--fw-muted)',
              border: '1px solid var(--fw-lavender-mid)', borderRadius: 8,
              fontWeight: 500, fontSize: 14, cursor: 'pointer',
            }}
          >Cancel</button>
        </div>
      </form>
    </div>
  )
}

/* ──────────────────────────── How it works panel ────────────── */
function HowItWorks() {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ border: '1px solid var(--fw-lavender-mid)', borderRadius: 10, overflow: 'hidden' }}>
      <button
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        style={{
          width: '100%', padding: '12px 16px',
          background: open ? 'var(--fw-lavender-light)' : 'none',
          border: 'none', cursor: 'pointer',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 14,
          color: 'var(--fw-aubergine)', textAlign: 'left',
        }}
      >
        How it works
        <span aria-hidden="true" style={{ fontSize: 18, lineHeight: 1 }}>{open ? '−' : '+'}</span>
      </button>
      {open && (
        <div style={{ padding: '4px 16px 16px', fontSize: 13, lineHeight: 1.65, color: 'var(--fw-aubergine)' }}>
          <ol style={{ margin: '0', paddingLeft: 18 }}>
            <li><strong>Create a relay</strong> with a title, opening prompt, and 2-6 contributor names.</li>
            <li><strong>Pass the device</strong> to the first contributor. They write their panel, enter a handoff sentence, preview, then seal it.</li>
            <li>The app shows a privacy cover. The <strong>next contributor clicks Ready</strong> — they see only the handoff sentence, never the full panel above.</li>
            <li>Once all panels are sealed, <strong>unfold the full story</strong> with credits and a printable zine layout.</li>
          </ol>
          <p style={{ margin: '10px 0 0', color: 'var(--fw-muted)', fontSize: 12 }}>
            This is a one-browser, pass-and-play demo. All data is stored locally. Local storage is not encrypted — contributors can inspect it if they choose. No online accounts or real collaboration across devices.
          </p>
          <p style={{ margin: '8px 0 0', color: 'var(--fw-muted)', fontSize: 12 }}>
            <strong>Planned:</strong> online invitations, real authorisation, a shared database, and Arc Testnet USDC split settlement requiring real wallet consent.
          </p>
          <p style={{ margin: '8px 0 0', color: 'var(--fw-muted)', fontSize: 12 }}>
            Attribution does not prove copyright ownership. Contributors should only share content they have permission to use.
          </p>
        </div>
      )}
    </div>
  )
}

/* ──────────────────────────── Library ───────────────────────── */
interface LibraryProps {
  relays: Relay[]
  onNavigate: (view: View) => void
  onCreateRelay: (input: CreateRelayInput) => string
  onDeleteRelay: (id: string) => void
  onResetDemos: () => void
}

export function Library({ relays, onNavigate, onCreateRelay, onDeleteRelay, onResetDemos }: LibraryProps) {
  const [showCreate, setShowCreate] = useState(false)
  const [confirmReset, setConfirmReset] = useState(false)

  const demoRelays = relays.filter((r) => r.id.startsWith('demo-'))
  const userRelays = relays.filter((r) => !r.id.startsWith('demo-'))

  function handleCreate(input: CreateRelayInput) {
    const id = onCreateRelay(input)
    setShowCreate(false)
    onNavigate({ name: 'desk', relayId: id })
  }

  function handleOpen(id: string) {
    const relay = relays.find((r) => r.id === id)
    if (!relay) return
    if (relay.status === 'complete') {
      onNavigate({ name: 'reveal', relayId: id })
    } else {
      onNavigate({ name: 'desk', relayId: id })
    }
  }

  return (
    <div style={{ minHeight: '100dvh', background: 'var(--fw-lavender)', paddingBottom: 80 }}>
      {/* Header */}
      <header style={{
        background: 'var(--fw-aubergine)', color: 'white',
        padding: '32px 24px 28px', textAlign: 'center',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
          <HeroIllustration />
        </div>
        <h1 style={{
          margin: '0 0 6px',
          fontFamily: 'var(--fw-font-serif)',
          fontSize: 'clamp(28px, 7vw, 42px)',
          fontStyle: 'italic',
          letterSpacing: '-0.01em',
          color: 'white',
        }}>Folded Worlds</h1>
        <p style={{
          margin: 0, fontSize: 15, color: 'rgba(255,255,255,0.7)',
          fontFamily: 'var(--fw-font-body)', fontStyle: 'italic', letterSpacing: '0.02em',
        }}>One story, many hands.</p>
      </header>

      <main style={{ maxWidth: 520, margin: '0 auto', padding: '28px 16px 0' }}>
        {/* Demo notice */}
        <div style={{
          background: 'var(--fw-tangerine-light)', border: '1px solid var(--fw-tangerine)',
          borderRadius: 8, padding: '10px 14px', marginBottom: 20,
          fontSize: 12, color: 'var(--fw-aubergine)', lineHeight: 1.55,
        }}>
          <strong>Pass-and-play demo</strong> — all stories are stored in your browser. No accounts, no online collaboration.
        </div>

        {/* Sample stories */}
        <section aria-label="Sample story relays">
          <h2 style={{
            margin: '0 0 14px', fontSize: 13, fontWeight: 700,
            letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--fw-muted)',
          }}>Sample stories</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 28 }}>
            {demoRelays.map((r) => (
              <RelayCard key={r.id} relay={r} onOpen={handleOpen} />
            ))}
          </div>
        </section>

        {/* User stories */}
        {userRelays.length > 0 && (
          <section aria-label="Your story relays" style={{ marginBottom: 28 }}>
            <h2 style={{
              margin: '0 0 14px', fontSize: 13, fontWeight: 700,
              letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--fw-muted)',
            }}>Your relays</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {userRelays.map((r) => (
                <RelayCard key={r.id} relay={r} onOpen={handleOpen} onDelete={onDeleteRelay} />
              ))}
            </div>
          </section>
        )}

        {/* Create form or button */}
        {showCreate ? (
          <CreateRelayForm
            onCancel={() => setShowCreate(false)}
            onCreate={handleCreate}
          />
        ) : (
          <button
            onClick={() => setShowCreate(true)}
            style={{
              width: '100%', padding: '14px 20px',
              background: 'var(--fw-aubergine)', color: 'white',
              border: 'none', borderRadius: 10,
              fontFamily: 'var(--fw-font-display)', fontWeight: 700, fontSize: 15,
              cursor: 'pointer', letterSpacing: '0.01em',
            }}
          >
            + New relay
          </button>
        )}

        {/* How it works */}
        <div style={{ marginTop: 24 }}>
          <HowItWorks />
        </div>

        {/* Reset demos */}
        <div style={{ marginTop: 24, textAlign: 'center' }}>
          {confirmReset ? (
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <button
                onClick={() => { onResetDemos(); setConfirmReset(false) }}
                style={{
                  padding: '8px 18px',
                  background: '#B8371A', color: 'white',
                  border: 'none', borderRadius: 8,
                  fontWeight: 600, fontSize: 13, cursor: 'pointer',
                }}
              >Yes, reset demos</button>
              <button
                onClick={() => setConfirmReset(false)}
                style={{
                  padding: '8px 18px',
                  background: 'none', color: 'var(--fw-muted)',
                  border: '1px solid var(--fw-lavender-mid)', borderRadius: 8,
                  fontWeight: 500, fontSize: 13, cursor: 'pointer',
                }}
              >Cancel</button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmReset(true)}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                color: 'var(--fw-muted)', fontSize: 12, textDecoration: 'underline',
              }}
            >Reset demo stories</button>
          )}
        </div>
      </main>
    </div>
  )
}
