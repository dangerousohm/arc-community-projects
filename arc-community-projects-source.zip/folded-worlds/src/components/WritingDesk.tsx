// Folded Worlds — Writing Desk view (pass-and-play)
import { useState } from 'react'
import type { Relay, View } from '../types'

const BODY_MIN = 30
const BODY_MAX = 600
const HANDOFF_MIN = 5
const HANDOFF_MAX = 160

/* ──────────────────────────── Helpers ───────────────────────── */
function countChars(s: string) {
  return [...s.trim()].length
}

/* ──────────────────────────── Privacy cover ─────────────────── */
function PrivacyCover({
  nextContributor,
  onReady,
}: {
  nextContributor: string
  onReady: () => void
}) {
  return (
    <div style={{
      minHeight: '100dvh', background: 'var(--fw-aubergine)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      padding: 32, textAlign: 'center',
    }}>
      {/* Sealed envelope SVG */}
      <svg width="80" height="68" viewBox="0 0 80 68" fill="none" aria-hidden="true" style={{ marginBottom: 28 }}>
        <rect x="1" y="8" width="78" height="56" rx="5" fill="#4A2D63" stroke="#C9BCE0" strokeWidth="1.5" />
        <path d="M1 8 L40 40 L79 8" stroke="#C9BCE0" strokeWidth="1.5" fill="none" />
        <path d="M1 64 L32 38" stroke="#C9BCE0" strokeWidth="1" strokeDasharray="3 3" />
        <path d="M79 64 L48 38" stroke="#C9BCE0" strokeWidth="1" strokeDasharray="3 3" />
        {/* Tangerine wax seal */}
        <circle cx="40" cy="44" r="12" fill="#E8650A" />
        <path d="M40 36 L42 42 H48 L43 46 L45 52 L40 48 L35 52 L37 46 L32 42 H38 Z" fill="#FBE9D8" />
      </svg>

      <h2 style={{
        margin: '0 0 10px',
        fontFamily: 'var(--fw-font-serif)', fontSize: 26,
        color: 'white', fontStyle: 'italic',
      }}>Panel sealed</h2>
      <p style={{
        margin: '0 0 6px', fontSize: 15, color: 'rgba(255,255,255,0.75)',
        maxWidth: 320, lineHeight: 1.55,
      }}>
        Pass the device to <strong style={{ color: 'white' }}>{nextContributor}</strong>.
      </p>
      <p style={{
        margin: '0 0 32px', fontSize: 13, color: 'rgba(255,255,255,0.5)',
        maxWidth: 320, lineHeight: 1.55,
      }}>
        The previous panel is hidden. When you're ready to write your part, tap below.
      </p>
      <button
        onClick={onReady}
        autoFocus
        style={{
          padding: '14px 36px',
          background: 'var(--fw-tangerine)', color: 'white',
          border: 'none', borderRadius: 10,
          fontFamily: 'var(--fw-font-display)', fontWeight: 700, fontSize: 16,
          cursor: 'pointer', letterSpacing: '0.01em',
        }}
      >
        Ready — I'm {nextContributor}
      </button>
    </div>
  )
}

/* ──────────────────────────── Preview pane ──────────────────── */
function PreviewPane({
  body,
  handoff,
  onBack,
  onSeal,
}: {
  body: string
  handoff: string
  onBack: () => void
  onSeal: () => void
}) {
  return (
    <div style={{
      background: 'var(--fw-lavender-light)', borderRadius: 14,
      border: '2px solid var(--fw-lavender-mid)',
      padding: '24px 24px 20px',
    }}>
      <h3 style={{
        margin: '0 0 16px', fontFamily: 'var(--fw-font-serif)',
        fontSize: 20, color: 'var(--fw-aubergine)',
      }}>Preview your panel</h3>

      <div style={{
        background: 'var(--fw-cream)', borderRadius: 8,
        border: '1px solid var(--fw-lavender-mid)',
        padding: '16px', marginBottom: 14,
      }}>
        <p style={{
          margin: 0, fontSize: 15, lineHeight: 1.7,
          color: 'var(--fw-aubergine)', fontFamily: 'var(--fw-font-serif)',
        }}>{body}</p>
      </div>

      <div style={{
        background: 'var(--fw-cobalt-light)', borderRadius: 8,
        border: '1px solid #AABFEE',
        padding: '12px 16px', marginBottom: 20,
      }}>
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: '0.08em',
          textTransform: 'uppercase', color: 'var(--fw-cobalt)', marginBottom: 6,
        }}>Handoff sentence (shown to next writer)</div>
        <p style={{
          margin: 0, fontSize: 14, lineHeight: 1.6,
          color: 'var(--fw-aubergine)', fontStyle: 'italic',
        }}>{handoff}</p>
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        <button
          onClick={onSeal}
          style={{
            flex: 1, padding: '12px 20px',
            background: 'var(--fw-tangerine)', color: 'white',
            border: 'none', borderRadius: 8,
            fontFamily: 'var(--fw-font-display)', fontWeight: 700, fontSize: 14,
            cursor: 'pointer',
          }}
        >Seal this panel</button>
        <button
          onClick={onBack}
          style={{
            padding: '12px 20px',
            background: 'none', color: 'var(--fw-muted)',
            border: '1px solid var(--fw-lavender-mid)', borderRadius: 8,
            fontWeight: 500, fontSize: 14, cursor: 'pointer',
          }}
        >Edit</button>
      </div>
    </div>
  )
}

/* ──────────────────────────── Writing pane ──────────────────── */
function WritingPane({
  contributor,
  panelIndex,
  totalPanels,
  prevHandoff,
  prompt,
  isFirst,
  onSealPanel,
}: {
  contributor: string
  panelIndex: number
  totalPanels: number
  prevHandoff: string | null
  prompt: string
  isFirst: boolean
  onSealPanel: (body: string, handoff: string) => void
}) {
  const [body, setBody] = useState('')
  const [handoff, setHandoff] = useState('')
  const [showPreview, setShowPreview] = useState(false)
  const [errors, setErrors] = useState<{ body?: string; handoff?: string }>({})

  const bodyLen = countChars(body)
  const handoffLen = countChars(handoff)

  function validate(): boolean {
    const e: { body?: string; handoff?: string } = {}
    if (bodyLen < BODY_MIN) e.body = `At least ${BODY_MIN} characters required.`
    if (bodyLen > BODY_MAX) e.body = `Maximum ${BODY_MAX} characters.`
    if (handoffLen < HANDOFF_MIN) e.handoff = `At least ${HANDOFF_MIN} characters required.`
    if (handoffLen > HANDOFF_MAX) e.handoff = `Maximum ${HANDOFF_MAX} characters.`
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handlePreview() {
    if (validate()) setShowPreview(true)
  }

  if (showPreview) {
    return (
      <PreviewPane
        body={body}
        handoff={handoff}
        onBack={() => setShowPreview(false)}
        onSeal={() => onSealPanel(body, handoff)}
      />
    )
  }

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '12px',
    background: 'var(--fw-cream)', border: '1px solid var(--fw-lavender-mid)',
    borderRadius: 8, fontFamily: 'var(--fw-font-body)', fontSize: 14,
    color: 'var(--fw-aubergine)', outline: 'none', resize: 'vertical', lineHeight: 1.65,
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Progress */}
      <div style={{
        background: 'var(--fw-lavender-light)', borderRadius: 8,
        border: '1px solid var(--fw-lavender-mid)',
        padding: '12px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--fw-aubergine)' }}>
            Writing now: <strong>{contributor}</strong>
          </div>
          <div style={{ fontSize: 12, color: 'var(--fw-muted)', marginTop: 2 }}>
            Panel {panelIndex + 1} of {totalPanels}
          </div>
        </div>
        <div
          role="progressbar"
          aria-valuenow={panelIndex + 1}
          aria-valuemin={1}
          aria-valuemax={totalPanels}
          aria-label={`Panel ${panelIndex + 1} of ${totalPanels}`}
          style={{ display: 'flex', gap: 4 }}
        >
          {Array.from({ length: totalPanels }, (_, i) => (
            <div
              key={i}
              style={{
                width: 10, height: 10, borderRadius: '50%',
                background: i < panelIndex
                  ? 'var(--fw-tangerine)'
                  : i === panelIndex
                    ? 'var(--fw-cobalt)'
                    : 'var(--fw-lavender-mid)',
              }}
            />
          ))}
        </div>
      </div>

      {/* Handoff context or prompt */}
      <div style={{
        background: 'var(--fw-cobalt-light)',
        borderLeft: '3px solid var(--fw-cobalt)',
        borderRadius: '0 8px 8px 0', padding: '14px 16px',
      }}>
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: '0.08em',
          textTransform: 'uppercase', color: 'var(--fw-cobalt)', marginBottom: 6,
        }}>
          {isFirst ? 'Opening prompt' : 'The previous writer left you here'}
        </div>
        <p style={{
          margin: 0, fontSize: 14, lineHeight: 1.65,
          color: 'var(--fw-aubergine)',
          fontFamily: isFirst ? 'var(--fw-font-body)' : 'var(--fw-font-serif)',
          fontStyle: isFirst ? 'normal' : 'italic',
        }}>
          {isFirst ? prompt : prevHandoff}
        </p>
      </div>

      {/* Body textarea */}
      <div>
        <label
          htmlFor={`body-${panelIndex}`}
          style={{ display: 'block', fontWeight: 600, fontSize: 13, marginBottom: 6, color: 'var(--fw-aubergine)' }}
        >
          Your panel <span style={{ color: 'var(--fw-muted)', fontWeight: 400 }}>({BODY_MIN}–{BODY_MAX} chars)</span>
        </label>
        <textarea
          id={`body-${panelIndex}`}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Continue the story here…"
          rows={7}
          maxLength={BODY_MAX + 50}
          style={{ ...inputStyle, borderColor: errors.body ? '#B8371A' : 'var(--fw-lavender-mid)' }}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3 }}>
          {errors.body ? (
            <span role="alert" style={{ fontSize: 12, color: '#B8371A' }}>{errors.body}</span>
          ) : <span />}
          <span style={{
            fontSize: 11, color: bodyLen > BODY_MAX ? '#B8371A' : bodyLen >= BODY_MIN ? '#1A7A4A' : 'var(--fw-muted)',
            fontVariantNumeric: 'tabular-nums',
          }}>{bodyLen}/{BODY_MAX}</span>
        </div>
      </div>

      {/* Handoff textarea */}
      <div>
        <label
          htmlFor={`handoff-${panelIndex}`}
          style={{ display: 'block', fontWeight: 600, fontSize: 13, marginBottom: 4, color: 'var(--fw-aubergine)' }}
        >
          Handoff sentence{' '}
          <span style={{ color: 'var(--fw-muted)', fontWeight: 400 }}>
            — the one sentence the next writer will see ({HANDOFF_MIN}–{HANDOFF_MAX} chars)
          </span>
        </label>
        <textarea
          id={`handoff-${panelIndex}`}
          value={handoff}
          onChange={(e) => setHandoff(e.target.value)}
          placeholder="End with a hook that opens the next chapter…"
          rows={3}
          maxLength={HANDOFF_MAX + 20}
          style={{ ...inputStyle, borderColor: errors.handoff ? '#B8371A' : 'var(--fw-lavender-mid)' }}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 3 }}>
          {errors.handoff ? (
            <span role="alert" style={{ fontSize: 12, color: '#B8371A' }}>{errors.handoff}</span>
          ) : <span />}
          <span style={{
            fontSize: 11,
            color: handoffLen > HANDOFF_MAX ? '#B8371A' : handoffLen >= HANDOFF_MIN ? '#1A7A4A' : 'var(--fw-muted)',
            fontVariantNumeric: 'tabular-nums',
          }}>{handoffLen}/{HANDOFF_MAX}</span>
        </div>
      </div>

      <button
        onClick={handlePreview}
        style={{
          padding: '13px 20px',
          background: 'var(--fw-aubergine)', color: 'white',
          border: 'none', borderRadius: 8,
          fontFamily: 'var(--fw-font-display)', fontWeight: 700, fontSize: 14,
          cursor: 'pointer',
        }}
      >Preview panel</button>
    </div>
  )
}

/* ──────────────────────────── Sample preview mode ───────────── */
function SamplePreview({ relay, onBack }: { relay: Relay; onBack: () => void }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{
        background: 'var(--fw-tangerine-light)',
        border: '1px solid var(--fw-tangerine)',
        borderRadius: 8, padding: '10px 14px',
        fontSize: 13, color: 'var(--fw-aubergine)',
      }}>
        <strong>Preview only</strong> — this sample story is complete. You are reading the sealed panels.
      </div>
      {relay.panels.filter((p) => p.sealed).map((p) => (
        <div key={p.index} style={{
          background: 'var(--fw-lavender-light)', borderRadius: 10,
          border: '1px solid var(--fw-lavender-mid)', padding: '16px',
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, letterSpacing: '0.08em',
            textTransform: 'uppercase', color: 'var(--fw-muted)', marginBottom: 8,
          }}>Panel {p.index + 1} — {p.contributor}</div>
          <p style={{ margin: 0, fontSize: 14, lineHeight: 1.7, color: 'var(--fw-aubergine)' }}>
            {p.body}
          </p>
          <div style={{
            marginTop: 10, paddingTop: 10,
            borderTop: '1px solid var(--fw-lavender-mid)',
            fontSize: 12, color: 'var(--fw-cobalt)', fontStyle: 'italic',
          }}>
            Handoff: {p.handoff}
          </div>
        </div>
      ))}
      <button
        onClick={onBack}
        style={{
          padding: '12px 20px',
          background: 'var(--fw-aubergine)', color: 'white',
          border: 'none', borderRadius: 8,
          fontFamily: 'var(--fw-font-display)', fontWeight: 600, fontSize: 14,
          cursor: 'pointer',
        }}
      >Back to library</button>
    </div>
  )
}

/* ──────────────────────────── Writing Desk ──────────────────── */
interface WritingDeskProps {
  relay: Relay
  onNavigate: (view: View) => void
  onSealPanel: (relayId: string, panelIndex: number, body: string, handoff: string) => 'ok' | 'error'
}

type DeskState =
  | { phase: 'writing'; currentIndex: number }
  | { phase: 'privacy'; nextIndex: number }
  | { phase: 'done' }
  | { phase: 'sample-preview' }

export function WritingDesk({ relay, onNavigate, onSealPanel }: WritingDeskProps) {
  // Find the first unsealed panel
  const firstUnsealedIndex = relay.panels.findIndex((p) => !p.sealed)

  const [state, setState] = useState<DeskState>(() => {
    if (relay.status === 'complete') return { phase: 'done' }
    if (relay.id === 'demo-complete') return { phase: 'sample-preview' }
    if (firstUnsealedIndex === -1) return { phase: 'done' }
    return { phase: 'writing', currentIndex: firstUnsealedIndex }
  })

  function handleSeal(body: string, handoff: string) {
    if (state.phase !== 'writing') return
    const idx = state.currentIndex
    const result = onSealPanel(relay.id, idx, body, handoff)
    if (result !== 'ok') return

    const nextIdx = idx + 1
    if (nextIdx >= relay.panels.length) {
      // All done
      setState({ phase: 'done' })
    } else {
      setState({ phase: 'privacy', nextIndex: nextIdx })
    }
  }

  function handleReady() {
    if (state.phase !== 'privacy') return
    setState({ phase: 'writing', currentIndex: state.nextIndex })
  }

  const backToLib = () => onNavigate({ name: 'library' })

  if (state.phase === 'sample-preview') {
    return (
      <div style={{ minHeight: '100dvh', background: 'var(--fw-lavender)', padding: '0 0 80px' }}>
        <header style={{
          background: 'var(--fw-aubergine)', color: 'white',
          padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <button
            onClick={backToLib}
            aria-label="Back to library"
            style={{
              background: 'none', border: 'none', color: 'white',
              cursor: 'pointer', fontSize: 22, padding: '0 4px', lineHeight: 1,
            }}
          >←</button>
          <div>
            <h2 style={{ margin: 0, fontFamily: 'var(--fw-font-serif)', fontSize: 18, fontStyle: 'italic' }}>
              {relay.title}
            </h2>
          </div>
        </header>
        <main style={{ maxWidth: 540, margin: '0 auto', padding: '24px 16px' }}>
          <SamplePreview relay={relay} onBack={backToLib} />
        </main>
      </div>
    )
  }

  if (state.phase === 'privacy') {
    const nextPanel = relay.panels[state.nextIndex]
    return (
      <PrivacyCover
        nextContributor={nextPanel.contributor}
        onReady={handleReady}
      />
    )
  }

  if (state.phase === 'done') {
    // All sealed — redirect to reveal
    onNavigate({ name: 'reveal', relayId: relay.id })
    return null
  }

  // Writing phase
  const currentPanel = relay.panels[state.currentIndex]
  const prevPanel = state.currentIndex > 0 ? relay.panels[state.currentIndex - 1] : null

  return (
    <div style={{ minHeight: '100dvh', background: 'var(--fw-lavender)', paddingBottom: 80 }}>
      <header style={{
        background: 'var(--fw-aubergine)', color: 'white',
        padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <button
          onClick={backToLib}
          aria-label="Back to library"
          style={{
            background: 'none', border: 'none', color: 'white',
            cursor: 'pointer', fontSize: 22, padding: '0 4px', lineHeight: 1,
          }}
        >←</button>
        <div>
          <h2 style={{ margin: 0, fontFamily: 'var(--fw-font-serif)', fontSize: 18, fontStyle: 'italic' }}>
            {relay.title}
          </h2>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', marginTop: 2 }}>
            Pass-and-play — one browser only. Local data is not encrypted.
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 540, margin: '0 auto', padding: '24px 16px' }}>
        <WritingPane
          key={state.currentIndex}
          contributor={currentPanel.contributor}
          panelIndex={state.currentIndex}
          totalPanels={relay.panels.length}
          prevHandoff={prevPanel?.handoff ?? null}
          prompt={relay.prompt}
          isFirst={state.currentIndex === 0}
          onSealPanel={handleSeal}
        />
      </main>
    </div>
  )
}
