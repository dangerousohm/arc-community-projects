// Folded Worlds — USDC split calculator
// All arithmetic in integer micro-USDC (6 decimal places = 1e6 per unit)
// This is a SIMULATION only. No wallet requests, no onchain transactions.

export interface SplitResult {
  totalMicroUsdc: bigint
  shares: { contributor: string; microUsdc: bigint; display: string }[]
  platformFeeMicroUsdc: bigint
  remainderExplanation: string
  valid: true
}

export interface SplitError {
  valid: false
  message: string
}

const MICRO = 1_000_000n // 1 USDC = 1,000,000 micro-USDC
const MAX_USDC = 1_000_000_000n // 1 billion USDC hard cap

/** Parse a decimal USDC string to micro-USDC bigint, with full validation. */
export function parseUsdcInput(raw: string): bigint | null {
  const trimmed = raw.trim()
  if (!trimmed) return null
  // Allow up to 6 decimal places
  if (!/^\d+(\.\d{1,6})?$/.test(trimmed)) return null
  const [intPart, fracPart = ''] = trimmed.split('.')
  const paddedFrac = fracPart.padEnd(6, '0')
  try {
    const result = BigInt(intPart) * MICRO + BigInt(paddedFrac)
    return result
  } catch {
    return null
  }
}

/** Format micro-USDC bigint to a human-readable USDC string with 6 dp. */
export function formatMicroUsdc(microUsdc: bigint): string {
  const negative = microUsdc < 0n
  const abs = negative ? -microUsdc : microUsdc
  const int = abs / MICRO
  const frac = (abs % MICRO).toString().padStart(6, '0')
  return `${negative ? '-' : ''}${int}.${frac}`
}

export function calculateSplit(
  usdcAmountStr: string,
  contributors: string[],
): SplitResult | SplitError {
  if (!contributors.length) return { valid: false, message: 'No contributors.' }

  const microUsdc = parseUsdcInput(usdcAmountStr)

  if (microUsdc === null) {
    return { valid: false, message: 'Enter a valid amount (up to 6 decimal places).' }
  }
  if (microUsdc < 0n) {
    return { valid: false, message: 'Amount must not be negative.' }
  }
  if (microUsdc > MAX_USDC * MICRO) {
    return { valid: false, message: 'Amount exceeds maximum allowed (1,000,000,000 USDC).' }
  }

  const n = BigInt(contributors.length)
  const base = microUsdc / n
  const remainder = microUsdc % n

  const shares = contributors.map((c, i) => {
    // Deterministic: first `remainder` contributors each get 1 extra micro-USDC
    const extra = BigInt(i) < remainder ? 1n : 0n
    const micro = base + extra
    return { contributor: c, microUsdc: micro, display: formatMicroUsdc(micro) }
  })

  // Verify sum equals total exactly
  const sum = shares.reduce((a, s) => a + s.microUsdc, 0n)
  if (sum !== microUsdc) {
    return { valid: false, message: 'Internal rounding error — please report this.' }
  }

  const remainderExplanation =
    remainder === 0n
      ? 'Divides evenly — no rounding.'
      : `${remainder} micro-USDC remainder distributed to the first ${remainder} contributor${remainder === 1n ? '' : 's'} in order.`

  return {
    valid: true,
    totalMicroUsdc: microUsdc,
    shares,
    platformFeeMicroUsdc: 0n,
    remainderExplanation,
  }
}
