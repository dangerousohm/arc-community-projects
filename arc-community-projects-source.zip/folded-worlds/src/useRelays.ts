// Folded Worlds — relay state hook with localStorage persistence
import { useState, useCallback } from 'react'
import { toast } from 'sonner'
import type { Relay } from './types'
import { SCHEMA_VERSION } from './types'
import { loadRelays, saveRelays, generateId } from './storage'
import { SEED_RELAYS } from './seedData'
import { sealPanel as pureSealPanel } from './relayLogic'

export interface CreateRelayInput {
  title: string
  prompt: string
  contributors: string[]
}

function persist(relays: Relay[]): void {
  const result = saveRelays(relays)
  if (result === 'quota') {
    toast.warning('Storage quota exceeded — changes are NOT saved. Delete a relay to free space.')
  } else if (result === 'error') {
    toast.error('Could not save to local storage — changes may be lost.')
  }
}

// Lazy initialiser — runs once on mount
function init(): Relay[] {
  const stored = loadRelays()
  // Always keep demo relays fresh (by id prefix); merge with user relays
  const userRelays = stored.filter((r) => !r.id.startsWith('demo-'))
  return [...SEED_RELAYS, ...userRelays]
}

export function useRelays() {
  const [relays, setRelays] = useState<Relay[]>(init)

  const userRelays = relays.filter((r) => !r.id.startsWith('demo-'))

  const persistUserRelays = useCallback(
    (next: Relay[]) => {
      setRelays(next)
      const userOnly = next.filter((r) => !r.id.startsWith('demo-'))
      persist(userOnly)
    },
    [],
  )

  const getRelay = useCallback(
    (id: string) => relays.find((r) => r.id === id) ?? null,
    [relays],
  )

  const createRelay = useCallback(
    (input: CreateRelayInput): string => {
      const id = generateId()
      const newRelay: Relay = {
        id,
        title: input.title.trim(),
        prompt: input.prompt.trim(),
        contributors: input.contributors.map((c) => c.trim()),
        shares: input.contributors.map(() => 1),
        panels: input.contributors.map((c, i) => ({
          index: i,
          contributor: c.trim(),
          body: '',
          handoff: '',
          sealed: false,
        })),
        status: 'draft',
        createdAt: new Date().toISOString(),
        schemaVersion: SCHEMA_VERSION,
      }
      persistUserRelays([...relays, newRelay])
      return id
    },
    [relays, persistUserRelays],
  )

  const deleteRelay = useCallback(
    (id: string) => {
      if (id.startsWith('demo-')) return // Cannot delete demos
      persistUserRelays(relays.filter((r) => r.id !== id))
    },
    [relays, persistUserRelays],
  )

  const sealPanel = useCallback(
    (relayId: string, panelIndex: number, body: string, handoff: string): 'ok' | 'error' => {
      const relay = relays.find((r) => r.id === relayId)
      if (!relay) return 'error'

      // Delegate all validation and state construction to the pure shared function
      const result = pureSealPanel(relay, panelIndex, body, handoff)
      if (!result.ok) return 'error'

      const updatedRelay = result.relay
      const next = relays.map((r) => (r.id === relayId ? updatedRelay : r))
      if (relayId.startsWith('demo-')) {
        setRelays(next) // demo changes are not persisted to localStorage
      } else {
        persistUserRelays(next)
      }
      return 'ok'
    },
    [relays, persistUserRelays],
  )

  const resetDemos = useCallback(() => {
    const userOnly = relays.filter((r) => !r.id.startsWith('demo-'))
    const next = [...SEED_RELAYS, ...userOnly]
    setRelays(next)
    // Persist user relays (demos not stored)
    persist(userOnly)
  }, [relays])

  return {
    relays,
    userRelays,
    getRelay,
    createRelay,
    deleteRelay,
    sealPanel,
    resetDemos,
  }
}
