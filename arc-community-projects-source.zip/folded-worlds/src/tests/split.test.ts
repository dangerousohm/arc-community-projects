// Split calculator tests — bun test
import { describe, it, expect } from 'bun:test'
import { calculateSplit, parseUsdcInput, formatMicroUsdc } from '../split'

describe('parseUsdcInput', () => {
  it('parses whole numbers', () => {
    expect(parseUsdcInput('10')).toBe(10_000_000n)
  })
  it('parses 6 decimal places', () => {
    expect(parseUsdcInput('1.000001')).toBe(1_000_001n)
  })
  it('parses zero', () => {
    expect(parseUsdcInput('0')).toBe(0n)
  })
  it('rejects empty string', () => {
    expect(parseUsdcInput('')).toBeNull()
  })
  it('rejects negative sign', () => {
    expect(parseUsdcInput('-1')).toBeNull()
  })
  it('rejects more than 6 dp', () => {
    expect(parseUsdcInput('1.1234567')).toBeNull()
  })
  it('rejects letters', () => {
    expect(parseUsdcInput('abc')).toBeNull()
  })
  it('handles leading dot', () => {
    // ".5" doesn't match /^\d+/ — should return null
    expect(parseUsdcInput('.5')).toBeNull()
  })
})

describe('formatMicroUsdc', () => {
  it('formats 1 USDC', () => {
    expect(formatMicroUsdc(1_000_000n)).toBe('1.000000')
  })
  it('formats 0', () => {
    expect(formatMicroUsdc(0n)).toBe('0.000000')
  })
  it('formats 1 micro-USDC', () => {
    expect(formatMicroUsdc(1n)).toBe('0.000001')
  })
  it('round-trips parse+format', () => {
    const micro = parseUsdcInput('99.999999')!
    expect(formatMicroUsdc(micro)).toBe('99.999999')
  })
})

describe('calculateSplit — validation', () => {
  it('rejects empty contributors list', () => {
    const r = calculateSplit('10', [])
    expect(r.valid).toBe(false)
  })
  it('rejects invalid amount string', () => {
    const r = calculateSplit('abc', ['Alice'])
    expect(r.valid).toBe(false)
  })
  it('rejects negative amount', () => {
    // parseUsdcInput rejects negative sign already, so invalid
    const r = calculateSplit('-1', ['Alice'])
    expect(r.valid).toBe(false)
  })
  it('rejects oversized amount', () => {
    const r = calculateSplit('1000000001', ['Alice'])
    expect(r.valid).toBe(false)
    if (!r.valid) expect(r.message).toMatch(/maximum/)
  })
})

describe('calculateSplit — arithmetic', () => {
  it('zero amount splits to zero for all', () => {
    const r = calculateSplit('0', ['A', 'B', 'C'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    for (const s of r.shares) expect(s.microUsdc).toBe(0n)
  })

  it('single contributor gets everything', () => {
    const r = calculateSplit('5.000000', ['Solo'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    expect(r.shares[0].microUsdc).toBe(5_000_000n)
  })

  it('even split produces no remainder', () => {
    const r = calculateSplit('3.000000', ['A', 'B', 'C'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    for (const s of r.shares) expect(s.microUsdc).toBe(1_000_000n)
    expect(r.remainderExplanation).toMatch(/evenly/)
  })

  it('uneven split: sum equals total exactly', () => {
    const r = calculateSplit('1.000000', ['A', 'B', 'C'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    const sum = r.shares.reduce((acc, s) => acc + s.microUsdc, 0n)
    expect(sum).toBe(1_000_000n)
  })

  it('1 micro-USDC split among 3: first gets 1, rest get 0', () => {
    const r = calculateSplit('0.000001', ['A', 'B', 'C'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    expect(r.shares[0].microUsdc).toBe(1n)
    expect(r.shares[1].microUsdc).toBe(0n)
    expect(r.shares[2].microUsdc).toBe(0n)
    const sum = r.shares.reduce((acc, s) => acc + s.microUsdc, 0n)
    expect(sum).toBe(1n)
  })

  it('remainder distributed to first N contributors in order', () => {
    // 10.000002 / 3 = 3.333334, 3.333334, 3.333334 => base=3333334, rem=2
    const r = calculateSplit('10.000002', ['A', 'B', 'C'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    expect(r.shares[0].microUsdc).toBe(3_333_334n)
    expect(r.shares[1].microUsdc).toBe(3_333_334n)
    expect(r.shares[2].microUsdc).toBe(3_333_334n)
    const sum = r.shares.reduce((acc, s) => acc + s.microUsdc, 0n)
    expect(sum).toBe(10_000_002n)
  })

  it('large safe input: 999999.999999 among 2', () => {
    const r = calculateSplit('999999.999999', ['A', 'B'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    const sum = r.shares.reduce((acc, s) => acc + s.microUsdc, 0n)
    expect(sum).toBe(999_999_999_999n)
  })

  it('platform fee is always zero', () => {
    const r = calculateSplit('100', ['A', 'B'])
    expect(r.valid).toBe(true)
    if (!r.valid) return
    expect(r.platformFeeMicroUsdc).toBe(0n)
  })
})
