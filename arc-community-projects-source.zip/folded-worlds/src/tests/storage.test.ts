// Storage validation tests — bun test
import { describe, it, expect, beforeEach, afterEach } from 'bun:test'
import { loadRelays, saveRelays, generateId } from '../storage'
import type { Relay } from '../types'
import { SCHEMA_VERSION } from '../types'

// Minimal in-memory localStorage mock for bun
const store: Record<string, string> = {}
const localStorageMock = {
  getItem: (k: string) => store[k] ?? null,
  setItem: (k: string, v: string) => { store[k] = v },
  removeItem: (k: string) => { delete store[k] },
  clear: () => { for (const k in store) delete store[k] },
}

// Patch global
if (typeof globalThis.localStorage === 'undefined') {
  Object.defineProperty(globalThis, 'localStorage', {
    value: localStorageMock,
    writable: true,
  })
} else {
  // If it exists, replace
  ;(globalThis as unknown as { localStorage: typeof localStorageMock }).localStorage = localStorageMock
}

function makeRelay(overrides: Partial<Relay> = {}): Relay {
  return {
    id: 'test-' + Math.random().toString(36).slice(2),
    title: 'Test Relay',
    prompt: 'A test prompt',
    contributors: ['Alice', 'Bob'],
    shares: [1, 1],
    panels: [
      { index: 0, contributor: 'Alice', body: '', handoff: '', sealed: false },
      { index: 1, contributor: 'Bob', body: '', handoff: '', sealed: false },
    ],
    status: 'draft',
    createdAt: new Date().toISOString(),
    schemaVersion: SCHEMA_VERSION,
    ...overrides,
  }
}

describe('loadRelays', () => {
  beforeEach(() => localStorageMock.clear())
  afterEach(() => localStorageMock.clear())

  it('returns empty array when storage is empty', () => {
    expect(loadRelays()).toEqual([])
  })

  it('returns empty array on malformed JSON', () => {
    store['foldedWorlds_relays_v1'] = 'not json {'
    expect(loadRelays()).toEqual([])
  })

  it('returns empty array when stored value is not an array', () => {
    store['foldedWorlds_relays_v1'] = JSON.stringify({ hello: 'world' })
    expect(loadRelays()).toEqual([])
  })

  it('filters out malformed records, preserves valid ones', () => {
    const good = makeRelay()
    const bad = { id: 123, title: null }
    store['foldedWorlds_relays_v1'] = JSON.stringify([good, bad])
    const result = loadRelays()
    expect(result.length).toBe(1)
    expect(result[0].id).toBe(good.id)
  })

  it('returns a valid relay intact', () => {
    const relay = makeRelay()
    store['foldedWorlds_relays_v1'] = JSON.stringify([relay])
    const result = loadRelays()
    expect(result.length).toBe(1)
    expect(result[0].title).toBe('Test Relay')
  })

  it('returns empty array when all records are malformed', () => {
    store['foldedWorlds_relays_v1'] = JSON.stringify([{ broken: true }, null, 42])
    expect(loadRelays()).toEqual([])
  })
})

describe('saveRelays', () => {
  beforeEach(() => localStorageMock.clear())
  afterEach(() => localStorageMock.clear())

  it('returns ok on successful save', () => {
    const result = saveRelays([makeRelay()])
    expect(result).toBe('ok')
  })

  it('persisted data can be loaded back', () => {
    const relay = makeRelay({ title: 'Persisted Story' })
    saveRelays([relay])
    const loaded = loadRelays()
    expect(loaded.length).toBe(1)
    expect(loaded[0].title).toBe('Persisted Story')
  })
})

describe('generateId', () => {
  it('returns a non-empty string', () => {
    const id = generateId()
    expect(typeof id).toBe('string')
    expect(id.length).toBeGreaterThan(0)
  })

  it('generates distinct ids', () => {
    const ids = new Set(Array.from({ length: 20 }, () => generateId()))
    expect(ids.size).toBe(20)
  })
})
