// Relay state-machine tests — bun test
// Imports PRODUCTION logic from relayLogic.ts and types.ts.
// No local mirrors of seal/validation logic.
import { describe, it, expect } from 'bun:test'
import type { Relay, Panel } from '../types'
import { SCHEMA_VERSION } from '../types'
import {
  sealPanel,
  validateCreateForm,
  BODY_MIN,
  BODY_MAX,
  HANDOFF_MIN,
  HANDOFF_MAX,
  TITLE_MAX,
  PROMPT_MAX,
  CONTRIBUTOR_MAX_LEN,
  CONTRIBUTORS_MAX,
} from '../relayLogic'

// ── Helpers ──────────────────────────────────────────────────────────────────

function makeRelay(numContributors: number, overrides: Partial<Relay> = {}): Relay {
  const contributors = Array.from({ length: numContributors }, (_, i) => `Writer${i + 1}`)
  const panels: Panel[] = contributors.map((c, i) => ({
    index: i,
    contributor: c,
    body: '',
    handoff: '',
    sealed: false,
  }))
  return {
    id: `relay-${Math.random().toString(36).slice(2)}`,
    title: 'Test',
    prompt: 'Test prompt',
    contributors,
    shares: contributors.map(() => 1),
    panels,
    status: 'draft',
    createdAt: new Date().toISOString(),
    schemaVersion: SCHEMA_VERSION,
    ...overrides,
  }
}

/** Minimal valid body/handoff that satisfies length constraints. */
const VALID_BODY = 'A'.repeat(BODY_MIN)
const VALID_HANDOFF = 'B'.repeat(HANDOFF_MIN)

// ── sealPanel: cannot reveal early ───────────────────────────────────────────

describe('cannot reveal before all panels sealed', () => {
  it('fresh relay is not complete', () => {
    const relay = makeRelay(3)
    expect(relay.status).not.toBe('complete')
    expect(relay.panels.every((p) => p.sealed)).toBe(false)
  })

  it('not complete after sealing 1 of 3', () => {
    const relay = makeRelay(3)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    expect(r1.relay.status).not.toBe('complete')
    expect(r1.relay.panels.every((p) => p.sealed)).toBe(false)
  })

  it('not complete after sealing 2 of 3', () => {
    const relay = makeRelay(3)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    const r2 = sealPanel(r1.relay, 1, VALID_BODY, VALID_HANDOFF)
    expect(r2.ok).toBe(true)
    if (!r2.ok) return
    expect(r2.relay.status).not.toBe('complete')
  })

  it('becomes complete only when all 3 of 3 are sealed', () => {
    const relay = makeRelay(3)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    const r2 = sealPanel(r1.relay, 1, VALID_BODY, VALID_HANDOFF)
    expect(r2.ok).toBe(true)
    if (!r2.ok) return
    const r3 = sealPanel(r2.relay, 2, VALID_BODY, VALID_HANDOFF)
    expect(r3.ok).toBe(true)
    if (!r3.ok) return
    expect(r3.relay.status).toBe('complete')
    expect(r3.relay.panels.every((p) => p.sealed)).toBe(true)
  })
})

// ── sealPanel: cannot seal twice ─────────────────────────────────────────────

describe('cannot seal a panel twice', () => {
  it('returns ok:false when sealing an already-sealed panel', () => {
    const relay = makeRelay(2)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    const r2 = sealPanel(r1.relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r2.ok).toBe(false)
  })

  it('body of sealed panel unchanged after rejected second attempt', () => {
    const relay = makeRelay(2)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    // Attempt to re-seal with different body — must be rejected, original preserved
    const r2 = sealPanel(r1.relay, 0, 'Z'.repeat(BODY_MIN), VALID_HANDOFF)
    expect(r2.ok).toBe(false)
    // Relay is untouched — use the pre-attempt relay
    expect(r1.relay.panels[0].body).toBe(VALID_BODY)
  })
})

// ── sealPanel: strict ordering ────────────────────────────────────────────────

describe('strict ordering — index must equal first unsealed', () => {
  it('allows sealing in order 0 → 1 → 2', () => {
    const relay = makeRelay(3)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    const r2 = sealPanel(r1.relay, 1, VALID_BODY, VALID_HANDOFF)
    expect(r2.ok).toBe(true)
    if (!r2.ok) return
    const r3 = sealPanel(r2.relay, 2, VALID_BODY, VALID_HANDOFF)
    expect(r3.ok).toBe(true)
    if (!r3.ok) return
    expect(r3.relay.status).toBe('complete')
  })

  // Regression: index 2 must be rejected before index 0 is sealed
  it('REGRESSION: index 2 cannot seal before index 0', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, 2, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/[Oo]ut-of-order/)
  })

  // Regression: index 1 cannot seal before index 0
  it('REGRESSION: index 1 cannot seal before index 0', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, 1, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/[Oo]ut-of-order/)
  })

  it('cannot seal index 2 before index 1 (when index 0 is already sealed)', () => {
    const relay = makeRelay(3)
    const r1 = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(r1.ok).toBe(true)
    if (!r1.ok) return
    const result = sealPanel(r1.relay, 2, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/[Oo]ut-of-order/)
  })
})

// ── sealPanel: invalid index values ──────────────────────────────────────────

describe('invalid panel index values', () => {
  it('rejects negative index', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, -1, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })

  it('rejects index equal to panels.length (out of range)', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, 3, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })

  it('rejects index far out of range', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, 99, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })

  // Regression: NaN must be rejected (was previously unchecked)
  it('REGRESSION: rejects NaN index', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, NaN, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.error).toMatch(/[Ii]nvalid panel index/)
  })

  it('rejects non-integer index (1.5)', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, 1.5, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })

  it('rejects Infinity index', () => {
    const relay = makeRelay(3)
    const result = sealPanel(relay, Infinity, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })
})

// ── sealPanel: body/handoff length enforcement ────────────────────────────────

describe('body and handoff length enforcement', () => {
  it('rejects body shorter than BODY_MIN', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, 'A'.repeat(BODY_MIN - 1), VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })

  it('rejects body longer than BODY_MAX', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, 'A'.repeat(BODY_MAX + 1), VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })

  it('accepts body exactly at BODY_MIN', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, 'A'.repeat(BODY_MIN), VALID_HANDOFF)
    expect(result.ok).toBe(true)
  })

  it('accepts body exactly at BODY_MAX', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, 'A'.repeat(BODY_MAX), VALID_HANDOFF)
    expect(result.ok).toBe(true)
  })

  it('rejects handoff shorter than HANDOFF_MIN', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, VALID_BODY, 'B'.repeat(HANDOFF_MIN - 1))
    expect(result.ok).toBe(false)
  })

  it('rejects handoff longer than HANDOFF_MAX', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, VALID_BODY, 'B'.repeat(HANDOFF_MAX + 1))
    expect(result.ok).toBe(false)
  })

  it('accepts handoff exactly at HANDOFF_MIN', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, VALID_BODY, 'B'.repeat(HANDOFF_MIN))
    expect(result.ok).toBe(true)
  })

  it('accepts handoff exactly at HANDOFF_MAX', () => {
    const relay = makeRelay(2)
    const result = sealPanel(relay, 0, VALID_BODY, 'B'.repeat(HANDOFF_MAX))
    expect(result.ok).toBe(true)
  })
})

// ── sealPanel: complete relay rejects further seals ───────────────────────────

describe('complete relay blocks further seals', () => {
  it('returns ok:false when relay.status is complete', () => {
    // Build a relay that is already marked complete
    const relay = makeRelay(1, { status: 'complete' })
    // Mark the single panel as already sealed too, to be safe
    relay.panels[0].sealed = true
    const result = sealPanel(relay, 0, VALID_BODY, VALID_HANDOFF)
    expect(result.ok).toBe(false)
  })
})

// ── sealPanel: state not mutated on rejection ────────────────────────────────

describe('state is not mutated on rejection', () => {
  it('original relay panels unchanged after a rejected seal', () => {
    const relay = makeRelay(3)
    // Attempt to seal index 2 out-of-order — should fail
    sealPanel(relay, 2, VALID_BODY, VALID_HANDOFF)
    // Original panels untouched
    expect(relay.panels[2].sealed).toBe(false)
    expect(relay.panels[2].body).toBe('')
    expect(relay.status).toBe('draft')
  })

  it('original relay panels unchanged after invalid index', () => {
    const relay = makeRelay(3)
    sealPanel(relay, -1, VALID_BODY, VALID_HANDOFF)
    expect(relay.panels[0].sealed).toBe(false)
    expect(relay.status).toBe('draft')
  })
})

// ── validateCreateForm ────────────────────────────────────────────────────────

describe('validateCreateForm', () => {
  it('accepts valid input', () => {
    const r = validateCreateForm('My Story', 'A prompt here', ['Alice', 'Bob'])
    expect(r.valid).toBe(true)
  })

  it('rejects empty title', () => {
    const r = validateCreateForm('', 'prompt', ['A', 'B'])
    expect(r.valid).toBe(false)
    if (r.valid) return
    expect(r.error).toMatch(/[Tt]itle.*required/)
  })

  it('rejects title over TITLE_MAX characters', () => {
    const r = validateCreateForm('A'.repeat(TITLE_MAX + 1), 'prompt', ['A', 'B'])
    expect(r.valid).toBe(false)
  })

  it('accepts title exactly at TITLE_MAX characters', () => {
    const r = validateCreateForm('A'.repeat(TITLE_MAX), 'prompt', ['A', 'B'])
    expect(r.valid).toBe(true)
  })

  it('rejects empty prompt', () => {
    const r = validateCreateForm('Title', '', ['A', 'B'])
    expect(r.valid).toBe(false)
    if (r.valid) return
    expect(r.error).toMatch(/[Pp]rompt.*required/)
  })

  it('rejects prompt over PROMPT_MAX characters', () => {
    const r = validateCreateForm('Title', 'P'.repeat(PROMPT_MAX + 1), ['A', 'B'])
    expect(r.valid).toBe(false)
  })

  it('rejects fewer than CONTRIBUTORS_MIN contributors', () => {
    const r = validateCreateForm('T', 'P', ['Solo'])
    expect(r.valid).toBe(false)
    if (r.valid) return
    expect(r.error).toMatch(/at least/)
  })

  it('rejects more than CONTRIBUTORS_MAX contributors', () => {
    const names = Array.from({ length: CONTRIBUTORS_MAX + 1 }, (_, i) => `Writer${i + 1}`)
    const r = validateCreateForm('T', 'P', names)
    expect(r.valid).toBe(false)
    if (r.valid) return
    expect(r.error).toMatch(/[Mm]aximum/)
  })

  it('accepts exactly CONTRIBUTORS_MAX contributors', () => {
    const names = Array.from({ length: CONTRIBUTORS_MAX }, (_, i) => `Writer${i + 1}`)
    const r = validateCreateForm('T', 'P', names)
    expect(r.valid).toBe(true)
  })

  it('rejects duplicate contributor names (case-insensitive)', () => {
    const r = validateCreateForm('T', 'P', ['Alice', 'alice'])
    expect(r.valid).toBe(false)
    if (r.valid) return
    expect(r.error).toMatch(/unique/)
  })

  it('rejects contributor name over CONTRIBUTOR_MAX_LEN', () => {
    const long = 'A'.repeat(CONTRIBUTOR_MAX_LEN + 1)
    const r = validateCreateForm('T', 'P', ['Alice', long])
    expect(r.valid).toBe(false)
  })

  it('accepts contributor name exactly at CONTRIBUTOR_MAX_LEN', () => {
    const exact = 'A'.repeat(CONTRIBUTOR_MAX_LEN)
    const r = validateCreateForm('T', 'P', ['Alice', exact])
    expect(r.valid).toBe(true)
  })
})
