// Folded Worlds — pure relay logic (no React, no side effects)
// This module is imported by useRelays.ts AND by the test suite.
// All functions are deterministic and return new values; none mutate inputs.

import type { Relay } from './types'

// ── Constants ────────────────────────────────────────────────────────────────

export const BODY_MIN = 30
export const BODY_MAX = 600
export const HANDOFF_MIN = 5
export const HANDOFF_MAX = 160

export const TITLE_MAX = 120
export const PROMPT_MAX = 600
export const CONTRIBUTOR_MAX_LEN = 40
export const CONTRIBUTORS_MIN = 2
export const CONTRIBUTORS_MAX = 6

// ── sealPanel result ─────────────────────────────────────────────────────────

export type SealResult =
  | { ok: true; relay: Relay }
  | { ok: false; error: string }

/**
 * Attempt to seal a panel on a relay.
 *
 * Rules enforced here (production logic — tested directly):
 *  1. panelIndex must be a safe integer in [0, panels.length).
 *     NaN, negative, out-of-range, and non-integer values are rejected.
 *  2. panelIndex must equal the index of the first unsealed panel
 *     (strict ordering — cannot skip ahead).
 *  3. The relay must not already be complete.
 *  4. The targeted panel must not already be sealed.
 *  5. body (trimmed) must be [BODY_MIN, BODY_MAX] characters.
 *  6. handoff (trimmed) must be [HANDOFF_MIN, HANDOFF_MAX] characters.
 *
 * On any failure, the original relay is returned unchanged (no mutation).
 */
export function sealPanel(
  relay: Relay,
  panelIndex: number,
  body: string,
  handoff: string,
): SealResult {
  // ── 1. Index validity ────────────────────────────────────────────────────
  if (
    !Number.isSafeInteger(panelIndex) ||
    panelIndex < 0 ||
    panelIndex >= relay.panels.length
  ) {
    return {
      ok: false,
      error: `Invalid panel index: ${panelIndex}. Must be an integer in [0, ${relay.panels.length - 1}].`,
    }
  }

  // ── 2. Strict ordering: must be the first unsealed panel ────────────────
  const firstUnsealedIndex = relay.panels.findIndex((p) => !p.sealed)
  if (firstUnsealedIndex === -1) {
    // All panels already sealed — relay is complete
    return { ok: false, error: 'All panels are already sealed.' }
  }
  if (panelIndex !== firstUnsealedIndex) {
    return {
      ok: false,
      error: `Out-of-order: panel ${panelIndex} cannot be sealed before panel ${firstUnsealedIndex}.`,
    }
  }

  // ── 3. Already complete ──────────────────────────────────────────────────
  if (relay.status === 'complete') {
    return { ok: false, error: 'Relay is already complete.' }
  }

  // ── 4. Panel already sealed ──────────────────────────────────────────────
  const panel = relay.panels[panelIndex]
  if (panel.sealed) {
    return { ok: false, error: `Panel ${panelIndex} is already sealed.` }
  }

  // ── 5. Body length ───────────────────────────────────────────────────────
  const bodyTrimmed = body.trim()
  const bodyLen = [...bodyTrimmed].length
  if (bodyLen < BODY_MIN) {
    return { ok: false, error: `Panel body must be at least ${BODY_MIN} characters.` }
  }
  if (bodyLen > BODY_MAX) {
    return { ok: false, error: `Panel body must be at most ${BODY_MAX} characters.` }
  }

  // ── 6. Handoff length ────────────────────────────────────────────────────
  const handoffTrimmed = handoff.trim()
  const handoffLen = [...handoffTrimmed].length
  if (handoffLen < HANDOFF_MIN) {
    return { ok: false, error: `Handoff must be at least ${HANDOFF_MIN} characters.` }
  }
  if (handoffLen > HANDOFF_MAX) {
    return { ok: false, error: `Handoff must be at most ${HANDOFF_MAX} characters.` }
  }

  // ── Apply ────────────────────────────────────────────────────────────────
  const updatedPanels = relay.panels.map((p) =>
    p.index === panelIndex
      ? { ...p, body: bodyTrimmed, handoff: handoffTrimmed, sealed: true }
      : p,
  )
  const allSealed = updatedPanels.every((p) => p.sealed)

  return {
    ok: true,
    relay: {
      ...relay,
      panels: updatedPanels,
      status: allSealed ? 'complete' : 'active',
    },
  }
}

// ── Create-relay form validation ─────────────────────────────────────────────

export type ValidationResult =
  | { valid: true }
  | { valid: false; error: string }

/**
 * Validate the create-relay form fields.
 * Accepts the raw (possibly untrimmed) values from the form.
 * Returns { valid: true } or { valid: false, error: string }.
 */
export function validateCreateForm(
  title: string,
  prompt: string,
  contributors: string[],
): ValidationResult {
  if (!title.trim()) return { valid: false, error: 'Title is required.' }
  if (title.trim().length > TITLE_MAX) {
    return { valid: false, error: `Title must be ${TITLE_MAX} characters or fewer.` }
  }
  if (!prompt.trim()) return { valid: false, error: 'Opening prompt is required.' }
  if (prompt.trim().length > PROMPT_MAX) {
    return { valid: false, error: `Prompt must be ${PROMPT_MAX} characters or fewer.` }
  }
  const filled = contributors.filter((c) => c.trim())
  if (filled.length < CONTRIBUTORS_MIN) {
    return { valid: false, error: `Add at least ${CONTRIBUTORS_MIN} contributors.` }
  }
  if (filled.length > CONTRIBUTORS_MAX) {
    return { valid: false, error: `Maximum ${CONTRIBUTORS_MAX} contributors.` }
  }
  const lower = filled.map((c) => c.trim().toLowerCase())
  const unique = new Set(lower)
  if (unique.size !== lower.length) {
    return { valid: false, error: 'Contributor names must be unique.' }
  }
  for (const c of filled) {
    if (c.trim().length > CONTRIBUTOR_MAX_LEN) {
      return { valid: false, error: `Each contributor name must be ${CONTRIBUTOR_MAX_LEN} characters or fewer.` }
    }
  }
  return { valid: true }
}
