# Folded Worlds — Project Memory

## What this project is
A compact, polished collaborative story relay app (no backend, no auth, no blockchain integration). Writers take turns sealing panels; only the last handoff sentence is shown to the next writer. When all panels are sealed the full story unfolds with a CSS paper animation, contributor credits, a printable zine layout, and a USDC split calculator (simulation only).

## Key files
| Path | Role |
|---|---|
| `src/types.ts` | Shared TypeScript types: `Relay`, `Panel`, `View`, `SCHEMA_VERSION` |
| `src/storage.ts` | `loadRelays` / `saveRelays` with JSON validation; `generateId` |
| `src/split.ts` | Pure USDC split calculator in integer micro-USDC (bigint) |
| `src/seedData.ts` | Three fictional seed relays (complete, active, draft) |
| `src/useRelays.ts` | React hook: relay state, `createRelay`, `sealPanel`, `deleteRelay`, `resetDemos` |
| `src/App.tsx` | Thin routing root (library / desk / reveal) |
| `src/components/Library.tsx` | Library view: relay cards, create form, validation |
| `src/components/WritingDesk.tsx` | Writing Desk: pass-and-play, privacy cover, panel sealing |
| `src/components/RevealCredits.tsx` | Reveal: unfold animation, credits, split calc, JSON export |
| `src/index.css` | CSS design tokens (aubergine/lavender/tangerine/cobalt palette) + unfold animation |
| `src/tests/split.test.ts` | 24 unit tests for split/parse/format |
| `src/tests/storage.test.ts` | 10 unit tests for localStorage layer |
| `src/tests/relayState.test.ts` | 17 unit tests for state transitions and validation |

## Deployed contracts
None — this app has no smart contracts.

## Test results (last run)
51 tests, 0 failures, 82 expect() calls. `bun test src/tests/`

## Lint/typecheck/build
All pass. Test files excluded from `tsc --noEmit` (uses `bun-types` which conflicts with DOM fetch type in tracing.ts). `@types/bun` installed for IDE support.

## Design tokens
- `--fw-aubergine`: #2D1B3D (primary ink)
- `--fw-lavender`: #E8E0F0 (paper background)
- `--fw-tangerine`: #E8650A (stamp/seal accent)
- `--fw-cobalt`: #1B4FCC (links/progress)
- Fonts: Space Grotesk (display), DM Serif Display (story prose), DM Sans (UI)

## Storage key
`foldedWorlds_relays_v1` — only user relays (non-demo) are persisted; demo relays are seeded in memory on each load.

## Known limitations
- One-browser pass-and-play only — no online collaboration.
- Local storage is not encrypted; contributors can inspect panel content via devtools.
- CSS unfold animation uses `scaleY` (performant); reduced motion respected.

## Planned features (NOT YET BUILT)
- **Online invitations**: real-time relay sharing via unique URLs, server-side storage.
- **Real authorisation**: named contributor accounts with verified identity.
- **Shared database**: multi-device relay state synchronisation.
- **Arc Testnet USDC split settlement**: actual onchain USDC transfers requiring each contributor's wallet connection and explicit transaction consent.
