/**
 * Trust Bridge — "Borrow a Possibility"
 * Community item-sharing app with USDC collateral escrow on Arc Testnet.
 *
 * Screens:
 *  1. Home — activity discovery + neighborhood map + search
 *  2. Item detail — condition, owner, USDC collateral, escrow CTA
 *  3. Create listing — form (planned feature, offchain for now)
 *  4. Dashboard — my lending & borrowing escrows (onchain reads)
 *  5. Timeline — escrow state machine, confirmations, settlement
 *  6. Dispute — evidence log + raise/resolve dispute
 */

import { useState } from 'react'
import { Home, LayoutDashboard, Plus } from 'lucide-react'
import HomeScreen from './components/screens/HomeScreen'
import ItemDetailScreen from './components/screens/ItemDetailScreen'
import CreateListingScreen from './components/screens/CreateListingScreen'
import DashboardScreen from './components/screens/DashboardScreen'
import TimelineScreen from './components/screens/TimelineScreen'
import DisputeScreen from './components/screens/DisputeScreen'
import type { DemoItem } from './demo-data'

type Screen =
  | { id: 'home' }
  | { id: 'item'; item: DemoItem }
  | { id: 'create' }
  | { id: 'dashboard' }
  | { id: 'timeline'; escrowId: bigint }
  | { id: 'dispute'; escrowId: bigint }

type NavTab = 'home' | 'create' | 'dashboard'

export default function App() {
  const [screen, setScreen] = useState<Screen>({ id: 'home' })
  const [activeTab, setActiveTab] = useState<NavTab>('home')

  const navigate = (s: Screen) => setScreen(s)

  const goHome = () => {
    setScreen({ id: 'home' })
    setActiveTab('home')
  }

  const renderScreen = () => {
    switch (screen.id) {
      case 'home':
        return (
          <HomeScreen
            onSelectItem={(item) => navigate({ id: 'item', item })}
          />
        )
      case 'item':
        return (
          <ItemDetailScreen
            item={screen.item}
            onBack={() => navigate({ id: 'home' })}
            onEscrowCreated={(escrowId) => navigate({ id: 'timeline', escrowId })}
          />
        )
      case 'create':
        return <CreateListingScreen onBack={goHome} />
      case 'dashboard':
        return (
          <DashboardScreen
            onBack={goHome}
            onOpenTimeline={(escrowId) => navigate({ id: 'timeline', escrowId })}
          />
        )
      case 'timeline':
        return (
          <TimelineScreen
            escrowId={screen.escrowId}
            onBack={() => navigate({ id: 'dashboard' })}
            onOpenDispute={(escrowId) => navigate({ id: 'dispute', escrowId })}
          />
        )
      case 'dispute':
        return (
          <DisputeScreen
            escrowId={screen.escrowId}
            onBack={() => navigate({ id: 'timeline', escrowId: screen.escrowId })}
          />
        )
    }
  }

  // Only show bottom nav on top-level screens
  const showNav = screen.id === 'home' || screen.id === 'create' || screen.id === 'dashboard'

  return (
    <div className="min-h-dvh relative" style={{ background: 'var(--bg-gradient)' }}>
      {renderScreen()}

      {showNav && (
        <nav
          className="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around px-4 pt-2 pb-safe"
          style={{
            background: 'rgba(250, 246, 240, 0.95)',
            backdropFilter: 'blur(16px)',
            borderTop: '1px solid var(--border)',
            paddingBottom: 'env(safe-area-inset-bottom, 16px)',
          }}
          aria-label="Main navigation"
        >
          <NavItem
            icon={<Home size={20} />}
            label="Browse"
            active={activeTab === 'home' && screen.id === 'home'}
            onClick={() => {
              setActiveTab('home')
              navigate({ id: 'home' })
            }}
          />
          <NavItem
            icon={
              <div
                className="flex items-center justify-center rounded-full"
                style={{
                  width: '44px',
                  height: '44px',
                  background: activeTab === 'create' ? 'var(--terra)' : 'var(--accent)',
                  color: 'white',
                  boxShadow: '0 4px 14px rgba(45,90,39,0.35)',
                  marginTop: '-20px',
                }}
              >
                <Plus size={22} />
              </div>
            }
            label="List Item"
            active={activeTab === 'create'}
            onClick={() => {
              setActiveTab('create')
              navigate({ id: 'create' })
            }}
            noActiveStyle
          />
          <NavItem
            icon={<LayoutDashboard size={20} />}
            label="Dashboard"
            active={activeTab === 'dashboard' && screen.id === 'dashboard'}
            onClick={() => {
              setActiveTab('dashboard')
              navigate({ id: 'dashboard' })
            }}
          />
        </nav>
      )}
    </div>
  )
}

function NavItem({
  icon,
  label,
  active,
  onClick,
  noActiveStyle,
}: {
  icon: React.ReactNode
  label: string
  active: boolean
  onClick: () => void
  noActiveStyle?: boolean
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-0.5 min-w-[64px] py-2 transition-colors"
      style={{
        color: active && !noActiveStyle ? 'var(--accent)' : 'var(--muted)',
      }}
      aria-current={active ? 'page' : undefined}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  )
}
