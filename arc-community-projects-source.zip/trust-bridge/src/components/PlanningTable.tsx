/**
 * Planning Table — local equipment bundle builder.
 *
 * Lets the user select an activity, add/remove items from the suggested bundle,
 * see which are demo-unavailable, and get a total suggested USDC collateral.
 *
 * STATE: localStorage key "trustbridge_plan_v1". No wallet required. No escrow
 * transaction is triggered here — each item goes through the individual escrow
 * workflow when the user clicks through to ItemDetail.
 *
 * All data is local/demo — clearly labeled.
 */

import { useState, useEffect, useCallback } from 'react'
import { CheckSquare, Square, Info, ShoppingBag, Trash2, ChevronDown, ChevronUp } from 'lucide-react'
import { ACTIVITIES, ACTIVITY_BUNDLES, DEMO_ITEMS, getItemsByActivity, type Activity, type DemoItem } from '../demo-data'

const STORAGE_KEY = 'trustbridge_plan_v1'

interface SavedPlan {
  activityId: string
  selectedIds: string[]
}

function loadPlan(): SavedPlan | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    return JSON.parse(raw) as SavedPlan
  } catch {
    return null
  }
}

function savePlan(plan: SavedPlan) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(plan))
  } catch {
    // storage unavailable — silently ignore
  }
}

interface Props {
  onSelectItem: (item: DemoItem) => void
}

export default function PlanningTable({ onSelectItem }: Props) {
  // Lazy initialisers read localStorage once at mount — avoids setState-in-effect
  const [activityId, setActivityId] = useState<string>(() => loadPlan()?.activityId ?? '')
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => {
    const saved = loadPlan()
    return saved ? new Set(saved.selectedIds) : new Set<string>()
  })
  const [isOpen, setIsOpen] = useState<boolean>(() => !!loadPlan())
  const [justSaved, setJustSaved] = useState(false)

  // Persist to localStorage on change
  useEffect(() => {
    if (activityId) {
      savePlan({ activityId, selectedIds: [...selectedIds] })
    }
  }, [activityId, selectedIds])

  const activity = ACTIVITIES.find((a) => a.id === activityId) ?? null
  const activityItems = activityId ? getItemsByActivity(activityId) : []

  // Bundle item IDs for this activity (ordered)
  const bundleIds: string[] = activityId ? (ACTIVITY_BUNDLES[activityId] ?? []) : []

  // Build a full ordered bundle: items in bundle order first, then remaining activity items
  const bundleItems: Array<{ item: DemoItem; inBundle: boolean }> = bundleIds.map((id) => ({
    item: DEMO_ITEMS.find((i) => i.id === id)!,
    inBundle: true,
  })).filter((x) => x.item != null)

  // Non-bundle items also in this activity
  const extraItems = activityItems
    .filter((i) => !bundleIds.includes(i.id))
    .map((item) => ({ item, inBundle: false }))

  const allRows = [...bundleItems, ...extraItems]

  // Collateral total for selected items (integer arithmetic to avoid floating-point issues)
  const totalCentsX100 = allRows.reduce((acc, { item }) => {
    if (!selectedIds.has(item.id)) return acc
    // suggestedCollateral is a whole number USDC value
    return acc + item.suggestedCollateral
  }, 0)

  const totalUsdc = totalCentsX100 // already whole USDC units

  const toggle = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  const handleActivityChange = (id: string) => {
    setActivityId(id)
    // Pre-select bundle items
    const bundle = ACTIVITY_BUNDLES[id] ?? []
    setSelectedIds(new Set(bundle))
  }

  const clearPlan = () => {
    setActivityId('')
    setSelectedIds(new Set())
    try { localStorage.removeItem(STORAGE_KEY) } catch { /* ignore */ }
  }

  const handleSave = () => {
    if (activityId) {
      savePlan({ activityId, selectedIds: [...selectedIds] })
      setJustSaved(true)
      setTimeout(() => setJustSaved(false), 2000)
    }
  }

  return (
    <section
      className="rounded-2xl overflow-hidden"
      style={{ border: '1.5px solid var(--border)', background: 'var(--surface-strong)' }}
    >
      {/* Header — always visible */}
      <button
        onClick={() => setIsOpen((v) => !v)}
        className="w-full flex items-center justify-between px-4 py-3 text-left transition-colors"
        style={{ minHeight: '52px' }}
        aria-expanded={isOpen}
        aria-controls="planning-table-body"
        onMouseEnter={(e) =>
          ((e.currentTarget as HTMLElement).style.background = 'var(--surface-muted)')
        }
        onMouseLeave={(e) =>
          ((e.currentTarget as HTMLElement).style.background = 'transparent')
        }
      >
        <div className="flex items-center gap-2">
          <ShoppingBag size={16} style={{ color: 'var(--terra)' }} aria-hidden="true" />
          <span className="text-sm font-semibold" style={{ color: 'var(--ink-2)' }}>
            ตารางวางแผน
          </span>
          <span
            className="text-xs px-2 py-0.5 rounded-full font-medium"
            style={{ background: 'var(--warning-light)', color: 'var(--warning)' }}
          >
            โลคอล
          </span>
          {activityId && selectedIds.size > 0 && (
            <span
              className="text-xs px-2 py-0.5 rounded-full font-medium tabular-nums"
              style={{ background: 'var(--accent-light)', color: 'var(--accent)' }}
            >
              {selectedIds.size} รายการ · ${totalUsdc} USDC
            </span>
          )}
        </div>
        {isOpen ? (
          <ChevronUp size={16} style={{ color: 'var(--muted)' }} aria-hidden="true" />
        ) : (
          <ChevronDown size={16} style={{ color: 'var(--muted)' }} aria-hidden="true" />
        )}
      </button>

      {/* Body */}
      {isOpen && (
        <div id="planning-table-body" className="px-4 pb-4 space-y-4">
          {/* Local notice */}
          <div
            className="flex items-start gap-2 rounded-xl p-3 text-xs"
            style={{
              background: 'var(--warning-light)',
              color: 'var(--warning)',
              border: '1px solid rgba(181,125,26,0.2)',
            }}
          >
            <Info size={12} className="flex-shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              <strong>โลคอล/เดโม:</strong> แผนนี้บันทึกในเบราว์เซอร์ของคุณเท่านั้น ไม่มีธุรกรรมบนบล็อกเชนเกิดขึ้น
              การยืมจริงต้องผ่าน escrow แยกต่อรายการ
            </span>
          </div>

          {/* Activity selector */}
          <div>
            <label className="text-xs font-semibold block mb-2" style={{ color: 'var(--ink-2)' }}>
              เลือกกิจกรรม
            </label>
            <div className="grid grid-cols-2 gap-2">
              {ACTIVITIES.map((a) => (
                <ActivityChip
                  key={a.id}
                  activity={a}
                  selected={activityId === a.id}
                  onSelect={handleActivityChange}
                />
              ))}
            </div>
          </div>

          {/* Bundle checklist */}
          {activity && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>
                  อุปกรณ์สำหรับ{activity.titleTh}
                </span>
                {selectedIds.size > 0 && (
                  <button
                    onClick={() => setSelectedIds(new Set())}
                    className="text-xs"
                    style={{ color: 'var(--muted)' }}
                  >
                    ยกเลิกทั้งหมด
                  </button>
                )}
              </div>

              <div className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
                {allRows.length === 0 ? (
                  <div className="px-4 py-6 text-center text-sm" style={{ color: 'var(--muted)' }}>
                    ไม่มีอุปกรณ์ในกิจกรรมนี้
                  </div>
                ) : (
                  allRows.map(({ item, inBundle }, idx) => (
                    <BundleRow
                      key={item.id}
                      item={item}
                      inBundle={inBundle}
                      selected={selectedIds.has(item.id)}
                      onToggle={toggle}
                      onViewItem={onSelectItem}
                      isLast={idx === allRows.length - 1}
                    />
                  ))
                )}
              </div>

              {/* Total */}
              {selectedIds.size > 0 && (
                <div
                  className="mt-3 rounded-xl px-4 py-3 flex items-center justify-between"
                  style={{ background: 'var(--accent-light)', border: '1px solid rgba(45,90,39,0.15)' }}
                >
                  <div>
                    <div className="text-xs font-semibold" style={{ color: 'var(--accent)' }}>
                      มัดจำรวมที่แนะนำ
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
                      {selectedIds.size} รายการ — แต่ละรายการ escrow แยกต่างหาก
                    </div>
                  </div>
                  <div
                    className="text-xl font-bold tabular-nums display"
                    style={{ color: 'var(--accent)', letterSpacing: '-0.03em' }}
                  >
                    ${totalUsdc}
                    <span className="text-sm font-semibold ml-1">USDC</span>
                  </div>
                </div>
              )}

              {/* Save / clear */}
              <div className="flex gap-2 mt-3">
                <button
                  onClick={handleSave}
                  className="flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all"
                  style={{
                    background: justSaved ? 'var(--success-light)' : 'var(--accent)',
                    color: justSaved ? 'var(--success)' : 'white',
                  }}
                >
                  {justSaved ? 'บันทึกแล้ว ✓' : 'บันทึกแผน'}
                </button>
                <button
                  onClick={clearPlan}
                  className="flex items-center justify-center rounded-xl w-11 transition-colors"
                  style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
                  aria-label="ล้างแผน"
                >
                  <Trash2 size={15} aria-hidden="true" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  )
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function ActivityChip({
  activity,
  selected,
  onSelect,
}: {
  activity: Activity
  selected: boolean
  onSelect: (id: string) => void
}) {
  return (
    <button
      onClick={() => onSelect(activity.id)}
      className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-left transition-all"
      style={{
        background: selected ? activity.color : 'var(--surface-muted)',
        border: `1.5px solid ${selected ? activity.color : 'var(--border)'}`,
        boxShadow: selected ? '0 2px 10px rgba(0,0,0,0.12)' : 'none',
        minHeight: '44px',
      }}
      aria-pressed={selected}
    >
      <span className="text-base" aria-hidden="true">{activity.icon}</span>
      <span
        className="text-xs font-semibold leading-tight"
        style={{ color: selected ? 'white' : 'var(--ink)' }}
      >
        {activity.titleTh}
      </span>
    </button>
  )
}

function BundleRow({
  item,
  inBundle,
  selected,
  onToggle,
  onViewItem,
  isLast,
}: {
  item: DemoItem
  inBundle: boolean
  selected: boolean
  onToggle: (id: string) => void
  onViewItem: (item: DemoItem) => void
  isLast: boolean
}) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5"
      style={{
        borderBottom: isLast ? 'none' : '1px solid var(--border)',
        background: selected ? 'rgba(45,90,39,0.04)' : 'transparent',
        minHeight: '52px',
      }}
    >
      {/* Checkbox */}
      <button
        onClick={() => onToggle(item.id)}
        aria-label={selected ? `ยกเลิก ${item.titleTh}` : `เพิ่ม ${item.titleTh}`}
        aria-pressed={selected}
        className="flex-shrink-0 transition-colors"
        style={{ color: selected ? 'var(--accent)' : 'var(--subtle)', minWidth: '20px' }}
      >
        {selected ? (
          <CheckSquare size={18} aria-hidden="true" />
        ) : (
          <Square size={18} aria-hidden="true" />
        )}
      </button>

      {/* Emoji */}
      <div
        className="flex-shrink-0 flex items-center justify-center rounded-lg"
        style={{
          width: '32px',
          height: '32px',
          background: item.imageColor + '22',
          fontSize: '16px',
        }}
        aria-hidden="true"
      >
        {item.imageEmoji}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div
          className="text-xs font-semibold truncate"
          style={{ color: selected ? 'var(--ink)' : 'var(--ink-2)' }}
        >
          {item.titleTh}
        </div>
        <div className="flex items-center gap-1.5 mt-0.5">
          {inBundle && (
            <span
              className="text-xs px-1.5 py-0.5 rounded font-medium"
              style={{ background: 'var(--accent-light)', color: 'var(--accent)', fontSize: '10px' }}
            >
              แนะนำ
            </span>
          )}
          <span className="text-xs" style={{ color: 'var(--muted)' }}>
            {item.condition}
          </span>
        </div>
      </div>

      {/* Collateral + action */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <div className="text-right">
          <div
            className="text-sm font-semibold tabular-nums"
            style={{ color: selected ? 'var(--accent)' : 'var(--muted)' }}
          >
            ${item.suggestedCollateral}
          </div>
          <div className="text-xs" style={{ color: 'var(--subtle)', fontSize: '10px' }}>USDC</div>
        </div>
        <button
          onClick={() => onViewItem(item)}
          className="rounded-lg px-2 py-1 text-xs font-medium transition-colors"
          style={{
            background: 'var(--surface-muted)',
            color: 'var(--muted)',
            minHeight: '28px',
          }}
          aria-label={`ดูรายละเอียด ${item.titleTh}`}
        >
          ดู
        </button>
      </div>
    </div>
  )
}
