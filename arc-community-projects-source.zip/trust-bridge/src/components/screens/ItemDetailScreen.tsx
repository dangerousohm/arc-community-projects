/**
 * Screen 2 — Item detail: condition, availability, owner, USDC collateral,
 * community story, and borrow CTA with escrow preview.
 */

import { useState } from 'react'
import { ArrowLeft, Star, Shield, Clock, User, MessageSquare, ChevronDown, ChevronUp } from 'lucide-react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt } from 'wagmi'
import { erc20Abi } from 'viem'
import { ConnectKitButton } from 'connectkit'
import { toast } from 'sonner'
import type { DemoItem } from '../../demo-data'
import { ITEM_LENDING_ESCROW_ABI } from '../../escrow-abi'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { parseAmount, Amount } from '@/onchain-money'

const ARC_TESTNET_CHAIN_ID = 5042002
const ESCROW_CONTRACT = import.meta.env.VITE_ESCROW_ADDRESS as `0x${string}` | undefined

const PLATFORM_FEE_BPS = 250n
const computePlatformFee = (collateral: bigint) => (collateral * PLATFORM_FEE_BPS) / 10000n

const ONE_DAY = 86400
const SEVEN_DAYS = 7 * ONE_DAY

interface Props {
  item: DemoItem
  onBack: () => void
  onEscrowCreated: (escrowId: bigint, item: DemoItem) => void
}

type Step = 'details' | 'preview' | 'approve' | 'create'

export default function ItemDetailScreen({ item, onBack, onEscrowCreated: _onEscrowCreated }: Props) {
  const { address, chainId, isConnected } = useAccount()
  const [showStory, setShowStory] = useState(false)
  const [step, setStep] = useState<Step>('details')
  const [borrowerAddress, setBorrowerAddress] = useState(address ?? '')
  const [returnDays, setReturnDays] = useState(3)

  const usdcFact = getUsdc(ARC_TESTNET_CHAIN_ID)!
  const collateralRaw = parseAmount(ARC_TESTNET_CHAIN_ID, item.suggestedCollateral.toString()).raw
  const platformFeeRaw = computePlatformFee(collateralRaw)
  const totalRaw = collateralRaw + platformFeeRaw
  const totalFormatted = Amount.fromRaw(totalRaw, usdcFact.decimals).toFixed(2)
  const collateralFormatted = Amount.fromRaw(collateralRaw, usdcFact.decimals).toFixed(2)
  const platformFeeFormatted = Amount.fromRaw(platformFeeRaw, usdcFact.decimals).toFixed(2)
  const [nowTs] = useState(() => Math.floor(Date.now() / 1000))

  const isLender = address && item.ownerAddress && address.toLowerCase() === item.ownerAddress.toLowerCase()
  const isWrongChain = isConnected && chainId !== ARC_TESTNET_CHAIN_ID
  const contractMissing = !ESCROW_CONTRACT

  // Approve USDC
  const {
    writeContract: approve,
    data: approveHash,
    isPending: isApproving,
  } = useWriteContract()
  const { isLoading: isApproveConfirming, isSuccess: isApproveSuccess } = useWaitForTransactionReceipt({
    hash: approveHash,
  })

  // Create escrow
  const {
    writeContract: createEscrow,
    data: createHash,
    isPending: isCreating,
  } = useWriteContract()
  const { isLoading: isCreateConfirming } = useWaitForTransactionReceipt({
    hash: createHash,
  })

  const handleApprove = () => {
    if (!ESCROW_CONTRACT || !usdcFact) return
    approve(
      {
        address: usdcFact.address as `0x${string}`,
        abi: erc20Abi,
        functionName: 'approve',
        args: [ESCROW_CONTRACT, totalRaw],
        chainId: ARC_TESTNET_CHAIN_ID,
      },
      {
        onSuccess: () => toast.success('Approval submitted'),
        onError: (e) => toast.error(parseError(e)),
      },
    )
  }

  const handleCreate = () => {
    if (!ESCROW_CONTRACT || !borrowerAddress) return
    createEscrow(
      {
        address: ESCROW_CONTRACT,
        abi: ITEM_LENDING_ESCROW_ABI,
        functionName: 'createEscrow',
        args: [
          borrowerAddress as `0x${string}`,
          collateralRaw,
          BigInt(nowTs + returnDays * ONE_DAY),
          BigInt(SEVEN_DAYS),
          item.id,
          item.listingId,
        ],
        chainId: ARC_TESTNET_CHAIN_ID,
      },
      {
        onSuccess: () => toast.success('Escrow created on-chain!'),
        onError: (e) => toast.error(parseError(e)),
      },
    )
  }

  const conditionBadge = {
    Excellent: { bg: 'var(--success-light)', color: 'var(--success)', label: 'Excellent' },
    Good: { bg: 'var(--warning-light)', color: 'var(--warning)', label: 'Good' },
    Fair: { bg: 'var(--surface-muted)', color: 'var(--muted)', label: 'Fair' },
  }[item.condition]

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3"
        style={{
          background: 'rgba(250, 246, 240, 0.90)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <button
          onClick={onBack}
          className="flex items-center justify-center rounded-xl w-9 h-9 transition-colors"
          style={{ background: 'var(--surface-muted)' }}
          aria-label="Go back"
        >
          <ArrowLeft size={16} style={{ color: 'var(--ink)' }} />
        </button>
        <h1 className="text-sm font-semibold flex-1 truncate" style={{ color: 'var(--ink)' }}>
          {item.title}
        </h1>
        {item.isDemo && (
          <span
            className="text-xs font-medium rounded-full px-2.5 py-1"
            style={{ background: 'var(--warning-light)', color: 'var(--warning)' }}
          >
            Demo listing
          </span>
        )}
      </header>

      <div className="max-w-lg mx-auto px-4 pb-32 pt-5 space-y-5">
        {/* Hero card */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{ border: '1.5px solid var(--border)', background: 'var(--surface-strong)' }}
        >
          {/* Item visual */}
          <div
            className="flex items-center justify-center"
            style={{
              height: '160px',
              background: `linear-gradient(135deg, ${item.imageColor}22, ${item.imageColor}44)`,
            }}
          >
            <span style={{ fontSize: '64px' }} role="img" aria-label={item.title}>
              {item.imageEmoji}
            </span>
          </div>

          <div className="p-5 space-y-4">
            <div>
              <h2 className="display text-xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
                {item.title}
              </h2>
              <div className="flex items-center gap-2 mt-1.5">
                <span
                  className="text-xs font-medium rounded-full px-2.5 py-1"
                  style={{ background: conditionBadge.bg, color: conditionBadge.color }}
                >
                  {conditionBadge.label} condition
                </span>
                <span className="text-xs" style={{ color: 'var(--muted)' }}>
                  {item.category}
                </span>
              </div>
            </div>

            <p className="text-sm text-pretty leading-relaxed" style={{ color: 'var(--ink-2)' }}>
              {item.description}
            </p>

            {/* Owner info */}
            <div
              className="flex items-center gap-3 rounded-xl p-3"
              style={{ background: 'var(--surface-muted)' }}
            >
              <div
                className="flex items-center justify-center rounded-full flex-shrink-0"
                style={{
                  width: '36px',
                  height: '36px',
                  background: item.imageColor,
                  color: 'white',
                  fontWeight: 700,
                  fontSize: '14px',
                }}
              >
                {item.ownerName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                  {item.ownerName}
                </div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>
                  {item.ownerHandle}
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs" style={{ color: 'var(--warning)' }}>
                <Star size={12} fill="currentColor" />
                <span className="font-medium">4.9</span>
                <span style={{ color: 'var(--muted)' }}>(demo)</span>
              </div>
            </div>

            {/* Availability */}
            <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--ink-2)' }}>
              <Clock size={14} style={{ color: 'var(--accent)' }} />
              <span>
                Available{' '}
                <strong>
                  {new Date(item.availableFrom).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </strong>{' '}
                –{' '}
                <strong>
                  {new Date(item.availableTo).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </strong>
              </span>
            </div>

            {/* Community story */}
            {item.story && (
              <div
                className="rounded-xl overflow-hidden"
                style={{ border: '1px solid var(--border)' }}
              >
                <button
                  onClick={() => setShowStory(!showStory)}
                  className="w-full flex items-center gap-2 px-3 py-2.5 text-left"
                  style={{ background: 'var(--surface-muted)' }}
                >
                  <MessageSquare size={13} style={{ color: 'var(--muted)' }} />
                  <span className="text-xs font-medium flex-1" style={{ color: 'var(--ink-2)' }}>
                    Community story
                  </span>
                  {showStory ? (
                    <ChevronUp size={13} style={{ color: 'var(--muted)' }} />
                  ) : (
                    <ChevronDown size={13} style={{ color: 'var(--muted)' }} />
                  )}
                </button>
                {showStory && (
                  <div className="px-3 pb-3 pt-2">
                    <p className="text-sm italic text-pretty" style={{ color: 'var(--muted)', lineHeight: '1.6' }}>
                      "{item.story}"
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Escrow preview / action flow */}
        {contractMissing ? (
          <DeployNotice />
        ) : !isConnected ? (
          <div className="flex flex-col items-center gap-3 rounded-2xl p-6 text-center" style={{ background: 'var(--surface-strong)', border: '1.5px solid var(--border)' }}>
            <Shield size={24} style={{ color: 'var(--accent)' }} />
            <p className="text-sm font-medium" style={{ color: 'var(--ink-2)' }}>Connect your wallet to borrow</p>
            <ConnectKitButton />
          </div>
        ) : isWrongChain ? (
          <WrongChainNotice />
        ) : isLender ? (
          <LenderView item={item} />
        ) : step === 'details' ? (
          <BorrowPreview
            item={item}
            collateralFormatted={collateralFormatted}
            platformFeeFormatted={platformFeeFormatted}
            totalFormatted={totalFormatted}
            returnDays={returnDays}
            setReturnDays={setReturnDays}
            borrowerAddress={borrowerAddress}
            setBorrowerAddress={setBorrowerAddress}
            onConfirm={() => setStep('preview')}
          />
        ) : step === 'preview' ? (
          <EscrowPreviewCard
            collateralFormatted={collateralFormatted}
            platformFeeFormatted={platformFeeFormatted}
            totalFormatted={totalFormatted}
            returnDays={returnDays}
            onApprove={() => { setStep('approve'); handleApprove() }}
            onBack={() => setStep('details')}
            isApproving={isApproving || isApproveConfirming}
            isApproveSuccess={isApproveSuccess}
            onCreate={() => { setStep('create'); handleCreate() }}
            isCreating={isCreating || isCreateConfirming}
            createHash={createHash}
            chainId={ARC_TESTNET_CHAIN_ID}
          />
        ) : null}
      </div>
    </div>
  )
}

function BorrowPreview({
  item,
  collateralFormatted,
  platformFeeFormatted,
  totalFormatted,
  returnDays,
  setReturnDays,
  borrowerAddress,
  setBorrowerAddress,
  onConfirm,
}: {
  item: DemoItem
  collateralFormatted: string
  platformFeeFormatted: string
  totalFormatted: string
  returnDays: number
  setReturnDays: (d: number) => void
  borrowerAddress: string
  setBorrowerAddress: (a: string) => void
  onConfirm: () => void
}) {
  return (
    <div className="rounded-2xl overflow-hidden" style={{ border: '1.5px solid var(--border)', background: 'var(--surface-strong)' }}>
      <div className="px-5 pt-5 pb-2">
        <h3 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>
          Borrow this item
        </h3>
        <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>
          You'll deposit USDC collateral held in escrow. It's returned when the item is back.
        </p>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Return days */}
        <div>
          <label className="text-xs font-semibold block mb-2" style={{ color: 'var(--ink-2)' }}>
            How long do you need it?
          </label>
          <div className="flex gap-2">
            {[1, 2, 3, 5, 7].map((d) => (
              <button
                key={d}
                onClick={() => setReturnDays(d)}
                className="flex-1 rounded-xl py-2 text-sm font-medium transition-all"
                style={{
                  background: returnDays === d ? 'var(--accent)' : 'var(--surface-muted)',
                  color: returnDays === d ? 'white' : 'var(--muted)',
                }}
              >
                {d}d
              </button>
            ))}
          </div>
        </div>

        {/* Borrower address (lender creating escrow) */}
        {item.ownerAddress && (
          <div>
            <label className="text-xs font-semibold block mb-1.5" style={{ color: 'var(--ink-2)' }}>
              Borrower wallet address
            </label>
            <input
              value={borrowerAddress}
              onChange={(e) => setBorrowerAddress(e.target.value)}
              placeholder="0x..."
              className="w-full rounded-xl px-3 py-2.5 text-sm mono"
              style={{
                background: 'var(--surface-muted)',
                border: '1.5px solid var(--border)',
                color: 'var(--ink)',
                outline: 'none',
              }}
            />
          </div>
        )}

        {/* Cost preview rows */}
        <div className="rounded-xl p-4 space-y-2" style={{ background: 'var(--accent-light)', border: '1px solid rgba(45,90,39,0.15)' }}>
          <Row label="Collateral (returned)" value={`$${collateralFormatted} USDC`} accent />
          <Row label="Platform fee (2.5%)" value={`$${platformFeeFormatted} USDC`} />
          <div className="border-t pt-2 mt-2 flex justify-between" style={{ borderColor: 'rgba(45,90,39,0.15)' }}>
            <span className="text-sm font-bold" style={{ color: 'var(--ink)' }}>Total to deposit</span>
            <span className="text-sm font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
              ${totalFormatted} USDC
            </span>
          </div>
        </div>
      </div>

      <div className="px-5 pb-5">
        <button
          onClick={onConfirm}
          className="w-full rounded-xl py-3.5 text-sm font-semibold transition-all"
          style={{ background: 'var(--accent)', color: 'white' }}
        >
          Review & Confirm
        </button>
      </div>
    </div>
  )
}

function EscrowPreviewCard({
  collateralFormatted,
  platformFeeFormatted,
  totalFormatted,
  returnDays,
  onApprove,
  onBack,
  isApproving,
  isApproveSuccess,
  onCreate,
  isCreating,
  createHash,
  chainId,
}: {
  collateralFormatted: string
  platformFeeFormatted: string
  totalFormatted: string
  returnDays: number
  onApprove: () => void
  onBack: () => void
  isApproving: boolean
  isApproveSuccess: boolean
  onCreate: () => void
  isCreating: boolean
  createHash?: `0x${string}`
  chainId: number
}) {
  const [baseNow] = useState(() => Date.now())
  const returnDate = new Date(baseNow + returnDays * 86400000).toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric',
  })
  const depositDeadline = new Date(baseNow + 86400000).toLocaleTimeString('en-US', {
    hour: '2-digit', minute: '2-digit', hour12: true,
  })

  return (
    <div className="rounded-2xl overflow-hidden" style={{ border: '1.5px solid var(--accent)', background: 'var(--surface-strong)' }}>
      <div className="px-5 pt-4 pb-3" style={{ background: 'var(--accent)', color: 'white' }}>
        <div className="flex items-center gap-2">
          <Shield size={16} />
          <span className="text-sm font-semibold">Escrow Summary</span>
        </div>
        <p className="text-xs opacity-70 mt-1">Review before you sign. These values are final once confirmed.</p>
      </div>

      <div className="p-5 space-y-3">
        <Row label="Collateral held in escrow" value={`$${collateralFormatted} USDC`} accent />
        <Row label="Platform fee (non-refundable)" value={`$${platformFeeFormatted} USDC`} />
        <Row label="Total you deposit" value={`$${totalFormatted} USDC`} bold />
        <Row label="Collateral refunded on return" value={`$${collateralFormatted} USDC`} accent />
        <div className="border-t pt-3 space-y-2" style={{ borderColor: 'var(--border)' }}>
          <Row label="Return deadline" value={returnDate} />
          <Row label="Deposit deadline" value={`Today by ${depositDeadline}`} />
          <Row label="Dispute window" value="7 days after return deadline" />
        </div>

        <div
          className="rounded-xl p-3 text-xs"
          style={{ background: 'var(--terra-light)', color: 'var(--terra)', border: '1px solid rgba(192,89,59,0.15)' }}
        >
          <strong>How escrow works:</strong> Your USDC goes into a smart contract. It's released back to you after both parties confirm return. If there's a dispute, the platform admin mediates within 7 days — or after 7 days you can trigger an automatic equal split.
        </div>

        {/* Step 1: Approve */}
        <div>
          <div className="text-xs font-semibold mb-2 flex items-center gap-2" style={{ color: 'var(--ink-2)' }}>
            <span
              className="rounded-full w-5 h-5 flex items-center justify-center text-xs"
              style={{
                background: isApproveSuccess ? 'var(--success)' : 'var(--accent)',
                color: 'white',
              }}
            >
              {isApproveSuccess ? '✓' : '1'}
            </span>
            Approve USDC spending
          </div>
          <button
            onClick={onApprove}
            disabled={isApproving || isApproveSuccess}
            className="w-full rounded-xl py-3 text-sm font-semibold transition-all disabled:opacity-60"
            style={{
              background: isApproveSuccess ? 'var(--success)' : 'var(--accent)',
              color: 'white',
            }}
          >
            {isApproveSuccess ? 'Approved' : isApproving ? 'Approving…' : `Approve $${totalFormatted} USDC`}
          </button>
        </div>

        {/* Step 2: Create escrow */}
        {isApproveSuccess && (
          <div>
            <div className="text-xs font-semibold mb-2 flex items-center gap-2" style={{ color: 'var(--ink-2)' }}>
              <span className="rounded-full w-5 h-5 flex items-center justify-center text-xs" style={{ background: 'var(--accent)', color: 'white' }}>
                2
              </span>
              Create escrow (lender)
            </div>
            {createHash ? (
              <div className="rounded-xl p-3 text-xs" style={{ background: 'var(--success-light)', color: 'var(--success)' }}>
                Escrow created!{' '}
                <a
                  href={buildTxExplorerUrl(chainId, createHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline font-medium"
                >
                  View on explorer
                </a>
              </div>
            ) : (
              <button
                onClick={onCreate}
                disabled={isCreating}
                className="w-full rounded-xl py-3 text-sm font-semibold transition-all disabled:opacity-60"
                style={{ background: 'var(--terra)', color: 'white' }}
              >
                {isCreating ? 'Creating escrow…' : 'Create Escrow on Arc Testnet'}
              </button>
            )}
          </div>
        )}

        <button
          onClick={onBack}
          className="w-full py-2 text-xs text-center"
          style={{ color: 'var(--muted)' }}
        >
          Go back and adjust
        </button>
      </div>
    </div>
  )
}

function Row({ label, value, accent, bold }: { label: string; value: string; accent?: boolean; bold?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      <span
        className={`text-xs tabular-nums font-${bold ? 'bold' : 'semibold'}`}
        style={{ color: accent ? 'var(--accent)' : 'var(--ink-2)' }}
      >
        {value}
      </span>
    </div>
  )
}

function LenderView({ item: _item }: { item: DemoItem }) {
  return (
    <div className="rounded-2xl p-5 text-center space-y-2" style={{ background: 'var(--success-light)', border: '1.5px solid rgba(26,120,64,0.2)' }}>
      <User size={20} style={{ color: 'var(--success)', margin: '0 auto' }} />
      <p className="text-sm font-semibold" style={{ color: 'var(--success)' }}>You own this item</p>
      <p className="text-xs" style={{ color: 'var(--muted)' }}>Go to your dashboard to manage lending requests.</p>
    </div>
  )
}

function DeployNotice() {
  return (
    <div
      className="rounded-2xl p-5 space-y-2"
      style={{ background: 'var(--terra-light)', border: '1.5px solid rgba(192,89,59,0.25)' }}
    >
      <p className="text-sm font-semibold" style={{ color: 'var(--terra)' }}>Contract not yet deployed</p>
      <p className="text-xs" style={{ color: 'var(--muted)' }}>
        The escrow contract needs to be deployed to Arc Testnet. Add{' '}
        <code className="mono text-xs">VITE_ESCROW_ADDRESS</code> to your .env file after deployment.
      </p>
    </div>
  )
}

function WrongChainNotice() {
  return (
    <div className="rounded-2xl p-5 text-center space-y-2" style={{ background: 'var(--warning-light)', border: '1.5px solid rgba(181,125,26,0.2)' }}>
      <p className="text-sm font-semibold" style={{ color: 'var(--warning)' }}>Switch to Arc Testnet</p>
      <p className="text-xs" style={{ color: 'var(--muted)' }}>This app runs on Arc Testnet (Chain ID 5042002).</p>
    </div>
  )
}

function parseError(e: unknown): string {
  const msg = (e as Error)?.message?.toLowerCase() ?? ''
  if (msg.includes('user rejected') || msg.includes('user denied')) return 'Transaction cancelled.'
  if (msg.includes('insufficient')) return 'Insufficient USDC balance.'
  if (msg.includes('reverted')) return 'Transaction reverted. Check your balance and try again.'
  return 'Something went wrong. Please try again.'
}
