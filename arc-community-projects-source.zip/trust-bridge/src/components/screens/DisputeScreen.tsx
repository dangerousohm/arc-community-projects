/**
 * Screen 6 — Dispute evidence and status screen.
 * Evidence is stored offchain (clearly labeled).
 * Contract-backed: raiseDispute, disputeTimeoutResolve, state reading.
 */

import { useState } from 'react'
import {
  ArrowLeft,
  AlertTriangle,
  Lock,
  Camera,
  FileText,
  MessageCircle,
  Scale,
  Clock,
  CheckCircle,
  Shield,
} from 'lucide-react'
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi'
import { toast } from 'sonner'
import { ITEM_LENDING_ESCROW_ABI, ESCROW_STATE, type EscrowData } from '../../escrow-abi'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { Amount } from '@/onchain-money'

const ARC_TESTNET_CHAIN_ID = 5042002
const ESCROW_CONTRACT = import.meta.env.VITE_ESCROW_ADDRESS as `0x${string}` | undefined

interface EvidenceEntry {
  type: 'photo' | 'message' | 'note'
  content: string
  timestamp: string
  author: string
}

interface Props {
  escrowId: bigint
  onBack: () => void
}

export default function DisputeScreen({ escrowId, onBack }: Props) {
  const { address } = useAccount()
  const usdcFact = getUsdc(ARC_TESTNET_CHAIN_ID)!

  const { data: escrow, refetch } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'getEscrow',
    args: [escrowId],
    chainId: ARC_TESTNET_CHAIN_ID,
  }) as { data: EscrowData | undefined; refetch: () => void }

  const { writeContract, data: txHash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash: txHash })

  // Off-chain evidence state — clearly not stored on-chain
  const [evidenceText, setEvidenceText] = useState('')
  const [evidenceLog, setEvidenceLog] = useState<EvidenceEntry[]>(() => [
    {
      type: 'note' as const,
      content: 'Escrow dispute tracking starts here. Evidence below is stored locally and NOT on-chain.',
      timestamp: new Date().toLocaleString(),
      author: 'System',
    },
  ])
  const [now] = useState(() => Math.floor(Date.now() / 1000))

  if (!ESCROW_CONTRACT || !escrow) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center gap-4 p-8 text-center" style={{ background: 'var(--bg-gradient)' }}>
        <AlertTriangle size={32} style={{ color: 'var(--terra)' }} />
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Loading dispute info…</p>
        <button onClick={onBack} className="text-xs" style={{ color: 'var(--muted)' }}>Go back</button>
      </div>
    )
  }

  const isLender = address?.toLowerCase() === escrow.lender.toLowerCase()
  const isBorrower = address?.toLowerCase() === escrow.borrower.toLowerCase()
  const collateralFmt = Amount.fromRaw(escrow.collateral, usdcFact.decimals).toFixed(2)
  const feeFmt = Amount.fromRaw(escrow.platformFee, usdcFact.decimals).toFixed(2)

  const disputeRaisedAt = Number(escrow.disputeRaisedAt)
  const disputeSlaDeadline = disputeRaisedAt + 7 * 86400
  const slaExpired = now >= disputeSlaDeadline
  const slaRemainingHours = Math.max(0, Math.round((disputeSlaDeadline - now) / 3600))
  const isDisputed = escrow.state === ESCROW_STATE.Disputed
  const isResolved = escrow.state === ESCROW_STATE.AdminResolved
  const canRaiseDispute =
    escrow.state === ESCROW_STATE.PickedUp ||
    escrow.state === ESCROW_STATE.Returned ||
    (escrow.state === ESCROW_STATE.Funded && isLender && now > Number(escrow.returnDeadline))

  const raiseDispute = () => {
    writeContract(
      {
        address: ESCROW_CONTRACT,
        abi: ITEM_LENDING_ESCROW_ABI,
        functionName: 'raiseDispute',
        args: [escrowId],
        chainId: ARC_TESTNET_CHAIN_ID,
      },
      {
        onSuccess: () => { toast.success('Dispute raised'); setTimeout(refetch, 3000) },
        onError: (e) => toast.error(parseError(e)),
      },
    )
  }

  const triggerTimeout = () => {
    writeContract(
      {
        address: ESCROW_CONTRACT,
        abi: ITEM_LENDING_ESCROW_ABI,
        functionName: 'disputeTimeoutResolve',
        args: [escrowId],
        chainId: ARC_TESTNET_CHAIN_ID,
      },
      {
        onSuccess: () => { toast.success('Dispute auto-resolved'); setTimeout(refetch, 3000) },
        onError: (e) => toast.error(parseError(e)),
      },
    )
  }

  const addEvidence = () => {
    if (!evidenceText.trim()) return
    setEvidenceLog((prev) => [
      ...prev,
      {
        type: 'message',
        content: evidenceText.trim(),
        timestamp: new Date().toLocaleString(),
        author: address ? `${address.slice(0, 6)}…${address.slice(-4)}` : 'You',
      },
    ])
    setEvidenceText('')
  }

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      <header
        className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3"
        style={{
          background: 'rgba(250, 246, 240, 0.90)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <button
          onClick={onBack}
          className="flex items-center justify-center rounded-xl w-9 h-9"
          style={{ background: 'var(--surface-muted)' }}
          aria-label="Go back"
        >
          <ArrowLeft size={16} style={{ color: 'var(--ink)' }} />
        </button>
        <div className="flex-1">
          <h1 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>
            {isDisputed ? 'Dispute Active' : isResolved ? 'Dispute Resolved' : 'Dispute'}
          </h1>
          <div className="text-xs mono" style={{ color: 'var(--muted)' }}>Escrow #{escrowId.toString()}</div>
        </div>
        <div
          className="rounded-full px-2.5 py-1 text-xs font-medium"
          style={{
            background: isDisputed ? 'var(--danger-light)' : isResolved ? 'var(--success-light)' : 'var(--surface-muted)',
            color: isDisputed ? 'var(--danger)' : isResolved ? 'var(--success)' : 'var(--muted)',
          }}
        >
          {isDisputed ? 'Disputed' : isResolved ? 'Resolved' : 'No dispute'}
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-5 pb-32 space-y-5">
        {/* Off-chain notice */}
        <div
          className="rounded-xl p-3 flex gap-2 text-xs"
          style={{ background: 'var(--warning-light)', color: 'var(--warning)', border: '1px solid rgba(181,125,26,0.2)' }}
        >
          <Lock size={14} className="flex-shrink-0 mt-0.5" />
          <span>
            <strong>Evidence is offchain:</strong> Messages and photos you add here are stored in your browser only. For the full version, evidence would be uploaded to decentralized storage (e.g. IPFS) with a content hash committed on-chain.
          </span>
        </div>

        {/* Escrow summary */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{ border: '1.5px solid var(--border)', background: 'var(--surface-strong)' }}
        >
          <div className="px-4 py-3 flex items-center gap-2" style={{ background: isDisputed ? 'var(--danger)' : 'var(--accent)', color: 'white' }}>
            {isDisputed ? <AlertTriangle size={14} /> : <Shield size={14} />}
            <span className="text-xs font-semibold">Escrow #{escrowId.toString()} — {escrow.itemId}</span>
          </div>
          <div className="p-4 space-y-2.5">
            <Row label="Lender" value={fmtAddr(escrow.lender)} />
            <Row label="Borrower" value={fmtAddr(escrow.borrower)} />
            <Row label="Collateral at stake" value={`$${collateralFmt} USDC`} accent />
            <Row label="Platform fee" value={`$${feeFmt} USDC`} />

            {isDisputed && disputeRaisedAt > 0 && (
              <>
                <div className="border-t pt-2.5 space-y-2" style={{ borderColor: 'var(--border)' }}>
                  <Row
                    label="Dispute raised"
                    value={new Date(disputeRaisedAt * 1000).toLocaleString()}
                  />
                  <Row
                    label="Admin resolution SLA"
                    value={slaExpired ? 'SLA expired' : `${slaRemainingHours}h remaining`}
                    overdue={slaExpired}
                  />
                  <Row
                    label="Timeout resolve available"
                    value={slaExpired ? 'Now (equal split)' : `In ${slaRemainingHours}h`}
                    accent={slaExpired}
                  />
                </div>
              </>
            )}
          </div>
        </div>

        {/* Raise dispute */}
        {canRaiseDispute && !isDisputed && !isResolved && (
          <div
            className="rounded-2xl p-5 space-y-4"
            style={{ border: '1.5px solid rgba(186,43,76,0.3)', background: 'var(--danger-light)' }}
          >
            <div>
              <h2 className="text-sm font-bold" style={{ color: 'var(--danger)' }}>Raise a dispute</h2>
              <p className="text-xs mt-1 text-pretty" style={{ color: 'var(--muted)' }}>
                Raising a dispute locks the escrow. The admin has 7 days to mediate. After 7 days, either party can trigger an automatic equal split of the collateral.
              </p>
            </div>
            <button
              onClick={raiseDispute}
              disabled={isPending || isConfirming}
              className="w-full rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-60"
              style={{ background: 'var(--danger)', color: 'white' }}
            >
              <AlertTriangle size={14} />
              {isPending || isConfirming ? 'Raising dispute…' : 'Raise Dispute On-Chain'}
            </button>
            {isSuccess && txHash && (
              <a href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, txHash)} target="_blank" rel="noopener noreferrer" className="text-xs underline text-center block" style={{ color: 'var(--danger)' }}>
                View on explorer
              </a>
            )}
          </div>
        )}

        {/* Dispute status when active */}
        {isDisputed && (
          <div className="space-y-4">
            {/* SLA progress */}
            <div
              className="rounded-2xl p-4 space-y-3"
              style={{ background: 'var(--surface-strong)', border: '1.5px solid var(--border)' }}
            >
              <div className="flex items-center gap-2">
                <Clock size={14} style={{ color: slaExpired ? 'var(--danger)' : 'var(--warning)' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                  Admin mediation SLA
                </span>
              </div>
              {slaExpired ? (
                <p className="text-xs" style={{ color: 'var(--danger)' }}>
                  SLA has expired. No admin action was taken. Either party can now trigger an automatic equal split.
                </p>
              ) : (
                <p className="text-xs" style={{ color: 'var(--muted)' }}>
                  The platform admin has <strong>{slaRemainingHours} hours</strong> remaining to resolve this dispute. If no resolution happens, either party can trigger an automatic equal split.
                </p>
              )}

              {/* Progress bar */}
              {disputeRaisedAt > 0 && (
                <div className="h-2 rounded-full overflow-hidden" style={{ background: 'var(--border)' }}>
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(100, ((now - disputeRaisedAt) / (7 * 86400)) * 100)}%`,
                      background: slaExpired ? 'var(--danger)' : 'var(--warning)',
                    }}
                  />
                </div>
              )}

              {slaExpired && (isLender || isBorrower) && (
                <button
                  onClick={triggerTimeout}
                  disabled={isPending || isConfirming}
                  className="w-full rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-60"
                  style={{ background: 'var(--warning)', color: 'white' }}
                >
                  <Scale size={14} />
                  {isPending || isConfirming ? 'Processing…' : 'Trigger Equal Split'}
                </button>
              )}
            </div>

            {/* What happens next */}
            <div className="rounded-xl p-4 space-y-2" style={{ background: 'var(--surface-muted)' }}>
              <p className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>What happens next?</p>
              <ul className="space-y-1.5 text-xs" style={{ color: 'var(--muted)' }}>
                <li className="flex gap-2"><span style={{ color: 'var(--accent)' }}>1.</span> Provide evidence below using the log below.</li>
                <li className="flex gap-2"><span style={{ color: 'var(--accent)' }}>2.</span> Platform admin reviews and splits collateral fairly.</li>
                <li className="flex gap-2"><span style={{ color: 'var(--accent)' }}>3.</span> After 7 days, either party can trigger an automatic 50/50 split.</li>
                <li className="flex gap-2"><span style={{ color: 'var(--accent)' }}>4.</span> Funds become available for withdrawal from your dashboard.</li>
              </ul>
            </div>
          </div>
        )}

        {/* Resolved state */}
        {isResolved && (
          <div className="rounded-2xl p-5 text-center space-y-2" style={{ background: 'var(--success-light)', border: '1.5px solid rgba(26,120,64,0.25)' }}>
            <CheckCircle size={24} style={{ color: 'var(--success)', margin: '0 auto' }} />
            <p className="text-sm font-semibold" style={{ color: 'var(--success)' }}>Dispute resolved</p>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>
              Funds have been split and are available for withdrawal from your dashboard.
            </p>
          </div>
        )}

        {/* Evidence log */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <FileText size={14} style={{ color: 'var(--muted)' }} />
            <h2 className="text-sm font-semibold" style={{ color: 'var(--ink-2)' }}>Evidence log</h2>
            <span
              className="text-xs rounded-full px-2 py-0.5"
              style={{ background: 'var(--warning-light)', color: 'var(--warning)' }}
            >
              Offchain demo
            </span>
          </div>

          <div className="rounded-2xl overflow-hidden" style={{ border: '1.5px solid var(--border)', background: 'var(--surface-strong)' }}>
            <div className="divide-y" style={{ maxHeight: '240px', overflowY: 'auto' }}>
              {evidenceLog.map((entry, i) => (
                <div key={i} className="px-4 py-3">
                  <div className="flex items-center gap-2 mb-1">
                    {entry.type === 'note' && <FileText size={12} style={{ color: 'var(--muted)' }} />}
                    {entry.type === 'message' && <MessageCircle size={12} style={{ color: 'var(--accent)' }} />}
                    {entry.type === 'photo' && <Camera size={12} style={{ color: 'var(--terra)' }} />}
                    <span className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>{entry.author}</span>
                    <span className="text-xs" style={{ color: 'var(--subtle)' }}>{entry.timestamp}</span>
                  </div>
                  <p className="text-xs text-pretty" style={{ color: 'var(--ink-2)', paddingLeft: '20px' }}>{entry.content}</p>
                </div>
              ))}
            </div>

            {/* Add evidence */}
            <div className="px-4 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
              <div className="flex gap-2">
                <input
                  value={evidenceText}
                  onChange={(e) => setEvidenceText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addEvidence()}
                  placeholder="Describe what happened, add context…"
                  className="flex-1 rounded-xl px-3 py-2 text-xs"
                  style={{
                    background: 'var(--surface-muted)',
                    border: '1.5px solid var(--border)',
                    color: 'var(--ink)',
                    outline: 'none',
                  }}
                />
                <button
                  onClick={addEvidence}
                  disabled={!evidenceText.trim()}
                  className="rounded-xl px-3 py-2 text-xs font-semibold transition-all disabled:opacity-50"
                  style={{ background: 'var(--accent)', color: 'white' }}
                >
                  Add
                </button>
              </div>
              <p className="text-xs mt-1.5" style={{ color: 'var(--subtle)' }}>
                Evidence stored locally only. Full version: IPFS + on-chain hash.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function Row({
  label,
  value,
  accent,
  overdue,
}: {
  label: string
  value: string
  accent?: boolean
  overdue?: boolean
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      <span
        className="text-xs tabular-nums font-semibold"
        style={{ color: overdue ? 'var(--danger)' : accent ? 'var(--accent)' : 'var(--ink-2)' }}
      >
        {overdue ? `⚠ ${value}` : value}
      </span>
    </div>
  )
}

function fmtAddr(addr: string) {
  return addr.slice(0, 6) + '…' + addr.slice(-4)
}

function parseError(e: unknown): string {
  const msg = (e as Error)?.message?.toLowerCase() ?? ''
  if (msg.includes('user rejected')) return 'Cancelled.'
  if (msg.includes('reverted')) return 'Transaction reverted — dispute window may have expired.'
  return 'Something went wrong.'
}
