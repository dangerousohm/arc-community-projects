/**
 * Screen 5 — Transaction timeline.
 * Shows all escrow states: deposit, pickup, return confirmations,
 * settlement, timeout, dispute, and admin resolution.
 * Backed by live contract reads on Arc Testnet.
 */

import {
  ArrowLeft,
  Shield,
  CheckCircle,
  Clock,
  AlertTriangle,
  XCircle,
  Wallet,
  Package,
  ArrowDownCircle,
  Scale,
} from 'lucide-react'
import { useState } from 'react'
import {
  useAccount,
  useReadContract,
  useWriteContract,
  useWaitForTransactionReceipt,
} from 'wagmi'
import { toast } from 'sonner'
import { ITEM_LENDING_ESCROW_ABI, ESCROW_STATE, ESCROW_STATE_LABELS, type EscrowData } from '../../escrow-abi'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { Amount } from '@/onchain-money'

const ARC_TESTNET_CHAIN_ID = 5042002
const ESCROW_CONTRACT = import.meta.env.VITE_ESCROW_ADDRESS as `0x${string}` | undefined

interface Props {
  escrowId: bigint
  onBack: () => void
  onOpenDispute: (escrowId: bigint) => void
}

export default function TimelineScreen({ escrowId, onBack, onOpenDispute }: Props) {
  const { address } = useAccount()
  const usdcFact = getUsdc(ARC_TESTNET_CHAIN_ID)!

  const { data: escrow, refetch } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'getEscrow',
    args: [escrowId],
    chainId: ARC_TESTNET_CHAIN_ID,
  }) as { data: EscrowData | undefined; refetch: () => void }

  const { data: pendingWithdrawal } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'pendingWithdrawals',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: !!address },
  })

  const { writeContract, data: txHash, isPending } = useWriteContract()
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash: txHash })
  const [now] = useState(() => Math.floor(Date.now() / 1000))

  if (!ESCROW_CONTRACT) return <ContractNotDeployed onBack={onBack} />
  if (!escrow) return <LoadingState onBack={onBack} />

  const isLender = address?.toLowerCase() === escrow.lender.toLowerCase()
  const isBorrower = address?.toLowerCase() === escrow.borrower.toLowerCase()
  const collateralFmt = Amount.fromRaw(escrow.collateral, usdcFact.decimals).toFixed(2)
  const feeFmt = Amount.fromRaw(escrow.platformFee, usdcFact.decimals).toFixed(2)
  const totalFmt = Amount.fromRaw(escrow.collateral + escrow.platformFee, usdcFact.decimals).toFixed(2)
  const isDepositExpired = escrow.state === ESCROW_STATE.Created && now > Number(escrow.depositDeadline)
  const isReturnOverdue = escrow.state === ESCROW_STATE.PickedUp && now > Number(escrow.returnDeadline)

  const pendingFmt = pendingWithdrawal
    ? Amount.fromRaw(pendingWithdrawal, usdcFact.decimals).toFixed(2)
    : '0.00'
  const hasPending = pendingWithdrawal && (pendingWithdrawal) > 0n

  const callContract = (functionName: string, args: unknown[]) => {
    writeContract(
      {
        address: ESCROW_CONTRACT,
        abi: ITEM_LENDING_ESCROW_ABI,
        functionName: functionName as 'confirmPickup',
        args: args as [bigint],
        chainId: ARC_TESTNET_CHAIN_ID,
      },
      {
        onSuccess: () => {
          toast.success('Transaction submitted')
          setTimeout(refetch, 3000)
        },
        onError: (e) => toast.error(parseError(e)),
      },
    )
  }

  const steps = buildSteps(escrow, isLender, isBorrower, now)

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      <header
        className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3"
        style={{
          background: 'rgba(250, 246, 240, 0.90)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <button
          onClick={onBack}
          className="flex items-center justify-center rounded-xl w-9 h-9"
          style={{ background: 'var(--surface-muted)' }}
          aria-label="Go back"
        >
          <ArrowLeft size={16} style={{ color: 'var(--ink)' }} />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>
            Escrow #{escrowId.toString()}
          </h1>
          <div className="text-xs mono" style={{ color: 'var(--muted)' }}>
            {escrow.itemId}
          </div>
        </div>
        <StateChip state={escrow.state} />
      </header>

      <div className="max-w-lg mx-auto px-4 py-5 pb-32 space-y-5">
        {/* Financial summary */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{ border: '1.5px solid var(--border)', background: 'var(--surface-strong)' }}
        >
          <div
            className="px-4 py-3 flex items-center gap-2"
            style={{ background: 'var(--accent)', color: 'white' }}
          >
            <Shield size={14} />
            <span className="text-xs font-semibold">Escrow Financials</span>
          </div>
          <div className="p-4 space-y-2.5">
            <FinRow label="Collateral (refundable)" value={`$${collateralFmt} USDC`} accent />
            <FinRow label="Platform fee (2.5%, non-refundable)" value={`$${feeFmt} USDC`} />
            <FinRow label="Total deposited by borrower" value={`$${totalFmt} USDC`} bold />
            <div className="border-t pt-2.5 space-y-2" style={{ borderColor: 'var(--border)' }}>
              <FinRow
                label="Deposit deadline"
                value={fmtDeadline(escrow.depositDeadline)}
                overdue={isDepositExpired}
              />
              <FinRow
                label="Return deadline"
                value={fmtDeadline(escrow.returnDeadline)}
                overdue={isReturnOverdue}
              />
              <FinRow
                label="Dispute window"
                value={`${Number(escrow.disputeWindow) / 86400}d after return deadline`}
              />
            </div>
          </div>
        </div>

        {/* Timeline steps */}
        <div>
          <h2 className="text-xs font-semibold mb-3" style={{ color: 'var(--muted)' }}>
            TRANSACTION TIMELINE
          </h2>
          <div className="relative">
            {/* Connecting line */}
            <div
              className="absolute left-5 top-6 bottom-6 w-px"
              style={{ background: 'var(--border)' }}
            />
            <div className="space-y-1">
              {steps.map((step, i) => (
                <TimelineStep key={i} step={step} />
              ))}
            </div>
          </div>
        </div>

        {/* Pending withdrawal */}
        {!!hasPending && (
          <div
            className="rounded-2xl p-4 space-y-3"
            style={{ background: 'var(--success-light)', border: '1.5px solid rgba(26,120,64,0.25)' }}
          >
            <div className="flex items-center gap-2">
              <Wallet size={16} style={{ color: 'var(--success)' }} />
              <div>
                <div className="text-sm font-semibold" style={{ color: 'var(--success)' }}>
                  ${pendingFmt} USDC ready to claim
                </div>
                <div className="text-xs" style={{ color: 'var(--muted)' }}>
                  Your collateral has been released from escrow.
                </div>
              </div>
            </div>
            <button
              onClick={() => callContract('withdraw', [])}
              disabled={isPending || isConfirming}
              className="w-full rounded-xl py-3 text-sm font-semibold transition-all disabled:opacity-60"
              style={{ background: 'var(--success)', color: 'white' }}
            >
              {isPending || isConfirming ? 'Withdrawing…' : `Withdraw $${pendingFmt} USDC`}
            </button>
            {isSuccess && txHash && (
              <a
                href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, txHash)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs underline block text-center"
                style={{ color: 'var(--success)' }}
              >
                View on explorer
              </a>
            )}
          </div>
        )}

        {/* Action buttons */}
        <div className="space-y-3">
          {/* Confirm pickup */}
          {escrow.state === ESCROW_STATE.Funded && (isLender || isBorrower) && (
            <ActionButton
              label={isLender ? 'Confirm pickup (lender)' : 'Confirm pickup (borrower)'}
              done={isLender ? escrow.lenderConfirmedPickup : escrow.borrowerConfirmedPickup}
              doneLabel="Pickup confirmed"
              onClick={() => callContract('confirmPickup', [escrowId])}
              loading={isPending || isConfirming}
              color="var(--accent)"
            />
          )}

          {/* Confirm return */}
          {escrow.state === ESCROW_STATE.PickedUp && (isLender || isBorrower) && (
            <ActionButton
              label={isLender ? 'Confirm return (lender)' : 'Confirm return (borrower)'}
              done={isLender ? escrow.lenderConfirmedReturn : escrow.borrowerConfirmedReturn}
              doneLabel="Return confirmed"
              onClick={() => callContract('confirmReturn', [escrowId])}
              loading={isPending || isConfirming}
              color="var(--terra)"
            />
          )}

          {/* Fund escrow */}
          {escrow.state === ESCROW_STATE.Created && isBorrower && !isDepositExpired && (
            <ActionButton
              label={`Fund escrow — deposit $${totalFmt} USDC`}
              done={false}
              doneLabel=""
              onClick={() => callContract('fundEscrow', [escrowId])}
              loading={isPending || isConfirming}
              color="var(--accent)"
            />
          )}

          {/* Claim timeout */}
          {escrow.state === ESCROW_STATE.Created && isLender && isDepositExpired && (
            <ActionButton
              label="Mark as timed out (borrower never funded)"
              done={false}
              doneLabel=""
              onClick={() => callContract('claimTimeout', [escrowId])}
              loading={isPending || isConfirming}
              color="var(--muted)"
            />
          )}

          {/* Raise dispute */}
          {(escrow.state === ESCROW_STATE.PickedUp ||
            escrow.state === ESCROW_STATE.Returned ||
            (escrow.state === ESCROW_STATE.Funded && isLender && now > Number(escrow.returnDeadline))) && (
            <button
              onClick={() => onOpenDispute(escrowId)}
              className="w-full rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-all"
              style={{
                background: 'var(--danger-light)',
                color: 'var(--danger)',
                border: '1.5px solid rgba(186,43,76,0.2)',
              }}
            >
              <AlertTriangle size={14} />
              Raise a Dispute
            </button>
          )}

          {/* Dispute timeout resolve */}
          {escrow.state === ESCROW_STATE.Disputed &&
            (isLender || isBorrower) &&
            Number(escrow.disputeRaisedAt) > 0 &&
            now >= Number(escrow.disputeRaisedAt) + 7 * 86400 && (
              <ActionButton
                label="Trigger dispute timeout (auto equal split)"
                done={false}
                doneLabel=""
                onClick={() => callContract('disputeTimeoutResolve', [escrowId])}
                loading={isPending || isConfirming}
                color="var(--warning)"
              />
            )}

          {/* Cancel */}
          {escrow.state === ESCROW_STATE.Created && (isLender || isBorrower) && (
            <button
              onClick={() => callContract('cancelEscrow', [escrowId])}
              disabled={isPending || isConfirming}
              className="w-full py-2 text-xs text-center transition-all disabled:opacity-50"
              style={{ color: 'var(--muted)' }}
            >
              Cancel escrow
            </button>
          )}
        </div>

        {/* Last tx confirmation */}
        {isSuccess && txHash && (
          <div className="rounded-xl p-3 text-xs text-center" style={{ background: 'var(--success-light)', color: 'var(--success)' }}>
            Transaction confirmed.{' '}
            <a href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, txHash)} target="_blank" rel="noopener noreferrer" className="underline font-medium">
              View on explorer
            </a>
          </div>
        )}
      </div>
    </div>
  )
}

interface TimelineStepData {
  icon: React.ReactNode
  label: string
  sublabel?: string
  status: 'done' | 'active' | 'pending' | 'warn' | 'error'
}

function buildSteps(escrow: EscrowData, _isLender: boolean, _isBorrower: boolean, _now: number): TimelineStepData[] {
  const s = escrow.state
  const steps: TimelineStepData[] = []

  steps.push({
    icon: <Package size={14} />,
    label: 'Escrow created',
    sublabel: `Lender: ${fmtAddr(escrow.lender)}`,
    status: s >= ESCROW_STATE.Created ? 'done' : 'pending',
  })

  if (s === ESCROW_STATE.TimedOut) {
    steps.push({ icon: <Clock size={14} />, label: 'Deposit timed out', sublabel: 'Borrower did not fund', status: 'warn' })
    return steps
  }
  if (s === ESCROW_STATE.Cancelled) {
    steps.push({ icon: <XCircle size={14} />, label: 'Cancelled', status: 'error' })
    return steps
  }

  steps.push({
    icon: <ArrowDownCircle size={14} />,
    label: 'Borrower deposited collateral',
    sublabel: `Borrower: ${fmtAddr(escrow.borrower)}`,
    status: s >= ESCROW_STATE.Funded ? 'done' : 'pending',
  })

  steps.push({
    icon: <CheckCircle size={14} />,
    label: 'Pickup confirmed',
    sublabel: `Lender: ${escrow.lenderConfirmedPickup ? '✓' : '○'}  Borrower: ${escrow.borrowerConfirmedPickup ? '✓' : '○'}`,
    status: s >= ESCROW_STATE.PickedUp ? 'done' : s === ESCROW_STATE.Funded ? 'active' : 'pending',
  })

  if (s === ESCROW_STATE.Disputed) {
    steps.push({ icon: <AlertTriangle size={14} />, label: 'Dispute raised', sublabel: 'Awaiting admin resolution', status: 'warn' })
    return steps
  }
  if (s === ESCROW_STATE.AdminResolved) {
    steps.push({ icon: <Scale size={14} />, label: 'Dispute resolved by admin', sublabel: 'Funds split and released', status: 'done' })
    return steps
  }

  steps.push({
    icon: <CheckCircle size={14} />,
    label: 'Return confirmed',
    sublabel: `Lender: ${escrow.lenderConfirmedReturn ? '✓' : '○'}  Borrower: ${escrow.borrowerConfirmedReturn ? '✓' : '○'}`,
    status: s >= ESCROW_STATE.Returned ? 'done' : s === ESCROW_STATE.PickedUp ? 'active' : 'pending',
  })

  steps.push({
    icon: <Wallet size={14} />,
    label: 'Escrow settled',
    sublabel: s === ESCROW_STATE.Settled ? 'Collateral refunded to borrower' : 'Pending return confirmation',
    status: s === ESCROW_STATE.Settled ? 'done' : 'pending',
  })

  return steps
}

function TimelineStep({ step }: { step: TimelineStepData }) {
  const colors: Record<string, string> = {
    done: 'var(--success)',
    active: 'var(--accent)',
    pending: 'var(--border-strong)',
    warn: 'var(--warning)',
    error: 'var(--danger)',
  }
  const bg: Record<string, string> = {
    done: 'var(--success-light)',
    active: 'var(--accent-light)',
    pending: 'var(--surface-muted)',
    warn: 'var(--warning-light)',
    error: 'var(--danger-light)',
  }

  return (
    <div className="flex items-start gap-3 pl-1 pb-4">
      <div
        className="flex items-center justify-center rounded-full w-8 h-8 flex-shrink-0 z-10"
        style={{ background: bg[step.status], color: colors[step.status] }}
      >
        {step.icon}
      </div>
      <div className="pt-1">
        <div className="text-sm font-semibold" style={{ color: step.status === 'pending' ? 'var(--muted)' : 'var(--ink)' }}>
          {step.label}
        </div>
        {step.sublabel && (
          <div className="text-xs mono mt-0.5" style={{ color: 'var(--muted)' }}>
            {step.sublabel}
          </div>
        )}
      </div>
    </div>
  )
}

function StateChip({ state }: { state: number }) {
  const map: Record<number, { bg: string; color: string }> = {
    [ESCROW_STATE.Created]: { bg: 'var(--surface-muted)', color: 'var(--muted)' },
    [ESCROW_STATE.Funded]: { bg: 'var(--warning-light)', color: 'var(--warning)' },
    [ESCROW_STATE.PickedUp]: { bg: 'var(--accent-light)', color: 'var(--accent)' },
    [ESCROW_STATE.Returned]: { bg: 'var(--accent-light)', color: 'var(--accent)' },
    [ESCROW_STATE.Settled]: { bg: 'var(--success-light)', color: 'var(--success)' },
    [ESCROW_STATE.Disputed]: { bg: 'var(--danger-light)', color: 'var(--danger)' },
    [ESCROW_STATE.Cancelled]: { bg: 'var(--surface-muted)', color: 'var(--muted)' },
    [ESCROW_STATE.TimedOut]: { bg: 'var(--surface-muted)', color: 'var(--muted)' },
    [ESCROW_STATE.AdminResolved]: { bg: 'var(--success-light)', color: 'var(--success)' },
  }
  const s = map[state] ?? { bg: 'var(--surface-muted)', color: 'var(--muted)' }
  return (
    <span className="text-xs font-medium rounded-full px-2.5 py-1" style={{ background: s.bg, color: s.color }}>
      {ESCROW_STATE_LABELS[state]}
    </span>
  )
}

function ActionButton({
  label,
  done,
  doneLabel,
  onClick,
  loading,
  color,
}: {
  label: string
  done: boolean
  doneLabel: string
  onClick: () => void
  loading: boolean
  color: string
}) {
  if (done) {
    return (
      <div className="w-full rounded-xl py-3 text-sm font-semibold text-center" style={{ background: 'var(--success-light)', color: 'var(--success)' }}>
        <CheckCircle size={14} className="inline mr-1.5" />
        {doneLabel}
      </div>
    )
  }
  return (
    <button
      onClick={onClick}
      disabled={loading}
      className="w-full rounded-xl py-3 text-sm font-semibold transition-all disabled:opacity-60"
      style={{ background: color, color: 'white' }}
    >
      {loading ? 'Submitting…' : label}
    </button>
  )
}

function FinRow({
  label,
  value,
  accent,
  bold,
  overdue,
}: {
  label: string
  value: string
  accent?: boolean
  bold?: boolean
  overdue?: boolean
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      <span
        className="text-xs tabular-nums font-semibold"
        style={{
          color: overdue ? 'var(--danger)' : accent ? 'var(--accent)' : bold ? 'var(--ink)' : 'var(--ink-2)',
          fontWeight: bold ? 700 : 600,
        }}
      >
        {overdue ? `⚠ ${value}` : value}
      </span>
    </div>
  )
}

function fmtAddr(addr: string) {
  return addr.slice(0, 6) + '…' + addr.slice(-4)
}

function fmtDeadline(ts: bigint) {
  return new Date(Number(ts) * 1000).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function parseError(e: unknown): string {
  const msg = (e as Error)?.message?.toLowerCase() ?? ''
  if (msg.includes('user rejected') || msg.includes('user denied')) return 'Cancelled.'
  if (msg.includes('reverted')) return 'Transaction reverted — check escrow state.'
  return 'Something went wrong.'
}

function ContractNotDeployed({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-dvh flex flex-col items-center justify-center gap-4 p-8 text-center" style={{ background: 'var(--bg-gradient)' }}>
      <Shield size={32} style={{ color: 'var(--terra)' }} />
      <p className="text-sm font-semibold" style={{ color: 'var(--terra)' }}>Contract not deployed</p>
      <button onClick={onBack} className="text-xs" style={{ color: 'var(--muted)' }}>Go back</button>
    </div>
  )
}

function LoadingState({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-dvh flex flex-col items-center justify-center gap-4 p-8 text-center" style={{ background: 'var(--bg-gradient)' }}>
      <div className="w-10 h-10 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: 'var(--accent)', borderTopColor: 'transparent' }} />
      <p className="text-sm" style={{ color: 'var(--muted)' }}>Loading escrow…</p>
      <button onClick={onBack} className="text-xs" style={{ color: 'var(--muted)' }}>Go back</button>
    </div>
  )
}
