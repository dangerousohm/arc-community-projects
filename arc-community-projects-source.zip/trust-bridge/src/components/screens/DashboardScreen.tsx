/**
 * Screen 4 — My borrowing and lending dashboard.
 * Reads escrow IDs for connected wallet from the deployed contract.
 */

import { ArrowLeft, Package, ArrowUpDown, Clock, CheckCircle } from 'lucide-react'
import { useAccount, useReadContract } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { ITEM_LENDING_ESCROW_ABI, ESCROW_STATE, ESCROW_STATE_LABELS, type EscrowData } from '../../escrow-abi'
import { getUsdc } from '@/onchain-facts'
import { Amount } from '@/onchain-money'

const ARC_TESTNET_CHAIN_ID = 5042002
const ESCROW_CONTRACT = import.meta.env.VITE_ESCROW_ADDRESS as `0x${string}` | undefined

interface Props {
  onBack: () => void
  onOpenTimeline: (escrowId: bigint) => void
}

export default function DashboardScreen({ onBack, onOpenTimeline }: Props) {
  const { address, isConnected } = useAccount()
  const usdcFact = getUsdc(ARC_TESTNET_CHAIN_ID)!

  // Load escrow IDs as lender
  const { data: lenderIds, isLoading: loadingLender } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'getEscrowsByLender',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: !!address && !!ESCROW_CONTRACT },
  })

  // Load escrow IDs as borrower
  const { data: borrowerIds, isLoading: loadingBorrower } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'getEscrowsByBorrower',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: !!address && !!ESCROW_CONTRACT },
  })

  // Pending withdrawals
  const { data: pendingWithdrawal } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'pendingWithdrawals',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: !!address && !!ESCROW_CONTRACT },
  })

  const isLoading = loadingLender || loadingBorrower
  const pendingAmount = pendingWithdrawal
    ? Amount.fromRaw(pendingWithdrawal, usdcFact.decimals).toFixed(2)
    : '0.00'
  const hasPending = pendingWithdrawal && (pendingWithdrawal) > 0n

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      <header
        className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3"
        style={{
          background: 'rgba(250, 246, 240, 0.90)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <button
          onClick={onBack}
          className="flex items-center justify-center rounded-xl w-9 h-9"
          style={{ background: 'var(--surface-muted)' }}
          aria-label="Go back"
        >
          <ArrowLeft size={16} style={{ color: 'var(--ink)' }} />
        </button>
        <h1 className="display text-base font-bold flex-1" style={{ color: 'var(--ink)' }}>
          My Dashboard
        </h1>
        <ConnectKitButton />
      </header>

      <div className="max-w-lg mx-auto px-4 py-5 pb-24 space-y-5">
        {!isConnected ? (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <Package size={32} style={{ color: 'var(--subtle)' }} />
            <p className="text-sm" style={{ color: 'var(--muted)' }}>Connect your wallet to see your escrows.</p>
            <ConnectKitButton />
          </div>
        ) : !ESCROW_CONTRACT ? (
          <ContractNotDeployed />
        ) : (
          <>
            {/* Pending withdrawal banner */}
            {hasPending && (
              <WithdrawBanner amount={pendingAmount} />
            )}

            {/* Lending */}
            <section>
              <div className="flex items-center gap-2 mb-3">
                <Package size={14} style={{ color: 'var(--accent)' }} />
                <h2 className="text-sm font-semibold" style={{ color: 'var(--ink-2)' }}>
                  Items I'm lending ({(lenderIds as bigint[])?.length ?? 0})
                </h2>
              </div>
              {isLoading ? (
                <LoadingSkeleton />
              ) : (lenderIds as bigint[])?.length === 0 ? (
                <EmptyState message="No lending escrows yet." cta="Create a listing to start lending." />
              ) : (
                <div className="space-y-2">
                  {(lenderIds as bigint[])?.map((id) => (
                    <EscrowCard
                      key={id.toString()}
                      escrowId={id}
                      onOpenTimeline={onOpenTimeline}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Borrowing */}
            <section>
              <div className="flex items-center gap-2 mb-3">
                <ArrowUpDown size={14} style={{ color: 'var(--terra)' }} />
                <h2 className="text-sm font-semibold" style={{ color: 'var(--ink-2)' }}>
                  Items I'm borrowing ({(borrowerIds as bigint[])?.length ?? 0})
                </h2>
              </div>
              {isLoading ? (
                <LoadingSkeleton />
              ) : (borrowerIds as bigint[])?.length === 0 ? (
                <EmptyState message="No borrowing escrows yet." cta="Browse items to start borrowing." />
              ) : (
                <div className="space-y-2">
                  {(borrowerIds as bigint[])?.map((id) => (
                    <EscrowCard
                      key={id.toString()}
                      escrowId={id}
                      onOpenTimeline={onOpenTimeline}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </div>
  )
}

function EscrowCard({
  escrowId,
  onOpenTimeline,
}: {
  escrowId: bigint
  onOpenTimeline: (id: bigint) => void
}) {
  const usdcFact = getUsdc(ARC_TESTNET_CHAIN_ID)!
  const { data: escrow } = useReadContract({
    address: ESCROW_CONTRACT,
    abi: ITEM_LENDING_ESCROW_ABI,
    functionName: 'getEscrow',
    args: [escrowId],
    chainId: ARC_TESTNET_CHAIN_ID,
  }) as { data: EscrowData | undefined }

  if (!escrow) return <div className="rounded-xl h-16 animate-pulse" style={{ background: 'var(--surface-muted)' }} />

  const collateralFmt = Amount.fromRaw(escrow.collateral, usdcFact.decimals).toFixed(2)
  const stateLabel = ESCROW_STATE_LABELS[escrow.state] ?? 'Unknown'
  const returnDate = new Date(Number(escrow.returnDeadline) * 1000).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  })

  const stateStyle = getStateStyle(escrow.state)

  return (
    <button
      onClick={() => onOpenTimeline(escrowId)}
      className="w-full text-left rounded-2xl p-4 transition-all hover:shadow-md"
      style={{ background: 'var(--surface-strong)', border: '1.5px solid var(--border)' }}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1 min-w-0 flex-1">
          <div className="text-xs font-semibold mono" style={{ color: 'var(--muted)' }}>
            Escrow #{escrowId.toString()}
          </div>
          <div className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>
            {escrow.itemId || 'Item'}
          </div>
          <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--muted)' }}>
            <Clock size={10} />
            <span>Return by {returnDate}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2 flex-shrink-0 ml-3">
          <span
            className="text-xs font-medium rounded-full px-2.5 py-1"
            style={{ background: stateStyle.bg, color: stateStyle.color }}
          >
            {stateLabel}
          </span>
          <span className="text-sm font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
            ${collateralFmt}
          </span>
        </div>
      </div>

      {/* Confirmation state mini-view */}
      {escrow.state === ESCROW_STATE.Funded && (
        <div className="mt-3 flex gap-3 text-xs">
          <ConfirmDot label="Lender pickup" done={escrow.lenderConfirmedPickup} />
          <ConfirmDot label="Borrower pickup" done={escrow.borrowerConfirmedPickup} />
        </div>
      )}
      {escrow.state === ESCROW_STATE.PickedUp && (
        <div className="mt-3 flex gap-3 text-xs">
          <ConfirmDot label="Lender return" done={escrow.lenderConfirmedReturn} />
          <ConfirmDot label="Borrower return" done={escrow.borrowerConfirmedReturn} />
        </div>
      )}

      <div className="mt-2 text-xs font-medium" style={{ color: 'var(--accent)' }}>
        View timeline →
      </div>
    </button>
  )
}

function ConfirmDot({ label, done }: { label: string; done: boolean }) {
  return (
    <div className="flex items-center gap-1">
      <div
        className="w-2 h-2 rounded-full flex-shrink-0"
        style={{ background: done ? 'var(--success)' : 'var(--border-strong)' }}
      />
      <span style={{ color: done ? 'var(--success)' : 'var(--muted)' }}>{label}</span>
    </div>
  )
}

function getStateStyle(state: number) {
  switch (state) {
    case ESCROW_STATE.Created: return { bg: 'var(--surface-muted)', color: 'var(--muted)' }
    case ESCROW_STATE.Funded: return { bg: 'var(--warning-light)', color: 'var(--warning)' }
    case ESCROW_STATE.PickedUp: return { bg: 'rgba(45,90,39,0.10)', color: 'var(--accent)' }
    case ESCROW_STATE.Returned: return { bg: 'var(--accent-light)', color: 'var(--accent)' }
    case ESCROW_STATE.Settled: return { bg: 'var(--success-light)', color: 'var(--success)' }
    case ESCROW_STATE.Disputed: return { bg: 'var(--danger-light)', color: 'var(--danger)' }
    case ESCROW_STATE.Cancelled: return { bg: 'var(--surface-muted)', color: 'var(--muted)' }
    case ESCROW_STATE.TimedOut: return { bg: 'var(--surface-muted)', color: 'var(--muted)' }
    case ESCROW_STATE.AdminResolved: return { bg: 'var(--accent-light)', color: 'var(--accent)' }
    default: return { bg: 'var(--surface-muted)', color: 'var(--muted)' }
  }
}

function WithdrawBanner({ amount }: { amount: string }) {
  return (
    <div
      className="rounded-2xl p-4 flex items-center gap-3"
      style={{ background: 'var(--success-light)', border: '1.5px solid rgba(26,120,64,0.25)' }}
    >
      <CheckCircle size={18} style={{ color: 'var(--success)', flexShrink: 0 }} />
      <div className="flex-1">
        <div className="text-sm font-semibold" style={{ color: 'var(--success)' }}>
          ${amount} USDC ready to withdraw
        </div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
          Collateral returned from a settled escrow. Go to the timeline to withdraw.
        </div>
      </div>
    </div>
  )
}

function EmptyState({ message, cta }: { message: string; cta: string }) {
  return (
    <div
      className="rounded-2xl py-8 px-4 text-center"
      style={{ background: 'var(--surface-muted)', border: '1.5px dashed var(--border-strong)' }}
    >
      <p className="text-sm font-medium" style={{ color: 'var(--ink-2)' }}>{message}</p>
      <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{cta}</p>
    </div>
  )
}

function LoadingSkeleton() {
  return (
    <div className="space-y-2">
      {[1, 2].map((i) => (
        <div key={i} className="rounded-2xl h-20 animate-pulse" style={{ background: 'var(--surface-muted)' }} />
      ))}
    </div>
  )
}

function ContractNotDeployed() {
  return (
    <div className="rounded-2xl p-5 space-y-2" style={{ background: 'var(--terra-light)', border: '1.5px solid rgba(192,89,59,0.25)' }}>
      <p className="text-sm font-semibold" style={{ color: 'var(--terra)' }}>Contract not deployed</p>
      <p className="text-xs" style={{ color: 'var(--muted)' }}>
        Set <code className="mono text-xs">VITE_ESCROW_ADDRESS</code> in .env after deploying ItemLendingEscrow to Arc Testnet.
      </p>
    </div>
  )
}
