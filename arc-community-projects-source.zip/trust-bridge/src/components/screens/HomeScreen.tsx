/**
 * Screen 1 — Activity discovery, item search, neighborhood map.
 * Desktop: two-column (sidebar + map/items). Mobile: single column.
 * Thai product copy; strong typography; warm cream/forest/terracotta palette.
 * Activity counts derived from DEMO_ITEMS, never hardcoded.
 */

import { useState } from 'react'
import { Search, Info } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import {
  ACTIVITIES,
  DEMO_ITEMS,
  getItemsByActivity,
  getActivityItemCount,
  searchItems,
  type DemoItem,
} from '../../demo-data'
import NeighborhoodMap from '../NeighborhoodMap'
import PlanningTable from '../PlanningTable'

interface Props {
  onSelectItem: (item: DemoItem) => void
}

export default function HomeScreen({ onSelectItem }: Props) {
  const [selectedActivity, setSelectedActivity] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  const displayedItems = searchQuery
    ? searchItems(searchQuery)
    : selectedActivity
      ? getItemsByActivity(selectedActivity)
      : DEMO_ITEMS.slice(0, 8)

  const toggleActivity = (id: string) => {
    setSearchQuery('')
    setSelectedActivity((prev) => (prev === id ? null : id))
  }

  const handleSearch = (q: string) => {
    setSearchQuery(q)
    if (q) setSelectedActivity(null)
  }

  const activeActivity = ACTIVITIES.find((a) => a.id === selectedActivity)

  const sectionTitle = searchQuery
    ? `ผลการค้นหา "${searchQuery}"`
    : selectedActivity
      ? `${activeActivity?.titleTh} — อุปกรณ์ใกล้คุณ`
      : 'ทุกอย่างที่ยืมได้ตอนนี้'

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 md:px-6"
        style={{
          background: 'rgba(250, 246, 240, 0.92)',
          backdropFilter: 'blur(14px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <div>
          <div
            className="display text-lg font-bold"
            style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
          >
            Trust Bridge
          </div>
          <div className="text-xs" style={{ color: 'var(--muted)' }}>
            Borrow a Possibility · ยืม ให้ยืม สร้างความไว้วางใจ
          </div>
        </div>
        <ConnectKitButton />
      </header>

      {/* Desktop two-column / mobile single-column */}
      <div className="md:flex md:min-h-[calc(100dvh-57px)]">
        {/* ── Sidebar (desktop sticky, mobile top section) ────────────────── */}
        <aside
          className="md:w-80 md:flex-shrink-0 md:sticky md:top-[57px] md:overflow-y-auto md:h-[calc(100dvh-57px)] px-4 pt-5 pb-6 md:px-5 space-y-5"
          style={{ borderRight: '1px solid var(--border)' }}
        >
          {/* Hero prompt */}
          <div>
            <h1
              className="display text-2xl font-bold text-balance"
              style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
            >
              อยากทำอะไร<br className="hidden md:block" />สุดสัปดาห์นี้?
            </h1>
            <p
              className="text-sm text-pretty mt-1.5"
              style={{ color: 'var(--muted)', maxWidth: '36ch' }}
            >
              ยืมอุปกรณ์จากเพื่อนบ้าน วางมัดจำ USDC — คืนของ คืนเงิน
            </p>
          </div>

          {/* Activity cards */}
          <div className="grid grid-cols-2 gap-2">
            {ACTIVITIES.map((activity) => {
              const count = getActivityItemCount(activity.id)
              const active = selectedActivity === activity.id
              return (
                <button
                  key={activity.id}
                  onClick={() => toggleActivity(activity.id)}
                  className="relative text-left rounded-2xl p-3 transition-all"
                  style={{
                    background: active ? activity.color : 'var(--surface-strong)',
                    border: `1.5px solid ${active ? activity.color : 'var(--border)'}`,
                    boxShadow: active
                      ? '0 4px 16px rgba(0,0,0,0.14)'
                      : '0 1px 4px rgba(0,0,0,0.04)',
                    minHeight: '80px',
                  }}
                  aria-pressed={active}
                >
                  <div className="text-xl mb-1.5" aria-hidden="true">
                    {activity.icon}
                  </div>
                  <div
                    className="text-xs font-bold leading-tight"
                    style={{ color: active ? 'white' : 'var(--ink)' }}
                  >
                    {activity.titleTh}
                  </div>
                  <div
                    className="text-xs mt-0.5 leading-tight"
                    style={{ color: active ? 'rgba(255,255,255,0.65)' : 'var(--muted)' }}
                  >
                    {activity.subtitleTh}
                  </div>
                  {/* Derived count — never hardcoded */}
                  <div
                    className="absolute top-2.5 right-2.5 text-xs font-semibold rounded-full px-1.5 py-0.5 tabular-nums"
                    style={{
                      background: active ? 'rgba(255,255,255,0.22)' : 'var(--surface-muted)',
                      color: active ? 'white' : 'var(--muted)',
                      fontSize: '10px',
                    }}
                  >
                    {count}
                  </div>
                </button>
              )
            })}
          </div>

          {/* Search */}
          <div className="relative">
            <Search
              size={15}
              className="absolute left-3 top-1/2 -translate-y-1/2"
              style={{ color: 'var(--subtle)' }}
              aria-hidden="true"
            />
            <input
              type="search"
              placeholder="ค้นหา: เต็นท์, กล้อง, สว่าน…"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full rounded-xl pl-9 pr-4 py-2.5 text-sm"
              style={{
                background: 'var(--surface-strong)',
                border: '1.5px solid var(--border)',
                color: 'var(--ink)',
                outline: 'none',
              }}
              aria-label="ค้นหาอุปกรณ์"
            />
          </div>

          {/* Planning Table — sidebar on desktop, hidden on mobile (shown below) */}
          <div className="hidden md:block">
            <PlanningTable onSelectItem={onSelectItem} />
          </div>

          {/* Demo notice */}
          <div
            className="rounded-xl px-3 py-2.5 text-xs flex gap-2"
            style={{
              background: 'var(--warning-light)',
              color: 'var(--warning)',
              border: '1px solid rgba(181,125,26,0.18)',
            }}
          >
            <Info size={12} className="flex-shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              <strong>เดโม:</strong> รายการสินค้าเป็นข้อมูลสมมุติ ธุรกรรม escrow เป็นจริงบน Arc Testnet
            </span>
          </div>
        </aside>

        {/* ── Main content ────────────────────────────────────────────────── */}
        <main className="flex-1 px-4 pt-5 pb-24 md:px-6 md:pt-6 space-y-5">
          {/* Section heading */}
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold" style={{ color: 'var(--ink-2)' }}>
              {sectionTitle}
            </h2>
            <span className="text-xs tabular-nums" style={{ color: 'var(--muted)' }}>
              {displayedItems.length} รายการ
            </span>
          </div>

          {/* Neighborhood Map */}
          <NeighborhoodMap items={displayedItems} onSelectItem={onSelectItem} />

          {/* Item cards grid — visible when activity selected or search active */}
          {(selectedActivity || searchQuery) && (
            <div>
              <h3 className="text-xs font-semibold mb-2" style={{ color: 'var(--ink-2)' }}>
                {searchQuery ? 'รายการที่พบ' : `ชุดอุปกรณ์สำหรับ${activeActivity?.titleTh}`}
              </h3>
              {displayedItems.length === 0 ? (
                <EmptyItems query={searchQuery} />
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {displayedItems.map((item) => (
                    <ItemCard key={item.id} item={item} onSelect={onSelectItem} />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Planning Table — shown inline on mobile */}
          <div className="md:hidden">
            <div className="text-xs font-semibold mb-2" style={{ color: 'var(--ink-2)' }}>
              ตารางวางแผนกิจกรรม
            </div>
            <PlanningTable onSelectItem={onSelectItem} />
          </div>
        </main>
      </div>
    </div>
  )
}

// ── Sub-components ────────────────────────────────────────────────────────────

function ItemCard({ item, onSelect }: { item: DemoItem; onSelect: (i: DemoItem) => void }) {
  return (
    <button
      onClick={() => onSelect(item)}
      className="w-full flex items-center gap-3 rounded-2xl p-3 text-left transition-all"
      style={{
        background: 'var(--surface-strong)',
        border: '1.5px solid var(--border)',
        boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
        minHeight: '60px',
      }}
      onMouseEnter={(e) => {
        ;(e.currentTarget as HTMLElement).style.boxShadow = '0 3px 12px rgba(0,0,0,0.10)'
      }}
      onMouseLeave={(e) => {
        ;(e.currentTarget as HTMLElement).style.boxShadow = '0 1px 4px rgba(0,0,0,0.04)'
      }}
    >
      <div
        className="flex items-center justify-center rounded-xl flex-shrink-0"
        style={{ width: '40px', height: '40px', background: item.imageColor + '22', fontSize: '20px' }}
        aria-hidden="true"
      >
        {item.imageEmoji}
      </div>
      <div className="min-w-0 flex-1">
        <div
          className="text-xs font-semibold truncate"
          style={{ color: 'var(--ink)' }}
        >
          {item.titleTh}
        </div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
          {item.ownerName}
        </div>
      </div>
      <div className="text-right flex-shrink-0">
        <div
          className="text-sm font-bold tabular-nums"
          style={{ color: 'var(--accent)' }}
        >
          ${item.suggestedCollateral}
        </div>
        <div className="text-xs" style={{ color: 'var(--subtle)', fontSize: '10px' }}>USDC</div>
      </div>
    </button>
  )
}

function EmptyItems({ query }: { query: string }) {
  return (
    <div className="rounded-2xl px-4 py-8 text-center" style={{ border: '1.5px dashed var(--border)' }}>
      <div className="text-2xl mb-2" aria-hidden="true">🔍</div>
      <p className="text-sm font-medium" style={{ color: 'var(--muted)' }}>
        {query ? `ไม่พบอุปกรณ์สำหรับ "${query}"` : 'ยังไม่มีอุปกรณ์ในหมวดนี้'}
      </p>
      <p className="text-xs mt-1" style={{ color: 'var(--subtle)' }}>
        ลองเปลี่ยนคำค้นหาหรือเพิ่มรายการด้วยปุ่ม +
      </p>
    </div>
  )
}
