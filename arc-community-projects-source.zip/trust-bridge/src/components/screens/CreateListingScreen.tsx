/**
 * Screen 3 — Create / manage local item drafts.
 *
 * DESIGN INTENT:
 * There is no on-chain listing registry yet. This screen saves drafts to
 * localStorage only. Drafts are clearly labeled "local draft" — they are NOT
 * published listings or blockchain-backed assets.
 *
 * Wallet connection is NOT required to draft an item. A wallet is required to
 * start a real escrow (done via ItemDetail → escrow flow).
 *
 * Validation rules:
 *   - Title, description: required, non-empty
 *   - Collateral: required, positive decimal up to 6 decimal places,
 *     stored and compared as integer micro-USDC to avoid floating-point issues
 *   - availableFrom: required, must be ≥ today
 *   - availableTo: required, must be > availableFrom
 *   - Activity: required
 */

import { useState } from 'react'
import { ArrowLeft, Plus, Info, Pencil, Trash2, ChevronRight, Package } from 'lucide-react'
import { ACTIVITIES } from '../../demo-data'

interface Props {
  onBack: () => void
}

// ── Draft type ────────────────────────────────────────────────────────────────

interface LocalDraft {
  id: string // uuid-lite
  title: string
  description: string
  condition: 'Excellent' | 'Good' | 'Fair'
  activityId: string
  collateralStr: string // raw decimal string the user typed
  availableFrom: string // YYYY-MM-DD
  availableTo: string
  story: string
  imageEmoji: string
  savedAt: string // ISO
}

type ScreenMode = 'list' | 'form'

const DRAFTS_KEY = 'trustbridge_drafts_v1'
const CONDITION_OPTIONS: Array<'Excellent' | 'Good' | 'Fair'> = ['Excellent', 'Good', 'Fair']
const EMOJI_OPTIONS = [
  '⛺', '🔧', '📷', '🎬', '🍳', '🏕️', '🎒', '🔦', '🛏', '🪑',
  '🍽', '🎸', '🖥', '🎙', '⛸', '🎿', '🪚', '🔩', '📏', '🫕',
]

function todayStr() {
  return new Date().toISOString().split('T')[0]
}

function nanoId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
}

// Validate collateral string: positive decimal, up to 6 decimal places, no NaN
function validateCollateral(s: string): string | null {
  const trimmed = s.trim()
  if (!trimmed) return 'กรุณาระบุมัดจำ'
  if (!/^\d+(\.\d{0,6})?$/.test(trimmed)) return 'ระบุตัวเลขทศนิยมสูงสุด 6 ตำแหน่ง'
  const n = Number(trimmed)
  if (!isFinite(n) || n <= 0) return 'มัดจำต้องมากกว่า 0'
  return null
}

function loadDrafts(): LocalDraft[] {
  try {
    const raw = localStorage.getItem(DRAFTS_KEY)
    if (!raw) return []
    return JSON.parse(raw) as LocalDraft[]
  } catch {
    return []
  }
}

function saveDrafts(drafts: LocalDraft[]) {
  try {
    localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts))
  } catch { /* storage unavailable */ }
}

const EMPTY_FORM = (): Omit<LocalDraft, 'id' | 'savedAt'> => ({
  title: '',
  description: '',
  condition: 'Good',
  activityId: '',
  collateralStr: '',
  availableFrom: todayStr(),
  availableTo: '',
  story: '',
  imageEmoji: '🎒',
})

export default function CreateListingScreen({ onBack }: Props) {
  const [mode, setMode] = useState<ScreenMode>('list')
  // Lazy initialiser reads localStorage once at mount — avoids setState-in-effect
  const [drafts, setDrafts] = useState<LocalDraft[]>(() => loadDrafts())
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY_FORM())
  const [errors, setErrors] = useState<Partial<Record<keyof typeof form, string>>>({})

  const set =
    (key: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [key]: e.target.value }))

  // ── Validation ──────────────────────────────────────────────────────────────

  const validate = (): boolean => {
    const e: Partial<Record<keyof typeof form, string>> = {}
    if (!form.title.trim()) e.title = 'จำเป็น'
    if (!form.description.trim()) e.description = 'จำเป็น'
    if (!form.activityId) e.activityId = 'เลือกกิจกรรม'

    const colErr = validateCollateral(form.collateralStr)
    if (colErr) e.collateralStr = colErr

    if (!form.availableFrom) {
      e.availableFrom = 'จำเป็น'
    } else if (form.availableFrom < todayStr()) {
      e.availableFrom = 'ต้องเป็นวันนี้หรือหลังจากนี้'
    }

    if (!form.availableTo) {
      e.availableTo = 'จำเป็น'
    } else if (form.availableTo <= form.availableFrom) {
      e.availableTo = 'ต้องหลังจากวันเริ่มต้น'
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // ── Actions ─────────────────────────────────────────────────────────────────

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    const now = new Date().toISOString()
    let updated: LocalDraft[]

    if (editingId) {
      updated = drafts.map((d) =>
        d.id === editingId ? { ...form, id: editingId, savedAt: now } : d,
      )
    } else {
      const newDraft: LocalDraft = { ...form, id: nanoId(), savedAt: now }
      updated = [newDraft, ...drafts]
    }

    saveDrafts(updated)
    setDrafts(updated)
    setMode('list')
    setEditingId(null)
    setForm(EMPTY_FORM())
    setErrors({})
  }

  const startEdit = (draft: LocalDraft) => {
    setEditingId(draft.id)
    setForm({
      title: draft.title,
      description: draft.description,
      condition: draft.condition,
      activityId: draft.activityId,
      collateralStr: draft.collateralStr,
      availableFrom: draft.availableFrom,
      availableTo: draft.availableTo,
      story: draft.story,
      imageEmoji: draft.imageEmoji,
    })
    setErrors({})
    setMode('form')
  }

  const deleteDraft = (id: string) => {
    const updated = drafts.filter((d) => d.id !== id)
    saveDrafts(updated)
    setDrafts(updated)
  }

  const startNew = () => {
    setEditingId(null)
    setForm(EMPTY_FORM())
    setErrors({})
    setMode('form')
  }

  const cancelForm = () => {
    setMode('list')
    setEditingId(null)
    setForm(EMPTY_FORM())
    setErrors({})
  }

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      <header
        className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3"
        style={{
          background: 'rgba(250, 246, 240, 0.92)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <button
          onClick={mode === 'form' ? cancelForm : onBack}
          className="flex items-center justify-center rounded-xl w-9 h-9 transition-colors"
          style={{ background: 'var(--surface-muted)', minWidth: '36px', minHeight: '36px' }}
          aria-label="ย้อนกลับ"
        >
          <ArrowLeft size={16} style={{ color: 'var(--ink)' }} aria-hidden="true" />
        </button>
        <h1 className="display text-base font-bold flex-1" style={{ color: 'var(--ink)' }}>
          {mode === 'form' ? (editingId ? 'แก้ไขรายการ' : 'เพิ่มรายการ') : 'รายการของฉัน'}
        </h1>
        <span
          className="text-xs font-medium rounded-full px-2.5 py-1"
          style={{ background: 'var(--warning-light)', color: 'var(--warning)' }}
        >
          ร่างโลคอล
        </span>
      </header>

      <div className="max-w-lg mx-auto px-4 py-5 pb-32">
        {/* Honest notice */}
        <div
          className="flex items-start gap-2 rounded-xl p-3 mb-4 text-xs"
          style={{
            background: 'var(--warning-light)',
            color: 'var(--warning)',
            border: '1px solid rgba(181,125,26,0.18)',
          }}
        >
          <Info size={12} className="flex-shrink-0 mt-0.5" aria-hidden="true" />
          <span>
            <strong>ร่างโลคอลเท่านั้น</strong> — รายการนี้บันทึกในเบราว์เซอร์ของคุณ ยังไม่ได้เผยแพร่หรือผูกกับบล็อกเชน
            การเปิด escrow จริงทำผ่านหน้ารายละเอียดสินค้า
          </span>
        </div>

        {mode === 'list' ? (
          <DraftList drafts={drafts} onEdit={startEdit} onDelete={deleteDraft} onNew={startNew} />
        ) : (
          <DraftForm
            form={form}
            errors={errors}
            set={set}
            isEditing={!!editingId}
            onSubmit={handleSubmit}
            onCancel={cancelForm}
            setForm={setForm}
          />
        )}
      </div>

      <style>{`
        .field-input {
          width: 100%;
          border-radius: 12px;
          padding: 10px 12px;
          font-size: 14px;
          background: var(--surface-strong);
          border: 1.5px solid var(--border);
          color: var(--ink);
          font-family: inherit;
          outline: none;
          transition: border-color 0.15s;
        }
        .field-input:focus {
          border-color: var(--focus);
        }
        .field-input[aria-invalid="true"] {
          border-color: var(--danger);
        }
      `}</style>
    </div>
  )
}

// ── Draft list view ─────────────────────────────────────────────────────────

function DraftList({
  drafts,
  onEdit,
  onDelete,
  onNew,
}: {
  drafts: LocalDraft[]
  onEdit: (d: LocalDraft) => void
  onDelete: (id: string) => void
  onNew: () => void
}) {
  return (
    <div className="space-y-4">
      <button
        onClick={onNew}
        className="w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold transition-all"
        style={{
          background: 'var(--accent)',
          color: 'white',
          boxShadow: '0 3px 14px rgba(45,90,39,0.25)',
          minHeight: '48px',
        }}
      >
        <Plus size={16} aria-hidden="true" />
        เพิ่มรายการใหม่
      </button>

      {drafts.length === 0 ? (
        <div className="rounded-2xl px-4 py-10 text-center" style={{ border: '1.5px dashed var(--border)' }}>
          <Package size={28} className="mx-auto mb-3" style={{ color: 'var(--subtle)' }} aria-hidden="true" />
          <p className="text-sm font-medium" style={{ color: 'var(--muted)' }}>
            ยังไม่มีร่างรายการ
          </p>
          <p className="text-xs mt-1" style={{ color: 'var(--subtle)' }}>
            กดปุ่มด้านบนเพื่อเริ่มต้น
          </p>
        </div>
      ) : (
        <div>
          <div className="text-xs font-semibold mb-2 flex items-center gap-2" style={{ color: 'var(--ink-2)' }}>
            ร่างโลคอล ({drafts.length})
          </div>
          <div className="rounded-2xl overflow-hidden" style={{ border: '1.5px solid var(--border)' }}>
            {drafts.map((draft, idx) => (
              <DraftRow
                key={draft.id}
                draft={draft}
                onEdit={onEdit}
                onDelete={onDelete}
                isLast={idx === drafts.length - 1}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function DraftRow({
  draft,
  onEdit,
  onDelete,
  isLast,
}: {
  draft: LocalDraft
  onEdit: (d: LocalDraft) => void
  onDelete: (id: string) => void
  isLast: boolean
}) {
  const [confirmDelete, setConfirmDelete] = useState(false)
  const savedDate = new Date(draft.savedAt).toLocaleDateString('th-TH', {
    day: 'numeric',
    month: 'short',
    year: '2-digit',
  })
  const activityLabel = ACTIVITIES.find((a) => a.id === draft.activityId)?.titleTh ?? draft.activityId

  return (
    <div
      className="flex items-center gap-3 px-4 py-3"
      style={{
        borderBottom: isLast ? 'none' : '1px solid var(--border)',
        background: 'var(--surface-strong)',
        minHeight: '60px',
      }}
    >
      <div
        className="flex items-center justify-center rounded-xl flex-shrink-0"
        style={{ width: '38px', height: '38px', background: 'var(--surface-muted)', fontSize: '18px' }}
        aria-hidden="true"
      >
        {draft.imageEmoji}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>
          {draft.title}
        </div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
          {activityLabel}
          <span className="mx-1.5" aria-hidden="true">·</span>
          ${draft.collateralStr} USDC
          <span className="mx-1.5" aria-hidden="true">·</span>
          บันทึก {savedDate}
        </div>
      </div>

      {confirmDelete ? (
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => onDelete(draft.id)}
            className="rounded-lg px-2.5 py-1.5 text-xs font-semibold"
            style={{ background: 'var(--danger-light)', color: 'var(--danger)', minHeight: '32px' }}
          >
            ลบ
          </button>
          <button
            onClick={() => setConfirmDelete(false)}
            className="rounded-lg px-2.5 py-1.5 text-xs"
            style={{ background: 'var(--surface-muted)', color: 'var(--muted)', minHeight: '32px' }}
          >
            ยกเลิก
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => onEdit(draft)}
            aria-label={`แก้ไข ${draft.title}`}
            className="flex items-center justify-center rounded-lg"
            style={{
              width: '34px',
              height: '34px',
              background: 'var(--surface-muted)',
              color: 'var(--muted)',
            }}
          >
            <Pencil size={13} aria-hidden="true" />
          </button>
          <button
            onClick={() => setConfirmDelete(true)}
            aria-label={`ลบ ${draft.title}`}
            className="flex items-center justify-center rounded-lg"
            style={{
              width: '34px',
              height: '34px',
              background: 'var(--surface-muted)',
              color: 'var(--muted)',
            }}
          >
            <Trash2 size={13} aria-hidden="true" />
          </button>
          <button
            onClick={() => onEdit(draft)}
            aria-label={`เปิด ${draft.title}`}
            className="flex items-center justify-center rounded-lg"
            style={{
              width: '34px',
              height: '34px',
              background: 'var(--surface-muted)',
              color: 'var(--muted)',
            }}
          >
            <ChevronRight size={13} aria-hidden="true" />
          </button>
        </div>
      )}
    </div>
  )
}

// ── Draft form ───────────────────────────────────────────────────────────────

function DraftForm({
  form,
  errors,
  set,
  isEditing,
  onSubmit,
  onCancel,
  setForm,
}: {
  form: ReturnType<typeof EMPTY_FORM>
  errors: Partial<Record<keyof ReturnType<typeof EMPTY_FORM>, string>>
  set: (key: keyof ReturnType<typeof EMPTY_FORM>) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void
  isEditing: boolean
  onSubmit: (e: React.FormEvent) => void
  onCancel: () => void
  setForm: React.Dispatch<React.SetStateAction<ReturnType<typeof EMPTY_FORM>>>
}) {
  const today = todayStr()

  return (
    <form onSubmit={onSubmit} className="space-y-5" noValidate>
      {/* Emoji picker */}
      <div>
        <label className="text-xs font-semibold block mb-2" style={{ color: 'var(--ink-2)' }}>
          ไอคอนสินค้า
        </label>
        <div className="flex flex-wrap gap-2">
          {EMOJI_OPTIONS.map((e) => (
            <button
              key={e}
              type="button"
              onClick={() => setForm((f) => ({ ...f, imageEmoji: e }))}
              className="w-9 h-9 rounded-xl text-lg flex items-center justify-center transition-all"
              style={{
                background: form.imageEmoji === e ? 'var(--accent-light)' : 'var(--surface-muted)',
                border: form.imageEmoji === e ? '2px solid var(--accent)' : '1.5px solid var(--border)',
                minWidth: '36px',
                minHeight: '36px',
              }}
              aria-label={`เลือก ${e}`}
              aria-pressed={form.imageEmoji === e}
            >
              {e}
            </button>
          ))}
        </div>
      </div>

      <Field label="ชื่อสินค้า *" error={errors.title}>
        <input
          value={form.title}
          onChange={set('title')}
          placeholder="เช่น เต็นท์แบ็คแพ็ค 2 คน"
          className="field-input"
          aria-invalid={!!errors.title}
          aria-describedby={errors.title ? 'err-title' : undefined}
          required
        />
      </Field>

      <Field label="คำอธิบาย *" error={errors.description}>
        <textarea
          value={form.description}
          onChange={set('description')}
          placeholder="อะไรรวมมาบ้าง? มีข้อควรระวังอะไรไหม?"
          rows={3}
          className="field-input resize-none"
          aria-invalid={!!errors.description}
          required
        />
      </Field>

      <div className="grid grid-cols-2 gap-4">
        <Field label="สภาพสินค้า">
          <select value={form.condition} onChange={set('condition')} className="field-input">
            {CONDITION_OPTIONS.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </Field>

        <Field label="กิจกรรม *" error={errors.activityId}>
          <select
            value={form.activityId}
            onChange={set('activityId')}
            className="field-input"
            aria-invalid={!!errors.activityId}
            required
          >
            <option value="">เลือก…</option>
            {ACTIVITIES.map((a) => (
              <option key={a.id} value={a.id}>{a.titleTh}</option>
            ))}
          </select>
        </Field>
      </div>

      {/* Collateral — decimal string validation, no floating-point arithmetic */}
      <Field label="มัดจำที่แนะนำ (USDC) *" error={errors.collateralStr}>
        <div className="relative">
          <span
            className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold"
            style={{ color: 'var(--muted)' }}
            aria-hidden="true"
          >
            $
          </span>
          <input
            type="text"
            inputMode="decimal"
            value={form.collateralStr}
            onChange={set('collateralStr')}
            placeholder="เช่น 40 หรือ 40.50"
            className="field-input pl-7 tabular-nums"
            aria-invalid={!!errors.collateralStr}
            required
          />
        </div>
        <p className="text-xs mt-1" style={{ color: 'var(--subtle)' }}>
          ทศนิยมสูงสุด 6 ตำแหน่ง — ใช้เป็นข้อมูลอ้างอิงเท่านั้น
        </p>
      </Field>

      <div className="grid grid-cols-2 gap-4">
        <Field label="วันที่เริ่มให้ยืม *" error={errors.availableFrom}>
          <input
            type="date"
            value={form.availableFrom}
            onChange={set('availableFrom')}
            className="field-input"
            min={today}
            aria-invalid={!!errors.availableFrom}
            required
          />
        </Field>
        <Field label="วันที่สิ้นสุด *" error={errors.availableTo}>
          <input
            type="date"
            value={form.availableTo}
            onChange={set('availableTo')}
            className="field-input"
            min={form.availableFrom || today}
            aria-invalid={!!errors.availableTo}
            required
          />
        </Field>
      </div>

      <Field label="เรื่องราวของสินค้า (ไม่บังคับ)">
        <textarea
          value={form.story}
          onChange={set('story')}
          placeholder="ประวัติสินค้า มันพาคุณไปที่ไหนบ้าง?"
          rows={3}
          className="field-input resize-none"
        />
      </Field>

      <div className="flex gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 rounded-xl py-3 text-sm font-semibold"
          style={{ background: 'var(--surface-muted)', color: 'var(--ink-2)' }}
        >
          ยกเลิก
        </button>
        <button
          type="submit"
          className="flex-1 rounded-xl py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-all"
          style={{ background: 'var(--accent)', color: 'white', minHeight: '48px' }}
        >
          {isEditing ? (
            <>
              <Pencil size={15} aria-hidden="true" />
              บันทึกการแก้ไข
            </>
          ) : (
            <>
              <Plus size={15} aria-hidden="true" />
              บันทึกร่าง
            </>
          )}
        </button>
      </div>
    </form>
  )
}

function Field({
  label,
  children,
  error,
}: {
  label: string
  children: React.ReactNode
  error?: string
}) {
  return (
    <div>
      <label className="text-xs font-semibold block mb-1.5" style={{ color: 'var(--ink-2)' }}>
        {label}
      </label>
      {children}
      {error && (
        <p className="text-xs mt-1" style={{ color: 'var(--danger)' }} role="alert">
          {error}
        </p>
      )}
    </div>
  )
}
