/**
 * Illustrated neighborhood map — SVG districts (Camping/Forest, Filmmaking/Studio,
 * DIY/Workshop, Dining), warm cream-forest-terracotta styling.
 * Pins are derived from passed-in items only — no invented counts.
 * Accessible list-toggle and empty-state. Desktop and mobile responsive.
 *
 * NOTICE: This is an illustrative conceptual map, not a real GPS map.
 * No real location claims are made.
 */

import { useState, useId } from 'react'
import { Map, List, Info } from 'lucide-react'
import type { DemoItem } from '../demo-data'

// ── District definitions ─────────────────────────────────────────────────────

interface District {
  id: string
  label: string
  labelTh: string
  // SVG path in 0-100 viewBox
  path: string
  fill: string
  textX: number
  textY: number
}

const DISTRICTS: District[] = [
  {
    id: 'camping',
    label: 'Forest District',
    labelTh: 'ย่านป่าไม้',
    path: 'M0,0 L45,0 L45,50 L0,50 Z',
    fill: '#c8ddc0',
    textX: 10,
    textY: 8,
  },
  {
    id: 'filmmaking',
    label: 'Studio District',
    labelTh: 'ย่านสตูดิโอ',
    path: 'M45,0 L100,0 L100,50 L45,50 Z',
    fill: '#e8cfc8',
    textX: 55,
    textY: 8,
  },
  {
    id: 'diy',
    label: 'Workshop District',
    labelTh: 'ย่านช่าง',
    path: 'M0,50 L45,50 L45,100 L0,100 Z',
    fill: '#ddd0c0',
    textX: 6,
    textY: 58,
  },
  {
    id: 'dinner',
    label: 'Dining District',
    labelTh: 'ย่านอาหาร',
    path: 'M45,50 L100,50 L100,100 L45,100 Z',
    fill: '#e8dfc0',
    textX: 55,
    textY: 58,
  },
]

// ── Fixed positions per item id (0-100 SVG coords) ──────────────────────────

const ITEM_POSITIONS: Record<string, { x: number; y: number }> = {
  // camping — top-left quadrant
  'tent-2person': { x: 18, y: 18 },
  'sleeping-bag-down': { x: 32, y: 32 },
  'camping-stove': { x: 10, y: 38 },
  headlamp: { x: 38, y: 14 },
  'trekking-poles': { x: 24, y: 44 },
  'water-filter': { x: 8, y: 26 },

  // filmmaking — top-right quadrant
  'dslr-camera': { x: 72, y: 16 },
  'tripod-heavy': { x: 88, y: 30 },
  'shotgun-mic': { x: 60, y: 38 },
  'led-panel': { x: 82, y: 44 },
  'monitor-field': { x: 68, y: 36 },
  'slider-rail': { x: 56, y: 20 },

  // diy — bottom-left quadrant
  'power-drill': { x: 14, y: 62 },
  'circular-saw': { x: 30, y: 74 },
  'level-set': { x: 8, y: 82 },
  'clamp-set': { x: 36, y: 60 },
  jigsaw: { x: 22, y: 88 },
  sander: { x: 42, y: 80 },

  // dinner — bottom-right quadrant
  'fondue-set': { x: 64, y: 62 },
  'chafing-dish': { x: 80, y: 74 },
  'linen-tablecloth': { x: 56, y: 80 },
  'serving-platters': { x: 92, y: 62 },
  'punch-bowl': { x: 74, y: 88 },
  candelabra: { x: 86, y: 86 },
}

// ── Decorative SVG elements ───────────────────────────────────────────────────

const TREES = [
  { x: 4, y: 14 }, { x: 40, y: 8 }, { x: 20, y: 4 }, { x: 6, y: 46 }, { x: 38, y: 46 },
]
const BUILDINGS = [
  // Studio district buildings
  { x: 52, y: 12, w: 8, h: 11, color: '#c8a898' },
  { x: 72, y: 6,  w: 10, h: 14, color: '#d0b0a0' },
  { x: 86, y: 10, w: 9,  h: 12, color: '#b8988a' },
  // Workshop
  { x: 6,  y: 65, w: 8, h: 10, color: '#c0b090' },
  { x: 28, y: 68, w: 10, h: 12, color: '#b8a880' },
  // Dining
  { x: 60, y: 64, w: 9,  h: 10, color: '#d0b870' },
  { x: 80, y: 60, w: 8,  h: 9,  color: '#c8a860' },
  { x: 92, y: 68, w: 7,  h: 8,  color: '#d0b068' },
]

function Tree({ x, y }: { x: number; y: number }) {
  return (
    <g>
      <circle cx={x} cy={y} r="3" fill="#3a6030" opacity="0.55" />
      <circle cx={x} cy={y - 1} r="2" fill="#4a7840" opacity="0.5" />
      <rect x={x - 0.5} y={y + 2.5} width="1" height="2.5" fill="#6a4a28" opacity="0.5" />
    </g>
  )
}

function Building({ x, y, w, h, color }: { x: number; y: number; w: number; h: number; color: string }) {
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill={color} rx="0.5" stroke="rgba(0,0,0,0.06)" strokeWidth="0.3" />
      <polygon
        points={`${x},${y} ${x + w / 2},${y - 4} ${x + w},${y}`}
        fill={color}
        stroke="rgba(0,0,0,0.08)"
        strokeWidth="0.2"
        style={{ filter: 'brightness(0.82)' }}
      />
      <rect x={x + 1.5} y={y + 3} width="2" height="2" fill="rgba(255,255,255,0.45)" rx="0.2" />
      <rect x={x + w - 3.5} y={y + 3} width="2" height="2" fill="rgba(255,255,255,0.45)" rx="0.2" />
    </g>
  )
}

// ── Types ─────────────────────────────────────────────────────────────────────

interface Props {
  items: DemoItem[]
  onSelectItem: (item: DemoItem) => void
}

function conditionColor(c: string) {
  if (c === 'Excellent') return 'var(--success)'
  if (c === 'Good') return 'var(--warning)'
  return 'var(--muted)'
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function NeighborhoodMap({ items, onSelectItem }: Props) {
  const [view, setView] = useState<'map' | 'list'>('map')
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const noticeId = useId()

  // Map items with positions, falling back to a deterministic spread
  const mapItems = items.map((item, idx) => ({
    item,
    x: ITEM_POSITIONS[item.id]?.x ?? 5 + (idx * 19) % 88,
    y: ITEM_POSITIONS[item.id]?.y ?? 8 + (idx * 23) % 85,
  }))

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{ border: '1.5px solid var(--border)' }}
    >
      {/* Toolbar */}
      <div
        className="flex items-center justify-between px-4 py-2.5"
        style={{
          background: 'var(--surface-strong)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold" style={{ color: 'var(--ink-2)' }}>
            อุปกรณ์ใกล้คุณ
          </span>
          <span className="text-xs" style={{ color: 'var(--muted)' }}>
            · {items.length} รายการ
          </span>
        </div>
        <div className="flex gap-1 rounded-lg p-1" style={{ background: 'var(--surface-muted)' }}>
          <button
            onClick={() => setView('map')}
            aria-pressed={view === 'map'}
            aria-label="แสดงแผนที่"
            className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-all"
            style={{
              background: view === 'map' ? 'white' : 'transparent',
              color: view === 'map' ? 'var(--ink)' : 'var(--muted)',
              boxShadow: view === 'map' ? '0 1px 3px rgba(0,0,0,0.10)' : 'none',
              minHeight: '32px',
            }}
          >
            <Map size={12} aria-hidden="true" />
            แผนที่
          </button>
          <button
            onClick={() => setView('list')}
            aria-pressed={view === 'list'}
            aria-label="แสดงรายการ"
            className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-all"
            style={{
              background: view === 'list' ? 'white' : 'transparent',
              color: view === 'list' ? 'var(--ink)' : 'var(--muted)',
              boxShadow: view === 'list' ? '0 1px 3px rgba(0,0,0,0.10)' : 'none',
              minHeight: '32px',
            }}
          >
            <List size={12} aria-hidden="true" />
            รายการ
          </button>
        </div>
      </div>

      {view === 'map' ? (
        <div>
          {/* Illustrative notice */}
          <div
            id={noticeId}
            className="flex items-center gap-1.5 px-4 py-2 text-xs"
            style={{
              background: 'var(--warning-light)',
              color: 'var(--warning)',
              borderBottom: '1px solid rgba(181,125,26,0.15)',
            }}
          >
            <Info size={11} aria-hidden="true" />
            <span>แผนที่ย่านสมมุติ — ไม่ใช่พิกัดจริง</span>
          </div>

          {/* SVG map */}
          <div
            className="relative w-full"
            style={{ aspectRatio: '16/9', minHeight: '220px', maxHeight: '360px', background: '#e8e2d8' }}
            role="img"
            aria-label="แผนที่ย่านชุมชน (ภาพประกอบ)"
            aria-describedby={noticeId}
          >
            <svg
              width="100%"
              height="100%"
              viewBox="0 0 100 100"
              preserveAspectRatio="xMidYMid slice"
              aria-hidden="true"
            >
              {/* Ground */}
              <rect width="100" height="100" fill="#e8e2d8" />

              {/* Districts */}
              {DISTRICTS.map((d) => (
                <path key={d.id} d={d.path} fill={d.fill} opacity="0.7" />
              ))}

              {/* Roads */}
              <line x1="45" y1="0" x2="45" y2="100" stroke="#d4ccc0" strokeWidth="2.5" />
              <line x1="0" y1="50" x2="100" y2="50" stroke="#d4ccc0" strokeWidth="2.5" />
              <line x1="0" y1="50" x2="100" y2="50" stroke="#ccc4b8" strokeWidth="1.5" strokeDasharray="3,2" />

              {/* Center plaza */}
              <circle cx="45" cy="50" r="4" fill="#d0c8b8" stroke="#c4bcb0" strokeWidth="0.5" />
              <circle cx="45" cy="50" r="1.5" fill="#b0a898" />

              {/* Trees in forest district */}
              {TREES.map((t, i) => <Tree key={i} x={t.x} y={t.y} />)}

              {/* Buildings */}
              {BUILDINGS.map((b, i) => (
                <Building key={i} x={b.x} y={b.y} w={b.w} h={b.h} color={b.color} />
              ))}

              {/* District labels */}
              {DISTRICTS.map((d) => (
                <g key={d.id + '-label'}>
                  <text
                    x={d.textX}
                    y={d.textY}
                    fontSize="3.2"
                    fontWeight="600"
                    fill="rgba(42,31,20,0.55)"
                    fontFamily="'DM Sans', sans-serif"
                    letterSpacing="0.02em"
                  >
                    {d.label.toUpperCase()}
                  </text>
                </g>
              ))}
            </svg>

            {/* Item pins — absolutely positioned over SVG */}
            {mapItems.length === 0 ? (
              <div
                className="absolute inset-0 flex items-center justify-center text-sm"
                style={{ color: 'var(--muted)' }}
              >
                ไม่พบรายการที่ตรงกัน
              </div>
            ) : (
              mapItems.map(({ item, x, y }) => {
                const isHovered = hoveredId === item.id
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectItem(item)}
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    onFocus={() => setHoveredId(item.id)}
                    onBlur={() => setHoveredId(null)}
                    aria-label={`ดู ${item.titleTh || item.title} – มัดจำ $${item.suggestedCollateral} USDC`}
                    className="absolute transition-transform focus-visible:outline-2"
                    style={{
                      left: `${x}%`,
                      top: `${y}%`,
                      transform: `translate(-50%, -100%) scale(${isHovered ? 1.18 : 1})`,
                      zIndex: isHovered ? 20 : 10,
                      transitionDuration: '120ms',
                    }}
                  >
                    {/* Tooltip */}
                    {isHovered && (
                      <div
                        className="absolute left-1/2 whitespace-nowrap rounded-lg px-2.5 py-1.5 text-xs font-medium shadow-lg pointer-events-none"
                        style={{
                          transform: 'translateX(-50%)',
                          bottom: 'calc(100% + 4px)',
                          background: 'var(--ink)',
                          color: 'white',
                          maxWidth: '160px',
                          whiteSpace: 'normal',
                        }}
                      >
                        <div className="font-semibold leading-tight">{item.titleTh || item.title}</div>
                        <div className="opacity-70 mt-0.5">${item.suggestedCollateral} USDC มัดจำ</div>
                      </div>
                    )}
                    {/* Pin bubble */}
                    <div
                      className="flex items-center justify-center rounded-full shadow-md"
                      style={{
                        width: '30px',
                        height: '30px',
                        background: item.imageColor,
                        border: '2.5px solid white',
                        fontSize: '14px',
                      }}
                    >
                      {item.imageEmoji}
                    </div>
                    {/* Pin tail */}
                    <div
                      className="w-2 h-2 mx-auto rotate-45"
                      style={{ background: item.imageColor, marginTop: '-5px' }}
                    />
                  </button>
                )
              })
            )}
          </div>
        </div>
      ) : (
        /* Accessible list view */
        <div
          role="list"
          aria-label="รายการอุปกรณ์"
          style={{ maxHeight: '360px', overflowY: 'auto' }}
        >
          {mapItems.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <div className="text-2xl mb-2" aria-hidden="true">🔍</div>
              <p className="text-sm font-medium" style={{ color: 'var(--muted)' }}>
                ไม่พบรายการที่ตรงกัน
              </p>
              <p className="text-xs mt-1" style={{ color: 'var(--subtle)' }}>
                ลองเปลี่ยนตัวกรองหรือคำค้นหา
              </p>
            </div>
          ) : (
            mapItems.map(({ item }) => (
              <button
                key={item.id}
                role="listitem"
                onClick={() => onSelectItem(item)}
                className="w-full flex items-center gap-3 px-4 py-3 text-left transition-colors"
                style={{ borderBottom: '1px solid var(--border)', minHeight: '52px' }}
                onMouseEnter={(e) =>
                  ((e.currentTarget as HTMLElement).style.background = 'var(--surface-muted)')
                }
                onMouseLeave={(e) =>
                  ((e.currentTarget as HTMLElement).style.background = 'transparent')
                }
              >
                <div
                  className="flex items-center justify-center rounded-xl flex-shrink-0"
                  style={{
                    width: '40px',
                    height: '40px',
                    background: item.imageColor + '22',
                    fontSize: '20px',
                  }}
                  aria-hidden="true"
                >
                  {item.imageEmoji}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>
                    {item.titleTh}
                  </div>
                  <div className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
                    {item.ownerName}
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    <span style={{ color: conditionColor(item.condition) }}>{item.condition}</span>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-semibold tabular-nums" style={{ color: 'var(--accent)' }}>
                    ${item.suggestedCollateral}
                  </div>
                  <div className="text-xs" style={{ color: 'var(--muted)' }}>USDC</div>
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  )
}
