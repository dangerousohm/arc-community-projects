/**
 * Demo data for Trust Bridge — clearly labeled as illustrative content.
 * Items, activities, and community stories are DEMO placeholders.
 * Contract interactions (escrow creation, funding, etc.) are real onchain transactions.
 * Item counts in ACTIVITIES are derived from DEMO_ITEMS, not hardcoded.
 */

export interface Activity {
  id: string
  title: string
  titleTh: string
  subtitle: string
  subtitleTh: string
  icon: string
  color: string
  districtLabel: string
  // itemCount is computed from DEMO_ITEMS — do NOT hardcode here
}

export interface DemoItem {
  id: string
  listingId: string
  title: string
  titleTh: string
  description: string
  condition: 'Excellent' | 'Good' | 'Fair'
  category: string
  activity: string
  imageEmoji: string
  imageColor: string
  suggestedCollateral: number // USDC whole units, e.g. 40 = 40 USDC
  ownerName: string
  ownerHandle: string
  ownerAddress: `0x${string}` | null // null = demo placeholder
  availableFrom: string
  availableTo: string
  story?: string
  // DEMO label: true = not a real listing backed by a contract
  isDemo: true
}

export const ACTIVITIES: Activity[] = [
  {
    id: 'camping',
    title: 'Go Camping',
    titleTh: 'ออกแคมป์',
    subtitle: 'Escape to the forest',
    subtitleTh: 'หนีเข้าป่า',
    icon: '⛺',
    color: '#2d5a27',
    districtLabel: 'Forest District',
  },
  {
    id: 'filmmaking',
    title: 'Make a Film',
    titleTh: 'ถ่ายทำหนัง',
    subtitle: 'Tell your story',
    subtitleTh: 'บอกเล่าเรื่องราวของคุณ',
    icon: '🎬',
    color: '#c0593b',
    districtLabel: 'Studio District',
  },
  {
    id: 'diy',
    title: 'DIY Project',
    titleTh: 'โปรเจกต์ DIY',
    subtitle: 'Build something real',
    subtitleTh: 'สร้างสิ่งใหม่',
    icon: '🔨',
    color: '#7a5c3a',
    districtLabel: 'Workshop District',
  },
  {
    id: 'dinner',
    title: 'Host a Dinner',
    titleTh: 'จัดงานเลี้ยง',
    subtitle: 'Gather your people',
    subtitleTh: 'รวมคนที่คุณรัก',
    icon: '🍽',
    color: '#b57d1a',
    districtLabel: 'Dining District',
  },
]

/** Suggested bundle (ordered item IDs) for each activity. */
export const ACTIVITY_BUNDLES: Record<string, string[]> = {
  camping: ['tent-2person', 'sleeping-bag-down', 'camping-stove', 'headlamp', 'trekking-poles', 'water-filter'],
  filmmaking: ['dslr-camera', 'tripod-heavy', 'shotgun-mic', 'led-panel', 'monitor-field', 'slider-rail'],
  diy: ['power-drill', 'circular-saw', 'level-set', 'clamp-set', 'jigsaw', 'sander'],
  dinner: ['fondue-set', 'chafing-dish', 'linen-tablecloth', 'serving-platters', 'punch-bowl', 'candelabra'],
}

export const DEMO_ITEMS: DemoItem[] = [
  // ── CAMPING ──────────────────────────────────────────────────────────────────
  {
    id: 'tent-2person',
    listingId: 'listing-tent-001',
    title: '2-Person Backpacking Tent',
    titleTh: 'เต็นท์แบ็คแพ็ค 2 คน',
    description:
      'Ultralight 3-season tent, perfect for weekend camping. Stakes, guylines, and footprint included. Sets up in under 5 minutes.',
    condition: 'Excellent',
    category: 'Camping',
    activity: 'camping',
    imageEmoji: '⛺',
    imageColor: '#2d5a27',
    suggestedCollateral: 40,
    ownerName: 'Mara Chen',
    ownerHandle: 'mara.eth',
    ownerAddress: null,
    availableFrom: '2026-10-15',
    availableTo: '2026-11-30',
    story:
      'This tent has been to the Cascades, Death Valley, and the Ozarks. It comes back from every trip ready for the next one.',
    isDemo: true,
  },
  {
    id: 'sleeping-bag-down',
    listingId: 'listing-bag-001',
    title: 'Down Sleeping Bag (20°F)',
    titleTh: 'ถุงนอนดาวน์ (-7°C)',
    description:
      'Rated to 20°F, 850-fill down. Compression sack included. Fits most heights up to 6ft 2in. Clean and aired after last use.',
    condition: 'Good',
    category: 'Camping',
    activity: 'camping',
    imageEmoji: '🛏',
    imageColor: '#4a7a5c',
    suggestedCollateral: 30,
    ownerName: 'Priya Nair',
    ownerHandle: 'priya_n',
    ownerAddress: null,
    availableFrom: '2026-10-14',
    availableTo: '2026-12-15',
    story: 'Bought for a solo trek in Colorado. Now lives in my closet 48 weeks a year — it deserves more adventures.',
    isDemo: true,
  },
  {
    id: 'camping-stove',
    listingId: 'listing-stove-001',
    title: 'Canister Camp Stove + Pot',
    titleTh: 'เตาแก๊สแคมป์ + หม้อ',
    description: '1L titanium pot with lid, lightweight stove head, fuel canister adapters. Boils water in 3 minutes.',
    condition: 'Good',
    category: 'Camping',
    activity: 'camping',
    imageEmoji: '🍳',
    imageColor: '#7a5c3a',
    suggestedCollateral: 15,
    ownerName: 'Tom Rivas',
    ownerHandle: 'tom.rivas',
    ownerAddress: null,
    availableFrom: '2026-10-16',
    availableTo: '2027-01-01',
    isDemo: true,
  },
  {
    id: 'headlamp',
    listingId: 'listing-lamp-001',
    title: 'Rechargeable Headlamp 400lm',
    titleTh: 'ไฟฉายคาดหัว 400 ลูเมน',
    description: 'USB-C rechargeable, 400 lumen flood/spot, red night-vision mode. Full charge lasts ~12 hours.',
    condition: 'Excellent',
    category: 'Camping',
    activity: 'camping',
    imageEmoji: '🔦',
    imageColor: '#b57d1a',
    suggestedCollateral: 10,
    ownerName: 'Keiko Tanaka',
    ownerHandle: 'keiko',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2026-11-20',
    isDemo: true,
  },
  {
    id: 'trekking-poles',
    listingId: 'listing-poles-001',
    title: 'Aluminium Trekking Poles (pair)',
    titleTh: 'ไม้เดินป่าอลูมิเนียม (คู่)',
    description: 'Adjustable 65–135cm, cork grips, anti-shock. Folds to 40cm for packing. Suitable for all terrain.',
    condition: 'Good',
    category: 'Camping',
    activity: 'camping',
    imageEmoji: '🏕️',
    imageColor: '#4a6040',
    suggestedCollateral: 12,
    ownerName: 'Sam Okafor',
    ownerHandle: 'sam_trek',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2026-12-31',
    isDemo: true,
  },
  {
    id: 'water-filter',
    listingId: 'listing-filter-001',
    title: 'Backpacking Water Filter',
    titleTh: 'กรองน้ำสำหรับแบ็คแพ็ค',
    description: 'Hollow-fiber squeeze filter, 0.1 micron. Filters 1L in 60s. Treats up to 100,000 gallons.',
    condition: 'Excellent',
    category: 'Camping',
    activity: 'camping',
    imageEmoji: '💧',
    imageColor: '#4a8090',
    suggestedCollateral: 18,
    ownerName: 'Lena Marsh',
    ownerHandle: 'lena_wild',
    ownerAddress: null,
    availableFrom: '2026-10-15',
    availableTo: '2026-12-20',
    isDemo: true,
  },

  // ── FILMMAKING ───────────────────────────────────────────────────────────────
  {
    id: 'dslr-camera',
    listingId: 'listing-cam-001',
    title: 'Mirrorless Camera Kit',
    titleTh: 'ชุดกล้อง Mirrorless',
    description:
      '24MP full-frame body, 24-70mm f/2.8 lens, two batteries, charger, and camera bag. 4K60 video capable.',
    condition: 'Excellent',
    category: 'Filmmaking',
    activity: 'filmmaking',
    imageEmoji: '📷',
    imageColor: '#c0593b',
    suggestedCollateral: 150,
    ownerName: 'Alex Kim',
    ownerHandle: 'alex.lens',
    ownerAddress: null,
    availableFrom: '2026-10-18',
    availableTo: '2026-12-01',
    story:
      "Shot a short film that screened at the local film festival last year. Ready to help create someone else's vision.",
    isDemo: true,
  },
  {
    id: 'tripod-heavy',
    listingId: 'listing-tripod-001',
    title: 'Carbon Fiber Tripod + Ball Head',
    titleTh: 'ขาตั้งกล้องคาร์บอน + หัวบอล',
    description: 'Supports 12kg, carbon legs, Arca-Swiss compatible head. Folds to 60cm. Great for video and stills.',
    condition: 'Good',
    category: 'Filmmaking',
    activity: 'filmmaking',
    imageEmoji: '📸',
    imageColor: '#8b5a2b',
    suggestedCollateral: 50,
    ownerName: 'River Santos',
    ownerHandle: 'riverdocs',
    ownerAddress: null,
    availableFrom: '2026-10-14',
    availableTo: '2026-11-28',
    isDemo: true,
  },
  {
    id: 'shotgun-mic',
    listingId: 'listing-mic-001',
    title: 'Shotgun Microphone + Boom',
    titleTh: 'ไมค์ Shotgun + บูม',
    description:
      'Super-cardioid shotgun mic, XLR output, foam and blimp windscreen included. Low self-noise, flat response.',
    condition: 'Excellent',
    category: 'Filmmaking',
    activity: 'filmmaking',
    imageEmoji: '🎙',
    imageColor: '#4a3060',
    suggestedCollateral: 35,
    ownerName: 'Dana Wolff',
    ownerHandle: 'dana.sound',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2026-12-31',
    isDemo: true,
  },
  {
    id: 'led-panel',
    listingId: 'listing-led-001',
    title: 'Bi-Colour LED Panel (2-light kit)',
    titleTh: 'แผง LED สองสี (ชุด 2 ดวง)',
    description:
      '95 CRI, 2700–6500K, dimmable. Each light 100W equivalent. Includes stands, diffusion, and carry bag.',
    condition: 'Good',
    category: 'Filmmaking',
    activity: 'filmmaking',
    imageEmoji: '💡',
    imageColor: '#c0a020',
    suggestedCollateral: 60,
    ownerName: 'Celine Moreau',
    ownerHandle: 'celine.light',
    ownerAddress: null,
    availableFrom: '2026-10-15',
    availableTo: '2027-01-01',
    isDemo: true,
  },
  {
    id: 'monitor-field',
    listingId: 'listing-monitor-001',
    title: '5" Field Monitor',
    titleTh: 'จอมอนิเตอร์ 5 นิ้ว',
    description: '5-inch IPS, 1000 nit, HDMI in/out, waveform and false colour. Works with any camera with HDMI out.',
    condition: 'Excellent',
    category: 'Filmmaking',
    activity: 'filmmaking',
    imageEmoji: '🖥',
    imageColor: '#2a3a70',
    suggestedCollateral: 45,
    ownerName: 'Keiko Tanaka',
    ownerHandle: 'keiko.film',
    ownerAddress: null,
    availableFrom: '2026-10-18',
    availableTo: '2026-12-15',
    isDemo: true,
  },
  {
    id: 'slider-rail',
    listingId: 'listing-slider-001',
    title: 'Camera Slider 80cm',
    titleTh: 'สไลเดอร์กล้อง 80 ซม.',
    description: 'Aluminium 80cm slider with ball-bearing carriage and adjustable damping. Max load 5kg.',
    condition: 'Good',
    category: 'Filmmaking',
    activity: 'filmmaking',
    imageEmoji: '🎬',
    imageColor: '#803020',
    suggestedCollateral: 30,
    ownerName: 'Tom Rivas',
    ownerHandle: 'tom.vid',
    ownerAddress: null,
    availableFrom: '2026-10-20',
    availableTo: '2026-11-30',
    isDemo: true,
  },

  // ── DIY ───────────────────────────────────────────────────────────────────────
  {
    id: 'power-drill',
    listingId: 'listing-drill-001',
    title: 'Brushless Power Drill Set',
    titleTh: 'ชุดสว่านไฟฟ้า Brushless',
    description: '20V brushless, 2 batteries, rapid charger, 70-piece bit set. Torque settings for wood, metal, tile.',
    condition: 'Excellent',
    category: 'DIY',
    activity: 'diy',
    imageEmoji: '🔧',
    imageColor: '#7a5c3a',
    suggestedCollateral: 25,
    ownerName: 'Dana Wolff',
    ownerHandle: 'dana.builds',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2026-12-31',
    story: 'My most-lent item. If you need a second drill bit for a specific size, just ask — I have a full set.',
    isDemo: true,
  },
  {
    id: 'circular-saw',
    listingId: 'listing-saw-001',
    title: 'Circular Saw 185mm',
    titleTh: 'เลื่อยวงเดือน 185 มม.',
    description: '1200W corded circular saw, blade included, rip fence and carry case. Bevels to 45°.',
    condition: 'Good',
    category: 'DIY',
    activity: 'diy',
    imageEmoji: '🪚',
    imageColor: '#5a4030',
    suggestedCollateral: 30,
    ownerName: 'Mara Chen',
    ownerHandle: 'mara.builds',
    ownerAddress: null,
    availableFrom: '2026-10-15',
    availableTo: '2026-12-20',
    isDemo: true,
  },
  {
    id: 'level-set',
    listingId: 'listing-level-001',
    title: 'Spirit Level + Laser Set',
    titleTh: 'ชุดระดับน้ำ + เลเซอร์',
    description: '60cm spirit level, cross-line laser, and digital angle finder. For framing, shelves, and tiling.',
    condition: 'Excellent',
    category: 'DIY',
    activity: 'diy',
    imageEmoji: '📏',
    imageColor: '#4a7060',
    suggestedCollateral: 18,
    ownerName: 'Sam Okafor',
    ownerHandle: 'sam.level',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2027-01-01',
    isDemo: true,
  },
  {
    id: 'clamp-set',
    listingId: 'listing-clamps-001',
    title: 'F-Clamp Set (8 piece)',
    titleTh: 'ชุดแคลมป์ F (8 ชิ้น)',
    description: '2×12", 2×8", 2×6", 2×4" F-clamps in a carry bag. Ideal for gluing, assembly, and framing.',
    condition: 'Good',
    category: 'DIY',
    activity: 'diy',
    imageEmoji: '🔩',
    imageColor: '#6a5040',
    suggestedCollateral: 15,
    ownerName: 'Priya Nair',
    ownerHandle: 'priya.diy',
    ownerAddress: null,
    availableFrom: '2026-10-14',
    availableTo: '2026-12-15',
    isDemo: true,
  },
  {
    id: 'jigsaw',
    listingId: 'listing-jigsaw-001',
    title: 'Jigsaw with Blade Set',
    titleTh: 'เลื่อยจิ๊กซอว์ + ชุดใบเลื่อย',
    description: '800W variable-speed jigsaw, 10 blades for wood/metal/tile. Orbital settings for fast or fine cuts.',
    condition: 'Good',
    category: 'DIY',
    activity: 'diy',
    imageEmoji: '🔨',
    imageColor: '#703020',
    suggestedCollateral: 20,
    ownerName: 'River Santos',
    ownerHandle: 'river.diy',
    ownerAddress: null,
    availableFrom: '2026-10-16',
    availableTo: '2026-12-31',
    isDemo: true,
  },
  {
    id: 'sander',
    listingId: 'listing-sander-001',
    title: 'Random Orbital Sander',
    titleTh: 'เครื่องขัดกระดาษทราย',
    description: '125mm random orbital sander, dust bag and 15 mixed-grit discs. Perfect for furniture finishing.',
    condition: 'Good',
    category: 'DIY',
    activity: 'diy',
    imageEmoji: '🪵',
    imageColor: '#8a6040',
    suggestedCollateral: 14,
    ownerName: 'Lena Marsh',
    ownerHandle: 'lena.craft',
    ownerAddress: null,
    availableFrom: '2026-10-18',
    availableTo: '2026-12-20',
    isDemo: true,
  },

  // ── DINNER ────────────────────────────────────────────────────────────────────
  {
    id: 'fondue-set',
    listingId: 'listing-fondue-001',
    title: 'Fondue Set (6-person)',
    titleTh: 'ชุดฟองดูว์ (6 ที่นั่ง)',
    description: 'Enameled cast iron pot, 6 forks, alcohol burner. Works for cheese or chocolate. Includes recipe card.',
    condition: 'Good',
    category: 'Dinner',
    activity: 'dinner',
    imageEmoji: '🫕',
    imageColor: '#b57d1a',
    suggestedCollateral: 20,
    ownerName: 'Celine Moreau',
    ownerHandle: 'celine.m',
    ownerAddress: null,
    availableFrom: '2026-10-15',
    availableTo: '2027-01-15',
    story: 'Inherited from my grandmother, used at every family gathering. It brings warmth to every table it visits.',
    isDemo: true,
  },
  {
    id: 'chafing-dish',
    listingId: 'listing-chafing-001',
    title: 'Chafing Dish Set (2 pans)',
    titleTh: 'ชุดถาดอุ่นอาหาร (2 ถาด)',
    description: 'Stainless 2×8-quart pans, wire stands, fuel cans, serving utensils. Buffet-ready for 20+ guests.',
    condition: 'Good',
    category: 'Dinner',
    activity: 'dinner',
    imageEmoji: '🍲',
    imageColor: '#b07030',
    suggestedCollateral: 18,
    ownerName: 'Alex Kim',
    ownerHandle: 'alex.host',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2027-01-01',
    isDemo: true,
  },
  {
    id: 'linen-tablecloth',
    listingId: 'listing-linen-001',
    title: 'Linen Tablecloth Set (3)',
    titleTh: 'ผ้าปูโต๊ะลินิน (3 ผืน)',
    description:
      '3×240cm linen tablecloths in ivory/sage/terracotta. Washed and pressed, storage bag included. Seats 8–10.',
    condition: 'Excellent',
    category: 'Dinner',
    activity: 'dinner',
    imageEmoji: '🪡',
    imageColor: '#a09060',
    suggestedCollateral: 12,
    ownerName: 'Keiko Tanaka',
    ownerHandle: 'keiko.table',
    ownerAddress: null,
    availableFrom: '2026-10-15',
    availableTo: '2027-02-01',
    isDemo: true,
  },
  {
    id: 'serving-platters',
    listingId: 'listing-platter-001',
    title: 'Ceramic Serving Platter Set (6)',
    titleTh: 'ชุดจานเสิร์ฟเซรามิก (6 ใบ)',
    description:
      'Hand-thrown stoneware in warm earth tones. Mix of oval and rectangular platters, dishwasher-safe, padded box.',
    condition: 'Excellent',
    category: 'Dinner',
    activity: 'dinner',
    imageEmoji: '🍽',
    imageColor: '#c09060',
    suggestedCollateral: 25,
    ownerName: 'Mara Chen',
    ownerHandle: 'mara.table',
    ownerAddress: null,
    availableFrom: '2026-10-14',
    availableTo: '2027-01-31',
    isDemo: true,
  },
  {
    id: 'punch-bowl',
    listingId: 'listing-punch-001',
    title: 'Glass Punch Bowl + 12 Cups',
    titleTh: 'โถน้ำผลไม้แก้ว + แก้ว 12 ใบ',
    description: 'Large 7L crystal glass punch bowl, ladle, and 12 matching cups. Perfect for sangria or mocktails.',
    condition: 'Good',
    category: 'Dinner',
    activity: 'dinner',
    imageEmoji: '🫙',
    imageColor: '#7a9090',
    suggestedCollateral: 15,
    ownerName: 'Sam Okafor',
    ownerHandle: 'sam.host',
    ownerAddress: null,
    availableFrom: '2026-10-17',
    availableTo: '2026-12-31',
    isDemo: true,
  },
  {
    id: 'candelabra',
    listingId: 'listing-candle-001',
    title: 'Brass Candelabra (pair)',
    titleTh: 'เชิงเทียนทองเหลือง (คู่)',
    description: 'Two 5-arm brass candelabras, polished, fits standard taper candles. Adds drama to any dinner table.',
    condition: 'Excellent',
    category: 'Dinner',
    activity: 'dinner',
    imageEmoji: '🕯',
    imageColor: '#c0902a',
    suggestedCollateral: 10,
    ownerName: 'Priya Nair',
    ownerHandle: 'priya.host',
    ownerAddress: null,
    availableFrom: '2026-10-13',
    availableTo: '2027-02-15',
    isDemo: true,
  },
]

// ── Derived helpers ─────────────────────────────────────────────────────────

/** Returns items for a given activity id. */
export function getItemsByActivity(activityId: string): DemoItem[] {
  return DEMO_ITEMS.filter((item) => item.activity === activityId)
}

/** Counts available items per activity — derived, never hardcoded. */
export function getActivityItemCount(activityId: string): number {
  return getItemsByActivity(activityId).length
}

export function getItemById(id: string): DemoItem | undefined {
  return DEMO_ITEMS.find((item) => item.id === id)
}

export function searchItems(query: string): DemoItem[] {
  const q = query.toLowerCase()
  return DEMO_ITEMS.filter(
    (item) =>
      item.title.toLowerCase().includes(q) ||
      item.titleTh.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.category.toLowerCase().includes(q),
  )
}
