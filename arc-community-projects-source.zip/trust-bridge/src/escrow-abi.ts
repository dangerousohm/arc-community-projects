/**
 * ABI and types for ItemLendingEscrow deployed on Arc Testnet.
 * Address is set in VITE_ESCROW_ADDRESS (.env).
 */

export const ESCROW_STATE_LABELS: Record<number, string> = {
  0: 'Created',
  1: 'Funded',
  2: 'Picked Up',
  3: 'Returned',
  4: 'Settled',
  5: 'Disputed',
  6: 'Cancelled',
  7: 'Timed Out',
  8: 'Resolved',
}

export const ESCROW_STATE = {
  Created: 0,
  Funded: 1,
  PickedUp: 2,
  Returned: 3,
  Settled: 4,
  Disputed: 5,
  Cancelled: 6,
  TimedOut: 7,
  AdminResolved: 8,
} as const

export type EscrowStateVal = (typeof ESCROW_STATE)[keyof typeof ESCROW_STATE]

export interface EscrowData {
  lender: `0x${string}`
  borrower: `0x${string}`
  collateral: bigint
  platformFee: bigint
  depositDeadline: bigint
  returnDeadline: bigint
  disputeWindow: bigint
  state: EscrowStateVal
  lenderConfirmedPickup: boolean
  borrowerConfirmedPickup: boolean
  lenderConfirmedReturn: boolean
  borrowerConfirmedReturn: boolean
  itemId: string
  listingId: string
  lastActivityAt: bigint
  disputeRaisedAt: bigint
}

export const ITEM_LENDING_ESCROW_ABI = [
  // Read functions
  {
    name: 'getEscrow',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [
      {
        components: [
          { name: 'lender', type: 'address' },
          { name: 'borrower', type: 'address' },
          { name: 'collateral', type: 'uint256' },
          { name: 'platformFee', type: 'uint256' },
          { name: 'depositDeadline', type: 'uint256' },
          { name: 'returnDeadline', type: 'uint256' },
          { name: 'disputeWindow', type: 'uint256' },
          { name: 'state', type: 'uint8' },
          { name: 'lenderConfirmedPickup', type: 'bool' },
          { name: 'borrowerConfirmedPickup', type: 'bool' },
          { name: 'lenderConfirmedReturn', type: 'bool' },
          { name: 'borrowerConfirmedReturn', type: 'bool' },
          { name: 'itemId', type: 'string' },
          { name: 'listingId', type: 'string' },
          { name: 'lastActivityAt', type: 'uint256' },
          { name: 'disputeRaisedAt', type: 'uint256' },
        ],
        name: '',
        type: 'tuple',
      },
    ],
  },
  {
    name: 'getEscrowsByLender',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'lender', type: 'address' }],
    outputs: [{ name: '', type: 'uint256[]' }],
  },
  {
    name: 'getEscrowsByBorrower',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'borrower', type: 'address' }],
    outputs: [{ name: '', type: 'uint256[]' }],
  },
  {
    name: 'computePlatformFee',
    type: 'function',
    stateMutability: 'pure',
    inputs: [{ name: 'collateral', type: 'uint256' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'pendingWithdrawals',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
  {
    name: 'PLATFORM_FEE_BPS',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'uint256' }],
  },
  // Write functions
  {
    name: 'createEscrow',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'borrower', type: 'address' },
      { name: 'collateral', type: 'uint256' },
      { name: 'returnDeadline', type: 'uint256' },
      { name: 'disputeWindowSeconds', type: 'uint256' },
      { name: 'itemId', type: 'string' },
      { name: 'listingId', type: 'string' },
    ],
    outputs: [{ name: 'escrowId', type: 'uint256' }],
  },
  {
    name: 'fundEscrow',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'confirmPickup',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'confirmReturn',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'raiseDispute',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'cancelEscrow',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'claimTimeout',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'disputeTimeoutResolve',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'escrowId', type: 'uint256' }],
    outputs: [],
  },
  {
    name: 'withdraw',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [],
    outputs: [],
  },
  // Events
  {
    name: 'EscrowCreated',
    type: 'event',
    inputs: [
      { name: 'escrowId', type: 'uint256', indexed: true },
      { name: 'lender', type: 'address', indexed: true },
      { name: 'borrower', type: 'address', indexed: true },
      { name: 'collateral', type: 'uint256', indexed: false },
      { name: 'platformFee', type: 'uint256', indexed: false },
      { name: 'returnDeadline', type: 'uint256', indexed: false },
      { name: 'itemId', type: 'string', indexed: false },
    ],
  },
  {
    name: 'EscrowFunded',
    type: 'event',
    inputs: [{ name: 'escrowId', type: 'uint256', indexed: true }],
  },
  {
    name: 'EscrowSettled',
    type: 'event',
    inputs: [
      { name: 'escrowId', type: 'uint256', indexed: true },
      { name: 'collateral', type: 'uint256', indexed: false },
      { name: 'platformFee', type: 'uint256', indexed: false },
    ],
  },
  {
    name: 'DisputeRaised',
    type: 'event',
    inputs: [
      { name: 'escrowId', type: 'uint256', indexed: true },
      { name: 'raisedBy', type: 'address', indexed: true },
    ],
  },
  {
    name: 'DisputeResolved',
    type: 'event',
    inputs: [
      { name: 'escrowId', type: 'uint256', indexed: true },
      { name: 'lenderPayout', type: 'uint256', indexed: false },
      { name: 'borrowerPayout', type: 'uint256', indexed: false },
    ],
  },
] as const
