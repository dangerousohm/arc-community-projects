// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

contract ItemLendingEscrow is Ownable2Step, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint256 public constant PLATFORM_FEE_BPS = 250;
    uint256 public constant MIN_COLLATERAL = 1_000_000;
    uint256 public constant MAX_DISPUTE_WINDOW = 7 days;
    uint256 public constant EMERGENCY_TIMEOUT = 30 days;
    uint256 public constant disputeResolutionSla = 7 days;

    enum EscrowState {
        Created,
        Funded,
        PickedUp,
        Returned,
        Settled,
        Disputed,
        Cancelled,
        TimedOut,
        AdminResolved
    }

    struct Escrow {
        address lender;
        address borrower;
        uint256 collateral;
        uint256 platformFee;
        uint256 depositDeadline;
        uint256 returnDeadline;
        uint256 disputeWindow;
        EscrowState state;
        bool lenderConfirmedPickup;
        bool borrowerConfirmedPickup;
        bool lenderConfirmedReturn;
        bool borrowerConfirmedReturn;
        string itemId;
        string listingId;
        uint256 lastActivityAt;
        uint256 disputeRaisedAt;
    }

    IERC20 public immutable usdc;

    uint256 private _nextEscrowId = 1;
    mapping(uint256 escrowId => Escrow escrow) private _escrows;
    mapping(address lender => uint256[] escrowIds) private _escrowsByLender;
    mapping(address borrower => uint256[] escrowIds) private _escrowsByBorrower;
    mapping(address => uint256) public pendingWithdrawals;

    event EscrowCreated(
        uint256 indexed escrowId,
        address indexed lender,
        address indexed borrower,
        uint256 collateral,
        uint256 platformFee,
        uint256 returnDeadline,
        string itemId
    );
    event EscrowFunded(uint256 indexed escrowId);
    event EscrowPickedUp(uint256 indexed escrowId);
    event EscrowSettled(uint256 indexed escrowId, uint256 collateral, uint256 platformFee);
    event EscrowCancelled(uint256 indexed escrowId, address indexed cancelledBy);
    event EscrowTimedOut(uint256 indexed escrowId);
    event PickupConfirmed(uint256 indexed escrowId, address indexed confirmer);
    event ReturnConfirmed(uint256 indexed escrowId, address indexed confirmer);
    event DisputeRaised(uint256 indexed escrowId, address indexed raisedBy);
    event DisputeResolved(uint256 indexed escrowId, uint256 lenderPayout, uint256 borrowerPayout);
    event EmergencyResolved(uint256 indexed escrowId, uint256 lenderPayout, uint256 borrowerPayout);
    event Withdrawn(address indexed recipient, uint256 amount);

    error InvalidAddress();
    error InvalidCollateral();
    error InvalidReturnDeadline();
    error InvalidDisputeWindow();
    error EscrowNotFound();
    error NotParticipant();
    error NotBorrower();
    error NotLender();
    error InvalidState();
    error DeadlinePassed();
    error DeadlineNotPassed();
    error DisputeWindowExpired();
    error DisputeWindowNotStarted();
    error InvalidPayouts();
    error EmergencyTimeoutNotReached();

    constructor(address usdcToken, address initialOwner) Ownable(initialOwner) {
        if (usdcToken == address(0) || initialOwner == address(0)) {
            revert InvalidAddress();
        }
        usdc = IERC20(usdcToken);
    }

    function createEscrow(
        address borrower,
        uint256 collateral,
        uint256 returnDeadline,
        uint256 disputeWindowSeconds,
        string calldata itemId,
        string calldata listingId
    ) external returns (uint256 escrowId) {
        if (borrower == address(0)) revert InvalidAddress();
        if (collateral < MIN_COLLATERAL) revert InvalidCollateral();
        if (returnDeadline <= block.timestamp) revert InvalidReturnDeadline();
        if (disputeWindowSeconds == 0 || disputeWindowSeconds > MAX_DISPUTE_WINDOW) revert InvalidDisputeWindow();

        escrowId = _nextEscrowId;
        _nextEscrowId = escrowId + 1;

        uint256 platformFee = computePlatformFee(collateral);

        Escrow storage escrow = _escrows[escrowId];
        escrow.lender = msg.sender;
        escrow.borrower = borrower;
        escrow.collateral = collateral;
        escrow.platformFee = platformFee;
        escrow.depositDeadline = block.timestamp + 24 hours;
        escrow.returnDeadline = returnDeadline;
        escrow.disputeWindow = disputeWindowSeconds;
        escrow.state = EscrowState.Created;
        escrow.itemId = itemId;
        escrow.listingId = listingId;
        escrow.lastActivityAt = block.timestamp;

        _escrowsByLender[msg.sender].push(escrowId);
        _escrowsByBorrower[borrower].push(escrowId);

        emit EscrowCreated(escrowId, msg.sender, borrower, collateral, platformFee, returnDeadline, itemId);
    }

    function fundEscrow(uint256 escrowId) external nonReentrant {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (msg.sender != escrow.borrower) revert NotBorrower();
        if (escrow.state != EscrowState.Created) revert InvalidState();
        if (block.timestamp > escrow.depositDeadline) revert DeadlinePassed();

        uint256 amount = escrow.collateral + escrow.platformFee;
        usdc.safeTransferFrom(msg.sender, address(this), amount);

        escrow.state = EscrowState.Funded;
        escrow.lastActivityAt = block.timestamp;

        emit EscrowFunded(escrowId);
    }

    function confirmPickup(uint256 escrowId) external {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (escrow.state != EscrowState.Funded) revert InvalidState();
        if (msg.sender != escrow.lender && msg.sender != escrow.borrower) revert NotParticipant();

        if (msg.sender == escrow.lender) {
            escrow.lenderConfirmedPickup = true;
        } else {
            escrow.borrowerConfirmedPickup = true;
        }

        escrow.lastActivityAt = block.timestamp;
        emit PickupConfirmed(escrowId, msg.sender);

        if (escrow.lenderConfirmedPickup && escrow.borrowerConfirmedPickup) {
            escrow.state = EscrowState.PickedUp;
            escrow.lastActivityAt = block.timestamp;
            emit EscrowPickedUp(escrowId);
        }
    }

    function confirmReturn(uint256 escrowId) external nonReentrant {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (escrow.state != EscrowState.PickedUp) revert InvalidState();
        if (msg.sender != escrow.lender && msg.sender != escrow.borrower) revert NotParticipant();

        if (msg.sender == escrow.lender) {
            escrow.lenderConfirmedReturn = true;
        } else {
            escrow.borrowerConfirmedReturn = true;
        }

        escrow.lastActivityAt = block.timestamp;
        emit ReturnConfirmed(escrowId, msg.sender);

        if (escrow.lenderConfirmedReturn && escrow.borrowerConfirmedReturn) {
            escrow.state = EscrowState.Returned;
            escrow.lastActivityAt = block.timestamp;
            _settle(escrowId);
        }
    }

    function raiseDispute(uint256 escrowId) external {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (msg.sender != escrow.lender && msg.sender != escrow.borrower) revert NotParticipant();

        if (msg.sender == escrow.borrower) {
            if (escrow.state != EscrowState.PickedUp && escrow.state != EscrowState.Returned) {
                revert InvalidState();
            }
        } else {
            bool lenderAllowedState = escrow.state == EscrowState.PickedUp
                || escrow.state == EscrowState.Returned
                || escrow.state == EscrowState.Funded;
            if (!lenderAllowedState) revert InvalidState();
            if (block.timestamp < escrow.returnDeadline) revert DisputeWindowNotStarted();
            if (block.timestamp > escrow.returnDeadline + escrow.disputeWindow) revert DisputeWindowExpired();
        }

        escrow.state = EscrowState.Disputed;
        escrow.disputeRaisedAt = block.timestamp;
        escrow.lastActivityAt = block.timestamp;

        emit DisputeRaised(escrowId, msg.sender);
    }

    function resolveDispute(uint256 escrowId, uint256 lenderPayout, uint256 borrowerPayout) external onlyOwner nonReentrant {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (escrow.state != EscrowState.Disputed) revert InvalidState();
        if (lenderPayout + borrowerPayout != escrow.collateral) revert InvalidPayouts();

        escrow.state = EscrowState.AdminResolved;
        escrow.lastActivityAt = block.timestamp;

        if (lenderPayout > 0) {
            pendingWithdrawals[escrow.lender] += lenderPayout;
        }
        if (borrowerPayout > 0) {
            pendingWithdrawals[escrow.borrower] += borrowerPayout;
        }
        pendingWithdrawals[owner()] += escrow.platformFee;

        emit DisputeResolved(escrowId, lenderPayout, borrowerPayout);
    }

    function disputeTimeoutResolve(uint256 escrowId) external {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (escrow.state != EscrowState.Disputed) revert InvalidState();
        if (msg.sender != escrow.lender && msg.sender != escrow.borrower) revert NotParticipant();
        if (block.timestamp < escrow.disputeRaisedAt + disputeResolutionSla) revert DeadlineNotPassed();

        uint256 lenderSplit = escrow.collateral / 2;
        uint256 borrowerSplit = escrow.collateral - lenderSplit;

        escrow.state = EscrowState.AdminResolved;
        escrow.lastActivityAt = block.timestamp;

        if (lenderSplit > 0) {
            pendingWithdrawals[escrow.lender] += lenderSplit;
        }
        if (borrowerSplit > 0) {
            pendingWithdrawals[escrow.borrower] += borrowerSplit;
        }
        pendingWithdrawals[owner()] += escrow.platformFee;

        emit DisputeResolved(escrowId, lenderSplit, borrowerSplit);
    }

    function cancelEscrow(uint256 escrowId) external {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (escrow.state != EscrowState.Created) revert InvalidState();
        if (msg.sender != escrow.lender && msg.sender != escrow.borrower) revert NotParticipant();

        escrow.state = EscrowState.Cancelled;
        escrow.lastActivityAt = block.timestamp;

        emit EscrowCancelled(escrowId, msg.sender);
    }

    function claimTimeout(uint256 escrowId) external {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (msg.sender != escrow.lender) revert NotLender();
        if (escrow.state != EscrowState.Created) revert InvalidState();
        if (block.timestamp <= escrow.depositDeadline) revert DeadlineNotPassed();

        escrow.state = EscrowState.TimedOut;
        escrow.lastActivityAt = block.timestamp;

        emit EscrowTimedOut(escrowId);
    }

    function emergencyResolve(uint256 escrowId, uint256 lenderPayout, uint256 borrowerPayout)
        external
        onlyOwner
        nonReentrant
    {
        Escrow storage escrow = _requireEscrow(escrowId);
        if (_isTerminal(escrow.state)) revert InvalidState();
        if (block.timestamp < escrow.lastActivityAt + EMERGENCY_TIMEOUT) revert EmergencyTimeoutNotReached();

        bool fundedState = escrow.state == EscrowState.Funded || escrow.state == EscrowState.PickedUp
            || escrow.state == EscrowState.Returned || escrow.state == EscrowState.Disputed;

        escrow.state = EscrowState.AdminResolved;
        escrow.lastActivityAt = block.timestamp;

        if (fundedState) {
            if (lenderPayout + borrowerPayout != escrow.collateral) revert InvalidPayouts();
            if (lenderPayout > 0) {
                pendingWithdrawals[escrow.lender] += lenderPayout;
            }
            if (borrowerPayout > 0) {
                pendingWithdrawals[escrow.borrower] += borrowerPayout;
            }
            pendingWithdrawals[owner()] += escrow.platformFee;
        } else {
            if (lenderPayout != 0 || borrowerPayout != 0) revert InvalidPayouts();
        }

        emit EmergencyResolved(escrowId, lenderPayout, borrowerPayout);
    }

    function withdraw() external nonReentrant {
        uint256 amount = pendingWithdrawals[msg.sender];
        pendingWithdrawals[msg.sender] = 0;
        usdc.safeTransfer(msg.sender, amount);
        emit Withdrawn(msg.sender, amount);
    }

    function getEscrow(uint256 escrowId) external view returns (Escrow memory) {
        return _requireEscrowView(escrowId);
    }

    function getEscrowsByLender(address lender) external view returns (uint256[] memory) {
        return _escrowsByLender[lender];
    }

    function getEscrowsByBorrower(address borrower) external view returns (uint256[] memory) {
        return _escrowsByBorrower[borrower];
    }

    function computePlatformFee(uint256 collateral) public pure returns (uint256) {
        return (collateral * PLATFORM_FEE_BPS) / 10_000;
    }

    function _settle(uint256 escrowId) internal {
        Escrow storage escrow = _escrows[escrowId];
        uint256 collateral = escrow.collateral;
        uint256 platformFee = escrow.platformFee;

        escrow.state = EscrowState.Settled;
        escrow.lastActivityAt = block.timestamp;

        pendingWithdrawals[escrow.borrower] += collateral;
        pendingWithdrawals[owner()] += platformFee;

        emit EscrowSettled(escrowId, collateral, platformFee);
    }

    function _requireEscrow(uint256 escrowId) internal view returns (Escrow storage escrow) {
        escrow = _escrows[escrowId];
        if (escrow.lender == address(0)) revert EscrowNotFound();
    }

    function _requireEscrowView(uint256 escrowId) internal view returns (Escrow memory escrow) {
        escrow = _escrows[escrowId];
        if (escrow.lender == address(0)) revert EscrowNotFound();
    }

    function _isTerminal(EscrowState state) internal pure returns (bool) {
        return state == EscrowState.Settled || state == EscrowState.Cancelled || state == EscrowState.TimedOut
            || state == EscrowState.AdminResolved;
    }
}
