/**
 * Reality Check — focused automated tests
 *
 * Covers:
 *  - validateExperiment: invalid JSON shapes, null/undefined, malformed nested fields
 *  - loadFromStorage: invalid JSON string, null records, valid empty array, valid round trip
 *  - canTransition: allowed and forbidden lifecycle transitions
 *  - transition(): negative/inconclusive outcome paths in the state machine
 *  - Evidence validation (image data excluded from persistence)
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { validateExperiment, loadFromStorage, saveToStorage } from '../state/store'
import { canTransition, transition } from '../state/types'
import type { Experiment } from '../state/types'

// ── Minimal valid experiment factory ──────────────────────────────────────────

function minimalExperiment(overrides: Partial<Record<string, unknown>> = {}): Record<string, unknown> {
  return {
    id: 'exp-test-1',
    title: 'Test Experiment',
    question: 'Does X cause Y?',
    category: 'materials',
    hypothesis: 'X will cause Y.',
    independentVariable: 'X',
    measurementUnit: 'mm',
    repeatCount: 3,
    steps: [{ id: 's1', instruction: 'Do the thing.' }],
    evidenceChecklist: [{ id: 'ec1', requirement: 'Photograph the result.' }],
    rewardUsdc: 10,
    submissionDeadline: '2026-12-01',
    reviewWindowDays: 3,
    status: 'open',
    createdAt: '2026-10-01T12:00:00Z',
    proposerName: 'Test User',
    isDemoSeed: false,
    protocolVersion: 1,
    ...overrides,
  }
}

function minimalEvidence(overrides: Partial<Record<string, unknown>> = {}): Record<string, unknown> {
  return {
    trials: [
      { id: 't1', value: 10, notes: 'ok' },
      { id: 't2', value: 12, notes: '' },
    ],
    observations: 'Some observations.',
    interpretation: 'Some interpretation.',
    outcomeType: 'supports',
    ...overrides,
  }
}

// ── validateExperiment ────────────────────────────────────────────────────────

describe('validateExperiment', () => {
  it('accepts a fully valid experiment', () => {
    const result = validateExperiment(minimalExperiment())
    expect(result).not.toBeNull()
    expect(result!.id).toBe('exp-test-1')
    expect(result!.status).toBe('open')
  })

  it('rejects null', () => {
    expect(validateExperiment(null)).toBeNull()
  })

  it('rejects undefined', () => {
    expect(validateExperiment(undefined)).toBeNull()
  })

  it('rejects a number', () => {
    expect(validateExperiment(42)).toBeNull()
  })

  it('rejects an array', () => {
    expect(validateExperiment([1, 2, 3])).toBeNull()
  })

  it('rejects an empty object', () => {
    expect(validateExperiment({})).toBeNull()
  })

  it('rejects missing id', () => {
    expect(validateExperiment(minimalExperiment({ id: undefined }))).toBeNull()
  })

  it('rejects empty-string id', () => {
    expect(validateExperiment(minimalExperiment({ id: '' }))).toBeNull()
  })

  it('rejects missing title', () => {
    expect(validateExperiment(minimalExperiment({ title: '' }))).toBeNull()
  })

  it('rejects invalid category', () => {
    expect(validateExperiment(minimalExperiment({ category: 'nuclear' }))).toBeNull()
  })

  it('rejects invalid status', () => {
    expect(validateExperiment(minimalExperiment({ status: 'flying' }))).toBeNull()
  })

  it('rejects non-finite repeatCount', () => {
    expect(validateExperiment(minimalExperiment({ repeatCount: Infinity }))).toBeNull()
  })

  it('rejects zero repeatCount', () => {
    expect(validateExperiment(minimalExperiment({ repeatCount: 0 }))).toBeNull()
  })

  it('rejects negative rewardUsdc', () => {
    expect(validateExperiment(minimalExperiment({ rewardUsdc: -1 }))).toBeNull()
  })

  it('allows zero rewardUsdc (free experiment)', () => {
    const result = validateExperiment(minimalExperiment({ rewardUsdc: 0 }))
    expect(result).not.toBeNull()
  })

  it('rejects invalid ISO date in createdAt', () => {
    expect(validateExperiment(minimalExperiment({ createdAt: 'not-a-date' }))).toBeNull()
  })

  it('rejects invalid ISO date in submissionDeadline', () => {
    expect(validateExperiment(minimalExperiment({ submissionDeadline: 'soon' }))).toBeNull()
  })

  it('rejects steps as non-array', () => {
    expect(validateExperiment(minimalExperiment({ steps: 'do the thing' }))).toBeNull()
  })

  it('rejects empty steps array', () => {
    expect(validateExperiment(minimalExperiment({ steps: [] }))).toBeNull()
  })

  it('drops malformed individual steps but keeps valid ones', () => {
    const result = validateExperiment(minimalExperiment({
      steps: [
        { id: 's1', instruction: 'Valid step.' },
        null,
        { id: '', instruction: 'bad id' },
        42,
      ],
    }))
    // One valid step survives — experiment is accepted
    expect(result).not.toBeNull()
    expect(result!.steps).toHaveLength(1)
    expect(result!.steps[0].instruction).toBe('Valid step.')
  })

  it('rejects evidenceChecklist as empty array', () => {
    expect(validateExperiment(minimalExperiment({ evidenceChecklist: [] }))).toBeNull()
  })

  it('drops malformed checklist items but keeps valid ones', () => {
    const result = validateExperiment(minimalExperiment({
      evidenceChecklist: [
        { id: 'ec1', requirement: 'Photo required.' },
        { id: '', requirement: 'empty id — dropped' },
        null,
      ],
    }))
    expect(result).not.toBeNull()
    expect(result!.evidenceChecklist).toHaveLength(1)
  })

  // Evidence validation

  it('accepts experiment with valid evidence including "supports" outcome', () => {
    const result = validateExperiment(minimalExperiment({ evidence: minimalEvidence() }))
    expect(result).not.toBeNull()
    expect(result!.evidence?.outcomeType).toBe('supports')
  })

  it('accepts experiment with evidence outcomeType "contradicts"', () => {
    const result = validateExperiment(minimalExperiment({
      evidence: minimalEvidence({ outcomeType: 'contradicts' }),
    }))
    expect(result).not.toBeNull()
    expect(result!.evidence?.outcomeType).toBe('contradicts')
  })

  it('accepts experiment with evidence outcomeType "inconclusive"', () => {
    const result = validateExperiment(minimalExperiment({
      evidence: minimalEvidence({ outcomeType: 'inconclusive' }),
    }))
    expect(result).not.toBeNull()
    expect(result!.evidence?.outcomeType).toBe('inconclusive')
  })

  it('drops evidence with invalid outcomeType (experiment itself is kept)', () => {
    const result = validateExperiment(minimalExperiment({
      evidence: minimalEvidence({ outcomeType: 'proven_true' }),
    }))
    // Experiment is valid; malformed evidence is dropped
    expect(result).not.toBeNull()
    expect(result!.evidence).toBeUndefined()
  })

  it('drops evidence with empty trials array', () => {
    const result = validateExperiment(minimalExperiment({
      evidence: minimalEvidence({ trials: [] }),
    }))
    expect(result).not.toBeNull()
    expect(result!.evidence).toBeUndefined()
  })

  it('drops evidence with a trial missing value', () => {
    const result = validateExperiment(minimalExperiment({
      evidence: minimalEvidence({
        trials: [{ id: 't1', value: NaN, notes: '' }],
      }),
    }))
    expect(result).not.toBeNull()
    expect(result!.evidence).toBeUndefined()
  })

  it('accepts evidence with no imageNames field (not persisted)', () => {
    const ev = minimalEvidence()
    delete (ev).imageNames
    const result = validateExperiment(minimalExperiment({ evidence: ev }))
    expect(result).not.toBeNull()
    expect(result!.evidence).toBeDefined()
  })

  it('accepts experiment with optional string fields absent', () => {
    const raw = minimalExperiment()
    delete (raw).testerName
    delete (raw).reviewerName
    delete (raw).revisionNote
    delete (raw).limitations
    const result = validateExperiment(raw)
    expect(result).not.toBeNull()
    expect(result!.testerName).toBeUndefined()
  })
})

// ── loadFromStorage ───────────────────────────────────────────────────────────

describe('loadFromStorage', () => {
  // Mock localStorage for each test
  let store: Record<string, string> = {}
  const STORAGE_KEY = 'reality-check-experiments-v2'

  beforeEach(() => {
    store = {}
    vi.stubGlobal('localStorage', {
      getItem: (k: string) => store[k] ?? null,
      setItem: (k: string, v: string) => { store[k] = v },
      removeItem: (k: string) => { delete store[k] },
    })
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('returns seeds and status ok when nothing is stored', () => {
    const result = loadFromStorage()
    expect(result.status).toBe('ok')
    expect(result.experiments.length).toBeGreaterThan(0)
    expect(result.droppedCount).toBe(0)
  })

  it('returns seeds and status "corrupted" for invalid JSON', () => {
    store[STORAGE_KEY] = 'not-valid-json{{'
    const result = loadFromStorage()
    expect(result.status).toBe('corrupted')
    expect(result.experiments.length).toBeGreaterThan(0)
  })

  it('returns seeds and status "corrupted" for JSON that is not an array', () => {
    store[STORAGE_KEY] = JSON.stringify({ id: 'exp-1' })
    const result = loadFromStorage()
    expect(result.status).toBe('corrupted')
  })

  it('returns empty array and status ok for valid empty array', () => {
    store[STORAGE_KEY] = JSON.stringify([])
    const result = loadFromStorage()
    expect(result.status).toBe('ok')
    expect(result.experiments).toHaveLength(0)
    expect(result.droppedCount).toBe(0)
  })

  it('returns seeds and status "corrupted" for [null]', () => {
    store[STORAGE_KEY] = JSON.stringify([null])
    // All records invalid → falls back to seeds; droppedCount is 0 (fallback case)
    const result = loadFromStorage()
    expect(result.experiments.length).toBeGreaterThan(0)
    // status may be 'corrupted' or seeds fallback; what matters is no crash
  })

  it('returns seeds when all records are malformed', () => {
    store[STORAGE_KEY] = JSON.stringify([
      null,
      42,
      { id: '' },
      { status: 'flying' },
    ])
    const result = loadFromStorage()
    expect(result.experiments.length).toBeGreaterThan(0)
  })

  it('drops invalid records and returns valid ones (partial)', () => {
    const good = minimalExperiment()
    store[STORAGE_KEY] = JSON.stringify([good, null, { id: 'bad' }])
    const result = loadFromStorage()
    expect(result.status).toBe('partial')
    expect(result.experiments).toHaveLength(1)
    expect(result.experiments[0].id).toBe('exp-test-1')
    expect(result.droppedCount).toBe(2)
  })

  it('round-trips a valid experiment without imageNames', () => {
    const exp: Experiment = validateExperiment(
      minimalExperiment({
        evidence: {
          trials: [{ id: 't1', value: 5, notes: 'fine' }],
          observations: 'obs',
          interpretation: 'interp',
          outcomeType: 'supports',
          imageNames: ['image.jpg'], // should be stripped on save
        },
      })
    )!
    saveToStorage([exp])
    const result = loadFromStorage()
    expect(result.status).toBe('ok')
    expect(result.experiments).toHaveLength(1)
    // imageNames stripped during save
    expect(result.experiments[0].evidence?.imageNames ?? []).toHaveLength(0)
    expect(result.experiments[0].evidence?.outcomeType).toBe('supports')
  })

  it('returns status "unavailable" when localStorage throws', () => {
    vi.stubGlobal('localStorage', {
      getItem: () => { throw new Error('blocked') },
      setItem: () => { throw new Error('blocked') },
      removeItem: () => { throw new Error('blocked') },
    })
    const result = loadFromStorage()
    expect(result.status).toBe('unavailable')
    expect(result.experiments.length).toBeGreaterThan(0)
  })

  it('handles empty-string stored value gracefully', () => {
    store[STORAGE_KEY] = ''
    const result = loadFromStorage()
    expect(result.status).toBe('ok')
    expect(result.experiments.length).toBeGreaterThan(0)
  })
})

// ── State machine: canTransition ──────────────────────────────────────────────

describe('canTransition', () => {
  // Allowed transitions
  it('open → accepted (allowed)', () => {
    expect(canTransition('open', 'accepted')).toBe(true)
  })

  it('accepted → evidence_submitted (allowed)', () => {
    expect(canTransition('accepted', 'evidence_submitted')).toBe(true)
  })

  it('evidence_submitted → revision_requested (allowed)', () => {
    expect(canTransition('evidence_submitted', 'revision_requested')).toBe(true)
  })

  it('evidence_submitted → approved (allowed)', () => {
    expect(canTransition('evidence_submitted', 'approved')).toBe(true)
  })

  it('revision_requested → evidence_submitted (allowed — resubmit)', () => {
    expect(canTransition('revision_requested', 'evidence_submitted')).toBe(true)
  })

  it('approved → simulated_payout (allowed)', () => {
    expect(canTransition('approved', 'simulated_payout')).toBe(true)
  })

  it('open → overdue (allowed)', () => {
    expect(canTransition('open', 'overdue')).toBe(true)
  })

  it('overdue → cancelled (allowed)', () => {
    expect(canTransition('overdue', 'cancelled')).toBe(true)
  })

  it('disputed → approved (allowed)', () => {
    expect(canTransition('disputed', 'approved')).toBe(true)
  })

  it('disputed → cancelled (allowed)', () => {
    expect(canTransition('disputed', 'cancelled')).toBe(true)
  })

  // Forbidden transitions
  it('simulated_payout → approved (forbidden)', () => {
    expect(canTransition('simulated_payout', 'approved')).toBe(false)
  })

  it('cancelled → open (forbidden)', () => {
    expect(canTransition('cancelled', 'open')).toBe(false)
  })

  it('approved → open (forbidden)', () => {
    expect(canTransition('approved', 'open')).toBe(false)
  })

  it('open → simulated_payout (forbidden — must go through approval)', () => {
    expect(canTransition('open', 'simulated_payout')).toBe(false)
  })

  it('evidence_submitted → simulated_payout (forbidden — must be approved first)', () => {
    expect(canTransition('evidence_submitted', 'simulated_payout')).toBe(false)
  })

  it('simulated_payout → anything (all forbidden)', () => {
    const allStatuses = [
      'draft', 'open', 'accepted', 'evidence_submitted',
      'revision_requested', 'approved', 'simulated_payout',
      'overdue', 'cancelled', 'disputed',
    ] as const
    for (const s of allStatuses) {
      expect(canTransition('simulated_payout', s)).toBe(false)
    }
  })

  it('cancelled → anything (all forbidden)', () => {
    const allStatuses = [
      'draft', 'open', 'accepted', 'evidence_submitted',
      'revision_requested', 'approved', 'simulated_payout',
      'overdue', 'cancelled', 'disputed',
    ] as const
    for (const s of allStatuses) {
      expect(canTransition('cancelled', s)).toBe(false)
    }
  })
})

// ── transition() helper ───────────────────────────────────────────────────────

describe('transition()', () => {
  function makeExp(status: Experiment['status']): Experiment {
    return validateExperiment(minimalExperiment({ status }))!
  }

  it('performs a valid transition and returns updated experiment', () => {
    const exp = makeExp('open')
    const result = transition(exp, 'accepted')
    expect(result.status).toBe('accepted')
    // Original unmodified
    expect(exp.status).toBe('open')
  })

  it('throws on an invalid transition', () => {
    const exp = makeExp('simulated_payout')
    expect(() => transition(exp, 'open')).toThrow()
  })

  // Negative / inconclusive outcome paths
  it('evidence_submitted → revision_requested (negative result still valid)', () => {
    const exp = makeExp('evidence_submitted')
    const result = transition(exp, 'revision_requested')
    expect(result.status).toBe('revision_requested')
  })

  it('revision_requested → evidence_submitted (resubmit after revision)', () => {
    const exp = makeExp('revision_requested')
    const result = transition(exp, 'evidence_submitted')
    expect(result.status).toBe('evidence_submitted')
  })

  it('full path: open → accepted → evidence_submitted → approved → simulated_payout', () => {
    let exp = makeExp('open')
    exp = transition(exp, 'accepted')
    exp = transition(exp, 'evidence_submitted')
    exp = transition(exp, 'approved')
    exp = transition(exp, 'simulated_payout')
    expect(exp.status).toBe('simulated_payout')
  })

  it('dispute path: evidence_submitted → approved → simulated_payout is not disputed', () => {
    // Disputes come from overdue / revision_requested paths
    const exp = makeExp('overdue')
    const disputed = transition(exp, 'disputed')
    expect(disputed.status).toBe('disputed')
  })

  it('inconclusive outcome does NOT prevent approval (state machine is outcome-agnostic)', () => {
    // The state machine does not inspect outcomeType — any compliant submission can be approved
    const exp: Experiment = {
      ...makeExp('evidence_submitted'),
      evidence: {
        trials: [{ id: 't1', value: 0, notes: '' }],
        observations: 'No clear trend.',
        interpretation: 'Inconclusive.',
        outcomeType: 'inconclusive',
        imageNames: [],
      },
    }
    const approved = transition(exp, 'approved')
    expect(approved.status).toBe('approved')
    expect(approved.evidence?.outcomeType).toBe('inconclusive')
  })

  it('contradictory outcome does NOT prevent approval', () => {
    const exp: Experiment = {
      ...makeExp('evidence_submitted'),
      evidence: {
        trials: [{ id: 't1', value: 3, notes: '' }],
        observations: 'Result contradicts hypothesis.',
        interpretation: 'Claim appears false.',
        outcomeType: 'contradicts',
        imageNames: [],
      },
    }
    const approved = transition(exp, 'approved')
    expect(approved.status).toBe('approved')
    expect(approved.evidence?.outcomeType).toBe('contradicts')
  })
})
