// Reality Check — local state store with localStorage persistence
import { useState, useCallback, useEffect } from 'react'
import type { Experiment, ExperimentStatus, EvidenceSubmission, ReviewAction } from './types'
import { SEED_EXPERIMENTS } from './seeds'
import { canTransition } from './types'

const STORAGE_KEY = 'reality-check-experiments-v2'

// ── Enum sets for validation ──────────────────────────────────────────────────
const VALID_STATUSES = new Set<string>([
  'draft', 'open', 'accepted', 'evidence_submitted',
  'revision_requested', 'approved', 'simulated_payout',
  'overdue', 'cancelled', 'disputed',
])
const VALID_CATEGORIES = new Set<string>([
  'materials', 'packaging', 'beverages', 'stationery',
  'household', 'environment', 'food', 'other',
])
const VALID_OUTCOMES = new Set<string>(['supports', 'contradicts', 'inconclusive'])

// ── Field-level validators ────────────────────────────────────────────────────

function isNonEmptyString(v: unknown): v is string {
  return typeof v === 'string' && v.trim().length > 0
}

function isISODateString(v: unknown): boolean {
  if (typeof v !== 'string') return false
  const d = new Date(v)
  return !isNaN(d.getTime())
}

function isPositiveFiniteNumber(v: unknown): v is number {
  return typeof v === 'number' && isFinite(v) && v > 0
}

function isNonNegativeFiniteNumber(v: unknown): v is number {
  return typeof v === 'number' && isFinite(v) && v >= 0
}

function validateProtocolStep(s: unknown): boolean {
  if (typeof s !== 'object' || s === null) return false
  const o = s as Record<string, unknown>
  return isNonEmptyString(o.id) && typeof o.instruction === 'string'
}

function validateChecklistItem(c: unknown): boolean {
  if (typeof c !== 'object' || c === null) return false
  const o = c as Record<string, unknown>
  return isNonEmptyString(o.id) && typeof o.requirement === 'string'
}

function validateTrial(t: unknown): boolean {
  if (typeof t !== 'object' || t === null) return false
  const o = t as Record<string, unknown>
  return (
    isNonEmptyString(o.id) &&
    isNonNegativeFiniteNumber(o.value) &&
    typeof o.notes === 'string'
  )
}

function validateEvidence(e: unknown): boolean {
  if (typeof e !== 'object' || e === null) return false
  const o = e as Record<string, unknown>
  return (
    Array.isArray(o.trials) &&
    o.trials.length > 0 &&
    o.trials.every(validateTrial) &&
    typeof o.observations === 'string' &&
    typeof o.interpretation === 'string' &&
    VALID_OUTCOMES.has(o.outcomeType as string)
    // imageNames is not persisted; its absence is fine
  )
}

function validateReview(r: unknown): boolean {
  if (typeof r !== 'object' || r === null) return false
  const o = r as Record<string, unknown>
  return (
    (o.decision === 'approved' || o.decision === 'revision_requested') &&
    typeof o.reason === 'string' &&
    isISODateString(o.reviewedAt)
  )
}

/** Returns the experiment if every required field passes validation, null otherwise. */
export function validateExperiment(raw: unknown): Experiment | null {
  if (typeof raw !== 'object' || raw === null) return null
  const o = raw as Record<string, unknown>

  // Required string fields
  if (!isNonEmptyString(o.id)) return null
  if (!isNonEmptyString(o.title)) return null
  if (!isNonEmptyString(o.question)) return null
  if (!VALID_CATEGORIES.has(o.category as string)) return null
  if (!isNonEmptyString(o.hypothesis)) return null
  if (!isNonEmptyString(o.independentVariable)) return null
  if (!isNonEmptyString(o.measurementUnit)) return null
  if (!isNonEmptyString(o.proposerName)) return null

  // Numbers
  if (!isPositiveFiniteNumber(o.repeatCount)) return null
  if (!isNonNegativeFiniteNumber(o.rewardUsdc)) return null
  if (!isPositiveFiniteNumber(o.reviewWindowDays)) return null
  if (typeof o.protocolVersion !== 'number' || !isFinite(o.protocolVersion)) return null

  // Enum fields
  if (!VALID_STATUSES.has(o.status as string)) return null

  // Date strings
  if (!isISODateString(o.createdAt)) return null
  if (!isISODateString(o.submissionDeadline)) return null

  // Arrays — must be arrays; individual bad items are dropped rather than rejecting the whole experiment
  if (!Array.isArray(o.steps)) return null
  const steps = (o.steps as unknown[]).filter(validateProtocolStep)
  if (steps.length === 0) return null

  if (!Array.isArray(o.evidenceChecklist)) return null
  const evidenceChecklist = (o.evidenceChecklist as unknown[]).filter(validateChecklistItem)
  if (evidenceChecklist.length === 0) return null

  // Optional nested objects
  const evidence =
    o.evidence != null
      ? validateEvidence(o.evidence)
        ? (o.evidence as EvidenceSubmission)
        : null // drop malformed evidence rather than crash
      : undefined

  const review =
    o.review != null
      ? validateReview(o.review)
        ? (o.review as ReviewAction)
        : null
      : undefined

  return {
    id: o.id,
    title: o.title,
    question: o.question,
    category: o.category as Experiment['category'],
    hypothesis: o.hypothesis,
    independentVariable: o.independentVariable,
    measurementUnit: o.measurementUnit,
    repeatCount: o.repeatCount,
    steps: steps as Experiment['steps'],
    evidenceChecklist: evidenceChecklist as Experiment['evidenceChecklist'],
    rewardUsdc: o.rewardUsdc,
    submissionDeadline: o.submissionDeadline as string,
    reviewWindowDays: o.reviewWindowDays,
    status: o.status as ExperimentStatus,
    createdAt: o.createdAt as string,
    proposerName: o.proposerName,
    testerName: typeof o.testerName === 'string' ? o.testerName : undefined,
    reviewerName: typeof o.reviewerName === 'string' ? o.reviewerName : undefined,
    evidence: evidence ?? undefined,
    review: review ?? undefined,
    revisionNote: typeof o.revisionNote === 'string' ? o.revisionNote : undefined,
    isDemoSeed: o.isDemoSeed === true,
    protocolVersion: o.protocolVersion,
    limitations: typeof o.limitations === 'string' ? o.limitations : undefined,
  }
}

// ── Load / Save ───────────────────────────────────────────────────────────────

export type StorageStatus =
  | 'ok'
  | 'unavailable'      // localStorage threw on access
  | 'corrupted'        // JSON parse error
  | 'partial'          // some records were invalid and dropped

export interface LoadResult {
  experiments: Experiment[]
  status: StorageStatus
  droppedCount: number
}

export function loadFromStorage(): LoadResult {
  let raw: string | null = null

  // Attempt to access localStorage — may throw in sandboxed iframes
  try {
    raw = localStorage.getItem(STORAGE_KEY)
  } catch {
    return { experiments: [...SEED_EXPERIMENTS], status: 'unavailable', droppedCount: 0 }
  }

  // No stored data — first visit
  if (raw === null) {
    return { experiments: [...SEED_EXPERIMENTS], status: 'ok', droppedCount: 0 }
  }

  // Empty string stored (shouldn't happen, but treat as no data)
  if (raw.trim() === '') {
    return { experiments: [...SEED_EXPERIMENTS], status: 'ok', droppedCount: 0 }
  }

  // Parse JSON
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch {
    return { experiments: [...SEED_EXPERIMENTS], status: 'corrupted', droppedCount: 0 }
  }

  // Must be an array
  if (!Array.isArray(parsed)) {
    return { experiments: [...SEED_EXPERIMENTS], status: 'corrupted', droppedCount: 0 }
  }

  // Empty array is valid (user deleted everything)
  if (parsed.length === 0) {
    return { experiments: [], status: 'ok', droppedCount: 0 }
  }

  // Validate every element; drop invalid ones
  const valid: Experiment[] = []
  let droppedCount = 0
  for (const item of parsed) {
    const exp = validateExperiment(item)
    if (exp !== null) {
      valid.push(exp)
    } else {
      droppedCount++
    }
  }

  const status: StorageStatus = droppedCount > 0 ? 'partial' : 'ok'
  // If everything was invalid, recover with seeds
  const experiments = valid.length === 0 ? [...SEED_EXPERIMENTS] : valid
  const finalDropped = valid.length === 0 ? 0 : droppedCount // don't claim drops when we fell back

  return { experiments, status, droppedCount: finalDropped }
}

export function saveToStorage(experiments: Experiment[]): StorageStatus {
  try {
    // Never persist image data
    const sanitised = experiments.map(e => ({
      ...e,
      evidence: e.evidence
        ? { ...e.evidence, imageNames: [] }
        : undefined,
    }))
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sanitised))
    return 'ok'
  } catch {
    return 'unavailable'
  }
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useExperimentStore() {
  const [loadResult] = useState<LoadResult>(loadFromStorage)
  const [experiments, setExperiments] = useState<Experiment[]>(loadResult.experiments)
  const [storageDroppedCount] = useState(loadResult.droppedCount)
  // saveFailed is updated asynchronously (via queueMicrotask) so it never triggers from
  // inside a synchronous render path, satisfying the React Compiler's no-setState-in-effect rule
  const [saveFailed, setSaveFailed] = useState(false)

  const storageStatus: StorageStatus = saveFailed
    ? 'unavailable'
    : loadResult.status

  useEffect(() => {
    const result = saveToStorage(experiments)
    if (result === 'unavailable') {
      // Queue the state update to run after the current render cycle
      queueMicrotask(() => setSaveFailed(true))
    }
  }, [experiments])

  const getById = useCallback(
    (id: string) => experiments.find(e => e.id === id),
    [experiments]
  )

  const addExperiment = useCallback((exp: Experiment) => {
    setExperiments(prev => [exp, ...prev])
  }, [])

  const updateExperiment = useCallback((updated: Experiment) => {
    setExperiments(prev =>
      prev.map(e => (e.id === updated.id ? updated : e))
    )
  }, [])

  const deleteExperiment = useCallback((id: string) => {
    setExperiments(prev => prev.filter(e => e.id !== id))
  }, [])

  const transitionStatus = useCallback(
    (id: string, to: ExperimentStatus): boolean => {
      let allowed = false
      setExperiments(prev =>
        prev.map(e => {
          if (e.id !== id) return e
          if (!canTransition(e.status, to)) return e
          allowed = true
          return { ...e, status: to }
        })
      )
      return allowed
    },
    []
  )

  const submitEvidence = useCallback(
    (id: string, evidence: EvidenceSubmission) => {
      setExperiments(prev =>
        prev.map(e => {
          if (e.id !== id) return e
          if (!canTransition(e.status, 'evidence_submitted')) return e
          return { ...e, status: 'evidence_submitted', evidence }
        })
      )
    },
    []
  )

  const submitReview = useCallback(
    (id: string, review: ReviewAction) => {
      const toStatus: ExperimentStatus =
        review.decision === 'approved' ? 'approved' : 'revision_requested'
      setExperiments(prev =>
        prev.map(e => {
          if (e.id !== id) return e
          if (!canTransition(e.status, toStatus)) return e
          return { ...e, status: toStatus, review }
        })
      )
    },
    []
  )

  const simulatePayout = useCallback((id: string) => {
    setExperiments(prev =>
      prev.map(e => {
        if (e.id !== id) return e
        if (!canTransition(e.status, 'simulated_payout')) return e
        return { ...e, status: 'simulated_payout' }
      })
    )
  }, [])

  const resetDemo = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch {
      // Storage unavailable — proceed with in-memory reset anyway
    }
    setExperiments([...SEED_EXPERIMENTS])
  }, [])

  return {
    experiments,
    storageStatus,
    storageDroppedCount,
    getById,
    addExperiment,
    updateExperiment,
    deleteExperiment,
    transitionStatus,
    submitEvidence,
    submitReview,
    simulatePayout,
    resetDemo,
  }
}

export type ExperimentStore = ReturnType<typeof useExperimentStore>
