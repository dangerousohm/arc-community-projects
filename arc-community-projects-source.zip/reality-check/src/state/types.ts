// Reality Check — core types and state machine

export type ExperimentStatus =
  | 'draft'
  | 'open'
  | 'accepted'
  | 'evidence_submitted'
  | 'revision_requested'
  | 'approved'
  | 'simulated_payout'
  | 'overdue'
  | 'cancelled'
  | 'disputed'

export type Category =
  | 'materials'
  | 'packaging'
  | 'beverages'
  | 'stationery'
  | 'household'
  | 'environment'
  | 'food'
  | 'other'

export type OutcomeType = 'supports' | 'contradicts' | 'inconclusive'

export interface ProtocolStep {
  id: string
  instruction: string
}

export interface EvidenceChecklistItem {
  id: string
  requirement: string
}

export interface Trial {
  id: string
  value: number
  notes: string
}

export interface EvidenceSubmission {
  trials: Trial[]
  observations: string
  interpretation: string
  outcomeType: OutcomeType
  imageNames: string[] // preview names only — not persisted
}

export interface ReviewAction {
  decision: 'approved' | 'revision_requested'
  reason: string
  reviewedAt: string
}

export interface Experiment {
  id: string
  title: string
  question: string
  category: Category
  hypothesis: string
  independentVariable: string
  measurementUnit: string
  repeatCount: number
  steps: ProtocolStep[]
  evidenceChecklist: EvidenceChecklistItem[]
  rewardUsdc: number
  submissionDeadline: string   // ISO date string
  reviewWindowDays: number
  status: ExperimentStatus
  createdAt: string
  proposerName: string
  testerName?: string
  reviewerName?: string
  evidence?: EvidenceSubmission
  review?: ReviewAction
  revisionNote?: string
  isDemoSeed: boolean
  protocolVersion: number
  limitations?: string
}

// ── State machine: valid transitions ──────────────────────────────────────────

const VALID_TRANSITIONS: Record<ExperimentStatus, ExperimentStatus[]> = {
  draft:             ['open', 'cancelled'],
  open:              ['accepted', 'overdue', 'cancelled'],
  accepted:          ['evidence_submitted', 'overdue', 'cancelled'],
  evidence_submitted:['revision_requested', 'approved'],
  revision_requested:['evidence_submitted', 'cancelled', 'disputed'],
  approved:          ['simulated_payout'],
  simulated_payout:  [],
  overdue:           ['cancelled', 'disputed'],
  cancelled:         [],
  disputed:          ['approved', 'cancelled'],
}

export function canTransition(from: ExperimentStatus, to: ExperimentStatus): boolean {
  return VALID_TRANSITIONS[from]?.includes(to) ?? false
}

export function transition(
  exp: Experiment,
  to: ExperimentStatus
): Experiment {
  if (!canTransition(exp.status, to)) {
    throw new Error(`Invalid transition: ${exp.status} → ${to}`)
  }
  return { ...exp, status: to }
}

export const STATUS_LABELS: Record<ExperimentStatus, string> = {
  draft:              'Draft',
  open:               'Open',
  accepted:           'Accepted',
  evidence_submitted: 'Evidence Submitted',
  revision_requested: 'Revision Requested',
  approved:           'Approved',
  simulated_payout:   'Simulated Payout',
  overdue:            'Overdue',
  cancelled:          'Cancelled',
  disputed:           'Disputed',
}

export const STATUS_COLORS: Record<ExperimentStatus, string> = {
  draft:              'text-[var(--muted)] border-[var(--border)]',
  open:               'text-[var(--pale-blue)] border-[var(--pale-blue)]',
  accepted:           'text-[var(--yellow)] border-[var(--yellow)]',
  evidence_submitted: 'text-[var(--yellow)] border-[var(--yellow)]',
  revision_requested: 'text-[var(--coral)] border-[var(--coral)]',
  approved:           'text-[var(--success)] border-[var(--success)]',
  simulated_payout:   'text-[var(--success)] border-[var(--success)]',
  overdue:            'text-[var(--coral)] border-[var(--coral)]',
  cancelled:          'text-[var(--coral)] border-[var(--coral)]',
  disputed:           'text-[var(--coral)] border-[var(--coral)]',
}

export const CATEGORY_LABELS: Record<Category, string> = {
  materials:   'Materials',
  packaging:   'Packaging',
  beverages:   'Beverages',
  stationery:  'Stationery',
  household:   'Household',
  environment: 'Environment',
  food:        'Food & Drink',
  other:       'Other',
}
