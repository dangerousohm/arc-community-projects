import { FlaskConical, RotateCcw } from 'lucide-react'
import { GraphPaperIcon } from './ui/SVGIcons'

interface NavProps {
  onHome: () => void
  onCreate: () => void
  onReset: () => void
}

export function Nav({ onHome, onCreate, onReset }: NavProps) {
  return (
    <nav
      className="sticky top-0 z-20 w-full"
      style={{
        background: 'rgba(11,22,41,0.85)',
        borderBottom: '1px solid var(--border)',
        backdropFilter: 'blur(16px)',
      }}
    >
      <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        {/* Logo */}
        <button
          onClick={onHome}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          aria-label="Go to experiment board"
        >
          <GraphPaperIcon className="w-7 h-7" />
          <span
            className="display text-base font-bold hidden sm:block"
            style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
          >
            Reality Check
          </span>
        </button>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onCreate}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
            style={{
              background: 'var(--yellow)',
              color: '#0b1629',
            }}
            aria-label="Create experiment"
          >
            <FlaskConical className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New experiment</span>
          </button>

          <button
            onClick={onReset}
            className="p-2 rounded-lg transition-colors hover:text-[var(--ink)]"
            style={{ color: 'var(--muted)' }}
            title="Reset demo data"
            aria-label="Reset demo data"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </nav>
  )
}
