import { useState, useRef, useEffect } from 'react'
import {
  ChevronLeft, Upload, Plus, Trash2, CheckCircle2, XCircle,
  AlertTriangle, Clock, Info, Download,
} from 'lucide-react'
import type {
  Experiment, Trial, EvidenceSubmission, ReviewAction, OutcomeType,
} from '../state/types'
import type { ExperimentStore } from '../state/store'
import { STATUS_LABELS } from '../state/types'
import { StatusBadge, CategoryBadge } from './ui/Badge'
import { Button } from './ui/Button'
import { Card, SectionLabel, SpecimenLabel } from './ui/Card'
import { DemoUsdcTag } from './ui/DemoTag'
import { FlaskIcon } from './ui/SVGIcons'

type Role = 'proposer' | 'tester' | 'reviewer'
const ROLE_LABELS: Record<Role, string> = {
  proposer: 'Proposer',
  tester:   'Tester',
  reviewer: 'Reviewer',
}

interface WorkbenchProps {
  experiment: Experiment
  store: ExperimentStore
  onBack: () => void
  onViewReceipt: (id: string) => void
}

function uid(): string {
  return Math.random().toString(36).slice(2, 10)
}

export function Workbench({ experiment: exp, store, onBack, onViewReceipt }: WorkbenchProps) {
  const [role, setRole] = useState<Role>('tester')

  // Evidence entry state (tester role)
  const [trials, setTrials] = useState<Trial[]>(
    exp.evidence?.trials ??
    Array.from({ length: exp.repeatCount }, () => ({ id: uid(), value: 0, notes: '' }))
  )
  const [observations, setObservations] = useState(exp.evidence?.observations ?? '')
  const [interpretation, setInterpretation] = useState(exp.evidence?.interpretation ?? '')
  const [outcomeType, setOutcomeType] = useState<OutcomeType>(exp.evidence?.outcomeType ?? 'supports')
  const [evidenceErrors, setEvidenceErrors] = useState<Record<string, string>>({})
  const [submitDone, setSubmitDone] = useState(false)

  // Review state (reviewer role)
  const [reviewDecision, setReviewDecision] = useState<'approved' | 'revision_requested'>('approved')
  const [reviewReason, setReviewReason] = useState('')
  const [reviewError, setReviewError] = useState('')
  const [reviewDone, setReviewDone] = useState(false)

  const current = store.getById(exp.id) ?? exp

  function updateTrial(id: string, field: 'value' | 'notes', v: string | number) {
    setTrials(prev => prev.map(t => (t.id === id ? { ...t, [field]: v } : t)))
  }

  function addTrial() {
    setTrials(prev => [...prev, { id: uid(), value: 0, notes: '' }])
  }

  function removeTrial(id: string) {
    if (trials.length > 1) setTrials(prev => prev.filter(t => t.id !== id))
  }

  function validateEvidence() {
    const errs: Record<string, string> = {}
    trials.forEach((t, i) => {
      if (isNaN(t.value)) errs[`trial-${i}`] = 'Enter a valid number.'
    })
    if (!observations.trim()) errs.observations = 'Observations are required.'
    return errs
  }

  function handleSubmitEvidence() {
    const errs = validateEvidence()
    setEvidenceErrors(errs)
    if (Object.keys(errs).length > 0) return
    const evidence: EvidenceSubmission = {
      trials,
      observations,
      interpretation,
      outcomeType,
      imageNames: [], // not persisted
    }
    store.submitEvidence(exp.id, evidence)
    setSubmitDone(true)
  }

  function handleRevise() {
    store.transitionStatus(exp.id, 'evidence_submitted')
    setSubmitDone(false)
  }

  function handleSubmitReview() {
    if (!reviewReason.trim()) {
      setReviewError('Provide a reason for your decision.')
      return
    }
    const review: ReviewAction = {
      decision: reviewDecision,
      reason: reviewReason,
      reviewedAt: new Date().toISOString(),
    }
    store.submitReview(exp.id, review)
    setReviewDone(true)
  }

  function handleSimulatePayout() {
    store.simulatePayout(exp.id)
  }

  // ── Derived stats ─────────────────────────────────────────────────────────
  const validValues = (current.evidence?.trials ?? trials)
    .map(t => Number(t.value))
    .filter(v => !isNaN(v))

  const mean = validValues.length > 0
    ? validValues.reduce((a, b) => a + b, 0) / validValues.length
    : null
  const range = validValues.length > 1
    ? Math.max(...validValues) - Math.min(...validValues)
    : null

  const inputClass =
    'w-full px-3 py-2.5 rounded-lg text-sm outline-none transition-colors focus:border-[var(--border-strong)]'
  const inputStyle = {
    background: 'var(--surface-muted)',
    border: '1px solid var(--border)',
    color: 'var(--ink)',
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 min-h-dvh">
      {/* Back */}
      <button
        className="flex items-center gap-1.5 text-sm mb-5 hover:text-[var(--ink)] transition-colors"
        style={{ color: 'var(--muted)' }}
        onClick={onBack}
      >
        <ChevronLeft className="w-4 h-4" /> All experiments
      </button>

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-6 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <CategoryBadge category={current.category} />
            <StatusBadge status={current.status} />
          </div>
          <h1
            className="display text-2xl md:text-3xl font-bold text-balance mb-1"
            style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}
          >
            {current.title}
          </h1>
          <p className="text-sm text-pretty" style={{ color: 'var(--muted)', maxWidth: '65ch' }}>
            {current.question}
          </p>
        </div>
        <div className="flex flex-col items-end gap-2 shrink-0">
          <DemoUsdcTag amount={current.rewardUsdc} />
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
            Proposed by {current.proposerName}
          </span>
        </div>
      </div>

      {/* Role switch — demo only */}
      <div
        className="mb-6 rounded-xl p-4"
        style={{
          background: 'var(--surface)',
          border: '1px solid var(--border)',
        }}
      >
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Demo role switch (not real authorization):
          </span>
          {(['proposer', 'tester', 'reviewer'] as Role[]).map(r => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                role === r
                  ? 'text-[#0b1629] bg-[var(--pale-blue)]'
                  : 'text-[var(--muted)] hover:text-[var(--ink)] bg-[var(--surface-muted)]'
              }`}
            >
              {ROLE_LABELS[r]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left: Protocol */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <FlaskIcon className="w-5 h-5" style={{ color: 'var(--yellow)' }} />
              <SectionLabel>Protocol (frozen)</SectionLabel>
            </div>
            <div className="space-y-2 mb-4">
              {current.steps.map((s, i) => (
                <div key={s.id} className="flex items-start gap-2">
                  <span
                    className="mono text-xs font-medium mt-0.5 shrink-0"
                    style={{ color: 'var(--yellow)' }}
                  >
                    {i + 1}
                  </span>
                  <p className="text-xs" style={{ color: 'var(--ink-2)' }}>{s.instruction}</p>
                </div>
              ))}
            </div>
            <div
              className="rounded-lg p-3 text-xs"
              style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}
            >
              Measurement: <span style={{ color: 'var(--ink-2)' }}>{current.measurementUnit}</span>
              <br />
              Trials: <span style={{ color: 'var(--ink-2)' }}>{current.repeatCount}</span>
            </div>
          </Card>

          <Card className="p-5">
            <SectionLabel>Evidence checklist</SectionLabel>
            <ul className="space-y-2">
              {current.evidenceChecklist.map(item => (
                <li key={item.id} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" style={{ color: 'var(--pale-blue)' }} />
                  <span className="text-xs" style={{ color: 'var(--ink-2)' }}>{item.requirement}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Status timeline */}
          <StatusTimeline experiment={current} />
        </div>

        {/* Right: Evidence + Review */}
        <div className="lg:col-span-2 space-y-5">

          {/* Tester: evidence entry */}
          {role === 'tester' && (
            <EvidencePanel
              experiment={current}
              trials={trials}
              observations={observations}
              interpretation={interpretation}
              outcomeType={outcomeType}
              evidenceErrors={evidenceErrors}
              submitDone={submitDone}
              mean={mean}
              rangeVal={range}
              inputClass={inputClass}
              inputStyle={inputStyle}
              onUpdateTrial={updateTrial}
              onAddTrial={addTrial}
              onRemoveTrial={removeTrial}
              onObservations={setObservations}
              onInterpretation={setInterpretation}
              onOutcomeType={setOutcomeType}
              onSubmit={handleSubmitEvidence}
              onRevise={handleRevise}
            />
          )}

          {/* Reviewer panel */}
          {role === 'reviewer' && (
            <ReviewerPanel
              experiment={current}
              mean={mean}
              rangeVal={range}
              decision={reviewDecision}
              reason={reviewReason}
              error={reviewError}
              done={reviewDone}
              inputClass={inputClass}
              inputStyle={inputStyle}
              onDecision={setReviewDecision}
              onReason={setReviewReason}
              onSubmit={handleSubmitReview}
              onPayout={handleSimulatePayout}
              onViewReceipt={() => onViewReceipt(exp.id)}
            />
          )}

          {/* Proposer info */}
          {role === 'proposer' && (
            <ProposerPanel
              experiment={current}
              mean={mean}
              rangeVal={range}
              onViewReceipt={() => onViewReceipt(exp.id)}
            />
          )}
        </div>
      </div>
    </div>
  )
}

// ── Evidence Panel ─────────────────────────────────────────────────────────
function EvidencePanel(props: {
  experiment: Experiment
  trials: Trial[]
  observations: string
  interpretation: string
  outcomeType: OutcomeType
  evidenceErrors: Record<string, string>
  submitDone: boolean
  mean: number | null
  rangeVal: number | null
  inputClass: string
  inputStyle: React.CSSProperties
  onUpdateTrial: (id: string, field: 'value' | 'notes', v: string | number) => void
  onAddTrial: () => void
  onRemoveTrial: (id: string) => void
  onObservations: (v: string) => void
  onInterpretation: (v: string) => void
  onOutcomeType: (v: OutcomeType) => void
  onSubmit: () => void
  onRevise: () => void
}) {
  const { experiment: exp } = props
  // Real in-memory image previews: object URLs, revoked on unmount / removal
  const [imagePreviews, setImagePreviews] = useState<Array<{ name: string; url: string }>>([])
  const fileRef = useRef<HTMLInputElement>(null)

  // Revoke all object URLs when the panel unmounts to avoid memory leaks
  useEffect(() => {
    return () => {
      imagePreviews.forEach(p => URL.revokeObjectURL(p.url))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? [])
    const incoming = files.map(f => ({ name: f.name, url: URL.createObjectURL(f) }))
    setImagePreviews(prev => {
      const combined = [...prev, ...incoming].slice(0, 5)
      // Revoke any extras that got cut off
      incoming.slice(5 - prev.length).forEach(p => URL.revokeObjectURL(p.url))
      return combined
    })
  }

  function removePreview(index: number) {
    setImagePreviews(prev => {
      URL.revokeObjectURL(prev[index].url)
      return prev.filter((_, i) => i !== index)
    })
  }

  function openFilePicker() {
    fileRef.current?.click()
  }

  const canSubmit =
    exp.status === 'open' ||
    exp.status === 'accepted' ||
    exp.status === 'revision_requested'

  const alreadySubmitted =
    exp.status === 'evidence_submitted' ||
    exp.status === 'revision_requested' ||
    exp.status === 'approved' ||
    exp.status === 'simulated_payout'

  const evidence = exp.evidence

  const trialsToShow = alreadySubmitted && evidence ? evidence.trials : props.trials

  return (
    <div className="space-y-5">
      {/* Outcome framing */}
      <div
        className="rounded-xl p-4 text-sm"
        style={{
          background: 'var(--surface)',
          border: '1px solid var(--pale-blue)',
          color: 'var(--ink-2)',
        }}
      >
        <Info className="w-4 h-4 inline mr-1.5 mb-0.5" style={{ color: 'var(--pale-blue)' }} />
        A result that contradicts the hypothesis or is inconclusive is equally valid.
        Rewards are paid for protocol compliance, not for confirming a claim.
      </div>

      {/* Trial data entry */}
      <Card className="p-5">
        <SpecimenLabel number="EVIDENCE" label="Trial measurements" />
        <p className="text-xs mb-4" style={{ color: 'var(--muted)' }}>
          Unit: <span style={{ color: 'var(--ink-2)' }}>{exp.measurementUnit}</span>
        </p>

        <div className="space-y-3">
          {trialsToShow.map((t, i) => (
            <div key={t.id} className="rounded-xl p-3" style={{ background: 'var(--surface-muted)' }}>
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="mono text-xs font-semibold px-1.5 py-0.5 rounded"
                  style={{
                    background: 'var(--yellow-muted)',
                    color: 'var(--yellow)',
                    border: '1px solid var(--yellow-border)',
                  }}
                >
                  T{i + 1}
                </span>
                {!alreadySubmitted && trialsToShow.length > 1 && (
                  <button
                    type="button"
                    onClick={() => props.onRemoveTrial(t.id)}
                    className="ml-auto p-1 rounded hover:text-[var(--coral)] transition-colors"
                    style={{ color: 'var(--subtle)' }}
                    aria-label="Remove trial"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--muted)' }}>
                    Measurement
                  </label>
                  <input
                    type="number"
                    step="any"
                    className={`${props.inputClass} tabular`}
                    style={props.inputStyle}
                    value={t.value}
                    readOnly={alreadySubmitted}
                    onChange={e => props.onUpdateTrial(t.id, 'value', parseFloat(e.target.value))}
                    aria-label={`Trial ${i + 1} measurement`}
                  />
                  {props.evidenceErrors[`trial-${i}`] && (
                    <p className="text-xs mt-1" style={{ color: 'var(--coral)' }}>
                      {props.evidenceErrors[`trial-${i}`]}
                    </p>
                  )}
                </div>
                <div>
                  <label className="text-xs font-medium mb-1 block" style={{ color: 'var(--muted)' }}>
                    Trial notes
                  </label>
                  <input
                    type="text"
                    className={props.inputClass}
                    style={props.inputStyle}
                    value={t.notes}
                    readOnly={alreadySubmitted}
                    onChange={e => props.onUpdateTrial(t.id, 'notes', e.target.value)}
                    placeholder="Optional notes…"
                    maxLength={200}
                    aria-label={`Trial ${i + 1} notes`}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {!alreadySubmitted && (
          <Button type="button" variant="ghost" size="sm" onClick={props.onAddTrial} className="mt-3">
            <Plus className="w-3.5 h-3.5" /> Add trial
          </Button>
        )}

        {/* Derived stats */}
        {trialsToShow.length > 0 && (
          <div className="mt-4 grid grid-cols-2 gap-3">
            <StatBox
              label="Mean"
              value={props.mean !== null ? props.mean.toFixed(2) : '—'}
              unit={exp.measurementUnit}
            />
            <StatBox
              label="Range"
              value={props.rangeVal !== null ? props.rangeVal.toFixed(2) : '—'}
              unit={exp.measurementUnit}
            />
          </div>
        )}
      </Card>

      {/* Chart */}
      {trialsToShow.length > 0 && <TrialChart trials={trialsToShow} unit={exp.measurementUnit} />}

      {/* Observations vs interpretation */}
      <Card className="p-5">
        <SectionLabel>Reported observations</SectionLabel>
        <p className="text-xs mb-2" style={{ color: 'var(--muted)' }}>
          Describe what you measured and saw — keep this factual, not interpretive.
        </p>
        <textarea
          className={`${props.inputClass} resize-none`}
          style={{ ...props.inputStyle, minHeight: 80 }}
          value={alreadySubmitted ? (evidence?.observations ?? '') : props.observations}
          readOnly={alreadySubmitted}
          onChange={e => props.onObservations(e.target.value)}
          placeholder="e.g. At t=6h the silicone cup was 1.2°C above start; the paper cup was 8.4°C above start."
          maxLength={800}
          aria-label="Observations"
        />
        {props.evidenceErrors.observations && (
          <p className="text-xs mt-1" style={{ color: 'var(--coral)' }}>
            {props.evidenceErrors.observations}
          </p>
        )}

        <div className="mt-4">
          <SectionLabel>Participant interpretation (optional)</SectionLabel>
          <p className="text-xs mb-2" style={{ color: 'var(--muted)' }}>
            Your interpretation of what the data might mean — separate from raw observations.
          </p>
          <textarea
            className={`${props.inputClass} resize-none`}
            style={{ ...props.inputStyle, minHeight: 64 }}
            value={alreadySubmitted ? (evidence?.interpretation ?? '') : props.interpretation}
            readOnly={alreadySubmitted}
            onChange={e => props.onInterpretation(e.target.value)}
            placeholder="e.g. The silicone cup appears to insulate better for short periods but the difference narrows at 6h."
            maxLength={600}
          />
        </div>

        <div className="mt-4">
          <SectionLabel>Outcome relative to hypothesis</SectionLabel>
          <div className="flex gap-2 flex-wrap">
            {(['supports', 'contradicts', 'inconclusive'] as OutcomeType[]).map(o => (
              <button
                key={o}
                onClick={() => !alreadySubmitted && props.onOutcomeType(o)}
                disabled={alreadySubmitted}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                  (alreadySubmitted ? evidence?.outcomeType : props.outcomeType) === o
                    ? o === 'supports'
                      ? 'bg-[var(--success)] text-[#0b1629] border-[var(--success)]'
                      : o === 'contradicts'
                      ? 'bg-[var(--coral)] text-white border-[var(--coral)]'
                      : 'bg-[var(--yellow-muted)] text-[var(--yellow)] border-[var(--yellow-border)]'
                    : 'text-[var(--muted)] border-[var(--border)] hover:border-[var(--border-strong)] disabled:cursor-default'
                }`}
              >
                {o === 'supports' ? 'Supports hypothesis' : o === 'contradicts' ? 'Contradicts hypothesis' : 'Inconclusive'}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* Image upload */}
      <Card className="p-5">
        <SectionLabel>Image evidence (preview only)</SectionLabel>
        <div
          className="rounded-xl p-4 text-sm text-center cursor-pointer border-dashed border-2 transition-colors hover:border-[var(--border-strong)]"
          style={{
            borderColor: 'var(--border)',
            color: 'var(--muted)',
          }}
          onClick={openFilePicker}
          role="button"
          tabIndex={0}
          onKeyDown={e => e.key === 'Enter' && openFilePicker()}
          aria-label="Upload images"
        >
          <Upload className="w-5 h-5 mx-auto mb-2" />
          <span>Click to attach images (up to 5)</span>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFileChange}
          />
        </div>
        {imagePreviews.length > 0 && (
          <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2">
            {imagePreviews.map((preview, i) => (
              <div
                key={preview.url}
                className="relative rounded-lg overflow-hidden group"
                style={{ border: '1px solid var(--border)', background: 'var(--surface-muted)' }}
              >
                <img
                  src={preview.url}
                  alt={preview.name}
                  className="w-full h-24 object-cover"
                />
                <div
                  className="absolute inset-0 flex flex-col justify-end p-1.5"
                  style={{ background: 'linear-gradient(transparent 40%, rgba(0,0,0,0.6))' }}
                >
                  <p
                    className="text-xs truncate"
                    style={{ color: '#fff', textShadow: '0 1px 2px rgba(0,0,0,0.8)' }}
                    title={preview.name}
                  >
                    {preview.name}
                  </p>
                </div>
                <button
                  onClick={() => removePreview(i)}
                  className="absolute top-1 right-1 w-5 h-5 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity"
                  style={{ background: 'rgba(0,0,0,0.6)' }}
                  aria-label={`Remove ${preview.name}`}
                  title="Remove"
                >
                  <XCircle className="w-3.5 h-3.5 text-white" />
                </button>
              </div>
            ))}
          </div>
        )}
        <p className="text-xs mt-2" style={{ color: 'var(--subtle)' }}>
          Thumbnails are in-memory object URLs and will not survive a page reload. No image data is stored or uploaded.
        </p>
      </Card>

      {/* Submit / revise */}
      {canSubmit && !props.submitDone && (
        <Button variant="yellow" size="lg" className="w-full" onClick={props.onSubmit}>
          Simulate evidence submission
        </Button>
      )}
      {props.submitDone && (
        <div
          className="rounded-xl p-4 flex items-center justify-between gap-4"
          style={{ background: 'rgba(92,201,139,0.1)', border: '1px solid var(--success)', color: 'var(--success)' }}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span className="text-sm font-medium">Evidence submitted (simulated)</span>
          </div>
          <Button variant="ghost" size="sm" onClick={props.onRevise}>Revise</Button>
        </div>
      )}
      {exp.status === 'revision_requested' && exp.review && (
        <div
          className="rounded-xl p-4"
          style={{ background: 'var(--coral-muted)', border: '1px solid var(--coral)', color: 'var(--coral)' }}
        >
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4" />
            <span className="text-sm font-semibold">Revision requested</span>
          </div>
          <p className="text-xs">{exp.review.reason}</p>
        </div>
      )}
    </div>
  )
}

// ── Reviewer Panel ─────────────────────────────────────────────────────────
function ReviewerPanel(props: {
  experiment: Experiment
  mean: number | null
  rangeVal: number | null
  decision: 'approved' | 'revision_requested'
  reason: string
  error: string
  done: boolean
  inputClass: string
  inputStyle: React.CSSProperties
  onDecision: (d: 'approved' | 'revision_requested') => void
  onReason: (r: string) => void
  onSubmit: () => void
  onPayout: () => void
  onViewReceipt: () => void
}) {
  const { experiment: exp } = props
  const evidence = exp.evidence
  const canReview = exp.status === 'evidence_submitted'
  const isApproved = exp.status === 'approved'
  const isPaid = exp.status === 'simulated_payout'

  if (!evidence && !canReview) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-4 h-4" style={{ color: 'var(--muted)' }} />
          <p className="text-sm" style={{ color: 'var(--muted)' }}>
            Awaiting evidence submission from tester.
          </p>
        </div>
        <p className="text-xs" style={{ color: 'var(--subtle)' }}>
          Current status: <StatusBadge status={exp.status} size="sm" />
        </p>
      </Card>
    )
  }

  return (
    <div className="space-y-5">
      {evidence && (
        <>
          <Card className="p-5">
            <SectionLabel>Submitted evidence summary</SectionLabel>
            <div className="space-y-3">
              <div>
                <p className="text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>Observations</p>
                <p className="text-sm" style={{ color: 'var(--ink-2)' }}>{evidence.observations}</p>
              </div>
              {evidence.interpretation && (
                <div>
                  <p className="text-xs font-medium mb-1" style={{ color: 'var(--muted)' }}>Tester interpretation</p>
                  <p className="text-sm italic" style={{ color: 'var(--muted)' }}>{evidence.interpretation}</p>
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <StatBox label="Mean" value={props.mean !== null ? props.mean.toFixed(2) : '—'} unit={exp.measurementUnit} />
                <StatBox label="Range" value={props.rangeVal !== null ? props.rangeVal.toFixed(2) : '—'} unit={exp.measurementUnit} />
              </div>
            </div>
          </Card>

          {evidence.trials.length > 0 && <TrialChart trials={evidence.trials} unit={exp.measurementUnit} />}

          {/* Data table */}
          <Card className="p-5">
            <SectionLabel>Trial data table</SectionLabel>
            <div className="overflow-x-auto">
              <table className="w-full text-sm" role="table" aria-label="Trial data">
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    {['Trial', 'Value', 'Notes'].map(h => (
                      <th key={h} className="text-left text-xs font-semibold pb-2 pr-4" style={{ color: 'var(--muted)' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {evidence.trials.map((t, i) => (
                    <tr key={t.id} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td className="py-2 pr-4 mono text-xs" style={{ color: 'var(--yellow)' }}>T{i + 1}</td>
                      <td className="py-2 pr-4 tabular text-sm" style={{ color: 'var(--ink)' }}>{t.value}</td>
                      <td className="py-2 text-xs" style={{ color: 'var(--muted)' }}>{t.notes || '—'}</td>
                    </tr>
                  ))}
                  {props.mean !== null && (
                    <tr>
                      <td className="pt-2 pr-4 text-xs font-semibold" style={{ color: 'var(--pale-blue)' }}>Mean</td>
                      <td className="pt-2 pr-4 tabular font-semibold" style={{ color: 'var(--pale-blue)' }}>{props.mean.toFixed(2)}</td>
                      <td />
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}

      {/* Review form */}
      {canReview && !props.done && (
        <Card className="p-5">
          <SectionLabel>Review decision</SectionLabel>
          <p className="text-xs mb-4" style={{ color: 'var(--muted)' }}>
            You are checking protocol compliance, not judging whether the result is true in all situations.
          </p>
          <div className="flex gap-2 mb-4">
            {(['approved', 'revision_requested'] as const).map(d => (
              <button
                key={d}
                onClick={() => props.onDecision(d)}
                className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
                  props.decision === d
                    ? d === 'approved'
                      ? 'bg-[var(--success)] text-[#0b1629] border-[var(--success)]'
                      : 'bg-[var(--coral-muted)] text-[var(--coral)] border-[var(--coral)]'
                    : 'text-[var(--muted)] border-[var(--border)] hover:border-[var(--border-strong)]'
                }`}
              >
                {d === 'approved' ? 'Approve evidence' : 'Request revision'}
              </button>
            ))}
          </div>
          <label className="text-xs font-medium block mb-1.5" style={{ color: 'var(--ink-2)' }}>
            Reason <span style={{ color: 'var(--coral)' }}>*</span>
          </label>
          <textarea
            className={`${props.inputClass} resize-none`}
            style={{ ...props.inputStyle, minHeight: 72 }}
            value={props.reason}
            onChange={e => props.onReason(e.target.value)}
            placeholder={props.decision === 'approved' ? 'e.g. Protocol followed correctly. Evidence complete.' : 'e.g. Trial 3 measurement missing. Please re-run.'}
            maxLength={400}
          />
          {props.error && (
            <p className="text-xs mt-1" style={{ color: 'var(--coral)' }}>{props.error}</p>
          )}
          <Button variant="yellow" size="md" className="mt-4 w-full" onClick={props.onSubmit}>
            Simulate review submission
          </Button>
        </Card>
      )}

      {props.done && (
        <div
          className="rounded-xl p-4 flex items-center gap-3"
          style={{ background: 'rgba(92,201,139,0.1)', border: '1px solid var(--success)', color: 'var(--success)' }}
        >
          <CheckCircle2 className="w-5 h-5" />
          <span className="text-sm font-medium">Review submitted (simulated)</span>
        </div>
      )}

      {isApproved && (
        <div className="space-y-3">
          <div
            className="rounded-xl p-4"
            style={{ background: 'rgba(92,201,139,0.08)', border: '1px solid var(--success)' }}
          >
            <p className="text-sm font-semibold mb-1" style={{ color: 'var(--success)' }}>Evidence approved</p>
            {exp.review && (
              <p className="text-xs" style={{ color: 'var(--muted)' }}>{exp.review.reason}</p>
            )}
          </div>
          <Button variant="yellow" size="md" className="w-full" onClick={props.onPayout}>
            Simulate USDC payout to tester
          </Button>
        </div>
      )}

      {isPaid && (
        <div
          className="rounded-xl p-5 text-center"
          style={{ background: 'var(--yellow-muted)', border: '1px solid var(--yellow-border)' }}
        >
          <p className="display text-lg font-bold mb-1" style={{ color: 'var(--yellow)' }}>
            Payout simulated
          </p>
          <p className="text-xs mb-3" style={{ color: 'var(--muted)' }}>
            <DemoUsdcTag amount={exp.rewardUsdc} /> would be released to the tester on Arc Testnet.
            No real funds have moved.
          </p>
          <Button variant="secondary" size="sm" onClick={props.onViewReceipt}>
            <Download className="w-3.5 h-3.5" /> View evidence receipt
          </Button>
        </div>
      )}
    </div>
  )
}

// ── Proposer Panel ─────────────────────────────────────────────────────────
function ProposerPanel({
  experiment: exp,
  mean,
  rangeVal,
  onViewReceipt,
}: {
  experiment: Experiment
  mean: number | null
  rangeVal: number | null
  onViewReceipt: () => void
}) {
  return (
    <div className="space-y-5">
      <Card className="p-5">
        <SectionLabel>Experiment overview</SectionLabel>
        <div className="space-y-2">
          <Row label="Hypothesis">{exp.hypothesis}</Row>
          <Row label="Status"><StatusBadge status={exp.status} size="sm" /></Row>
          <Row label="Tester">{exp.testerName ?? 'Not yet accepted'}</Row>
          <Row label="Reviewer">{exp.reviewerName ?? 'Not yet assigned'}</Row>
          <Row label="Deadline">{exp.submissionDeadline}</Row>
          <Row label="Reward"><DemoUsdcTag amount={exp.rewardUsdc} /></Row>
        </div>
      </Card>
      {exp.evidence && (
        <Card className="p-5">
          <SectionLabel>Evidence received</SectionLabel>
          <p className="text-sm mb-3" style={{ color: 'var(--ink-2)' }}>{exp.evidence.observations}</p>
          <div className="grid grid-cols-2 gap-3">
            <StatBox label="Mean" value={mean !== null ? mean.toFixed(2) : '—'} unit={exp.measurementUnit} />
            <StatBox label="Range" value={rangeVal !== null ? rangeVal.toFixed(2) : '—'} unit={exp.measurementUnit} />
          </div>
        </Card>
      )}
      {(exp.status === 'approved' || exp.status === 'simulated_payout') && (
        <Button variant="secondary" size="md" className="w-full" onClick={onViewReceipt}>
          <Download className="w-4 h-4" /> View evidence receipt
        </Button>
      )}
    </div>
  )
}

// ── Status Timeline ────────────────────────────────────────────────────────
function StatusTimeline({ experiment: exp }: { experiment: Experiment }) {
  const ORDERED_STATUSES = [
    'open', 'accepted', 'evidence_submitted', 'approved', 'simulated_payout',
  ]

  const currentIdx = ORDERED_STATUSES.indexOf(exp.status)
  const isTerminal = ['overdue', 'cancelled', 'disputed'].includes(exp.status)

  const STATUS_DESCS: Record<string, string> = {
    open: 'Awaiting a tester',
    accepted: 'Tester is running trials',
    evidence_submitted: 'Evidence under review',
    revision_requested: 'Revision requested from tester',
    approved: 'Evidence approved; awaiting payout',
    simulated_payout: 'Reward paid (simulated)',
    overdue: 'Submission deadline passed',
    cancelled: 'Experiment cancelled',
    disputed: 'Under dispute resolution',
  }

  return (
    <Card className="p-5">
      <SectionLabel>Status timeline</SectionLabel>

      {isTerminal ? (
        <div
          className="rounded-xl p-3 text-sm"
          style={{ background: 'var(--coral-muted)', border: '1px solid var(--coral)', color: 'var(--coral)' }}
        >
          <div className="flex items-center gap-2 mb-1">
            <XCircle className="w-4 h-4" />
            <span className="font-semibold">{STATUS_LABELS[exp.status]}</span>
          </div>
          <p className="text-xs">{STATUS_DESCS[exp.status]}</p>
          {exp.status === 'overdue' && (
            <p className="text-xs mt-1" style={{ color: 'var(--ink-2)' }}>
              The submission deadline has passed with no evidence submitted. The proposer may cancel or raise a dispute.
            </p>
          )}
          {exp.status === 'cancelled' && (
            <p className="text-xs mt-1" style={{ color: 'var(--ink-2)' }}>
              This experiment has been cancelled. In a funded version, the escrowed reward would be returned to the proposer.
            </p>
          )}
          {exp.status === 'disputed' && (
            <p className="text-xs mt-1" style={{ color: 'var(--ink-2)' }}>
              An independent resolver reviews the dispute. The outcome will be either approved evidence or a refund.
            </p>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {ORDERED_STATUSES.map((s, i) => {
            const done = i < currentIdx || (s === 'revision_requested' && exp.status === 'revision_requested')
            const active = s === exp.status || (exp.status === 'revision_requested' && s === 'evidence_submitted')
            return (
              <div key={s} className="flex items-start gap-3">
                <div
                  className={`w-5 h-5 rounded-full border-2 shrink-0 mt-0.5 flex items-center justify-center transition-colors ${
                    active
                      ? 'border-[var(--yellow)] bg-[var(--yellow-muted)]'
                      : done
                      ? 'border-[var(--success)] bg-[rgba(92,201,139,0.1)]'
                      : 'border-[var(--border)] bg-transparent'
                  }`}
                >
                  {done && !active && (
                    <svg className="w-2.5 h-2.5" viewBox="0 0 10 10" fill="none">
                      <path d="M2 5l2.5 2.5 4-4" stroke="var(--success)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                  {active && <div className="w-1.5 h-1.5 rounded-full bg-[var(--yellow)]" />}
                </div>
                <div>
                  <p className="text-xs font-medium" style={{ color: active ? 'var(--yellow)' : done ? 'var(--success)' : 'var(--subtle)' }}>
                    {STATUS_LABELS[s as keyof typeof STATUS_LABELS]}
                  </p>
                  {active && (
                    <p className="text-xs" style={{ color: 'var(--muted)' }}>
                      {STATUS_DESCS[exp.status]}
                    </p>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}

// ── Trial chart ────────────────────────────────────────────────────────────
function TrialChart({ trials, unit }: { trials: Trial[]; unit: string }) {
  const values = trials.map(t => Number(t.value)).filter(v => !isNaN(v))
  if (values.length === 0) return null
  const min = Math.min(...values)
  const max = Math.max(...values)
  const spread = max - min || 1
  const BAR_HEIGHT = 120

  return (
    <Card className="p-5">
      <SectionLabel>Comparison chart</SectionLabel>
      <div
        className="relative flex items-end gap-3 overflow-x-auto pb-2"
        style={{ minHeight: BAR_HEIGHT + 48 }}
        role="img"
        aria-label={`Bar chart of ${trials.length} trial measurements`}
      >
        {trials.map((t, i) => {
          const v = Number(t.value)
          const barH = isNaN(v) ? 0 : Math.round(((v - min) / spread) * BAR_HEIGHT * 0.8) + BAR_HEIGHT * 0.2
          return (
            <div key={t.id} className="flex flex-col items-center gap-1 min-w-[44px]">
              <span
                className="tabular text-xs font-semibold mb-1"
                style={{ color: 'var(--yellow)' }}
              >
                {isNaN(v) ? '—' : v}
              </span>
              <div
                className="rounded-t-md w-8 transition-all"
                style={{
                  height: barH,
                  background: 'linear-gradient(180deg, var(--yellow) 0%, rgba(245,217,61,0.4) 100%)',
                  minHeight: 4,
                }}
              />
              <span
                className="mono text-xs"
                style={{ color: 'var(--muted)' }}
              >
                T{i + 1}
              </span>
            </div>
          )
        })}
        <div
          className="absolute top-0 left-0 w-full flex flex-col justify-between"
          style={{ height: BAR_HEIGHT }}
          aria-hidden="true"
        >
          {[max, (max + min) / 2, min].map((v, i) => (
            <div key={i} className="flex items-center gap-1">
              <span className="tabular text-xs" style={{ color: 'var(--subtle)' }}>
                {v.toFixed(1)}
              </span>
              <div className="flex-1 border-t border-dashed" style={{ borderColor: 'var(--border)' }} />
            </div>
          ))}
        </div>
      </div>
      <p className="text-xs mt-1" style={{ color: 'var(--subtle)' }}>Values in {unit}</p>
    </Card>
  )
}

// ── Helpers ────────────────────────────────────────────────────────────────
function StatBox({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="rounded-xl p-3 text-center" style={{ background: 'var(--surface-muted)' }}>
      <p className="text-xs mb-1" style={{ color: 'var(--muted)' }}>{label}</p>
      <p className="tabular text-lg font-bold display" style={{ color: 'var(--yellow)', letterSpacing: '-0.02em' }}>{value}</p>
      <p className="text-xs" style={{ color: 'var(--subtle)' }}>{unit}</p>
    </div>
  )
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 py-1">
      <span className="text-xs font-medium w-28 shrink-0 mt-0.5" style={{ color: 'var(--muted)' }}>{label}</span>
      <span className="text-sm flex-1" style={{ color: 'var(--ink-2)' }}>{children}</span>
    </div>
  )
}
