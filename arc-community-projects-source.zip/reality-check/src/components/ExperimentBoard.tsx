import { useState, useMemo } from 'react'
import { Search, Plus, FlaskConical, ArrowRight, Clock, Users } from 'lucide-react'
import type { Experiment, Category, ExperimentStatus } from '../state/types'
import { CATEGORY_LABELS, STATUS_LABELS } from '../state/types'
import { StatusBadge, CategoryBadge } from './ui/Badge'
import { Button } from './ui/Button'
import { Card } from './ui/Card'
import { DemoUsdcTag } from './ui/DemoTag'
import { GraphPaperIcon } from './ui/SVGIcons'

interface BoardProps {
  experiments: Experiment[]
  onSelect: (id: string) => void
  onCreate: () => void
}

const ALL_CATEGORIES: Category[] = [
  'materials', 'packaging', 'beverages', 'stationery', 'household', 'environment', 'food', 'other'
]

const FILTER_STATUSES: ExperimentStatus[] = [
  'open', 'accepted', 'evidence_submitted', 'approved', 'simulated_payout'
]

export function ExperimentBoard({ experiments, onSelect, onCreate }: BoardProps) {
  const [query, setQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all')
  const [selectedStatus, setSelectedStatus] = useState<ExperimentStatus | 'all'>('all')

  const visible = useMemo(() => {
    return experiments
      .filter(e => e.status !== 'draft')
      .filter(e => {
        if (query) {
          const q = query.toLowerCase()
          return (
            e.title.toLowerCase().includes(q) ||
            e.question.toLowerCase().includes(q)
          )
        }
        return true
      })
      .filter(e => selectedCategory === 'all' || e.category === selectedCategory)
      .filter(e => selectedStatus === 'all' || e.status === selectedStatus)
  }, [experiments, query, selectedCategory, selectedStatus])

  const featured = experiments.find(e => e.id === 'exp-001')

  return (
    <div className="min-h-dvh flex flex-col">
      {/* Hero */}
      <section
        className="relative overflow-hidden px-4 pt-16 pb-12 md:pt-24 md:pb-20"
        style={{ borderBottom: '1px solid var(--border)' }}
      >
        {/* background decoration */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse 60% 40% at 50% 0%, rgba(245,217,61,0.06) 0%, transparent 70%)',
          }}
        />
        <div className="relative max-w-3xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <GraphPaperIcon className="w-10 h-10" />
            <div>
              <h1
                className="display text-3xl md:text-5xl font-bold text-balance"
                style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
              >
                Reality Check
              </h1>
            </div>
          </div>
          <p
            className="text-sm font-semibold tracking-widest uppercase mb-6"
            style={{ color: 'var(--yellow)', letterSpacing: '0.1em' }}
          >
            Fund the test, not the answer.
          </p>
          <h2
            className="display text-xl md:text-2xl font-semibold text-balance mb-4"
            style={{ color: 'var(--ink-2)' }}
          >
            What would you like to put to the test?
          </h2>
          <p className="text-sm max-w-xl mx-auto text-pretty mb-8" style={{ color: 'var(--muted)' }}>
            A community workbench for small, safe, repeatable everyday experiments.
            Earn a fixed reward for following the protocol and submitting usable evidence
            — regardless of the result.
          </p>

          {/* Search */}
          <div className="relative max-w-lg mx-auto">
            <Search
              className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4"
              style={{ color: 'var(--muted)' }}
            />
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search experiments…"
              className="w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-colors"
              style={{
                background: 'var(--surface-strong)',
                border: '1px solid var(--border)',
                color: 'var(--ink)',
              }}
              aria-label="Search experiments"
            />
          </div>

          {/* Create CTA */}
          <div className="mt-5">
            <Button variant="yellow" size="lg" onClick={onCreate}>
              <Plus className="w-4 h-4" />
              Create experiment
            </Button>
          </div>
        </div>
      </section>

      {/* Filters */}
      <div
        className="sticky top-0 z-10 px-4 py-3 flex gap-2 flex-wrap items-center"
        style={{
          background: 'var(--bg)',
          borderBottom: '1px solid var(--border)',
          backdropFilter: 'blur(12px)',
        }}
      >
        <span className="text-xs font-medium mr-1" style={{ color: 'var(--muted)' }}>Category:</span>
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${selectedCategory === 'all' ? 'text-[#0b1629] bg-[var(--pale-blue)]' : 'text-[var(--muted)] hover:text-[var(--ink)]'}`}
        >
          All
        </button>
        {ALL_CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${selectedCategory === cat ? 'text-[#0b1629] bg-[var(--pale-blue)]' : 'text-[var(--muted)] hover:text-[var(--ink)]'}`}
          >
            {CATEGORY_LABELS[cat]}
          </button>
        ))}

        <span className="text-xs font-medium ml-2" style={{ color: 'var(--muted)' }}>Status:</span>
        <button
          onClick={() => setSelectedStatus('all')}
          className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${selectedStatus === 'all' ? 'text-[#0b1629] bg-[var(--pale-blue)]' : 'text-[var(--muted)] hover:text-[var(--ink)]'}`}
        >
          All
        </button>
        {FILTER_STATUSES.map(s => (
          <button
            key={s}
            onClick={() => setSelectedStatus(s)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${selectedStatus === s ? 'text-[#0b1629] bg-[var(--pale-blue)]' : 'text-[var(--muted)] hover:text-[var(--ink)]'}`}
          >
            {STATUS_LABELS[s]}
          </button>
        ))}
      </div>

      {/* Content */}
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">

        {/* Featured */}
        {featured && !query && selectedCategory === 'all' && selectedStatus === 'all' && (
          <div className="mb-8">
            <p
              className="text-xs font-semibold tracking-widest uppercase mb-3"
              style={{ color: 'var(--yellow)', letterSpacing: '0.09em' }}
            >
              Featured experiment
            </p>
            <FeaturedCard experiment={featured} onSelect={onSelect} />
          </div>
        )}

        {/* Grid */}
        <div className="mb-3 flex items-center justify-between">
          <p className="text-xs font-medium" style={{ color: 'var(--muted)' }}>
            {visible.length} experiment{visible.length !== 1 ? 's' : ''} shown
          </p>
        </div>

        {visible.length === 0 ? (
          <div className="text-center py-16">
            <FlaskConical className="w-8 h-8 mx-auto mb-3" style={{ color: 'var(--subtle)' }} />
            <p className="text-sm" style={{ color: 'var(--muted)' }}>No experiments match your filters.</p>
            <button
              className="mt-2 text-sm underline"
              style={{ color: 'var(--pale-blue)' }}
              onClick={() => { setQuery(''); setSelectedCategory('all'); setSelectedStatus('all') }}
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {visible.map((exp, i) => (
              <ExperimentCard
                key={exp.id}
                experiment={exp}
                index={i + 1}
                onSelect={onSelect}
              />
            ))}
          </div>
        )}

        {/* Proposed future section */}
        <div
          className="mt-12 rounded-2xl p-6 border"
          style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
        >
          <p
            className="text-xs font-semibold tracking-widest uppercase mb-3"
            style={{ color: 'var(--pale-blue)', letterSpacing: '0.09em' }}
          >
            Technical roadmap
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { label: 'Arc Testnet escrow', desc: 'Fixed reward locked on-chain at proposal creation' },
              { label: 'USDC payout on approval', desc: 'Smart contract releases reward to tester\'s wallet' },
              { label: 'On-chain evidence hash', desc: 'Receipt hash published to Arc Testnet for provenance' },
            ].map(item => (
              <div key={item.label} className="rounded-xl p-4" style={{ background: 'var(--surface-muted)' }}>
                <p className="text-xs font-semibold mb-1" style={{ color: 'var(--pale-blue)' }}>
                  Planned: {item.label}
                </p>
                <p className="text-xs" style={{ color: 'var(--muted)' }}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}

function FeaturedCard({ experiment: e, onSelect }: { experiment: Experiment; onSelect: (id: string) => void }) {
  return (
    <Card
      elevated
      className="p-6 cursor-pointer hover:border-[var(--yellow-border)] transition-colors group"
      onClick={() => onSelect(e.id)}
      style={{ borderColor: 'var(--yellow-border)', background: 'var(--yellow-muted)' }}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span
              className="mono text-xs font-medium px-1.5 py-0.5 rounded"
              style={{
                background: 'rgba(245,217,61,0.3)',
                color: 'var(--yellow)',
                border: '1px solid var(--yellow-border)',
              }}
            >
              EXP-001
            </span>
            <CategoryBadge category={e.category} />
            <StatusBadge status={e.status} size="sm" />
          </div>
          <h3
            className="display text-lg md:text-xl font-semibold mb-2 text-balance"
            style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
          >
            {e.title}
          </h3>
          <p className="text-sm text-pretty mb-4" style={{ color: 'var(--ink-2)', maxWidth: '60ch' }}>
            {e.question}
          </p>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" style={{ color: 'var(--muted)' }} />
              <span className="text-xs" style={{ color: 'var(--muted)' }}>
                {e.repeatCount} trials × 6 hours
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" style={{ color: 'var(--muted)' }} />
              <span className="text-xs" style={{ color: 'var(--muted)' }}>
                Proposed by {e.proposerName}
              </span>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-3 shrink-0">
          <DemoUsdcTag amount={e.rewardUsdc} />
          <Button variant="yellow" size="sm" className="group-hover:opacity-100">
            Open workbench <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </Card>
  )
}

function ExperimentCard({
  experiment: e,
  index,
  onSelect,
}: {
  experiment: Experiment
  index: number
  onSelect: (id: string) => void
}) {
  return (
    <Card
      className="p-5 cursor-pointer hover:border-[var(--border-strong)] transition-colors group"
      onClick={() => onSelect(e.id)}
    >
      <div className="flex items-start gap-3 mb-3">
        <span
          className="mono text-xs font-medium px-1.5 py-0.5 rounded shrink-0"
          style={{
            background: 'var(--surface-muted)',
            color: 'var(--muted)',
            border: '1px solid var(--border)',
          }}
        >
          {String(index).padStart(3, '0')}
        </span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap mb-1">
            <CategoryBadge category={e.category} />
            <StatusBadge status={e.status} size="sm" />
          </div>
          <h3
            className="display text-base font-semibold text-balance leading-snug"
            style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
          >
            {e.title}
          </h3>
        </div>
      </div>

      <p className="text-sm text-pretty mb-4 line-clamp-2" style={{ color: 'var(--muted)', maxWidth: '55ch' }}>
        {e.question}
      </p>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" style={{ color: 'var(--subtle)' }} />
            <span className="text-xs tabular" style={{ color: 'var(--subtle)' }}>
              {e.repeatCount} trials
            </span>
          </div>
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>
            Deadline {e.submissionDeadline}
          </span>
        </div>
        <DemoUsdcTag amount={e.rewardUsdc} />
      </div>
    </Card>
  )
}
