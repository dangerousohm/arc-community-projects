import { useState, useId, type FormEvent } from 'react'
import {
  Plus, Trash2, ChevronLeft, ChevronRight, AlertCircle, Info,
} from 'lucide-react'
import type { Experiment, Category, ProtocolStep, EvidenceChecklistItem } from '../state/types'
import { CATEGORY_LABELS } from '../state/types'
import { Button } from './ui/Button'
import { Card, SectionLabel } from './ui/Card'
import { DemoUsdcTag } from './ui/DemoTag'
import { StatusBadge } from './ui/Badge'

type BuilderStep = 'form' | 'review' | 'published'

interface ProtocolBuilderProps {
  existingDraft?: Experiment
  onPublish: (exp: Experiment) => void
  onCancel: () => void
}

function uid(): string {
  return Math.random().toString(36).slice(2, 10)
}

function todayPlus(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}

const HAZARD_KEYWORDS = [
  'electric', 'chemical', 'acid', 'bleach', 'fire', 'flame', 'explosive', 'combustion',
  'medication', 'drug', 'pharmaceutical', 'blood', 'virus', 'bacteria', 'radioactive',
  'invest', 'stock', 'trade', 'crypto', 'finance', 'heat above 100', 'voltage',
]

function detectHazard(text: string): string | null {
  const lower = text.toLowerCase()
  for (const kw of HAZARD_KEYWORDS) {
    if (lower.includes(kw)) return kw
  }
  return null
}

interface FormErrors {
  title?: string
  question?: string
  category?: string
  hypothesis?: string
  independentVariable?: string
  measurementUnit?: string
  repeatCount?: string
  steps?: string
  evidenceChecklist?: string
  rewardUsdc?: string
  submissionDeadline?: string
  reviewWindowDays?: string
  hazard?: string
}

export function ProtocolBuilder({ existingDraft, onPublish, onCancel }: ProtocolBuilderProps) {
  const formId = useId()
  // Stable creation timestamp: captured once at mount, never updated on re-render
  const [createdAt] = useState<string>(() => existingDraft?.createdAt ?? new Date().toISOString())
  const [builderStep, setBuilderStep] = useState<BuilderStep>('form')

  // Form state
  const [title, setTitle] = useState(existingDraft?.title ?? '')
  const [question, setQuestion] = useState(existingDraft?.question ?? '')
  const [category, setCategory] = useState<Category | ''>(existingDraft?.category ?? '')
  const [hypothesis, setHypothesis] = useState(existingDraft?.hypothesis ?? '')
  const [independentVariable, setIndependentVariable] = useState(existingDraft?.independentVariable ?? '')
  const [measurementUnit, setMeasurementUnit] = useState(existingDraft?.measurementUnit ?? '')
  const [repeatCount, setRepeatCount] = useState<number>(existingDraft?.repeatCount ?? 3)
  const [steps, setSteps] = useState<ProtocolStep[]>(
    existingDraft?.steps ?? [{ id: uid(), instruction: '' }]
  )
  const [checklist, setChecklist] = useState<EvidenceChecklistItem[]>(
    existingDraft?.evidenceChecklist ?? [{ id: uid(), requirement: '' }]
  )
  const [rewardUsdc, setRewardUsdc] = useState<number>(existingDraft?.rewardUsdc ?? 10)
  const [submissionDeadline, setSubmissionDeadline] = useState(
    existingDraft?.submissionDeadline ?? todayPlus(14)
  )
  const [reviewWindowDays, setReviewWindowDays] = useState<number>(existingDraft?.reviewWindowDays ?? 3)
  const [errors, setErrors] = useState<FormErrors>({})
  const [publishedExp, setPublishedExp] = useState<Experiment | null>(null)

  function validate(): FormErrors {
    const errs: FormErrors = {}
    if (!title.trim()) errs.title = 'Title is required.'
    if (!question.trim()) errs.question = 'Question is required.'
    if (!category) errs.category = 'Please choose a category.'
    if (!hypothesis.trim()) errs.hypothesis = 'Hypothesis is required.'
    if (!independentVariable.trim()) errs.independentVariable = 'Independent variable is required.'
    if (!measurementUnit.trim()) errs.measurementUnit = 'Measurement unit is required.'
    if (repeatCount < 1 || repeatCount > 20) errs.repeatCount = 'Enter a repeat count between 1 and 20.'
    if (steps.filter(s => s.instruction.trim()).length < 2) errs.steps = 'Add at least 2 protocol steps.'
    if (checklist.filter(c => c.requirement.trim()).length < 1) errs.evidenceChecklist = 'Add at least 1 evidence requirement.'
    if (rewardUsdc < 1 || rewardUsdc > 500) errs.rewardUsdc = 'Reward must be between 1 and 500 Demo USDC.'
    if (!submissionDeadline) errs.submissionDeadline = 'Submission deadline is required.'
    else if (submissionDeadline <= new Date().toISOString().slice(0, 10)) {
      errs.submissionDeadline = 'Deadline must be in the future.'
    }
    if (reviewWindowDays < 1 || reviewWindowDays > 14) errs.reviewWindowDays = 'Review window must be 1–14 days.'

    // Hazard check across all text fields
    const allText = [title, question, hypothesis, independentVariable, ...steps.map(s => s.instruction)].join(' ')
    const hazard = detectHazard(allText)
    if (hazard) {
      errs.hazard = `Your protocol may reference a hazardous topic ("${hazard}"). Reality Check only supports safe, everyday, non-hazardous experiments.`
    }
    return errs
  }

  function handleReview(e: FormEvent) {
    e.preventDefault()
    const errs = validate()
    setErrors(errs)
    if (Object.keys(errs).length === 0) setBuilderStep('review')
  }

  function buildExperiment(): Experiment {
    const id = existingDraft?.id ?? `exp-${uid()}`
    return {
      id,
      title: title.trim(),
      question: question.trim(),
      category: category as Category,
      hypothesis: hypothesis.trim(),
      independentVariable: independentVariable.trim(),
      measurementUnit: measurementUnit.trim(),
      repeatCount,
      steps: steps.filter(s => s.instruction.trim()),
      evidenceChecklist: checklist.filter(c => c.requirement.trim()),
      rewardUsdc,
      submissionDeadline,
      reviewWindowDays,
      status: 'open',
      createdAt,
      proposerName: 'You (Demo)',
      isDemoSeed: false,
      protocolVersion: (existingDraft?.protocolVersion ?? 0) + 1,
    }
  }

  function handlePublish() {
    const exp = buildExperiment()
    setPublishedExp(exp)
    onPublish(exp)
    setBuilderStep('published')
  }

  // ── Step management ────────────────────────────────────────────────────────
  function addStep() {
    setSteps(prev => [...prev, { id: uid(), instruction: '' }])
  }
  function updateStep(id: string, instruction: string) {
    setSteps(prev => prev.map(s => (s.id === id ? { ...s, instruction } : s)))
  }
  function removeStep(id: string) {
    if (steps.length > 1) setSteps(prev => prev.filter(s => s.id !== id))
  }
  function addCheck() {
    setChecklist(prev => [...prev, { id: uid(), requirement: '' }])
  }
  function updateCheck(id: string, requirement: string) {
    setChecklist(prev => prev.map(c => (c.id === id ? { ...c, requirement } : c)))
  }
  function removeCheck(id: string) {
    if (checklist.length > 1) setChecklist(prev => prev.filter(c => c.id !== id))
  }

  if (builderStep === 'published' && publishedExp) {
    return <PublishedConfirmation exp={publishedExp} onBoard={onCancel} />
  }

  if (builderStep === 'review') {
    const preview = buildExperiment()
    return (
      <ReviewPage
        exp={preview}
        onBack={() => setBuilderStep('form')}
        onConfirm={handlePublish}
      />
    )
  }

  // ── Form ──────────────────────────────────────────────────────────────────
  const inputClass =
    'w-full px-3 py-2.5 rounded-lg text-sm outline-none transition-colors focus:border-[var(--border-strong)]'
  const inputStyle = {
    background: 'var(--surface-muted)',
    border: '1px solid var(--border)',
    color: 'var(--ink)',
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <button
        className="flex items-center gap-1.5 text-sm mb-6 transition-colors hover:text-[var(--ink)]"
        style={{ color: 'var(--muted)' }}
        onClick={onCancel}
      >
        <ChevronLeft className="w-4 h-4" /> Back to board
      </button>

      <h1
        className="display text-2xl md:text-3xl font-bold mb-1"
        style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
      >
        {existingDraft ? 'Edit protocol' : 'New experiment'}
      </h1>
      <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
        Design a safe, repeatable protocol. Your draft stays in this browser only until you publish it to the demo board.
      </p>

      {/* Info banner */}
      <div
        className="flex items-start gap-3 rounded-xl p-4 mb-6 text-sm"
        style={{
          background: 'var(--pale-blue-muted)',
          border: '1px solid rgba(168,200,232,0.2)',
          color: 'var(--ink-2)',
        }}
      >
        <Info className="w-4 h-4 shrink-0 mt-0.5" style={{ color: 'var(--pale-blue)' }} />
        <span>
          Drafts and published experiments exist only in this browser session. Clearing browser data removes them.
          No wallet connection or real payment is required in this prototype.
        </span>
      </div>

      {errors.hazard && (
        <div
          className="flex items-start gap-3 rounded-xl p-4 mb-6 text-sm"
          style={{
            background: 'var(--coral-muted)',
            border: '1px solid var(--coral)',
            color: 'var(--coral)',
          }}
        >
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errors.hazard}</span>
        </div>
      )}

      <form id={formId} onSubmit={handleReview} noValidate>
        <Card className="p-6 mb-6">
          <SectionLabel>Basic information</SectionLabel>
          <div className="space-y-4">
            <Field label="Experiment title" error={errors.title} required>
              <input
                className={inputClass}
                style={inputStyle}
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Reusable Cup Insulation Test"
                maxLength={120}
                aria-required="true"
              />
            </Field>
            <Field label="Research question" error={errors.question} required>
              <textarea
                className={`${inputClass} resize-none`}
                style={{ ...inputStyle, minHeight: 72 }}
                value={question}
                onChange={e => setQuestion(e.target.value)}
                placeholder="A specific, testable question about an everyday object or situation."
                maxLength={400}
              />
            </Field>
            <Field label="Category" error={errors.category} required>
              <select
                className={inputClass}
                style={{ ...inputStyle, appearance: 'auto' }}
                value={category}
                onChange={e => setCategory(e.target.value as Category)}
              >
                <option value="">Choose a category…</option>
                {(Object.keys(CATEGORY_LABELS) as Category[]).map(c => (
                  <option key={c} value={c}>{CATEGORY_LABELS[c]}</option>
                ))}
              </select>
            </Field>
            <Field label="Hypothesis" error={errors.hypothesis} required>
              <textarea
                className={`${inputClass} resize-none`}
                style={{ ...inputStyle, minHeight: 72 }}
                value={hypothesis}
                onChange={e => setHypothesis(e.target.value)}
                placeholder="A testable prediction. e.g. 'Bubble wrap will reduce damage more than foam peanuts.'"
                maxLength={400}
              />
            </Field>
          </div>
        </Card>

        <Card className="p-6 mb-6">
          <SectionLabel>Measurement design</SectionLabel>
          <div className="space-y-4">
            <Field label="Independent variable" error={errors.independentVariable} required>
              <input
                className={inputClass}
                style={inputStyle}
                value={independentVariable}
                onChange={e => setIndependentVariable(e.target.value)}
                placeholder="e.g. Cup material type"
                maxLength={120}
              />
            </Field>
            <Field label="Measurement unit" error={errors.measurementUnit} required>
              <input
                className={inputClass}
                style={inputStyle}
                value={measurementUnit}
                onChange={e => setMeasurementUnit(e.target.value)}
                placeholder="e.g. °C, kg, minutes, score 0–5"
                maxLength={80}
              />
            </Field>
            <Field label="Number of trials (repeats)" error={errors.repeatCount} required>
              <input
                type="number"
                className={`${inputClass} tabular`}
                style={inputStyle}
                value={repeatCount}
                min={1}
                max={20}
                onChange={e => setRepeatCount(Number(e.target.value))}
              />
            </Field>
          </div>
        </Card>

        <Card className="p-6 mb-6">
          <SectionLabel>Protocol steps</SectionLabel>
          {errors.steps && <ErrorMsg>{errors.steps}</ErrorMsg>}
          <div className="space-y-2.5">
            {steps.map((step, i) => (
              <div key={step.id} className="flex items-start gap-2">
                <span
                  className="mono text-xs font-medium mt-3 shrink-0 w-7 text-right"
                  style={{ color: 'var(--muted)' }}
                >
                  {i + 1}.
                </span>
                <input
                  className={`${inputClass} flex-1`}
                  style={inputStyle}
                  value={step.instruction}
                  onChange={e => updateStep(step.id, e.target.value)}
                  placeholder={`Step ${i + 1} instruction…`}
                  maxLength={300}
                />
                <button
                  type="button"
                  onClick={() => removeStep(step.id)}
                  disabled={steps.length === 1}
                  className="mt-2.5 p-1.5 rounded-lg transition-colors hover:text-[var(--coral)] disabled:opacity-30"
                  style={{ color: 'var(--muted)' }}
                  aria-label="Remove step"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={addStep}
            className="mt-3"
          >
            <Plus className="w-3.5 h-3.5" /> Add step
          </Button>
        </Card>

        <Card className="p-6 mb-6">
          <SectionLabel>Evidence checklist</SectionLabel>
          {errors.evidenceChecklist && <ErrorMsg>{errors.evidenceChecklist}</ErrorMsg>}
          <div className="space-y-2.5">
            {checklist.map((item, i) => (
              <div key={item.id} className="flex items-start gap-2">
                <span
                  className="mono text-xs font-medium mt-3 shrink-0"
                  style={{ color: 'var(--muted)' }}
                >
                  EC{i + 1}
                </span>
                <input
                  className={`${inputClass} flex-1`}
                  style={inputStyle}
                  value={item.requirement}
                  onChange={e => updateCheck(item.id, e.target.value)}
                  placeholder="e.g. Photo of sample before and after"
                  maxLength={200}
                />
                <button
                  type="button"
                  onClick={() => removeCheck(item.id)}
                  disabled={checklist.length === 1}
                  className="mt-2.5 p-1.5 rounded-lg transition-colors hover:text-[var(--coral)] disabled:opacity-30"
                  style={{ color: 'var(--muted)' }}
                  aria-label="Remove checklist item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          <Button type="button" variant="ghost" size="sm" onClick={addCheck} className="mt-3">
            <Plus className="w-3.5 h-3.5" /> Add requirement
          </Button>
        </Card>

        <Card className="p-6 mb-8">
          <SectionLabel>Payment & deadlines</SectionLabel>
          <div className="space-y-4">
            <Field
              label="Fixed reward (Demo USDC)"
              error={errors.rewardUsdc}
              required
              hint="Demo USDC — no real funds. In a future version this will be locked in an Arc Testnet smart contract."
            >
              <input
                type="number"
                className={`${inputClass} tabular`}
                style={inputStyle}
                value={rewardUsdc}
                min={1}
                max={500}
                step={1}
                onChange={e => setRewardUsdc(Number(e.target.value))}
              />
            </Field>
            <div
              className="rounded-lg p-3 text-sm"
              style={{
                background: 'var(--yellow-muted)',
                border: '1px solid var(--yellow-border)',
                color: 'var(--ink-2)',
              }}
            >
              Platform fee: <strong style={{ color: 'var(--yellow)' }}>0% in this prototype.</strong>{' '}
              Future versions may charge a small fee to fund the dispute resolver.
            </div>
            <Field label="Submission deadline" error={errors.submissionDeadline} required>
              <input
                type="date"
                className={`${inputClass} tabular`}
                style={inputStyle}
                value={submissionDeadline}
                min={todayPlus(1)}
                onChange={e => setSubmissionDeadline(e.target.value)}
              />
            </Field>
            <Field
              label="Review window (days after submission)"
              error={errors.reviewWindowDays}
              required
            >
              <input
                type="number"
                className={`${inputClass} tabular`}
                style={inputStyle}
                value={reviewWindowDays}
                min={1}
                max={14}
                onChange={e => setReviewWindowDays(Number(e.target.value))}
              />
            </Field>
          </div>
        </Card>

        <div className="flex gap-3">
          <Button type="button" variant="ghost" size="md" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" variant="yellow" size="md" className="flex-1">
            Review before publishing <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </form>
    </div>
  )
}

// ── Field wrapper ──────────────────────────────────────────────────────────
function Field({
  label,
  error,
  hint,
  required,
  children,
}: {
  label: string
  error?: string
  hint?: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <div>
      <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--ink-2)' }}>
        {label}
        {required && <span className="ml-1" style={{ color: 'var(--coral)' }}>*</span>}
      </label>
      {children}
      {hint && (
        <p className="mt-1 text-xs" style={{ color: 'var(--subtle)' }}>{hint}</p>
      )}
      {error && <p className="mt-1 text-xs font-medium" style={{ color: 'var(--coral)' }}>{error}</p>}
    </div>
  )
}

function ErrorMsg({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-xs font-medium mb-2" style={{ color: 'var(--coral)' }}>{children}</p>
  )
}

// ── Review page ────────────────────────────────────────────────────────────
function ReviewPage({
  exp,
  onBack,
  onConfirm,
}: {
  exp: Experiment
  onBack: () => void
  onConfirm: () => void
}) {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <button
        className="flex items-center gap-1.5 text-sm mb-6 hover:text-[var(--ink)] transition-colors"
        style={{ color: 'var(--muted)' }}
        onClick={onBack}
      >
        <ChevronLeft className="w-4 h-4" /> Back to form
      </button>

      <h1 className="display text-2xl font-bold mb-1" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
        Review your protocol
      </h1>
      <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
        Once published to the demo board, the protocol is frozen for testers.
      </p>

      <Card className="p-6 mb-4">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h2 className="display text-xl font-semibold mb-1" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
              {exp.title}
            </h2>
            <p className="text-sm" style={{ color: 'var(--muted)' }}>{exp.question}</p>
          </div>
          <StatusBadge status="open" />
        </div>
        <Divider />
        <Row label="Category">{CATEGORY_LABELS[exp.category]}</Row>
        <Row label="Hypothesis">{exp.hypothesis}</Row>
        <Row label="Independent variable">{exp.independentVariable}</Row>
        <Row label="Measurement unit">{exp.measurementUnit}</Row>
        <Row label="Trials">{exp.repeatCount}</Row>
        <Divider />
        <p className="text-xs font-semibold mb-2" style={{ color: 'var(--ink-2)' }}>Protocol steps</p>
        <ol className="list-decimal list-inside space-y-1">
          {exp.steps.map(s => (
            <li key={s.id} className="text-sm" style={{ color: 'var(--muted)' }}>{s.instruction}</li>
          ))}
        </ol>
        <Divider />
        <p className="text-xs font-semibold mb-2" style={{ color: 'var(--ink-2)' }}>Evidence checklist</p>
        <ul className="space-y-1">
          {exp.evidenceChecklist.map(c => (
            <li key={c.id} className="text-sm flex items-start gap-2" style={{ color: 'var(--muted)' }}>
              <span className="mono text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>EC</span>
              {c.requirement}
            </li>
          ))}
        </ul>
      </Card>

      <Card highlighted className="p-6 mb-6">
        <SectionLabel>Payment summary</SectionLabel>
        <div className="space-y-2">
          <Row label="Fixed reward"><DemoUsdcTag amount={exp.rewardUsdc} /></Row>
          <Row label="Platform fee"><span style={{ color: 'var(--success)' }}>0% — prototype</span></Row>
          <Row label="Submission deadline">{exp.submissionDeadline}</Row>
          <Row label="Review window">{exp.reviewWindowDays} days after submission</Row>
        </div>
        <div
          className="mt-4 rounded-lg p-3 text-xs"
          style={{
            background: 'rgba(0,0,0,0.15)',
            color: 'var(--ink-2)',
            border: '1px solid var(--yellow-border)',
          }}
        >
          This is a simulated publication. No real USDC is locked or paid. In a future on-chain version,
          the reward would be held in an Arc Testnet smart contract until a reviewer approves the evidence.
        </div>
      </Card>

      <div className="flex gap-3">
        <Button variant="ghost" size="md" onClick={onBack}>Back</Button>
        <Button variant="yellow" size="md" className="flex-1" onClick={onConfirm}>
          Simulate publish to demo board
        </Button>
      </div>
    </div>
  )
}

function PublishedConfirmation({ exp, onBoard }: { exp: Experiment; onBoard: () => void }) {
  return (
    <div className="max-w-lg mx-auto px-4 py-16 text-center">
      <div
        className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-5"
        style={{ background: 'var(--yellow-muted)', border: '2px solid var(--yellow-border)' }}
      >
        <span className="text-2xl" aria-hidden>✓</span>
      </div>
      <h1 className="display text-2xl font-bold mb-2" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
        Protocol published (demo)
      </h1>
      <p className="text-sm mb-2" style={{ color: 'var(--muted)' }}>
        <strong style={{ color: 'var(--ink-2)' }}>{exp.title}</strong> is now on the demo board with status{' '}
        <StatusBadge status="open" size="sm" />.
      </p>
      <p className="text-xs mb-6" style={{ color: 'var(--subtle)' }}>
        This experiment lives only in your browser. Image previews and unsaved data are not persisted.
      </p>
      <Button variant="yellow" size="md" onClick={onBoard}>
        Go to experiment board
      </Button>
    </div>
  )
}

function Divider() {
  return <div className="my-4 border-t" style={{ borderColor: 'var(--border)' }} />
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 py-1">
      <span className="text-xs font-medium w-32 shrink-0 mt-0.5" style={{ color: 'var(--muted)' }}>
        {label}
      </span>
      <span className="text-sm flex-1" style={{ color: 'var(--ink-2)' }}>{children}</span>
    </div>
  )
}
