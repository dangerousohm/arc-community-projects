import { AlertTriangle } from 'lucide-react'
import { Button } from './ui/Button'

interface ResetModalProps {
  onConfirm: () => void
  onCancel: () => void
}

export function ResetModal({ onConfirm, onCancel }: ResetModalProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="reset-title"
    >
      <div
        className="w-full max-w-sm rounded-2xl p-6"
        style={{
          background: 'var(--surface-lifted)',
          border: '1px solid var(--border-strong)',
        }}
      >
        <div className="flex items-center gap-3 mb-4">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: 'var(--coral-muted)', border: '1px solid var(--coral)' }}
          >
            <AlertTriangle className="w-5 h-5" style={{ color: 'var(--coral)' }} />
          </div>
          <h2 id="reset-title" className="display text-lg font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
            Reset demo data?
          </h2>
        </div>
        <p className="text-sm mb-6" style={{ color: 'var(--muted)' }}>
          This will remove all drafts, evidence, and your published experiments, and restore the original five demo experiments. This action cannot be undone.
        </p>
        <div className="flex gap-3">
          <Button variant="ghost" size="md" onClick={onCancel} className="flex-1">
            Cancel
          </Button>
          <Button variant="danger" size="md" onClick={onConfirm} className="flex-1">
            Reset demo
          </Button>
        </div>
      </div>
    </div>
  )
}
