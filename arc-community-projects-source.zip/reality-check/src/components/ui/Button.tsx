import { type ButtonHTMLAttributes, forwardRef } from 'react'
import { clsx } from 'clsx'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'yellow'
type Size = 'sm' | 'md' | 'lg'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
}

const variantClasses: Record<Variant, string> = {
  primary:
    'bg-[var(--pale-blue)] text-[#0b1629] font-semibold hover:bg-[var(--ink)] focus-visible:ring-2 focus-visible:ring-[var(--focus)] disabled:opacity-40',
  secondary:
    'bg-[var(--surface-strong)] text-[var(--ink)] border border-[var(--border)] hover:border-[var(--border-strong)] hover:bg-[var(--surface-lifted)] disabled:opacity-40',
  ghost:
    'text-[var(--ink-2)] hover:text-[var(--ink)] hover:bg-[var(--surface)] disabled:opacity-40',
  danger:
    'bg-[var(--coral-muted)] text-[var(--coral)] border border-[var(--coral)] hover:bg-[var(--coral)] hover:text-white disabled:opacity-40',
  yellow:
    'bg-[var(--yellow)] text-[#0b1629] font-semibold hover:opacity-90 focus-visible:ring-2 focus-visible:ring-[var(--yellow)] disabled:opacity-40',
}

const sizeClasses: Record<Size, string> = {
  sm: 'px-3 py-1.5 text-sm rounded-md min-h-[36px]',
  md: 'px-4 py-2 text-sm rounded-lg min-h-[44px]',
  lg: 'px-6 py-3 text-base rounded-xl min-h-[52px]',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'secondary', size = 'md', loading, children, className, disabled, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={clsx(
          'inline-flex items-center justify-center gap-2 transition-all duration-150 cursor-pointer',
          'focus-visible:outline-none',
          variantClasses[variant],
          sizeClasses[size],
          className
        )}
        {...props}
      >
        {loading && (
          <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
        )}
        {children}
      </button>
    )
  }
)

Button.displayName = 'Button'
