// Persistent demo watermark — used throughout the app

export function DemoUsdcTag({ amount }: { amount: number }) {
  return (
    <span
      className="tabular text-sm font-semibold"
      style={{ color: 'var(--yellow)' }}
      title="Demo USDC — no real funds"
    >
      {amount.toFixed(2)}{' '}
      <span className="text-xs font-normal" style={{ color: 'var(--muted)' }}>
        Demo USDC
      </span>
    </span>
  )
}

export function SimulatedBanner() {
  return (
    <div
      className="w-full text-center py-1.5 text-xs font-medium tracking-wide"
      style={{
        background: 'var(--yellow-muted)',
        color: 'var(--yellow)',
        borderBottom: '1px solid var(--yellow-border)',
        letterSpacing: '0.05em',
      }}
    >
      DEMO ONLY — All balances and payments are simulated. No real funds are involved.
    </div>
  )
}

export function PlannedTag({ label }: { label: string }) {
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 text-xs rounded font-medium"
      style={{
        background: 'rgba(99,165,230,0.1)',
        color: 'var(--pale-blue)',
        border: '1px solid rgba(99,165,230,0.2)',
        letterSpacing: '0.05em',
      }}
    >
      Planned: {label}
    </span>
  )
}
