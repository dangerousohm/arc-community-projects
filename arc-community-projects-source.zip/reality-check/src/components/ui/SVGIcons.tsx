// Custom SVG instrument/sample illustrations for Reality Check
import type { CSSProperties } from 'react'

interface IconProps { className?: string; style?: CSSProperties }

export function FlaskIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M9 3h6M9 3v6l-4 9a1 1 0 00.9 1.5h12.2a1 1 0 00.9-1.5L15 9V3" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="10" cy="15" r="1" fill="currentColor" stroke="none" />
      <circle cx="13" cy="17" r="0.75" fill="currentColor" stroke="none" />
    </svg>
  )
}

export function CaliperIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M3 6h18M3 6v3M21 6v3M7 9v9M17 9v9M7 18h10" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M5 6V4h14v2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function ClipboardCheckIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="8" y="2" width="8" height="4" rx="1" strokeLinecap="round" />
      <path d="M7 4H5a2 2 0 00-2 2v13a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2h-2" strokeLinecap="round" />
      <path d="M9 12l2 2 4-4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function ScaleIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M12 3v18M5 21h14" strokeLinecap="round" />
      <path d="M5 9l-3 6h6L5 9zM19 9l-3 6h6L19 9z" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M5 9h14" strokeLinecap="round" />
    </svg>
  )
}

export function BeakerIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M4.5 6.375a4.125 4.125 0 118.25 0 4.125 4.125 0 01-8.25 0z" strokeLinecap="round" />
      <path d="M7.5 6.375V18a3 3 0 006 0V6.375" strokeLinecap="round" />
      <path d="M4 20h16" strokeLinecap="round" />
    </svg>
  )
}

export function ThermometerIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M14 14.764V7a2 2 0 10-4 0v7.764A4 4 0 1014 14.764z" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M12 12V9" strokeLinecap="round" />
    </svg>
  )
}

export function MagnifyIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.35-4.35" strokeLinecap="round" />
    </svg>
  )
}

export function ReceiptIcon({ className = 'w-6 h-6', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" strokeLinecap="round" />
      <rect x="9" y="3" width="6" height="4" rx="1" strokeLinecap="round" />
      <path d="M9 12h6M9 16h4" strokeLinecap="round" />
    </svg>
  )
}

export function GraphPaperIcon({ className = 'w-8 h-8', style }: IconProps) {
  return (
    <svg className={className} style={style} viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="4" fill="rgba(99,165,230,0.08)" />
      {[8, 16, 24].map(x => (
        <line key={`v${x}`} x1={x} y1="4" x2={x} y2="28" stroke="rgba(99,165,230,0.3)" strokeWidth="0.5" />
      ))}
      {[8, 16, 24].map(y => (
        <line key={`h${y}`} x1="4" y1={y} x2="28" y2={y} stroke="rgba(99,165,230,0.3)" strokeWidth="0.5" />
      ))}
      <circle cx="16" cy="16" r="3" fill="var(--yellow)" opacity="0.8" />
      <circle cx="8" cy="8" r="1.5" fill="rgba(99,165,230,0.5)" />
      <circle cx="24" cy="24" r="1.5" fill="rgba(99,165,230,0.5)" />
    </svg>
  )
}
