import type { ExperimentStatus, Category } from '../../state/types'
import { STATUS_LABELS, STATUS_COLORS, CATEGORY_LABELS } from '../../state/types'

interface StatusBadgeProps {
  status: ExperimentStatus
  size?: 'sm' | 'md'
}

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const color = STATUS_COLORS[status]
  const label = STATUS_LABELS[status]
  const sz = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs'
  return (
    <span
      className={`inline-flex items-center border rounded font-medium tracking-wider uppercase ${sz} ${color}`}
      style={{ letterSpacing: '0.07em' }}
    >
      {label}
    </span>
  )
}

interface CategoryBadgeProps {
  category: Category
}

export function CategoryBadge({ category }: CategoryBadgeProps) {
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded"
      style={{
        background: 'var(--pale-blue-muted)',
        color: 'var(--pale-blue)',
        border: '1px solid rgba(168,200,232,0.2)',
        letterSpacing: '0.06em',
      }}
    >
      {CATEGORY_LABELS[category]}
    </span>
  )
}
