import { type HTMLAttributes } from 'react'
import { clsx } from 'clsx'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  elevated?: boolean
  highlighted?: boolean
}

export function Card({ elevated, highlighted, className, children, ...props }: CardProps) {
  return (
    <div
      className={clsx(
        'rounded-2xl border transition-all duration-200',
        elevated
          ? 'border-[var(--border-strong)]'
          : 'border-[var(--border)]',
        highlighted
          ? 'border-[var(--yellow-border)] bg-[var(--yellow-muted)]'
          : 'bg-[var(--surface)]',
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p
      className="text-xs font-semibold tracking-widest uppercase mb-3"
      style={{ color: 'var(--muted)', letterSpacing: '0.09em' }}
    >
      {children}
    </p>
  )
}

export function SpecimenLabel({ number, label }: { number: string; label: string }) {
  return (
    <div className="flex items-center gap-2 mb-1">
      <span
        className="mono text-xs font-medium px-1.5 py-0.5 rounded"
        style={{
          background: 'var(--yellow-muted)',
          color: 'var(--yellow)',
          border: '1px solid var(--yellow-border)',
        }}
      >
        {number}
      </span>
      <span className="text-xs font-medium" style={{ color: 'var(--muted)' }}>
        {label}
      </span>
    </div>
  )
}
