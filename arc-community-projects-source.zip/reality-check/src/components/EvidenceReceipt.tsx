import { ChevronLeft, Download, Printer, AlertTriangle, Info } from 'lucide-react'
import type { Experiment, OutcomeType } from '../state/types'
import { STATUS_LABELS, CATEGORY_LABELS } from '../state/types'
import { StatusBadge, CategoryBadge } from './ui/Badge'
import { Button } from './ui/Button'
import { Card, SectionLabel, SpecimenLabel } from './ui/Card'
import { DemoUsdcTag } from './ui/DemoTag'
import { ReceiptIcon } from './ui/SVGIcons'

interface ReceiptProps {
  experiment: Experiment
  onBack: () => void
}

const OUTCOME_LABELS: Record<OutcomeType, string> = {
  supports:      'Supports hypothesis',
  contradicts:   'Contradicts hypothesis',
  inconclusive:  'Inconclusive',
}

const OUTCOME_COLORS: Record<OutcomeType, string> = {
  supports:     'var(--success)',
  contradicts:  'var(--coral)',
  inconclusive: 'var(--yellow)',
}

export function EvidenceReceipt({ experiment: exp, onBack }: ReceiptProps) {
  const evidence = exp.evidence

  const validValues = (evidence?.trials ?? [])
    .map(t => Number(t.value))
    .filter(v => !isNaN(v))
  const mean = validValues.length > 0
    ? validValues.reduce((a, b) => a + b, 0) / validValues.length
    : null
  const minV = validValues.length > 0 ? Math.min(...validValues) : null
  const maxV = validValues.length > 0 ? Math.max(...validValues) : null
  const range = minV !== null && maxV !== null ? maxV - minV : null

  function handleExport() {
    const receipt = buildJsonReceipt(exp, mean, range)
    const blob = new Blob([JSON.stringify(receipt, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `reality-check-receipt-${exp.id}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  function handlePrint() {
    window.print()
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8 print:py-4 print:px-0">
      {/* Back — hidden in print */}
      <button
        className="flex items-center gap-1.5 text-sm mb-6 hover:text-[var(--ink)] transition-colors print:hidden"
        style={{ color: 'var(--muted)' }}
        onClick={onBack}
      >
        <ChevronLeft className="w-4 h-4" /> Back to workbench
      </button>

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-6 flex-wrap">
        <div className="flex items-start gap-3">
          <ReceiptIcon className="w-8 h-8 shrink-0 mt-1" style={{ color: 'var(--yellow)' }} />
          <div>
            <h1
              className="display text-2xl md:text-3xl font-bold text-balance mb-1"
              style={{ color: 'var(--ink)', letterSpacing: '-0.025em' }}
            >
              Evidence Receipt
            </h1>
            <p className="mono text-xs" style={{ color: 'var(--muted)' }}>
              Receipt ID: {exp.id} · Protocol v{exp.protocolVersion}
            </p>
          </div>
        </div>
        <div className="flex gap-2 print:hidden">
          <Button variant="secondary" size="sm" onClick={handleExport}>
            <Download className="w-3.5 h-3.5" /> Export JSON
          </Button>
          <Button variant="ghost" size="sm" onClick={handlePrint}>
            <Printer className="w-3.5 h-3.5" /> Print
          </Button>
        </div>
      </div>

      {/* Honesty notice */}
      <div
        className="rounded-xl p-4 mb-6 text-sm print:border print:border-gray-300"
        style={{
          background: 'var(--surface)',
          border: '1px solid var(--border)',
          color: 'var(--ink-2)',
        }}
      >
        <Info className="w-4 h-4 inline mr-1.5 mb-0.5" style={{ color: 'var(--pale-blue)' }} />
        This is a local demo receipt. There is no cryptographic verification, no public publication,
        and no scientific certification attached to this document. Data lives only in this browser.
      </div>

      {/* Question and status */}
      <Card elevated className="p-6 mb-5">
        <SpecimenLabel number="Q" label="Research question" />
        <p
          className="display text-lg font-semibold mb-4 text-balance"
          style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}
        >
          {exp.question}
        </p>
        <div className="flex items-center gap-2 flex-wrap">
          <CategoryBadge category={exp.category} />
          <StatusBadge status={exp.status} />
        </div>
      </Card>

      {/* Participants */}
      <Card className="p-5 mb-5">
        <SectionLabel>Demo participants (fictional)</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { role: 'Proposer', name: exp.proposerName },
            { role: 'Tester', name: exp.testerName ?? 'Unassigned' },
            { role: 'Reviewer', name: exp.reviewerName ?? 'Unassigned' },
          ].map(p => (
            <div
              key={p.role}
              className="rounded-lg p-3"
              style={{ background: 'var(--surface-muted)' }}
            >
              <p className="text-xs font-semibold mb-1" style={{ color: 'var(--muted)' }}>{p.role}</p>
              <p className="text-sm" style={{ color: 'var(--ink-2)' }}>{p.name}</p>
            </div>
          ))}
        </div>
        <p className="text-xs mt-2" style={{ color: 'var(--subtle)' }}>
          All participant names are fictional demo identifiers.
        </p>
      </Card>

      {/* Protocol snapshot */}
      <Card className="p-5 mb-5">
        <SectionLabel>Protocol snapshot (v{exp.protocolVersion})</SectionLabel>
        <div className="space-y-2 mb-4">
          <Row label="Hypothesis">{exp.hypothesis}</Row>
          <Row label="Independent variable">{exp.independentVariable}</Row>
          <Row label="Measurement unit">{exp.measurementUnit}</Row>
          <Row label="Trials">{exp.repeatCount}</Row>
        </div>
        <div className="mt-3">
          <p className="text-xs font-medium mb-2" style={{ color: 'var(--ink-2)' }}>Steps</p>
          <ol className="list-decimal list-inside space-y-1">
            {exp.steps.map(s => (
              <li key={s.id} className="text-xs" style={{ color: 'var(--muted)' }}>{s.instruction}</li>
            ))}
          </ol>
        </div>
      </Card>

      {/* Trial data */}
      {evidence ? (
        <>
          <Card className="p-5 mb-5">
            <SectionLabel>Trial data</SectionLabel>
            <div className="overflow-x-auto mb-4">
              <table className="w-full text-sm" role="table" aria-label="Trial data table">
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    {['Trial', `Measurement (${exp.measurementUnit})`, 'Notes'].map(h => (
                      <th key={h} className="text-left text-xs font-semibold pb-2 pr-4" style={{ color: 'var(--muted)' }}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {evidence.trials.map((t, i) => (
                    <tr key={t.id} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td className="py-2 pr-4 mono text-xs" style={{ color: 'var(--yellow)' }}>T{i + 1}</td>
                      <td className="py-2 pr-4 tabular" style={{ color: 'var(--ink)' }}>{t.value}</td>
                      <td className="py-2 text-xs" style={{ color: 'var(--muted)' }}>{t.notes || '—'}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot style={{ borderTop: '1px solid var(--border-strong)' }}>
                  <tr>
                    <td className="pt-2 pr-4 text-xs font-semibold" style={{ color: 'var(--pale-blue)' }}>Mean</td>
                    <td className="pt-2 pr-4 tabular font-semibold" style={{ color: 'var(--pale-blue)' }}>
                      {mean !== null ? mean.toFixed(2) : '—'}
                    </td>
                    <td />
                  </tr>
                  <tr>
                    <td className="pb-2 pr-4 text-xs font-semibold" style={{ color: 'var(--pale-blue)' }}>Range</td>
                    <td className="pb-2 pr-4 tabular font-semibold" style={{ color: 'var(--pale-blue)' }}>
                      {range !== null ? range.toFixed(2) : '—'}
                    </td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Outcome */}
            <div
              className="rounded-xl p-4"
              style={{
                background: evidence.outcomeType === 'supports'
                  ? 'rgba(92,201,139,0.1)'
                  : evidence.outcomeType === 'contradicts'
                  ? 'var(--coral-muted)'
                  : 'var(--yellow-muted)',
                border: `1px solid ${OUTCOME_COLORS[evidence.outcomeType]}`,
              }}
            >
              <p
                className="text-sm font-semibold mb-1"
                style={{ color: OUTCOME_COLORS[evidence.outcomeType] }}
              >
                Outcome: {OUTCOME_LABELS[evidence.outcomeType]}
              </p>
              <p className="text-xs" style={{ color: 'var(--ink-2)' }}>
                {evidence.outcomeType === 'contradicts' && (
                  <>A result that contradicts the hypothesis is not a failure — it is equally valid evidence.<br /></>
                )}
                {evidence.outcomeType === 'inconclusive' && (
                  <>An inconclusive result means the data did not clearly support or contradict the hypothesis. It is still valid evidence.<br /></>
                )}
              </p>
            </div>
          </Card>

          {/* Observations */}
          <Card className="p-5 mb-5">
            <SectionLabel>Reported observations</SectionLabel>
            <p className="text-sm mb-4" style={{ color: 'var(--ink-2)' }}>{evidence.observations}</p>
            {evidence.interpretation && (
              <>
                <SectionLabel>Participant interpretation</SectionLabel>
                <p className="text-sm italic" style={{ color: 'var(--muted)' }}>{evidence.interpretation}</p>
              </>
            )}
          </Card>
        </>
      ) : (
        <Card className="p-5 mb-5">
          <p className="text-sm" style={{ color: 'var(--muted)' }}>No evidence submitted yet.</p>
        </Card>
      )}

      {/* Reviewer decision */}
      {exp.review && (
        <Card className="p-5 mb-5">
          <SectionLabel>Reviewer decision</SectionLabel>
          <div className="flex items-center gap-2 mb-2">
            <StatusBadge status={exp.review.decision === 'approved' ? 'approved' : 'revision_requested'} size="sm" />
            <span className="text-xs" style={{ color: 'var(--muted)' }}>
              by {exp.reviewerName ?? 'Reviewer'} · {new Date(exp.review.reviewedAt).toLocaleDateString()}
            </span>
          </div>
          <p className="text-sm" style={{ color: 'var(--ink-2)' }}>{exp.review.reason}</p>
          <p className="text-xs mt-3" style={{ color: 'var(--subtle)' }}>
            The reviewer checks protocol compliance only — not whether the result is universally true.
          </p>
        </Card>
      )}

      {/* Limitations */}
      <Card className="p-5 mb-5">
        <SectionLabel>Limitations</SectionLabel>
        <p className="text-sm" style={{ color: 'var(--ink-2)' }}>
          {exp.limitations ?? 'No explicit limitations noted for this demo experiment.'}
        </p>
        <div
          className="mt-3 rounded-lg p-3 flex items-start gap-2"
          style={{ background: 'var(--yellow-muted)', border: '1px solid var(--yellow-border)' }}
        >
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: 'var(--yellow)' }} />
          <p className="text-xs" style={{ color: 'var(--ink-2)' }}>
            <strong>One experiment is not proof for every situation.</strong> These results apply only
            to the specific conditions tested. Other environments, materials, or methods may give
            different results.
          </p>
        </div>
      </Card>

      {/* Payment provenance */}
      <Card className="p-5 mb-5">
        <SectionLabel>Payment provenance</SectionLabel>
        <div className="space-y-1">
          <Row label="Fixed reward"><DemoUsdcTag amount={exp.rewardUsdc} /></Row>
          <Row label="Platform fee">0% (prototype)</Row>
          <Row label="Payment status"><StatusBadge status={exp.status} size="sm" /></Row>
          <Row label="Submission deadline">{exp.submissionDeadline}</Row>
          <Row label="Review window">{exp.reviewWindowDays} days</Row>
        </div>
        <div
          className="mt-4 rounded-lg p-3 text-xs"
          style={{ background: 'var(--surface-muted)', color: 'var(--muted)', border: '1px solid var(--border)' }}
        >
          This receipt is local to your browser. No transaction hash, no deployed contract, no on-chain publication.
          Planned Arc Testnet integration would anchor the evidence hash to the blockchain for transparent provenance.
        </div>
      </Card>

      {/* Export reminder */}
      <div
        className="rounded-xl p-4 print:hidden"
        style={{
          background: 'var(--surface)',
          border: '1px solid var(--border)',
          color: 'var(--muted)',
        }}
      >
        <p className="text-xs">
          Export the JSON receipt to save a copy of this evidence locally. The receipt does not include image data — image previews are memory-only and disappear on page reload.
        </p>
      </div>
    </div>
  )
}

// ── Helpers ────────────────────────────────────────────────────────────────
function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 py-1">
      <span className="text-xs font-medium w-32 shrink-0 mt-0.5" style={{ color: 'var(--muted)' }}>{label}</span>
      <span className="text-sm flex-1" style={{ color: 'var(--ink-2)' }}>{children}</span>
    </div>
  )
}

function buildJsonReceipt(exp: Experiment, mean: number | null, range: number | null) {
  return {
    receiptVersion: '1.0.0',
    generatedAt: new Date().toISOString(),
    disclaimer:
      'This is a local demo receipt from Reality Check. No cryptographic verification, no public publication, and no scientific certification is attached. One experiment is not proof for every situation.',
    experiment: {
      id: exp.id,
      title: exp.title,
      question: exp.question,
      category: CATEGORY_LABELS[exp.category],
      status: STATUS_LABELS[exp.status],
      protocolVersion: exp.protocolVersion,
    },
    protocol: {
      hypothesis: exp.hypothesis,
      independentVariable: exp.independentVariable,
      measurementUnit: exp.measurementUnit,
      repeatCount: exp.repeatCount,
      steps: exp.steps.map(s => s.instruction),
      evidenceChecklist: exp.evidenceChecklist.map(c => c.requirement),
    },
    participants: {
      proposer: exp.proposerName,
      tester: exp.testerName ?? null,
      reviewer: exp.reviewerName ?? null,
      note: 'All participant names are fictional demo identifiers.',
    },
    evidence: exp.evidence
      ? {
          trials: exp.evidence.trials.map((t, i) => ({
            index: i + 1,
            value: t.value,
            notes: t.notes,
          })),
          derivedMean: mean,
          derivedRange: range,
          observations: exp.evidence.observations,
          interpretation: exp.evidence.interpretation,
          outcomeType: exp.evidence.outcomeType,
          imageNote: 'Image previews are not included in this export.',
        }
      : null,
    review: exp.review ?? null,
    payment: {
      rewardUsdc: exp.rewardUsdc,
      currency: 'Demo USDC — no real funds',
      platformFee: '0% (prototype)',
      submissionDeadline: exp.submissionDeadline,
      reviewWindowDays: exp.reviewWindowDays,
    },
    limitations: exp.limitations ?? 'No explicit limitations noted.',
    provenance:
      'Planned: evidence hash anchored to Arc Testnet. Currently: local browser state only.',
  }
}
