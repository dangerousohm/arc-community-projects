import { useState, useEffect } from 'react'
import { toast } from 'sonner'
import { useExperimentStore } from './state/store'
import type { Experiment } from './state/types'
import { Nav } from './components/Nav'
import { ExperimentBoard } from './components/ExperimentBoard'
import { ProtocolBuilder } from './components/ProtocolBuilder'
import { Workbench } from './components/Workbench'
import { EvidenceReceipt } from './components/EvidenceReceipt'
import { ResetModal } from './components/ResetModal'
import { SimulatedBanner } from './components/ui/DemoTag'

type View =
  | { name: 'board' }
  | { name: 'builder'; draft?: Experiment }
  | { name: 'workbench'; id: string }
  | { name: 'receipt'; id: string }

export default function App() {
  const store = useExperimentStore()
  const [view, setView] = useState<View>({ name: 'board' })
  const [showReset, setShowReset] = useState(false)

  // Surface storage warnings once on mount
  useEffect(() => {
    if (store.storageStatus === 'unavailable') {
      toast.warning(
        'Browser storage is unavailable. Your experiments will not be saved between sessions.',
        { duration: 8000 }
      )
    } else if (store.storageStatus === 'corrupted') {
      toast.warning(
        'Saved data could not be read (corrupted). Demo experiments have been restored.',
        { duration: 8000 }
      )
    } else if (store.storageStatus === 'partial' && store.storageDroppedCount > 0) {
      toast.warning(
        `${store.storageDroppedCount} stored record${store.storageDroppedCount > 1 ? 's were' : ' was'} invalid and dropped. Other experiments were restored.`,
        { duration: 8000 }
      )
    }
  // Only run on mount
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function goBoard() { setView({ name: 'board' }) }
  function goCreate() { setView({ name: 'builder' }) }
  function goWorkbench(id: string) { setView({ name: 'workbench', id }) }
  function goReceipt(id: string) { setView({ name: 'receipt', id }) }

  function handlePublish(exp: Experiment) {
    store.addExperiment(exp)
    toast.success('Protocol published to demo board (simulated)')
    setView({ name: 'board' })
  }

  function handleReset() {
    store.resetDemo()
    setShowReset(false)
    setView({ name: 'board' })
    if (store.storageStatus === 'unavailable') {
      toast.warning('Demo reset in memory only — storage is unavailable, changes will not persist.')
    } else {
      toast.success('Demo data reset to defaults')
    }
  }

  const currentExp = (view.name === 'workbench' || view.name === 'receipt')
    ? store.getById(view.id)
    : null

  return (
    <div className="min-h-dvh flex flex-col">
      <SimulatedBanner />
      <Nav
        onHome={goBoard}
        onCreate={goCreate}
        onReset={() => setShowReset(true)}
      />

      <main className="flex-1">
        {view.name === 'board' && (
          <ExperimentBoard
            experiments={store.experiments}
            onSelect={goWorkbench}
            onCreate={goCreate}
          />
        )}

        {view.name === 'builder' && (
          <ProtocolBuilder
            existingDraft={view.draft}
            onPublish={handlePublish}
            onCancel={goBoard}
          />
        )}

        {view.name === 'workbench' && currentExp ? (
          <Workbench
            experiment={currentExp}
            store={store}
            onBack={goBoard}
            onViewReceipt={goReceipt}
          />
        ) : view.name === 'workbench' ? (
          <NotFound onBack={goBoard} />
        ) : null}

        {view.name === 'receipt' && currentExp ? (
          <EvidenceReceipt
            experiment={currentExp}
            onBack={() => goWorkbench(view.id)}
          />
        ) : view.name === 'receipt' ? (
          <NotFound onBack={goBoard} />
        ) : null}
      </main>

      {showReset && (
        <ResetModal
          onConfirm={handleReset}
          onCancel={() => setShowReset(false)}
        />
      )}
    </div>
  )
}

function NotFound({ onBack }: { onBack: () => void }) {
  return (
    <div className="max-w-md mx-auto px-4 py-16 text-center">
      <p className="text-sm mb-4" style={{ color: 'var(--muted)' }}>Experiment not found.</p>
      <button
        onClick={onBack}
        className="text-sm underline"
        style={{ color: 'var(--pale-blue)' }}
      >
        Back to board
      </button>
    </div>
  )
}
