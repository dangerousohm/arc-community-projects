# Reality Check — Future Escrow Specification

**Status:** Draft / Not yet implemented  
**Target chain:** Arc Testnet (and Arc Mainnet for production)  
**Document date:** October 2026

---

## Overview

This document describes the planned smart-contract escrow for Reality Check experiment rewards. The current prototype simulates all payment actions. No Solidity implementation exists yet.

---

## Key Principles

- Rewards are paid for **protocol compliance**, not for supporting a claim.
- A result that contradicts the hypothesis is equally eligible for the reward.
- The reviewer checks whether the protocol was followed — not whether the claim is universally true.
- Agreement on protocol compliance is strictly separate from any product claim or scientific truth.

---

## Actors and Trust Model

| Actor | Responsibility | Trust level |
|---|---|---|
| Proposer | Designs protocol, funds escrow | Trusted to fund; constrained by protocol hash |
| Tester | Runs trials, submits evidence | Untrusted until evidence reviewed |
| Reviewer | Checks protocol compliance | Trusted third party; incentivised by reviewer fee |
| Resolver | Handles disputes | Decentralised or Circle-operated fallback |
| Contract | Enforces rules, holds funds | Trustless |

---

## Contract Lifecycle

### 1. Protocol creation and funding

- Proposer calls `createExperiment(protocolHash, rewardUsdc, submissionDeadline, reviewWindowDays, reviewerAddress)`.
- Contract stores `keccak256(protocolJson)` to detect tampering.
- Proposer transfers `rewardUsdc` USDC to the contract (ERC-20 `approve` + `transferFrom`).
- Status → `open`.

### 2. Tester acceptance

- Any eligible address calls `acceptExperiment(experimentId)`.
- Status → `accepted`.
- No funds move at this step.

### 3. Evidence submission

- Tester calls `submitEvidence(experimentId, evidenceHash)` before `submissionDeadline`.
- Contract stores `keccak256(evidenceJson)` for provenance.
- Status → `evidence_submitted`.
- Tester may call `reviseEvidence(experimentId, newHash)` if the reviewer requests a revision, up to `maxRevisions` (default 2).

### 4. Review window

- Reviewer has `reviewWindowDays` days from submission to call `approveEvidence(experimentId, reason)` or `requestRevision(experimentId, reason)`.
- On approval: status → `approved`; reward released to tester.
- On revision request: status → `revision_requested`; tester has `revisionDeadlineDays` (default 7) to resubmit.
- If reviewer does not respond within the review window: status → `reviewer_timeout`; dispute resolution triggered.

### 5. Reward release

- On `approved`, contract calls USDC ERC-20 `transfer(tester, rewardUsdc - platformFee)`.
- Platform fee (if any) transferred to Circle fee address.
- Status → `paid`.

---

## Deadline Handling

| Scenario | Rule |
|---|---|
| Tester misses `submissionDeadline` | Status → `overdue`. Proposer calls `cancelExpired` to reclaim full reward. |
| Reviewer misses review window | Status → `reviewer_timeout`. Dispute auto-opens. After `disputeTimeoutDays`, resolver decides. |
| Tester misses revision deadline | Status → `revision_expired`. Reward refunded to proposer. |
| Proposer cancels before acceptance | Status → `cancelled`. Full reward refunded immediately. |

---

## Dispute Handling

- Either proposer or tester calls `openDispute(experimentId)` within `disputeWindowDays` of a contested decision.
- Resolver (trusted address or multisig) calls `resolveDispute(experimentId, winner)`.
- If resolver does not respond within `resolverTimeoutDays`: funds split 50/50 between proposer and tester.
- Disputes are over **protocol compliance**, not over whether the product claim is true.

---

## Revision Limits

- Default: `maxRevisions = 2`.
- After the limit is reached and no approval, proposer may trigger `resolveStaleRevision`, which refunds the reward.

---

## Refund Rules

| Condition | Refund to |
|---|---|
| Cancelled before acceptance | Proposer — full amount |
| Overdue (tester never submitted) | Proposer — full amount |
| Revision expired | Proposer — full amount |
| Dispute: proposer wins | Proposer — full amount |
| Dispute: tester wins | Tester — full amount |
| Dispute timeout (no resolver) | Proposer 50%, Tester 50% |

---

## Release Rules (exact)

1. `approveEvidence` is called by the designated `reviewerAddress` for `experimentId`.
2. Contract checks `status == evidence_submitted`.
3. Contract checks `block.timestamp <= submissionDeadline + reviewWindowDays * 1 days`.
4. Contract checks caller is `reviewerAddress`.
5. Contract transfers `rewardUsdc - platformFee` to tester via USDC `transfer`.
6. Status → `paid`. Event emitted.

---

## Separation of Agreement and Truth

The contract and protocol deliberately do NOT:
- Certify that any product claim is true.
- Assert that results generalise to all situations.
- Act as scientific publication.

All receipts include: *"One experiment is not proof for every situation."*

---

## Platform Fee

- Initial prototype: 0%.
- Future: up to 3% to fund dispute resolution infrastructure.
- Fee address: Circle-controlled multi-sig.

---

## USDC on Arc

- USDC is the native gas token on Arc — a single pool, not two separate assets.
- Reward amounts stored and transferred as USDC ERC-20 (6-decimal view).
- All native-to-ERC-20 conversion uses `usdcToGasToken` / `gasTokenToUsdc` from Arc SDK.

---

*This spec covers planned functionality only. No contract has been deployed.*
