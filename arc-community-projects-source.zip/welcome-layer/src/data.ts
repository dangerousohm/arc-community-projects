/**
 * Welcome Layer — fictional seed data
 * All events, participants, providers, and prices are fictional demo data.
 */

import type { WelcomeEvent } from './types';
import { MICRO_PER_USDC } from './logic';

const M = MICRO_PER_USDC;

export const SEED_EVENTS: WelcomeEvent[] = [
  // ── 1. Detailed film evening ─────────────────────────────────────────────
  {
    id: 'evt-film-evening',
    title: 'Civic Film Evening: "The River Road"',
    description:
      'A free community screening of a locally produced documentary about the waterway restoration project. Open to all. Held at Riverside Community Hall.',
    date: '2026-11-15',
    location: 'Riverside Community Hall, 12 Mill Lane',
    floorPlanId: 'hall',
    improvements: [
      {
        id: 'imp-captions',
        eventId: 'evt-film-evening',
        title: 'Live Captions for Screening',
        description:
          'A trained captioner will provide real-time captions projected on a side screen alongside the film. This allows people who are deaf, hard of hearing, or prefer to read text to follow the dialogue and audio description.',
        provider: {
          name: 'caption-co',
          displayName: 'CaptionCo Demo Services',
          note: 'Fictional demo provider. Not a real company.',
        },
        lineItems: [
          { description: 'Captioner (3-hour session)', quantity: 1, unitCostMicro: 180 * M },
          { description: 'Side-screen rental', quantity: 1, unitCostMicro: 40 * M },
          { description: 'Setup and calibration', quantity: 1, unitCostMicro: 20 * M },
        ],
        targetMicro: 240 * M,
        fundingDeadline: '2026-11-01',
        deliveryDate: '2026-11-15',
        deliveryConfirmation:
          'Organiser will confirm in writing that the captioner was present and captions displayed throughout the screening.',
        participationNote:
          'Captions support a wide range of people including those who are deaf or hard of hearing, non-native language speakers, and people in noisy or quiet-room situations.',
        status: 'funding',
        isQuoteDemo: true,
        floorX: 62,
        floorY: 38,
        floorZone: 'Main Screen',
      },
      {
        id: 'imp-signage',
        eventId: 'evt-film-evening',
        title: 'Translated Event Signage (4 languages)',
        description:
          'Printed bilingual/multilingual direction signs (English, Spanish, Somali, Polish) for toilets, exits, the quiet room, and the main screening area. Large-format, high-contrast print.',
        provider: {
          name: 'quickprint-demo',
          displayName: 'QuickPrint Demo Studio',
          note: 'Fictional demo provider. Not a real company.',
        },
        lineItems: [
          { description: 'A2 direction signs (set of 12)', quantity: 1, unitCostMicro: 60 * M },
          { description: 'Translation review (4 languages)', quantity: 4, unitCostMicro: 15 * M },
        ],
        targetMicro: 120 * M,
        fundingDeadline: '2026-11-05',
        deliveryDate: '2026-11-15',
        deliveryConfirmation:
          'Organiser will photograph signs in place before doors open.',
        participationNote:
          'Multilingual signage helps attendees who are more comfortable reading in a language other than English.',
        status: 'funded',
        isQuoteDemo: true,
        floorX: 22,
        floorY: 68,
        floorZone: 'Lobby',
      },
      {
        id: 'imp-quiet-space',
        eventId: 'evt-film-evening',
        title: 'Staffed Quiet Space',
        description:
          'A dedicated low-stimulus room adjacent to the main hall with dim lighting, earplugs available, and a trained volunteer available to support attendees who need a break from the main event.',
        provider: {
          name: 'volunteer-hub',
          displayName: 'Community Volunteer Hub',
          note: 'Fictional demo provider. Not a real company.',
        },
        lineItems: [
          { description: 'Volunteer coordinator (5 hours)', quantity: 1, unitCostMicro: 60 * M },
          { description: 'Sensory supplies (earplugs, fidget items)', quantity: 1, unitCostMicro: 25 * M },
          { description: 'Signage for quiet room', quantity: 1, unitCostMicro: 15 * M },
        ],
        targetMicro: 100 * M,
        fundingDeadline: '2026-11-08',
        deliveryDate: '2026-11-15',
        deliveryConfirmation:
          'Volunteer coordinator confirms attendance in event log. Photo of room setup provided to organiser.',
        participationNote:
          'A quiet space supports attendees who may find sustained crowd environments tiring, including but not limited to those with sensory sensitivities.',
        status: 'ready',
        isQuoteDemo: true,
        floorX: 80,
        floorY: 72,
        floorZone: 'Side Room',
      },
      {
        id: 'imp-largeprint',
        eventId: 'evt-film-evening',
        title: 'Large-Print Programme Guides',
        description:
          'A4 large-print (18pt) versions of the event programme, including film synopsis, discussion prompts, and venue map. Printed in high-contrast black on cream paper.',
        provider: {
          name: 'quickprint-demo',
          displayName: 'QuickPrint Demo Studio',
          note: 'Fictional demo provider. Not a real company.',
        },
        lineItems: [
          { description: 'Large-print A4 programmes (50 copies)', quantity: 50, unitCostMicro: 1 * M },
          { description: 'Design layout fee', quantity: 1, unitCostMicro: 30 * M },
        ],
        targetMicro: 80 * M,
        fundingDeadline: '2026-11-10',
        deliveryDate: '2026-11-15',
        deliveryConfirmation:
          'Organiser confirms programmes available at the door. Leftover copies counted.',
        participationNote:
          'Large-print guides support attendees with low vision or those who prefer larger text.',
        status: 'cancelled',
        isQuoteDemo: true,
        floorX: 38,
        floorY: 25,
        floorZone: 'Entrance Desk',
      },
    ],
  },

  // ── 2. Community Science Fair ────────────────────────────────────────────
  {
    id: 'evt-science-fair',
    title: 'Neighbourhood Science Fair',
    description:
      'An afternoon of hands-on science activities for families. Held at Meadow Park Pavilion. All activities are drop-in.',
    date: '2026-12-06',
    location: 'Meadow Park Pavilion, Park Road',
    floorPlanId: 'pavilion',
    improvements: [
      {
        id: 'imp-audio-desc',
        eventId: 'evt-science-fair',
        title: 'Audio Description of Exhibits',
        description:
          'Short audio guides for three exhibit stations, accessible via QR code linking to free hosted audio files. A narrator describes the visual elements of each experiment.',
        provider: {
          name: 'audiodesc-demo',
          displayName: 'AudioDesc Demo Co',
          note: 'Fictional demo provider.',
        },
        lineItems: [
          { description: 'Audio narration (3 guides × 3 mins)', quantity: 3, unitCostMicro: 40 * M },
          { description: 'QR code print cards', quantity: 1, unitCostMicro: 10 * M },
        ],
        targetMicro: 130 * M,
        fundingDeadline: '2026-11-20',
        deliveryDate: '2026-12-06',
        deliveryConfirmation: 'Audio files linked and accessible before event opens. Organiser tests all three.',
        participationNote: 'Audio description supports attendees who are blind or have low vision.',
        status: 'draft',
        isQuoteDemo: true,
        floorX: 50,
        floorY: 45,
        floorZone: 'Central Exhibits',
      },
      {
        id: 'imp-bsl',
        eventId: 'evt-science-fair',
        title: 'BSL Interpreter for Welcome Talk',
        description:
          'A British Sign Language interpreter for the 15-minute opening welcome talk and Q&A. Positioned at the front of the exhibit space.',
        provider: {
          name: 'sign-solutions-demo',
          displayName: 'SignSolutions Demo',
          note: 'Fictional demo provider.',
        },
        lineItems: [
          { description: 'BSL interpreter (half-day)', quantity: 1, unitCostMicro: 200 * M },
        ],
        targetMicro: 200 * M,
        fundingDeadline: '2026-11-25',
        deliveryDate: '2026-12-06',
        deliveryConfirmation: 'Event photographer captures interpreter in position. Organiser confirms.',
        participationNote: 'BSL interpretation supports Deaf attendees who use British Sign Language.',
        status: 'funding',
        isQuoteDemo: true,
        floorX: 30,
        floorY: 20,
        floorZone: 'Welcome Area',
      },
    ],
  },

  // ── 3. Youth Theatre Showcase ────────────────────────────────────────────
  {
    id: 'evt-theatre',
    title: 'Youth Theatre Showcase — Spring Scenes',
    description:
      'Short performances by local youth theatre groups, ages 10–18. Held at the Old Library Studio Space.',
    date: '2027-03-22',
    location: 'Old Library Studio Space, Central Square',
    floorPlanId: 'studio',
    improvements: [
      {
        id: 'imp-relaxed',
        eventId: 'evt-theatre',
        title: 'Relaxed Performance Session',
        description:
          'One of the two performances designated as a relaxed session: house lights raised slightly, sound levels reduced, audience free to move or leave quietly, and a chill-out area outside the studio.',
        provider: {
          name: 'volunteer-hub',
          displayName: 'Community Volunteer Hub',
          note: 'Fictional demo provider.',
        },
        lineItems: [
          { description: 'Volunteer support staff (2 people × 3 hours)', quantity: 6, unitCostMicro: 12 * M },
          { description: 'Chill-out area setup supplies', quantity: 1, unitCostMicro: 28 * M },
        ],
        targetMicro: 100 * M,
        fundingDeadline: '2027-03-01',
        deliveryDate: '2027-03-22',
        deliveryConfirmation: 'Volunteer coordinator logs attendance. Relaxed performance listed on printed programme.',
        participationNote: 'Relaxed performances benefit a wide range of attendees who prefer a less formal or stimulating environment.',
        status: 'draft',
        isQuoteDemo: true,
        floorX: 55,
        floorY: 55,
        floorZone: 'Studio',
      },
      {
        id: 'imp-captioned-theatre',
        eventId: 'evt-theatre',
        title: 'Captioned Programme Booklets',
        description:
          'Printed captioned/subtitle-style booklet with full script for the performed scenes, allowing audience members to read along.',
        provider: {
          name: 'quickprint-demo',
          displayName: 'QuickPrint Demo Studio',
          note: 'Fictional demo provider.',
        },
        lineItems: [
          { description: 'Programme booklets (40 copies)', quantity: 40, unitCostMicro: 1_500_000 },
          { description: 'Script formatting and layout', quantity: 1, unitCostMicro: 35 * M },
        ],
        targetMicro: 95 * M,
        fundingDeadline: '2027-03-10',
        deliveryDate: '2027-03-22',
        deliveryConfirmation: 'Programmes available at door. Any surplus counted.',
        participationNote: 'Script booklets support audience members who are deaf or hard of hearing, or who process information better in written form.',
        status: 'funding',
        isQuoteDemo: true,
        floorX: 25,
        floorY: 78,
        floorZone: 'Foyer',
      },
    ],
  },
];

export const FLOOR_PLANS: Record<string, { label: string; viewBox: string }> = {
  hall: { label: 'Community Hall', viewBox: '0 0 400 300' },
  pavilion: { label: 'Park Pavilion', viewBox: '0 0 400 300' },
  studio: { label: 'Library Studio', viewBox: '0 0 400 300' },
};
