/**
 * Welcome Layer — shared production logic
 * All monetary values: integer micro-USDC (1 USDC = 1_000_000).
 * Tests import directly from this file.
 */

import type {
  Improvement,
  ImprovementStatus,
  Contribution,
  ContributeResult,
  TransitionResult,
  QuoteLineItem,
  ValidationErrors,
  AppState,
  AccountabilityReport,
} from './types';

// ─── Constants ──────────────────────────────────────────────────────────────

export const MICRO_PER_USDC = 1_000_000;
export const MAX_CONTRIBUTION_DECIMALS = 2; // e.g. 1.50 USDC max precision
export const SCHEMA_VERSION = 1;

// ─── Money helpers ───────────────────────────────────────────────────────────

/** Convert a USDC decimal string / number to micro-USDC integer.
 *  Rejects negative values, values with more than 2 decimal places, and non-finite. */
export function parseMicro(value: string | number): { ok: true; micro: number } | { ok: false; error: string } {
  const str = String(value).trim();
  if (!/^[0-9]+(\.[0-9]{1,2})?$/.test(str)) {
    return { ok: false, error: 'Amount must be a positive number with at most 2 decimal places (e.g. 5 or 5.50).' };
  }
  const n = Number(str);
  if (!Number.isFinite(n) || n <= 0) {
    return { ok: false, error: 'Amount must be a positive number.' };
  }
  // Multiply carefully to avoid float drift: work with string parts
  const [whole, frac = ''] = str.split('.');
  const fracPadded = frac.padEnd(6, '0');
  const micro = parseInt(whole, 10) * MICRO_PER_USDC + parseInt(fracPadded, 10);
  if (!Number.isFinite(micro) || micro <= 0) {
    return { ok: false, error: 'Amount is not a valid positive number.' };
  }
  return { ok: true, micro };
}

/** Format micro-USDC to a display string like "12.50" */
export function formatMicro(micro: number): string {
  const whole = Math.floor(micro / MICRO_PER_USDC);
  const frac = micro % MICRO_PER_USDC;
  // Show 2 decimal places
  const fracStr = String(Math.round(frac / 10000)).padStart(2, '0');
  return `${whole}.${fracStr}`;
}

/** Sum of line items for an improvement */
export function computeTarget(lineItems: QuoteLineItem[]): number {
  return lineItems.reduce((sum, li) => sum + li.quantity * li.unitCostMicro, 0);
}

/** Total active (non-refunded) contributions for an improvement */
export function raisedMicro(improvementId: string, contributions: Contribution[]): number {
  return contributions
    .filter(c => c.improvementId === improvementId && c.status === 'active')
    .reduce((sum, c) => sum + c.amountMicro, 0);
}

/** Remaining gap to target */
export function remainingMicro(improvement: Improvement, contributions: Contribution[]): number {
  const raised = raisedMicro(improvement.id, contributions);
  return Math.max(0, improvement.targetMicro - raised);
}

// ─── Allowed state transitions ───────────────────────────────────────────────

const ALLOWED_TRANSITIONS: Record<ImprovementStatus, ImprovementStatus[]> = {
  draft:     ['funding', 'cancelled'],
  funding:   ['funded', 'cancelled'],
  funded:    ['ready', 'cancelled'],
  ready:     [],          // terminal
  cancelled: ['refunded'],
  refunded:  [],          // terminal
};

export function canTransition(from: ImprovementStatus, to: ImprovementStatus): boolean {
  return ALLOWED_TRANSITIONS[from]?.includes(to) ?? false;
}

export function applyTransition(
  improvement: Improvement,
  to: ImprovementStatus,
): TransitionResult {
  if (!canTransition(improvement.status, to)) {
    return {
      ok: false,
      error: `Cannot move from "${improvement.status}" to "${to}".`,
    };
  }
  return { ok: true };
}

// ─── Contributions ───────────────────────────────────────────────────────────

export function contribute(
  improvement: Improvement,
  contributions: Contribution[],
  amountInput: string,
  contributorLabel: string,
  idFactory: () => string,
): ContributeResult {
  if (improvement.status !== 'funding') {
    return { ok: false, error: `This improvement is not currently accepting contributions (status: ${improvement.status}).` };
  }

  const parsed = parseMicro(amountInput);
  if (!parsed.ok) return { ok: false, error: parsed.error };
  const { micro } = parsed;

  const remaining = remainingMicro(improvement, contributions);
  if (micro > remaining) {
    return {
      ok: false,
      error: `Contribution of Demo USDC ${formatMicro(micro)} would exceed the remaining gap of Demo USDC ${formatMicro(remaining)}. Please enter a smaller amount.`,
    };
  }

  const contribution: Contribution = {
    id: idFactory(),
    improvementId: improvement.id,
    contributorLabel,
    amountMicro: micro,
    timestamp: new Date().toISOString(),
    status: 'active',
  };

  return { ok: true, contribution };
}

/** Process refunds for a cancelled improvement. Returns updated contributions.
 *  Idempotent: already-refunded contributions are not touched. */
export function processRefunds(
  improvementId: string,
  contributions: Contribution[],
  now: string = new Date().toISOString(),
): Contribution[] {
  return contributions.map(c => {
    if (c.improvementId === improvementId && c.status === 'active') {
      return { ...c, status: 'refunded' as const, refundedAt: now };
    }
    return c;
  });
}

/** Preview of what each contributor would receive in a refund. No changes applied. */
export function previewRefunds(
  improvementId: string,
  contributions: Contribution[],
): Array<{ contributorLabel: string; amountMicro: number; alreadyRefunded: boolean }> {
  return contributions
    .filter(c => c.improvementId === improvementId)
    .map(c => ({
      contributorLabel: c.contributorLabel,
      amountMicro: c.amountMicro,
      alreadyRefunded: c.status === 'refunded',
    }));
}

// ─── Improvement validation ──────────────────────────────────────────────────

export function validateImprovement(imp: Partial<Improvement>): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!imp.title?.trim()) errors.title = 'Title is required.';
  if (!imp.description?.trim()) errors.description = 'Description is required.';
  if (!imp.provider?.displayName?.trim()) errors.providerName = 'Provider display name is required.';

  if (!imp.fundingDeadline) {
    errors.fundingDeadline = 'Funding deadline is required.';
  }
  if (!imp.deliveryDate) {
    errors.deliveryDate = 'Planned delivery date is required.';
  }
  if (imp.fundingDeadline && imp.deliveryDate && imp.deliveryDate < imp.fundingDeadline) {
    errors.deliveryDate = 'Planned delivery date must be on or after the funding deadline.';
  }

  if (!imp.deliveryConfirmation?.trim()) {
    errors.deliveryConfirmation = 'Delivery confirmation method is required.';
  }

  if (!imp.lineItems?.length) {
    errors.lineItems = 'At least one quote line item is required.';
  } else {
    for (const li of imp.lineItems) {
      if (!li.description?.trim()) { errors.lineItems = 'Each line item needs a description.'; break; }
      if (li.quantity <= 0) { errors.lineItems = 'Quantity must be positive.'; break; }
      if (li.unitCostMicro <= 0) { errors.lineItems = 'Unit cost must be positive.'; break; }
    }
  }

  return errors;
}

// ─── State persistence ───────────────────────────────────────────────────────

const STORAGE_KEY = 'welcome-layer-v1';

export function loadState(fallback: AppState): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as unknown;
    if (
      typeof parsed !== 'object' ||
      parsed === null ||
      !Array.isArray((parsed as AppState).events) ||
      !Array.isArray((parsed as AppState).contributions)
    ) {
      console.warn('Welcome Layer: stored state is malformed — using defaults.');
      return fallback;
    }
    const state = parsed as AppState;
    if (state.schemaVersion !== SCHEMA_VERSION) {
      console.warn(`Welcome Layer: schema version mismatch (stored ${state.schemaVersion}, expected ${SCHEMA_VERSION}) — using defaults.`);
      return fallback;
    }
    return state;
  } catch (e) {
    console.warn('Welcome Layer: failed to load state —', e);
    return fallback;
  }
}

export function saveState(state: AppState): { ok: true } | { ok: false; error: string } {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

export function clearState(): void {
  localStorage.removeItem(STORAGE_KEY);
}

// ─── Accountability report ───────────────────────────────────────────────────

export function generateReport(state: AppState): AccountabilityReport {
  const allEvents = [...state.events, ...state.draftEvents];
  return {
    generatedAt: new Date().toISOString(),
    schemaVersion: state.schemaVersion,
    disclaimer:
      'This report is a local browser demo. All participants, providers, and prices are fictional. ' +
      'Contributions are simulated Demo USDC — no real funds were transferred. ' +
      'Organizer declarations indicate intent; they do not constitute independent verification of service delivery. ' +
      'This report does not certify that any event is accessible to every person.',
    events: allEvents.map(ev => ({
      id: ev.id,
      title: ev.title,
      date: ev.date,
      improvements: ev.improvements.map(imp => {
        const contribs = state.contributions.filter(c => c.improvementId === imp.id);
        const raised = contribs.filter(c => c.status === 'active').reduce((s, c) => s + c.amountMicro, 0);
        return {
          id: imp.id,
          title: imp.title,
          status: imp.status,
          targetMicro: imp.targetMicro,
          raisedMicro: raised,
          contributions: contribs.map(c => ({
            id: c.id,
            amountMicro: c.amountMicro,
            timestamp: c.timestamp,
            status: c.status,
          })),
          limitations: [
            'Organizer declaration does not prove independent service delivery.',
            'A funded status does not mean the service has been delivered.',
            'No third-party accessibility certification has been made.',
          ],
        };
      }),
    })),
    limitations: [
      'This is a browser-local prototype. No real transactions occurred.',
      'All monetary values are simulated Demo USDC.',
      'No wallet connection, smart contract, or live payment system is involved.',
      'Planned Arc Testnet integration (separate per-improvement escrow, named resolver permissions, timeout handling) is not yet implemented.',
    ],
  };
}

// ─── ID generation ───────────────────────────────────────────────────────────

export function makeId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
