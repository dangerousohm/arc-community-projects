/**
 * Welcome Layer — logic unit tests
 * Tests import from the actual shared production functions in logic.ts.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  parseMicro,
  formatMicro,
  computeTarget,
  raisedMicro,
  remainingMicro,
  contribute,
  processRefunds,
  previewRefunds,
  canTransition,
  applyTransition,
  validateImprovement,
  loadState,
  makeId,
  MICRO_PER_USDC,
} from '../logic';
import type { Improvement, Contribution, QuoteLineItem, AppState, ImprovementStatus } from '../types';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function makeImp(overrides: Partial<Improvement> = {}): Improvement {
  return {
    id: 'imp-test',
    eventId: 'evt-test',
    title: 'Test Improvement',
    description: 'A test service',
    provider: { name: 'test', displayName: 'Test Provider', note: '' },
    lineItems: [{ description: 'Item A', quantity: 1, unitCostMicro: 100 * MICRO_PER_USDC }],
    targetMicro: 100 * MICRO_PER_USDC,
    fundingDeadline: '2026-11-01',
    deliveryDate: '2026-11-15',
    deliveryConfirmation: 'Organiser confirms.',
    participationNote: '',
    status: 'funding',
    isQuoteDemo: true,
    floorX: 50,
    floorY: 50,
    floorZone: 'Test Zone',
    ...overrides,
  };
}

function makeContrib(overrides: Partial<Contribution> = {}): Contribution {
  return {
    id: makeId(),
    improvementId: 'imp-test',
    contributorLabel: 'Tester',
    amountMicro: 10 * MICRO_PER_USDC,
    timestamp: '2026-10-01T00:00:00Z',
    status: 'active',
    ...overrides,
  };
}

const idCounter = { n: 0 };
function testIdFactory() {
  return `test-id-${++idCounter.n}`;
}

// ─── parseMicro ───────────────────────────────────────────────────────────────

describe('parseMicro', () => {
  it('parses a whole number', () => {
    const r = parseMicro('100');
    expect(r).toMatchObject({ ok: true, micro: 100 * MICRO_PER_USDC });
  });

  it('parses a decimal with 2 places', () => {
    const r = parseMicro('5.50');
    expect(r).toMatchObject({ ok: true, micro: 5_500_000 });
  });

  it('parses a decimal with 1 place', () => {
    const r = parseMicro('3.5');
    expect(r).toMatchObject({ ok: true, micro: 3_500_000 });
  });

  it('rejects zero', () => {
    const r = parseMicro('0');
    expect(r.ok).toBe(false);
  });

  it('rejects negative', () => {
    const r = parseMicro('-5');
    expect(r.ok).toBe(false);
  });

  it('rejects more than 2 decimal places', () => {
    const r = parseMicro('1.123');
    expect(r.ok).toBe(false);
  });

  it('rejects non-numeric', () => {
    const r = parseMicro('abc');
    expect(r.ok).toBe(false);
  });

  it('rejects empty string', () => {
    const r = parseMicro('');
    expect(r.ok).toBe(false);
  });

  it('rejects scientific notation (e.g. 1e5)', () => {
    const r = parseMicro('1e5');
    expect(r.ok).toBe(false);
  });

  it('handles exact 6-decimal-safe arithmetic: 1.99 → 1990000 micro', () => {
    const r = parseMicro('1.99');
    expect(r).toMatchObject({ ok: true, micro: 1_990_000 });
  });
});

// ─── formatMicro ─────────────────────────────────────────────────────────────

describe('formatMicro', () => {
  it('formats whole USDC', () => {
    expect(formatMicro(100 * MICRO_PER_USDC)).toBe('100.00');
  });

  it('formats fractional USDC', () => {
    expect(formatMicro(5_500_000)).toBe('5.50');
  });

  it('formats zero', () => {
    expect(formatMicro(0)).toBe('0.00');
  });

  it('formats 1 cent', () => {
    expect(formatMicro(10_000)).toBe('0.01');
  });
});

// ─── computeTarget ───────────────────────────────────────────────────────────

describe('computeTarget', () => {
  it('sums line items correctly', () => {
    const items: QuoteLineItem[] = [
      { description: 'A', quantity: 2, unitCostMicro: 50 * MICRO_PER_USDC },
      { description: 'B', quantity: 1, unitCostMicro: 30 * MICRO_PER_USDC },
    ];
    expect(computeTarget(items)).toBe(130 * MICRO_PER_USDC);
  });

  it('handles empty list', () => {
    expect(computeTarget([])).toBe(0);
  });

  it('handles multiple improvements independently (no cross-item mixing)', () => {
    const items1: QuoteLineItem[] = [{ description: 'X', quantity: 1, unitCostMicro: 100 * MICRO_PER_USDC }];
    const items2: QuoteLineItem[] = [{ description: 'Y', quantity: 1, unitCostMicro: 200 * MICRO_PER_USDC }];
    expect(computeTarget(items1)).toBe(100 * MICRO_PER_USDC);
    expect(computeTarget(items2)).toBe(200 * MICRO_PER_USDC);
  });
});

// ─── raisedMicro / remainingMicro ────────────────────────────────────────────

describe('raisedMicro', () => {
  it('sums only active contributions for a given improvement', () => {
    const contribs: Contribution[] = [
      makeContrib({ amountMicro: 30 * MICRO_PER_USDC, status: 'active' }),
      makeContrib({ amountMicro: 20 * MICRO_PER_USDC, status: 'active' }),
      makeContrib({ amountMicro: 50 * MICRO_PER_USDC, status: 'refunded' }),
      makeContrib({ improvementId: 'other-imp', amountMicro: 100 * MICRO_PER_USDC, status: 'active' }),
    ];
    expect(raisedMicro('imp-test', contribs)).toBe(50 * MICRO_PER_USDC);
  });

  it('returns 0 when no contributions', () => {
    expect(raisedMicro('imp-test', [])).toBe(0);
  });
});

describe('remainingMicro', () => {
  it('returns gap to target', () => {
    const imp = makeImp({ targetMicro: 100 * MICRO_PER_USDC });
    const contribs = [makeContrib({ amountMicro: 60 * MICRO_PER_USDC, status: 'active' })];
    expect(remainingMicro(imp, contribs)).toBe(40 * MICRO_PER_USDC);
  });

  it('returns 0 when exactly funded', () => {
    const imp = makeImp({ targetMicro: 100 * MICRO_PER_USDC });
    const contribs = [makeContrib({ amountMicro: 100 * MICRO_PER_USDC, status: 'active' })];
    expect(remainingMicro(imp, contribs)).toBe(0);
  });

  it('never returns negative (overfund cannot happen via contribute())', () => {
    const imp = makeImp({ targetMicro: 100 * MICRO_PER_USDC });
    const contribs = [makeContrib({ amountMicro: 120 * MICRO_PER_USDC, status: 'active' })];
    expect(remainingMicro(imp, contribs)).toBe(0);
  });
});

// ─── contribute ──────────────────────────────────────────────────────────────

describe('contribute', () => {
  it('accepts a valid contribution', () => {
    const imp = makeImp();
    const result = contribute(imp, [], '25', 'Alice', testIdFactory);
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.contribution.amountMicro).toBe(25 * MICRO_PER_USDC);
      expect(result.contribution.status).toBe('active');
    }
  });

  it('rejects contribution when status is not funding', () => {
    const imp = makeImp({ status: 'funded' });
    const result = contribute(imp, [], '10', 'Alice', testIdFactory);
    expect(result.ok).toBe(false);
  });

  it('rejects zero amount', () => {
    const imp = makeImp();
    const result = contribute(imp, [], '0', 'Alice', testIdFactory);
    expect(result.ok).toBe(false);
  });

  it('rejects negative amount', () => {
    const imp = makeImp();
    const result = contribute(imp, [], '-5', 'Alice', testIdFactory);
    expect(result.ok).toBe(false);
  });

  it('rejects over-precise amount (3 decimals)', () => {
    const imp = makeImp();
    const result = contribute(imp, [], '1.123', 'Alice', testIdFactory);
    expect(result.ok).toBe(false);
  });

  it('rejects amount over remaining gap', () => {
    const imp = makeImp({ targetMicro: 50 * MICRO_PER_USDC });
    const existing = [makeContrib({ amountMicro: 40 * MICRO_PER_USDC })];
    const result = contribute(imp, existing, '20', 'Alice', testIdFactory);
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error).toMatch(/exceed/i);
    }
  });

  it('accepts exact remaining amount', () => {
    const imp = makeImp({ targetMicro: 50 * MICRO_PER_USDC });
    const existing = [makeContrib({ amountMicro: 30 * MICRO_PER_USDC })];
    const result = contribute(imp, existing, '20', 'Alice', testIdFactory);
    expect(result.ok).toBe(true);
  });

  it('partial funding — two contributions total target', () => {
    const imp = makeImp({ targetMicro: 100 * MICRO_PER_USDC });
    const r1 = contribute(imp, [], '60', 'Alice', testIdFactory);
    expect(r1.ok).toBe(true);
    if (!r1.ok) return;
    const contribs1 = [r1.contribution];
    const r2 = contribute(imp, contribs1, '40', 'Bob', testIdFactory);
    expect(r2.ok).toBe(true);
    if (!r2.ok) return;
    const total = raisedMicro(imp.id, [r1.contribution, r2.contribution]);
    expect(total).toBe(100 * MICRO_PER_USDC);
  });

  it('rejects malformed input', () => {
    const imp = makeImp();
    expect(contribute(imp, [], 'not-a-number', 'A', testIdFactory).ok).toBe(false);
    expect(contribute(imp, [], '', 'A', testIdFactory).ok).toBe(false);
    expect(contribute(imp, [], '1e5', 'A', testIdFactory).ok).toBe(false);
  });
});

// ─── State transitions ────────────────────────────────────────────────────────

describe('canTransition', () => {
  const validTransitions: Array<[ImprovementStatus, ImprovementStatus]> = [
    ['draft', 'funding'],
    ['draft', 'cancelled'],
    ['funding', 'funded'],
    ['funding', 'cancelled'],
    ['funded', 'ready'],
    ['funded', 'cancelled'],
    ['cancelled', 'refunded'],
  ];

  const invalidTransitions: Array<[ImprovementStatus, ImprovementStatus]> = [
    ['ready', 'funding'],
    ['ready', 'funded'],
    ['ready', 'cancelled'],
    ['refunded', 'funding'],
    ['refunded', 'cancelled'],
    ['funded', 'draft'],
    ['funding', 'draft'],
    ['cancelled', 'funding'],
  ];

  for (const [from, to] of validTransitions) {
    it(`allows ${from} → ${to}`, () => {
      expect(canTransition(from, to)).toBe(true);
    });
  }

  for (const [from, to] of invalidTransitions) {
    it(`rejects ${from} → ${to}`, () => {
      expect(canTransition(from, to)).toBe(false);
    });
  }
});

describe('applyTransition', () => {
  it('succeeds on valid transition', () => {
    const imp = makeImp({ status: 'draft' });
    expect(applyTransition(imp, 'funding').ok).toBe(true);
  });

  it('fails on invalid transition', () => {
    const imp = makeImp({ status: 'ready' });
    const r = applyTransition(imp, 'cancelled');
    expect(r.ok).toBe(false);
  });
});

// ─── Refunds ─────────────────────────────────────────────────────────────────

describe('processRefunds', () => {
  let contribs: Contribution[];

  beforeEach(() => {
    contribs = [
      makeContrib({ id: 'c1', amountMicro: 30 * MICRO_PER_USDC, status: 'active' }),
      makeContrib({ id: 'c2', amountMicro: 20 * MICRO_PER_USDC, status: 'active' }),
      makeContrib({ id: 'c3', amountMicro: 10 * MICRO_PER_USDC, improvementId: 'other', status: 'active' }),
    ];
  });

  it('marks all active contributions for imp-test as refunded', () => {
    const updated = processRefunds('imp-test', contribs, '2026-11-01T00:00:00Z');
    const impContribs = updated.filter(c => c.improvementId === 'imp-test');
    expect(impContribs.every(c => c.status === 'refunded')).toBe(true);
  });

  it('does not touch contributions for other improvements', () => {
    const updated = processRefunds('imp-test', contribs, '2026-11-01T00:00:00Z');
    const other = updated.find(c => c.id === 'c3');
    expect(other?.status).toBe('active');
  });

  it('idempotent — already-refunded contributions are not double-refunded', () => {
    const once = processRefunds('imp-test', contribs, '2026-11-01T00:00:00Z');
    const twice = processRefunds('imp-test', once, '2026-11-02T00:00:00Z');
    // refundedAt should be the first date, not the second
    const c1 = twice.find(c => c.id === 'c1');
    expect(c1?.refundedAt).toBe('2026-11-01T00:00:00Z');
    expect(c1?.status).toBe('refunded');
  });

  it('each contribution refunded exactly once', () => {
    const updated = processRefunds('imp-test', contribs, '2026-11-01T00:00:00Z');
    const refundedIds = updated.filter(c => c.status === 'refunded').map(c => c.id);
    const unique = new Set(refundedIds);
    expect(refundedIds.length).toBe(unique.size);
  });

  it('no cross-item balance mixing — other improvement total unchanged', () => {
    const updated = processRefunds('imp-test', contribs, '2026-11-01T00:00:00Z');
    const otherRaised = raisedMicro('other', updated);
    expect(otherRaised).toBe(10 * MICRO_PER_USDC);
  });
});

describe('previewRefunds', () => {
  it('returns correct preview including already-refunded', () => {
    const contribs: Contribution[] = [
      makeContrib({ id: 'c1', status: 'active', amountMicro: 50 * MICRO_PER_USDC }),
      makeContrib({ id: 'c2', status: 'refunded', amountMicro: 25 * MICRO_PER_USDC }),
    ];
    const preview = previewRefunds('imp-test', contribs);
    expect(preview).toHaveLength(2);
    expect(preview.find(p => p.amountMicro === 50 * MICRO_PER_USDC)?.alreadyRefunded).toBe(false);
    expect(preview.find(p => p.amountMicro === 25 * MICRO_PER_USDC)?.alreadyRefunded).toBe(true);
  });
});

// ─── validateImprovement ──────────────────────────────────────────────────────

describe('validateImprovement', () => {
  const valid: Partial<import('../types').Improvement> = {
    title: 'Live Captions',
    description: 'Real-time captions for the talk.',
    provider: { name: 'test', displayName: 'Test Co', note: '' },
    fundingDeadline: '2026-11-01',
    deliveryDate: '2026-11-15',
    deliveryConfirmation: 'Organiser confirms.',
    lineItems: [{ description: 'Item A', quantity: 1, unitCostMicro: 100 * MICRO_PER_USDC }],
  };

  it('returns no errors for valid data', () => {
    const errs = validateImprovement(valid);
    expect(Object.keys(errs)).toHaveLength(0);
  });

  it('requires title', () => {
    const errs = validateImprovement({ ...valid, title: '' });
    expect(errs.title).toBeTruthy();
  });

  it('requires description', () => {
    const errs = validateImprovement({ ...valid, description: '' });
    expect(errs.description).toBeTruthy();
  });

  it('requires provider display name', () => {
    const errs = validateImprovement({ ...valid, provider: { name: '', displayName: '', note: '' } });
    expect(errs.providerName).toBeTruthy();
  });

  it('requires funding deadline', () => {
    const errs = validateImprovement({ ...valid, fundingDeadline: '' });
    expect(errs.fundingDeadline).toBeTruthy();
  });

  it('rejects delivery date before funding deadline', () => {
    const errs = validateImprovement({ ...valid, fundingDeadline: '2026-11-15', deliveryDate: '2026-11-01' });
    expect(errs.deliveryDate).toBeTruthy();
  });

  it('accepts delivery date equal to funding deadline', () => {
    const errs = validateImprovement({ ...valid, fundingDeadline: '2026-11-01', deliveryDate: '2026-11-01' });
    expect(errs.deliveryDate).toBeUndefined();
  });

  it('requires at least one line item', () => {
    const errs = validateImprovement({ ...valid, lineItems: [] });
    expect(errs.lineItems).toBeTruthy();
  });

  it('requires delivery confirmation', () => {
    const errs = validateImprovement({ ...valid, deliveryConfirmation: '' });
    expect(errs.deliveryConfirmation).toBeTruthy();
  });
});

// ─── loadState (malformed data) ───────────────────────────────────────────────

describe('loadState', () => {
  it('returns fallback on null', () => {
    const fallback: AppState = {
      events: [], contributions: [], draftEvents: [], schemaVersion: 1,
    };
    // Pass a JSON string that parses to null-equivalent
    const result = loadState(fallback);
    // Without actual localStorage manipulation, just confirm it returns the same shape
    expect(result).toHaveProperty('events');
    expect(result).toHaveProperty('contributions');
  });
});

// ─── Multiple improvements — no cross-item mixing ────────────────────────────

describe('multiple improvements independence', () => {
  it('contributions to imp-A do not affect balance of imp-B', () => {
    const impA = makeImp({ id: 'imp-A', targetMicro: 100 * MICRO_PER_USDC });
    const impB = makeImp({ id: 'imp-B', targetMicro: 200 * MICRO_PER_USDC });

    const contribA = makeContrib({ id: 'cA', improvementId: 'imp-A', amountMicro: 80 * MICRO_PER_USDC });
    const contribB = makeContrib({ id: 'cB', improvementId: 'imp-B', amountMicro: 50 * MICRO_PER_USDC });
    const all = [contribA, contribB];

    expect(raisedMicro('imp-A', all)).toBe(80 * MICRO_PER_USDC);
    expect(remainingMicro(impA, all)).toBe(20 * MICRO_PER_USDC);
    expect(raisedMicro('imp-B', all)).toBe(50 * MICRO_PER_USDC);
    expect(remainingMicro(impB, all)).toBe(150 * MICRO_PER_USDC);
  });

  it('cancelling imp-A refunds only imp-A contributions', () => {
    const contribA = makeContrib({ id: 'cA', improvementId: 'imp-A', amountMicro: 80 * MICRO_PER_USDC });
    const contribB = makeContrib({ id: 'cB', improvementId: 'imp-B', amountMicro: 50 * MICRO_PER_USDC });
    const updated = processRefunds('imp-A', [contribA, contribB]);
    expect(updated.find(c => c.id === 'cA')?.status).toBe('refunded');
    expect(updated.find(c => c.id === 'cB')?.status).toBe('active');
  });
});

// ─── Cancellation before/after funding ───────────────────────────────────────

describe('cancellation', () => {
  it('can cancel from draft (before funding)', () => {
    expect(canTransition('draft', 'cancelled')).toBe(true);
  });

  it('can cancel during funding', () => {
    expect(canTransition('funding', 'cancelled')).toBe(true);
  });

  it('can cancel after funded (before ready)', () => {
    expect(canTransition('funded', 'cancelled')).toBe(true);
  });

  it('cannot cancel once ready (terminal)', () => {
    expect(canTransition('ready', 'cancelled')).toBe(false);
  });

  it('cannot cancel once refunded (terminal)', () => {
    expect(canTransition('refunded', 'cancelled')).toBe(false);
  });
});
