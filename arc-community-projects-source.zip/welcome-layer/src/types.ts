/**
 * Welcome Layer — shared types
 * All monetary values stored as integer micro-USDC (1 USDC = 1_000_000 micro).
 */

export type ImprovementStatus =
  | 'draft'       // created, not yet open for funding
  | 'funding'     // accepting contributions
  | 'funded'      // target reached, awaiting delivery
  | 'ready'       // organizer declared service ready/delivered
  | 'cancelled'   // cancelled, refunds available
  | 'refunded';   // all contributions returned

export type ContributionStatus = 'active' | 'refunded';

export interface Provider {
  name: string;
  displayName: string;
  note: string;
}

export interface QuoteLineItem {
  description: string;
  quantity: number;
  unitCostMicro: number; // micro-USDC
}

/** A single service/improvement on an event */
export interface Improvement {
  id: string;
  eventId: string;
  title: string;
  description: string;        // plain text, rendered as text
  provider: Provider;
  lineItems: QuoteLineItem[];
  targetMicro: number;        // sum of lineItems, validated
  fundingDeadline: string;    // ISO date
  deliveryDate: string;       // ISO date, must be >= fundingDeadline
  deliveryConfirmation: string; // how delivery will be confirmed
  participationNote: string;  // optional, no personal medical details
  status: ImprovementStatus;
  isQuoteDemo: boolean;       // true = demo estimate, not a real quote
  // Floor plan position (0–100 percentage coordinates)
  floorX: number;
  floorY: number;
  floorZone: string;          // e.g. "Main Screen", "Lobby"
}

/** A simulated contribution */
export interface Contribution {
  id: string;
  improvementId: string;
  contributorLabel: string;   // demo label only, no real identity
  amountMicro: number;
  timestamp: string;          // ISO
  status: ContributionStatus;
  refundedAt?: string;        // ISO, set when refunded
}

/** An event */
export interface WelcomeEvent {
  id: string;
  title: string;
  description: string;
  date: string;               // ISO date
  location: string;
  floorPlanId: string;        // which SVG floor plan to render
  improvements: Improvement[];
}

/** Persisted app state */
export interface AppState {
  events: WelcomeEvent[];
  contributions: Contribution[];
  draftEvents: WelcomeEvent[];  // locally created drafts
  schemaVersion: number;
}

/** Accountability report shape */
export interface AccountabilityReport {
  generatedAt: string;
  schemaVersion: number;
  disclaimer: string;
  events: Array<{
    id: string;
    title: string;
    date: string;
    improvements: Array<{
      id: string;
      title: string;
      status: ImprovementStatus;
      targetMicro: number;
      raisedMicro: number;
      contributions: Array<{
        id: string;
        amountMicro: number;
        timestamp: string;
        status: ContributionStatus;
      }>;
      deliveryDeclaredAt?: string;
      limitations: string[];
    }>;
  }>;
  limitations: string[];
}

/** Result of a contribution attempt */
export type ContributeResult =
  | { ok: true; contribution: Contribution }
  | { ok: false; error: string };

/** Result of a state transition */
export type TransitionResult =
  | { ok: true }
  | { ok: false; error: string };

/** Validation error for improvement fields */
export interface ValidationErrors {
  [field: string]: string;
}
