import { useState, useMemo } from 'react';
import { MapPin, List, Filter, Info, X, ChevronRight, Calendar, Clock } from 'lucide-react';
import type { WelcomeEvent, Improvement, ImprovementStatus } from '../types';
import { raisedMicro, remainingMicro, formatMicro } from '../logic';
import type { Contribution } from '../types';
import StatusBadge from '../components/StatusBadge';
import FloorPlanHall from '../components/FloorPlanHall';
import FloorPlanPavilion from '../components/FloorPlanPavilion';
import FloorPlanStudio from '../components/FloorPlanStudio';
import ServiceMarker from '../components/ServiceMarker';

const FLOOR_PLAN_COMPONENTS = {
  hall: FloorPlanHall,
  pavilion: FloorPlanPavilion,
  studio: FloorPlanStudio,
};

const ALL_STATUSES: ImprovementStatus[] = ['draft', 'funding', 'funded', 'ready', 'cancelled', 'refunded'];
const STATUS_LABELS: Record<ImprovementStatus, string> = {
  draft: 'Draft',
  funding: 'Needs Funding',
  funded: 'Funded — Pending',
  ready: 'Organiser: Ready',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
};

interface Props {
  events: WelcomeEvent[];
  contributions: Contribution[];
  onSelectImprovement: (eventId: string, impId: string) => void;
}

export default function EventPlan({ events, contributions, onSelectImprovement }: Props) {
  const [selectedEventId, setSelectedEventId] = useState<string>(events[0]?.id ?? '');
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [selectedImpId, setSelectedImpId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<ImprovementStatus | 'all'>('all');
  const [showFilters, setShowFilters] = useState(false);

  const event = events.find(e => e.id === selectedEventId) ?? events[0];

  const filteredImps = useMemo(() => {
    if (!event) return [];
    return event.improvements.filter(
      imp => filterStatus === 'all' || imp.status === filterStatus,
    );
  }, [event, filterStatus]);

  const selectedImp = event?.improvements.find(i => i.id === selectedImpId) ?? null;

  function handleMarkerClick(imp: Improvement) {
    setSelectedImpId(prev => (prev === imp.id ? null : imp.id));
  }

  const FloorPlanComp = FLOOR_PLAN_COMPONENTS[event?.floorPlanId as keyof typeof FLOOR_PLAN_COMPONENTS] ?? FloorPlanHall;

  return (
    <div className="space-y-4">
      {/* Event selector */}
      <div className="bg-white rounded-2xl border border-[var(--border)] p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Calendar size={16} className="text-[var(--muted)]" />
          <span className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)]">Select Event</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {events.map(ev => (
            <button
              key={ev.id}
              onClick={() => { setSelectedEventId(ev.id); setSelectedImpId(null); }}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all border focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-1 ${
                selectedEventId === ev.id
                  ? 'bg-[var(--accent)] text-white border-[var(--accent)]'
                  : 'bg-[var(--surface-muted)] text-[var(--ink-2)] border-[var(--border)] hover:border-[var(--accent)]'
              }`}
            >
              {ev.title}
            </button>
          ))}
        </div>
        {event && (
          <div className="mt-3 flex flex-wrap gap-4 text-xs text-[var(--muted)]">
            <span className="flex items-center gap-1"><Calendar size={12} /> {event.date}</span>
            <span className="flex items-center gap-1"><MapPin size={12} /> {event.location}</span>
          </div>
        )}
        <p className="mt-2 text-xs text-[var(--subtle)] italic">
          Note: This event listing does not indicate that any event is universally accessible. Improvements are individual services, not an accessibility certification.
        </p>
      </div>

      {/* View toggle + filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex rounded-xl border border-[var(--border)] overflow-hidden bg-white shadow-sm">
          <button
            onClick={() => setViewMode('map')}
            aria-pressed={viewMode === 'map'}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${viewMode === 'map' ? 'bg-[var(--accent)] text-white' : 'text-[var(--ink-2)] hover:bg-[var(--surface-muted)]'}`}
          >
            <MapPin size={14} /> Map
          </button>
          <button
            onClick={() => setViewMode('list')}
            aria-pressed={viewMode === 'list'}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${viewMode === 'list' ? 'bg-[var(--accent)] text-white' : 'text-[var(--ink-2)] hover:bg-[var(--surface-muted)]'}`}
          >
            <List size={14} /> List
          </button>
        </div>

        <button
          onClick={() => setShowFilters(f => !f)}
          aria-expanded={showFilters}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[var(--border)] bg-white text-sm font-medium text-[var(--ink-2)] hover:bg-[var(--surface-muted)] transition-colors shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]"
        >
          <Filter size={14} />
          {filterStatus === 'all' ? 'All statuses' : STATUS_LABELS[filterStatus]}
        </button>

        <span className="ml-auto text-xs text-[var(--muted)] tabular-nums">
          {filteredImps.length} improvement{filteredImps.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Filter panel */}
      {showFilters && (
        <div className="bg-white rounded-2xl border border-[var(--border)] p-4 shadow-sm">
          <div className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-3">Filter by status</div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => { setFilterStatus('all'); setShowFilters(false); }}
              className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${filterStatus === 'all' ? 'bg-[var(--accent)] text-white border-[var(--accent)]' : 'bg-[var(--surface-muted)] text-[var(--ink-2)] border-[var(--border)] hover:border-[var(--accent)]'}`}
            >
              All
            </button>
            {ALL_STATUSES.map(s => (
              <button
                key={s}
                onClick={() => { setFilterStatus(s); setShowFilters(false); }}
                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${filterStatus === s ? 'bg-[var(--accent)] text-white border-[var(--accent)]' : 'bg-[var(--surface-muted)] text-[var(--ink-2)] border-[var(--border)] hover:border-[var(--accent)]'}`}
              >
                {STATUS_LABELS[s]}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Map view */}
      {viewMode === 'map' && event && (
        <div className="bg-white rounded-2xl border border-[var(--border)] p-4 shadow-sm overflow-hidden">
          <div className="flex items-center gap-2 mb-3">
            <MapPin size={15} className="text-cobalt" />
            <span className="text-sm font-semibold text-[var(--ink)]">Floor Plan</span>
            <span className="text-xs text-[var(--muted)] ml-1">— select a marker to view details</span>
          </div>
          <div className="relative rounded-xl overflow-hidden border border-[var(--border)]">
            <FloorPlanComp>
              {event.improvements
                .filter(imp => filterStatus === 'all' || imp.status === filterStatus)
                .map(imp => (
                  <ServiceMarker
                    key={imp.id}
                    improvement={imp}
                    selected={selectedImpId === imp.id}
                    onClick={() => handleMarkerClick(imp)}
                  />
                ))}
            </FloorPlanComp>
          </div>
          {/* Legend */}
          <div className="mt-3 flex flex-wrap gap-3">
            {[
              { status: 'funding', color: '#F59E0B', label: 'Needs Funding' },
              { status: 'funded',  color: '#38BDF8', label: 'Funded' },
              { status: 'ready',   color: '#4ADE80', label: 'Organiser: Ready' },
              { status: 'cancelled', color: '#F87171', label: 'Cancelled' },
              { status: 'draft',   color: '#94A3B8', label: 'Draft' },
            ].map(l => (
              <span key={l.status} className="flex items-center gap-1 text-xs text-[var(--muted)]">
                <span className="w-3 h-3 rounded-full inline-block" style={{ background: l.color }} />
                {l.label}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* List view */}
      {viewMode === 'list' && event && (
        <div className="space-y-2">
          {filteredImps.length === 0 && (
            <div className="bg-white rounded-2xl border border-[var(--border)] p-8 text-center text-[var(--muted)] text-sm">
              No improvements match this filter.
            </div>
          )}
          {filteredImps.map(imp => {
            const raised = raisedMicro(imp.id, contributions);
            const target = imp.targetMicro;
            const pct = target > 0 ? Math.min(100, Math.round((raised / target) * 100)) : 0;
            return (
              <button
                key={imp.id}
                onClick={() => setSelectedImpId(prev => prev === imp.id ? null : imp.id)}
                aria-pressed={selectedImpId === imp.id}
                className="w-full text-left bg-white rounded-2xl border border-[var(--border)] p-4 hover:border-cobalt/40 transition-all shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-sm font-semibold text-[var(--ink)] truncate">{imp.title}</span>
                      <StatusBadge status={imp.status} size="sm" />
                    </div>
                    <p className="text-xs text-[var(--muted)] mb-2 line-clamp-2">{imp.description}</p>
                    {/* Progress bar */}
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-[var(--surface-muted)] rounded-full h-1.5 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${pct}%`,
                            background: imp.status === 'ready' ? '#4ADE80' :
                                        imp.status === 'cancelled' ? '#F87171' :
                                        '#2563EB',
                          }}
                        />
                      </div>
                      <span className="text-xs tabular-nums text-[var(--muted)] whitespace-nowrap">
                        Demo USDC {formatMicro(raised)} / {formatMicro(target)}
                      </span>
                    </div>
                  </div>
                  <ChevronRight
                    size={16}
                    className={`flex-shrink-0 mt-1 text-[var(--muted)] transition-transform ${selectedImpId === imp.id ? 'rotate-90' : ''}`}
                  />
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Detail panel */}
      {selectedImp && (
        <ImprovementDetail
          improvement={selectedImp}
          contributions={contributions}
          onClose={() => setSelectedImpId(null)}
          onSupport={() => onSelectImprovement(event.id, selectedImp.id)}
        />
      )}
    </div>
  );
}

// ─── Detail panel ────────────────────────────────────────────────────────────

function ImprovementDetail({
  improvement: imp,
  contributions,
  onClose,
  onSupport,
}: {
  improvement: Improvement;
  contributions: Contribution[];
  onClose: () => void;
  onSupport: () => void;
}) {
  const raised = raisedMicro(imp.id, contributions);
  const target = imp.targetMicro;
  const remaining = remainingMicro(imp, contributions);
  const pct = target > 0 ? Math.min(100, Math.round((raised / target) * 100)) : 0;

  return (
    <div
      className="bg-white rounded-2xl border border-[var(--border)] shadow-lg overflow-hidden"
      role="region"
      aria-label={`Details for ${imp.title}`}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 p-5 border-b border-[var(--border)]">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <h3 className="text-base font-semibold text-[var(--ink)] display">{imp.title}</h3>
            <StatusBadge status={imp.status} />
          </div>
          <p className="text-xs text-[var(--muted)]">{imp.floorZone}</p>
        </div>
        <button
          onClick={onClose}
          aria-label="Close details"
          className="flex-shrink-0 rounded-lg p-1.5 text-[var(--muted)] hover:bg-[var(--surface-muted)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]"
        >
          <X size={16} />
        </button>
      </div>

      <div className="p-5 space-y-5">
        {/* Purpose */}
        <section>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-2">Purpose</h4>
          <p className="text-sm text-[var(--ink-2)] text-pretty leading-relaxed">{imp.description}</p>
        </section>

        {/* Participation note */}
        {imp.participationNote && (
          <section className="bg-[#EFF6FF] rounded-xl p-4 flex gap-3">
            <Info size={15} className="flex-shrink-0 text-[#2563EB] mt-0.5" />
            <p className="text-xs text-[#1E40AF] leading-relaxed">{imp.participationNote}</p>
          </section>
        )}

        {/* Provider */}
        <section>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-2">Proposed Provider</h4>
          <p className="text-sm font-medium text-[var(--ink)]">{imp.provider.displayName}</p>
          {imp.isQuoteDemo && (
            <p className="text-xs text-[#92400E] bg-[#FEF3C7] rounded-lg px-3 py-2 mt-2 border border-[#FDE68A]">
              Demo estimate only — not a real or agreed quote.
            </p>
          )}
        </section>

        {/* Itemised quote */}
        <section>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-2">Itemised Quote</h4>
          <div className="rounded-xl overflow-hidden border border-[var(--border)]">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[var(--surface-muted)] text-[var(--muted)]">
                  <th className="text-left py-2 px-3 font-semibold">Item</th>
                  <th className="text-right py-2 px-3 font-semibold tabular-nums">Qty</th>
                  <th className="text-right py-2 px-3 font-semibold tabular-nums">Unit</th>
                  <th className="text-right py-2 px-3 font-semibold tabular-nums">Total</th>
                </tr>
              </thead>
              <tbody>
                {imp.lineItems.map((li, i) => (
                  <tr key={i} className="border-t border-[var(--border)]">
                    <td className="py-2 px-3 text-[var(--ink-2)]">{li.description}</td>
                    <td className="py-2 px-3 text-right tabular-nums text-[var(--ink-2)]">{li.quantity}</td>
                    <td className="py-2 px-3 text-right tabular-nums text-[var(--ink-2)]">{formatMicro(li.unitCostMicro)}</td>
                    <td className="py-2 px-3 text-right tabular-nums font-medium text-[var(--ink)]">{formatMicro(li.quantity * li.unitCostMicro)}</td>
                  </tr>
                ))}
                <tr className="border-t-2 border-[var(--border)] bg-[var(--surface-muted)]">
                  <td colSpan={3} className="py-2 px-3 font-semibold text-[var(--ink)]">Total (Demo USDC)</td>
                  <td className="py-2 px-3 text-right tabular-nums font-bold text-[var(--ink)]">{formatMicro(target)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* Funding progress */}
        <section>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-2">Funding Progress</h4>
          <div className="bg-[var(--surface-muted)] rounded-xl p-4 space-y-3">
            <div className="w-full bg-white rounded-full h-3 overflow-hidden border border-[var(--border)]">
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: `${pct}%`,
                  background: imp.status === 'ready' ? '#4ADE80' :
                              imp.status === 'cancelled' ? '#F87171' :
                              'linear-gradient(90deg, #2563EB, #38BDF8)',
                }}
                role="progressbar"
                aria-valuenow={pct}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={`${pct}% funded`}
              />
            </div>
            <div className="flex justify-between text-xs tabular-nums">
              <span className="text-[var(--muted)]">Raised: <span className="font-semibold text-[var(--ink)]">Demo USDC {formatMicro(raised)}</span></span>
              <span className="text-[var(--muted)]">Target: <span className="font-semibold text-[var(--ink)]">Demo USDC {formatMicro(target)}</span></span>
            </div>
            {remaining > 0 && imp.status === 'funding' && (
              <p className="text-xs text-[var(--muted)]">
                Remaining gap: <span className="font-semibold text-[var(--ink)] tabular-nums">Demo USDC {formatMicro(remaining)}</span>
              </p>
            )}
          </div>
        </section>

        {/* Dates */}
        <section className="grid grid-cols-2 gap-3">
          <div className="bg-[var(--surface-muted)] rounded-xl p-3">
            <div className="flex items-center gap-1.5 mb-1">
              <Clock size={12} className="text-[var(--muted)]" />
              <span className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)]">Funding Deadline</span>
            </div>
            <p className="text-sm font-medium text-[var(--ink)] tabular-nums">{imp.fundingDeadline}</p>
          </div>
          <div className="bg-[var(--surface-muted)] rounded-xl p-3">
            <div className="flex items-center gap-1.5 mb-1">
              <Calendar size={12} className="text-[var(--muted)]" />
              <span className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)]">Planned Delivery</span>
            </div>
            <p className="text-sm font-medium text-[var(--ink)] tabular-nums">{imp.deliveryDate}</p>
          </div>
        </section>

        {/* Delivery plan */}
        <section>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-2">How Delivery Will Be Confirmed</h4>
          <p className="text-sm text-[var(--ink-2)] text-pretty">{imp.deliveryConfirmation}</p>
          <p className="text-xs text-[var(--subtle)] mt-2 italic">
            Organiser declaration does not constitute independent verification of service delivery. Funding complete does not automatically mean the service has been delivered.
          </p>
        </section>

        {/* CTA */}
        {imp.status === 'funding' && (
          <button
            onClick={onSupport}
            className="w-full py-3 rounded-xl bg-[var(--accent)] text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2 active:scale-[0.98]"
          >
            Simulate Support — Demo USDC
          </button>
        )}
      </div>
    </div>
  );
}
