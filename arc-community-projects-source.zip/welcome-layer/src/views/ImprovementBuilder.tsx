import { useState, useId } from 'react';
import { Plus, Trash2, AlertCircle, CheckCircle, Info, ChevronDown, ChevronUp } from 'lucide-react';
import type { WelcomeEvent, Improvement, QuoteLineItem } from '../types';
import {
  validateImprovement,
  computeTarget,
  formatMicro,
  parseMicro,
  makeId,
  MICRO_PER_USDC,
} from '../logic';

interface Props {
  draftEvents: WelcomeEvent[];
  onSaveDraft: (event: WelcomeEvent) => void;
  onDeleteDraft: (eventId: string) => void;
}

const EMPTY_LINE_ITEM = (): QuoteLineItem => ({
  description: '',
  quantity: 1,
  unitCostMicro: 10 * MICRO_PER_USDC,
});

const EMPTY_IMP = (eventId: string): Partial<Improvement> => ({
  id: makeId(),
  eventId,
  title: '',
  description: '',
  provider: { name: '', displayName: '', note: '' },
  lineItems: [EMPTY_LINE_ITEM()],
  fundingDeadline: '',
  deliveryDate: '',
  deliveryConfirmation: '',
  participationNote: '',
  status: 'draft' as const,
  isQuoteDemo: true,
  floorX: 50,
  floorY: 50,
  floorZone: '',
});

const EMPTY_EVENT = (): WelcomeEvent => ({
  id: makeId(),
  title: '',
  description: '',
  date: '',
  location: '',
  floorPlanId: 'hall',
  improvements: [],
});

export default function ImprovementBuilder({ draftEvents, onSaveDraft, onDeleteDraft }: Props) {
  const formId = useId();
  const [mode, setMode] = useState<'list' | 'newEvent' | 'addImp'>('list');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(
    draftEvents[0]?.id ?? null,
  );
  const [eventDraft, setEventDraft] = useState<WelcomeEvent>(EMPTY_EVENT());
  const [impDraft, setImpDraft] = useState<Partial<Improvement>>(EMPTY_IMP(''));
  const [unitCostInputs, setUnitCostInputs] = useState<string[]>(['10.00']);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);
  const [showBudget, setShowBudget] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);

  function startNewEvent() {
    const ev = EMPTY_EVENT();
    setEventDraft(ev);
    setMode('newEvent');
    setErrors({});
    setSaved(false);
  }

  function startAddImp(eventId: string) {
    const imp = EMPTY_IMP(eventId);
    setImpDraft(imp);
    setUnitCostInputs(['10.00']);
    setSelectedEventId(eventId);
    setMode('addImp');
    setErrors({});
    setSaved(false);
    setShowBudget(false);
  }

  function validateAndSaveEvent() {
    const errs: Record<string, string> = {};
    if (!eventDraft.title.trim()) errs.eventTitle = 'Event title is required.';
    if (!eventDraft.date) errs.eventDate = 'Event date is required.';
    if (!eventDraft.location.trim()) errs.eventLocation = 'Location is required.';
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onSaveDraft(eventDraft);
    setSelectedEventId(eventDraft.id);
    setMode('list');
    setSaved(true);
    setErrors({});
  }

  function updateLineItem(i: number, field: keyof QuoteLineItem, value: string | number) {
    const items = [...(impDraft.lineItems ?? [])];
    if (field === 'unitCostMicro') {
      // handled via unitCostInputs
    } else {
      items[i] = { ...items[i], [field]: field === 'quantity' ? Number(value) : value };
    }
    setImpDraft(d => ({ ...d, lineItems: items }));
  }

  function updateUnitCost(i: number, raw: string) {
    const inputs = [...unitCostInputs];
    inputs[i] = raw;
    setUnitCostInputs(inputs);
    // parse immediately to update micro
    const parsed = parseMicro(raw);
    const items = [...(impDraft.lineItems ?? [])];
    if (parsed.ok) {
      items[i] = { ...items[i], unitCostMicro: parsed.micro };
    } else {
      items[i] = { ...items[i], unitCostMicro: 0 };
    }
    setImpDraft(d => ({ ...d, lineItems: items }));
  }

  function addLineItem() {
    setImpDraft(d => ({ ...d, lineItems: [...(d.lineItems ?? []), EMPTY_LINE_ITEM()] }));
    setUnitCostInputs(v => [...v, '10.00']);
  }

  function removeLineItem(i: number) {
    setImpDraft(d => ({ ...d, lineItems: (d.lineItems ?? []).filter((_, j) => j !== i) }));
    setUnitCostInputs(v => v.filter((_, j) => j !== i));
  }

  function validateAndSaveImp() {
    const target = computeTarget(impDraft.lineItems ?? []);
    const fullImp: Partial<Improvement> = { ...impDraft, targetMicro: target };
    const errs = validateImprovement(fullImp);
    // also validate unit cost inputs
    unitCostInputs.forEach((raw, i) => {
      const p = parseMicro(raw);
      if (!p.ok) errs[`lineItem_${i}_cost`] = `Line ${i + 1}: ${p.error}`;
    });
    if (Object.keys(errs).length) { setErrors(errs); setShowBudget(false); return; }
    setErrors({});
    setShowBudget(true);
  }

  function confirmSaveImp() {
    const target = computeTarget(impDraft.lineItems ?? []);
    const full: Improvement = {
      id: impDraft.id ?? makeId(),
      eventId: impDraft.eventId ?? selectedEventId ?? '',
      title: impDraft.title ?? '',
      description: impDraft.description ?? '',
      provider: impDraft.provider ?? { name: '', displayName: '', note: '' },
      lineItems: impDraft.lineItems ?? [],
      targetMicro: target,
      fundingDeadline: impDraft.fundingDeadline ?? '',
      deliveryDate: impDraft.deliveryDate ?? '',
      deliveryConfirmation: impDraft.deliveryConfirmation ?? '',
      participationNote: impDraft.participationNote ?? '',
      status: 'draft',
      isQuoteDemo: true,
      floorX: impDraft.floorX ?? 50,
      floorY: impDraft.floorY ?? 50,
      floorZone: impDraft.floorZone ?? '',
    };

    const allDrafts = draftEvents.map(ev => {
      if (ev.id === full.eventId) {
        return { ...ev, improvements: [...ev.improvements, full] };
      }
      return ev;
    });
    // find and save
    const targetEvent = allDrafts.find(ev => ev.id === full.eventId);
    if (targetEvent) onSaveDraft(targetEvent);
    setMode('list');
    setSaved(true);
    setShowBudget(false);
    setErrors({});
  }

  const selectedEvent = draftEvents.find(e => e.id === selectedEventId) ?? null;
  const impTarget = computeTarget(impDraft.lineItems ?? []);

  // ── Render ──────────────────────────────────────────────────────────────────

  if (mode === 'newEvent') {
    return (
      <div className="bg-white rounded-2xl border border-[var(--border)] p-5 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-[var(--ink)] display">New Event Draft</h3>
          <button onClick={() => setMode('list')} className="text-xs text-[var(--muted)] underline hover:text-[var(--ink)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
            Cancel
          </button>
        </div>

        <Field label="Event title" error={errors.eventTitle} htmlFor={`${formId}-title`} required>
          <input
            id={`${formId}-title`}
            type="text"
            value={eventDraft.title}
            onChange={e => setEventDraft(d => ({ ...d, title: e.target.value }))}
            className={inputCls(!!errors.eventTitle)}
            placeholder="e.g. Summer Music Night"
            maxLength={120}
          />
        </Field>

        <Field label="Short description" htmlFor={`${formId}-desc`}>
          <textarea
            id={`${formId}-desc`}
            value={eventDraft.description}
            onChange={e => setEventDraft(d => ({ ...d, description: e.target.value }))}
            rows={2}
            className={inputCls(false)}
            placeholder="Brief description of the event"
            maxLength={400}
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Event date" error={errors.eventDate} htmlFor={`${formId}-date`} required>
            <input
              id={`${formId}-date`}
              type="date"
              value={eventDraft.date}
              onChange={e => setEventDraft(d => ({ ...d, date: e.target.value }))}
              className={inputCls(!!errors.eventDate)}
            />
          </Field>
          <Field label="Floor plan" htmlFor={`${formId}-fp`}>
            <select
              id={`${formId}-fp`}
              value={eventDraft.floorPlanId}
              onChange={e => setEventDraft(d => ({ ...d, floorPlanId: e.target.value }))}
              className={inputCls(false)}
            >
              <option value="hall">Community Hall</option>
              <option value="pavilion">Park Pavilion</option>
              <option value="studio">Library Studio</option>
            </select>
          </Field>
        </div>

        <Field label="Location" error={errors.eventLocation} htmlFor={`${formId}-loc`} required>
          <input
            id={`${formId}-loc`}
            type="text"
            value={eventDraft.location}
            onChange={e => setEventDraft(d => ({ ...d, location: e.target.value }))}
            className={inputCls(!!errors.eventLocation)}
            placeholder="Venue name and address"
            maxLength={200}
          />
        </Field>

        <button
          onClick={validateAndSaveEvent}
          className="w-full py-3 rounded-xl bg-[var(--accent)] text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2"
        >
          Save Event Draft
        </button>
      </div>
    );
  }

  if (mode === 'addImp') {
    return (
      <div className="bg-white rounded-2xl border border-[var(--border)] p-5 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-[var(--ink)] display">Add Improvement</h3>
          <button onClick={() => setMode('list')} className="text-xs text-[var(--muted)] underline hover:text-[var(--ink)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
            Cancel
          </button>
        </div>

        <Field label="Improvement title" error={errors.title} htmlFor={`${formId}-ititle`} required>
          <input id={`${formId}-ititle`} type="text" value={impDraft.title ?? ''}
            onChange={e => setImpDraft(d => ({ ...d, title: e.target.value }))}
            className={inputCls(!!errors.title)} placeholder="e.g. Live Captions for Talk" maxLength={120} />
        </Field>

        <Field label="Plain-language description" error={errors.description} htmlFor={`${formId}-idesc`} required>
          <textarea id={`${formId}-idesc`} value={impDraft.description ?? ''}
            onChange={e => setImpDraft(d => ({ ...d, description: e.target.value }))}
            rows={3} className={inputCls(!!errors.description)}
            placeholder="What does this service do and who does it help?" maxLength={600} />
        </Field>

        <Field label="Provider display name" error={errors.providerName} htmlFor={`${formId}-pname`} required>
          <input id={`${formId}-pname`} type="text" value={impDraft.provider?.displayName ?? ''}
            onChange={e => setImpDraft(d => ({ ...d, provider: { ...(d.provider ?? { name: '', note: '' }), displayName: e.target.value } }))}
            className={inputCls(!!errors.providerName)} placeholder="e.g. City Caption Services" maxLength={120} />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Funding deadline" error={errors.fundingDeadline} htmlFor={`${formId}-fd`} required>
            <input id={`${formId}-fd`} type="date" value={impDraft.fundingDeadline ?? ''}
              onChange={e => setImpDraft(d => ({ ...d, fundingDeadline: e.target.value }))}
              className={inputCls(!!errors.fundingDeadline)} />
          </Field>
          <Field label="Planned delivery date" error={errors.deliveryDate} htmlFor={`${formId}-dd`} required>
            <input id={`${formId}-dd`} type="date" value={impDraft.deliveryDate ?? ''}
              onChange={e => setImpDraft(d => ({ ...d, deliveryDate: e.target.value }))}
              className={inputCls(!!errors.deliveryDate)} />
          </Field>
        </div>
        {errors.deliveryDate && (
          <p className="text-xs text-[var(--danger)] -mt-3 flex items-center gap-1">
            <AlertCircle size={12} /> {errors.deliveryDate}
          </p>
        )}

        <div className="grid grid-cols-2 gap-4">
          <Field label="Floor zone" htmlFor={`${formId}-fzone`}>
            <input id={`${formId}-fzone`} type="text" value={impDraft.floorZone ?? ''}
              onChange={e => setImpDraft(d => ({ ...d, floorZone: e.target.value }))}
              className={inputCls(false)} placeholder="e.g. Main Stage" maxLength={60} />
          </Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Map X %" htmlFor={`${formId}-fx`}>
              <input id={`${formId}-fx`} type="number" min={0} max={100}
                value={impDraft.floorX ?? 50}
                onChange={e => setImpDraft(d => ({ ...d, floorX: Number(e.target.value) }))}
                className={inputCls(false)} />
            </Field>
            <Field label="Map Y %" htmlFor={`${formId}-fy`}>
              <input id={`${formId}-fy`} type="number" min={0} max={100}
                value={impDraft.floorY ?? 50}
                onChange={e => setImpDraft(d => ({ ...d, floorY: Number(e.target.value) }))}
                className={inputCls(false)} />
            </Field>
          </div>
        </div>

        {/* Quote items */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)]">Quote Line Items</h4>
            <span className="text-[10px] text-[#92400E] bg-[#FEF3C7] px-2 py-1 rounded-full border border-[#FDE68A]">Demo estimate — not a real quote</span>
          </div>
          {errors.lineItems && (
            <p className="text-xs text-[var(--danger)] mb-2 flex items-center gap-1"><AlertCircle size={12} />{errors.lineItems}</p>
          )}
          <div className="space-y-2">
            {(impDraft.lineItems ?? []).map((li, i) => (
              <div key={i} className="grid grid-cols-[1fr_60px_90px_32px] gap-2 items-end">
                <div>
                  {i === 0 && <label className="block text-[10px] text-[var(--muted)] mb-1">Description</label>}
                  <input type="text" value={li.description}
                    onChange={e => updateLineItem(i, 'description', e.target.value)}
                    className={inputCls(false)} placeholder="Item description" maxLength={100} />
                </div>
                <div>
                  {i === 0 && <label className="block text-[10px] text-[var(--muted)] mb-1">Qty</label>}
                  <input type="number" min={1} value={li.quantity}
                    onChange={e => updateLineItem(i, 'quantity', e.target.value)}
                    className={inputCls(false)} />
                </div>
                <div>
                  {i === 0 && <label className="block text-[10px] text-[var(--muted)] mb-1">Unit (USDC)</label>}
                  <input type="text" value={unitCostInputs[i] ?? '10.00'}
                    onChange={e => updateUnitCost(i, e.target.value)}
                    className={inputCls(!!errors[`lineItem_${i}_cost`])}
                    placeholder="10.00" />
                  {errors[`lineItem_${i}_cost`] && (
                    <p className="text-[10px] text-[var(--danger)] mt-0.5">{errors[`lineItem_${i}_cost`]}</p>
                  )}
                </div>
                <div className={i === 0 ? 'mt-5' : ''}>
                  <button onClick={() => removeLineItem(i)} disabled={(impDraft.lineItems ?? []).length <= 1}
                    aria-label="Remove line item"
                    className="w-8 h-8 flex items-center justify-center rounded-lg text-[var(--muted)] hover:bg-[#FEE2E2] hover:text-[var(--danger)] disabled:opacity-30 disabled:cursor-not-allowed transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <button onClick={addLineItem}
            className="mt-2 flex items-center gap-1.5 text-xs text-cobalt font-medium px-3 py-1.5 rounded-lg border border-dashed border-cobalt/40 hover:bg-cobalt/5 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
            <Plus size={13} /> Add line item
          </button>
        </div>

        {/* Delivery confirmation */}
        <Field label="How delivery will be confirmed" error={errors.deliveryConfirmation} htmlFor={`${formId}-confirm`} required>
          <textarea id={`${formId}-confirm`} value={impDraft.deliveryConfirmation ?? ''}
            onChange={e => setImpDraft(d => ({ ...d, deliveryConfirmation: e.target.value }))}
            rows={2} className={inputCls(!!errors.deliveryConfirmation)}
            placeholder="e.g. Organiser will photograph service in use and provide a written declaration." maxLength={400} />
        </Field>

        {/* Participation note */}
        <div>
          <Field label="Participation note (optional)" htmlFor={`${formId}-pnote`}>
            <textarea id={`${formId}-pnote`} value={impDraft.participationNote ?? ''}
              onChange={e => setImpDraft(d => ({ ...d, participationNote: e.target.value }))}
              rows={2} className={inputCls(false)}
              placeholder="Who does this service help? Keep it general — no personal medical details." maxLength={400} />
          </Field>
          <div className="mt-1.5 flex items-start gap-2 text-[10px] text-[#6D28D9] bg-[#F5F3FF] rounded-lg p-2.5 border border-[#DDD6FE]">
            <Info size={11} className="flex-shrink-0 mt-0.5" />
            Do not include personal medical details, disability diagnoses, or identifiable participant information.
          </div>
        </div>

        {/* Budget review */}
        {showBudget && (
          <div className="bg-[#F0FDF4] rounded-xl border border-[#BBF7D0] p-4 space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle size={15} className="text-[#166534]" />
              <span className="text-sm font-semibold text-[#166534]">Budget review</span>
            </div>
            <table className="w-full text-xs">
              <tbody>
                {(impDraft.lineItems ?? []).map((li, i) => (
                  <tr key={i} className="border-t border-[#BBF7D0]">
                    <td className="py-1.5 text-[#166534]">{li.description}</td>
                    <td className="py-1.5 text-right tabular-nums text-[#166534]">{li.quantity} × Demo USDC {formatMicro(li.unitCostMicro)}</td>
                    <td className="py-1.5 text-right tabular-nums font-semibold text-[#166534]">Demo USDC {formatMicro(li.quantity * li.unitCostMicro)}</td>
                  </tr>
                ))}
                <tr className="border-t-2 border-[#4ADE80]">
                  <td colSpan={2} className="py-2 font-bold text-[#166534]">Total target</td>
                  <td className="py-2 text-right tabular-nums font-bold text-[#166534]">Demo USDC {formatMicro(impTarget)}</td>
                </tr>
              </tbody>
            </table>
            <p className="text-[10px] text-[#15803D]">Demo estimates only — not real or agreed quotes. Platform fee: Demo USDC 0.00.</p>
            <button onClick={confirmSaveImp}
              className="w-full py-3 rounded-xl bg-[#166534] text-white font-semibold text-sm hover:bg-[#14532D] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2">
              Confirm and Save Improvement
            </button>
            <button onClick={() => setShowBudget(false)}
              className="w-full py-2 rounded-xl bg-white border border-[#BBF7D0] text-[#166534] font-medium text-sm hover:bg-[#F0FDF4] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
              Back to Edit
            </button>
          </div>
        )}

        {!showBudget && (
          <button onClick={validateAndSaveImp}
            className="w-full py-3 rounded-xl bg-[var(--accent)] text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2">
            Review Budget
          </button>
        )}
      </div>
    );
  }

  // ── List view ────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-4">
      {saved && (
        <div className="flex items-center gap-2 bg-[#F0FDF4] border border-[#BBF7D0] rounded-xl px-4 py-3 text-sm text-[#166534]">
          <CheckCircle size={15} />
          Draft saved locally in this browser.
        </div>
      )}

      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-[var(--ink)]">Your Draft Events</h3>
        <button onClick={startNewEvent}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[var(--accent)] text-white text-sm font-medium hover:bg-[var(--accent-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
          <Plus size={14} /> New Event
        </button>
      </div>

      {draftEvents.length === 0 && (
        <div className="bg-white rounded-2xl border border-dashed border-[var(--border)] p-10 text-center">
          <p className="text-[var(--muted)] text-sm">No draft events yet. Create your first to add improvements.</p>
        </div>
      )}

      {draftEvents.map(ev => (
        <div key={ev.id} className="bg-white rounded-2xl border border-[var(--border)] p-5 shadow-sm space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h4 className="font-semibold text-[var(--ink)] text-sm">{ev.title || '(Untitled)'}</h4>
              <p className="text-xs text-[var(--muted)]">{ev.date} — {ev.location || 'No location set'}</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => startAddImp(ev.id)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[var(--surface-muted)] text-[var(--ink-2)] text-xs font-medium hover:bg-cobalt/10 hover:text-cobalt transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                <Plus size={12} /> Add Improvement
              </button>
              {resetConfirm ? (
                <div className="flex items-center gap-1">
                  <button onClick={() => { onDeleteDraft(ev.id); setResetConfirm(false); }}
                    className="text-xs text-[var(--danger)] font-medium px-2 py-1 rounded hover:bg-[#FEE2E2] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                    Delete
                  </button>
                  <button onClick={() => setResetConfirm(false)}
                    className="text-xs text-[var(--muted)] px-2 py-1 rounded hover:bg-[var(--surface-muted)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                    Cancel
                  </button>
                </div>
              ) : (
                <button onClick={() => setResetConfirm(true)}
                  className="p-1.5 rounded-lg text-[var(--muted)] hover:bg-[#FEE2E2] hover:text-[var(--danger)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]"
                  aria-label="Delete draft">
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>

          {ev.improvements.length === 0 && (
            <p className="text-xs text-[var(--subtle)] italic">No improvements added yet.</p>
          )}

          {ev.improvements.map(imp => (
            <ImpSummaryRow key={imp.id} imp={imp} />
          ))}
        </div>
      ))}

      {/* Future Arc integration note */}
      <details className="bg-[#EFF6FF] rounded-2xl border border-[#BFDBFE] p-4">
        <summary className="flex items-center gap-2 cursor-pointer text-sm font-semibold text-[#1D4ED8] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] rounded">
          <ChevronDown size={15} />
          Planned: Arc Testnet Integration
        </summary>
        <ul className="mt-3 space-y-1.5 text-xs text-[#1E40AF] list-disc list-inside">
          <li>Separate per-improvement on-chain escrow accounts</li>
          <li>Explicit refund and delivery-review rules enforced by smart contract</li>
          <li>Real user wallet authorisation for funding and release</li>
          <li>Named reviewer/resolver permissions with immutable agreed terms</li>
          <li>Timeout handling: automatic refund if delivery not confirmed by deadline</li>
          <li>Offchain private evidence submission (not public in this version)</li>
          <li>Wallet confirmation for all transactions</li>
          <li className="font-medium">A smart contract can enforce fund rules but cannot independently prove a physical service was delivered or certify accessibility.</li>
        </ul>
      </details>
    </div>
  );
}

function ImpSummaryRow({ imp }: { imp: Improvement }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-[var(--border)] overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-3 px-4 py-3 text-sm bg-[var(--surface-muted)] hover:bg-white transition-colors text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]"
        aria-expanded={open}
      >
        <span className="font-medium text-[var(--ink)] truncate">{imp.title}</span>
        <span className="flex items-center gap-2 flex-shrink-0">
          <span className="text-xs tabular-nums text-[var(--muted)]">Demo USDC {formatMicro(imp.targetMicro)}</span>
          {open ? <ChevronUp size={13} className="text-[var(--muted)]" /> : <ChevronDown size={13} className="text-[var(--muted)]" />}
        </span>
      </button>
      {open && (
        <div className="px-4 pb-3 pt-2 text-xs text-[var(--ink-2)] space-y-1 bg-white">
          <p><span className="font-medium">Provider:</span> {imp.provider.displayName}</p>
          <p><span className="font-medium">Funding deadline:</span> {imp.fundingDeadline}</p>
          <p><span className="font-medium">Delivery date:</span> {imp.deliveryDate}</p>
          <p><span className="font-medium">Status:</span> {imp.status}</p>
        </div>
      )}
    </div>
  );
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function inputCls(hasError: boolean): string {
  return `w-full rounded-xl border px-3 py-2 text-sm text-[var(--ink)] bg-white placeholder:text-[var(--subtle)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-1 transition-colors ${
    hasError ? 'border-[var(--danger)]' : 'border-[var(--border)] hover:border-[var(--border-strong)]'
  }`;
}

function Field({
  label, htmlFor, required, error, children,
}: {
  label: string; htmlFor?: string; required?: boolean; error?: string; children: React.ReactNode;
}) {
  return (
    <div className="space-y-1">
      <label htmlFor={htmlFor} className="block text-xs font-semibold text-[var(--ink-2)]">
        {label}{required && <span className="text-[var(--danger)] ml-0.5" aria-hidden="true">*</span>}
      </label>
      {children}
      {error && (
        <p className="text-xs text-[var(--danger)] flex items-center gap-1" role="alert">
          <AlertCircle size={11} /> {error}
        </p>
      )}
    </div>
  );
}
