import { useState, useMemo } from 'react';
import { DollarSign, Download, CheckCircle, AlertCircle, RefreshCw, User, Shield, X, ChevronDown } from 'lucide-react';
import type { WelcomeEvent, Improvement, Contribution, ImprovementStatus } from '../types';
import {
  contribute,
  raisedMicro,
  remainingMicro,
  formatMicro,
  processRefunds,
  previewRefunds,
  applyTransition,
  canTransition,
  generateReport,
  makeId,
  parseMicro,
} from '../logic';
import type { AppState } from '../types';
import StatusBadge from '../components/StatusBadge';

type Role = 'supporter' | 'organiser';

interface Props {
  events: WelcomeEvent[];
  contributions: Contribution[];
  onContribute: (c: Contribution) => void;
  onTransition: (eventId: string, impId: string, to: ImprovementStatus, updatedContributions?: Contribution[]) => void;
  initialImpId?: string | null;
  fullState: AppState;
}

export default function SupportDelivery({
  events, contributions, onContribute, onTransition, initialImpId, fullState,
}: Props) {
  const [role, setRole] = useState<Role>('supporter');
  const [selectedEventId, setSelectedEventId] = useState<string>(
    (() => {
      if (initialImpId) {
        const ev = events.find(e => e.improvements.some(i => i.id === initialImpId));
        return ev?.id ?? events[0]?.id ?? '';
      }
      return events[0]?.id ?? '';
    })()
  );
  const [selectedImpId, setSelectedImpId] = useState<string | null>(initialImpId ?? null);
  const [amount, setAmount] = useState('');
  const [amountError, setAmountError] = useState('');
  const [contributorLabel, setContributorLabel] = useState('Supporter A');
  const [step, setStep] = useState<'choose' | 'preview' | 'done' | 'refund-preview'>('choose');
  const [pendingContribution, setPendingContribution] = useState<Contribution | null>(null);
  const [transitionError, setTransitionError] = useState('');
  const [resetConfirm, setResetConfirm] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportStr, setReportStr] = useState('');

  const event = events.find(e => e.id === selectedEventId);
  const allImps: Array<{ imp: Improvement; eventId: string }> = events.flatMap(ev =>
    ev.improvements.map(imp => ({ imp, eventId: ev.id })),
  );
  const selectedImpInfo = allImps.find(x => x.imp.id === selectedImpId);
  const imp = selectedImpInfo?.imp ?? null;
  const impContribs = useMemo(() => contributions.filter(c => c.improvementId === (imp?.id ?? '')), [contributions, imp]);
  const raised = imp ? raisedMicro(imp.id, contributions) : 0;
  const remaining = imp ? remainingMicro(imp, contributions) : 0;
  const target = imp?.targetMicro ?? 0;
  const pct = target > 0 ? Math.min(100, Math.round((raised / target) * 100)) : 0;

  function handleAmountChange(val: string) {
    setAmount(val);
    setAmountError('');
  }

  function handlePreview() {
    if (!imp) return;
    const r = parseMicro(amount);
    if (!r.ok) { setAmountError(r.error); return; }
    if (r.micro > remaining) {
      setAmountError(`Amount exceeds remaining gap of Demo USDC ${formatMicro(remaining)}.`);
      return;
    }
    setAmountError('');
    setStep('preview');
  }

  function handleConfirmContribute() {
    if (!imp) return;
    const result = contribute(imp, contributions, amount, contributorLabel, makeId);
    if (!result.ok) { setAmountError(result.error); setStep('choose'); return; }
    onContribute(result.contribution);
    setPendingContribution(result.contribution);
    setStep('done');
    setAmount('');
    // auto-transition if now fully funded
    const newRaised = raised + result.contribution.amountMicro;
    if (newRaised >= target && canTransition(imp.status, 'funded')) {
      onTransition(selectedEventId, imp.id, 'funded');
    }
  }

  function handleTransition(to: ImprovementStatus) {
    if (!imp) return;
    const result = applyTransition(imp, to);
    if (!result.ok) { setTransitionError(result.error); return; }
    setTransitionError('');
    if (to === 'refunded') {
      const updated = processRefunds(imp.id, contributions);
      onTransition(selectedEventId, imp.id, 'refunded', updated);
    } else {
      onTransition(selectedEventId, imp.id, to);
    }
    setStep('choose');
  }

  function handleRefundPreview() {
    setStep('refund-preview');
  }

  function handleExportReport() {
    const report = generateReport(fullState);
    const str = JSON.stringify(report, null, 2);
    setReportStr(str);
    setShowReport(true);
  }

  function downloadReport() {
    const blob = new Blob([reportStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `welcome-layer-report-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <div className="space-y-4">
      {/* Role switch */}
      <div className="bg-[#FFF7ED] rounded-2xl border border-[#FDE68A] p-4">
        <div className="flex items-center gap-2 mb-2">
          <Shield size={15} className="text-[#B45309]" />
          <span className="text-xs font-semibold uppercase tracking-widest text-[#92400E]">Demo Role Switch</span>
          <span className="text-[10px] text-[#92400E] bg-[#FEF3C7] rounded-full px-2 py-0.5 border border-[#FDE68A]">Not Authentication</span>
        </div>
        <div className="flex rounded-xl border border-[#FDE68A] overflow-hidden bg-white/60 w-fit">
          {(['supporter', 'organiser'] as Role[]).map(r => (
            <button key={r} onClick={() => { setRole(r); setStep('choose'); setTransitionError(''); }}
              aria-pressed={role === r}
              className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium capitalize transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${role === r ? 'bg-[#B45309] text-white' : 'text-[#92400E] hover:bg-[#FEF3C7]'}`}>
              {r === 'supporter' ? <DollarSign size={13} /> : <User size={13} />}
              {r}
            </button>
          ))}
        </div>
        <p className="text-[10px] text-[#92400E] mt-2">This switch is a demo label only. It does not represent real access control or authentication.</p>
      </div>

      {/* Event + improvement selector */}
      <div className="bg-white rounded-2xl border border-[var(--border)] p-4 shadow-sm space-y-3">
        <h3 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)]">Select Improvement</h3>
        <div className="flex flex-wrap gap-2">
          {events.map(ev => (
            <button key={ev.id} onClick={() => { setSelectedEventId(ev.id); setSelectedImpId(null); setStep('choose'); setAmount(''); setAmountError(''); }}
              className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${selectedEventId === ev.id ? 'bg-[var(--accent)] text-white border-[var(--accent)]' : 'bg-[var(--surface-muted)] text-[var(--ink-2)] border-[var(--border)] hover:border-[var(--accent)]'}`}>
              {ev.title}
            </button>
          ))}
        </div>
        {event && (
          <div className="space-y-1.5">
            {event.improvements.map(i => (
              <button key={i.id} onClick={() => { setSelectedImpId(i.id); setStep('choose'); setAmount(''); setAmountError(''); setTransitionError(''); }}
                aria-pressed={selectedImpId === i.id}
                className={`w-full text-left flex items-center justify-between gap-3 px-4 py-3 rounded-xl border text-sm font-medium transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${selectedImpId === i.id ? 'border-cobalt bg-[#EFF6FF] text-[#1D4ED8]' : 'border-[var(--border)] bg-white text-[var(--ink-2)] hover:border-cobalt/40'}`}>
                <span className="truncate">{i.title}</span>
                <StatusBadge status={i.status} size="sm" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main action panel */}
      {imp && (
        <div className="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden">
          {/* Header */}
          <div className="p-5 border-b border-[var(--border)]">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h3 className="text-base font-semibold text-[var(--ink)] display">{imp.title}</h3>
              <StatusBadge status={imp.status} />
            </div>
            <p className="text-xs text-[var(--muted)]">{imp.provider.displayName}</p>
          </div>

          <div className="p-5 space-y-5">
            {/* Progress */}
            <div className="bg-[var(--surface-muted)] rounded-xl p-4 space-y-3">
              <div className="w-full bg-white rounded-full h-3 overflow-hidden border border-[var(--border)]">
                <div className="h-full rounded-full transition-all"
                  style={{ width: `${pct}%`, background: imp.status === 'ready' ? '#4ADE80' : imp.status === 'cancelled' ? '#F87171' : 'linear-gradient(90deg, #2563EB, #38BDF8)' }}
                  role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={`${pct}% funded`} />
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <div className="text-[var(--muted)]">Target</div>
                  <div className="font-semibold tabular-nums text-[var(--ink)]">Demo USDC {formatMicro(target)}</div>
                </div>
                <div>
                  <div className="text-[var(--muted)]">Raised</div>
                  <div className="font-semibold tabular-nums text-[var(--ink)]">Demo USDC {formatMicro(raised)}</div>
                </div>
                <div>
                  <div className="text-[var(--muted)]">Remaining</div>
                  <div className={`font-semibold tabular-nums ${remaining === 0 ? 'text-[var(--success)]' : 'text-[var(--ink)]'}`}>
                    Demo USDC {formatMicro(remaining)}
                  </div>
                </div>
              </div>
            </div>

            {/* Contribution list */}
            {impContribs.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)] mb-2">Contributions ({impContribs.length})</h4>
                <div className="space-y-1.5">
                  {impContribs.map(c => (
                    <div key={c.id} className={`flex items-center justify-between px-3 py-2 rounded-xl text-xs border ${c.status === 'refunded' ? 'bg-[#F1F5F9] border-[var(--border)] opacity-60' : 'bg-[var(--surface-muted)] border-[var(--border)]'}`}>
                      <span className="text-[var(--muted)]">{c.contributorLabel}</span>
                      <span className={`tabular-nums font-medium ${c.status === 'refunded' ? 'line-through text-[var(--muted)]' : 'text-[var(--ink)]'}`}>
                        Demo USDC {formatMicro(c.amountMicro)}
                      </span>
                      {c.status === 'refunded' && <span className="ml-2 text-[10px] text-[var(--muted)]">refunded</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Supporter actions */}
            {role === 'supporter' && imp.status === 'funding' && step === 'choose' && (
              <div className="space-y-4">
                <div className="bg-[#FEF3C7] rounded-xl px-4 py-3 text-xs text-[#78350F] border border-[#FDE68A]">
                  <strong>All money actions are simulated.</strong> Demo USDC only — no real funds. Platform fee: Demo USDC 0.00. Cancellation rule: if this improvement is cancelled before delivery, each contribution is refunded in full, exactly once.
                </div>
                <div className="space-y-1">
                  <label htmlFor="contributor-label" className="block text-xs font-semibold text-[var(--ink-2)]">Your demo label</label>
                  <input id="contributor-label" type="text" value={contributorLabel}
                    onChange={e => setContributorLabel(e.target.value)}
                    maxLength={40} className="w-full rounded-xl border border-[var(--border)] px-3 py-2 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]" />
                </div>
                <div className="space-y-1">
                  <label htmlFor="contrib-amount" className="block text-xs font-semibold text-[var(--ink-2)]">Contribution amount (Demo USDC)</label>
                  <div className="flex gap-2">
                    <input id="contrib-amount" type="text" inputMode="decimal" value={amount}
                      onChange={e => handleAmountChange(e.target.value)}
                      className={`flex-1 rounded-xl border px-3 py-2 text-sm tabular-nums focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${amountError ? 'border-[var(--danger)]' : 'border-[var(--border)]'}`}
                      placeholder="e.g. 25.00" aria-describedby={amountError ? 'amount-error' : undefined} />
                    {/* Quick chips */}
                    {[10, 25, 50].map(v => {
                      const micro = v * 1_000_000;
                      const ok = micro <= remaining;
                      return (
                        <button key={v} onClick={() => handleAmountChange(String(v))} disabled={!ok}
                          className="px-3 py-2 rounded-xl border border-[var(--border)] text-sm font-medium text-[var(--ink-2)] bg-[var(--surface-muted)] hover:bg-cobalt/10 hover:border-cobalt/40 disabled:opacity-30 disabled:cursor-not-allowed transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                          {v}
                        </button>
                      );
                    })}
                  </div>
                  {amountError && (
                    <p id="amount-error" className="text-xs text-[var(--danger)] flex items-center gap-1 mt-1" role="alert">
                      <AlertCircle size={11} /> {amountError}
                    </p>
                  )}
                </div>
                <button onClick={handlePreview} disabled={!amount.trim()}
                  className="w-full py-3 rounded-xl bg-[var(--accent)] text-white font-semibold text-sm hover:bg-[var(--accent-hover)] disabled:opacity-40 disabled:cursor-not-allowed transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2">
                  Simulate Contribution — Demo USDC
                </button>
              </div>
            )}

            {/* Preview step */}
            {role === 'supporter' && imp.status === 'funding' && step === 'preview' && (
              <div className="space-y-4">
                <div className="bg-[#EFF6FF] rounded-xl border border-[#BFDBFE] p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <DollarSign size={15} className="text-[#2563EB]" />
                    <span className="font-semibold text-[#1D4ED8] text-sm">Review before simulating</span>
                  </div>
                  <table className="w-full text-xs">
                    <tbody>
                      <tr><td className="py-1 text-[var(--muted)]">Improvement</td><td className="py-1 text-right font-medium text-[var(--ink)]">{imp.title}</td></tr>
                      <tr><td className="py-1 text-[var(--muted)]">Your label</td><td className="py-1 text-right text-[var(--ink)]">{contributorLabel}</td></tr>
                      <tr className="border-t border-[#BFDBFE]">
                        <td className="py-1.5 font-semibold text-[var(--ink)]">Amount</td>
                        <td className="py-1.5 text-right font-bold tabular-nums text-[var(--ink)]">Demo USDC {amount}</td>
                      </tr>
                      <tr><td className="py-1 text-[var(--muted)]">Platform fee</td><td className="py-1 text-right tabular-nums text-[var(--ink)]">Demo USDC 0.00</td></tr>
                    </tbody>
                  </table>
                  <p className="text-[10px] text-[#1E40AF]">
                    Cancellation: if this improvement is cancelled, your contribution will be returned in full exactly once. No cross-item balance mixing.
                    Funding complete does not automatically mean the service has been delivered.
                  </p>
                </div>
                <div className="flex gap-3">
                  <button onClick={handleConfirmContribute}
                    className="flex-1 py-3 rounded-xl bg-[var(--accent)] text-white font-semibold text-sm hover:bg-[var(--accent-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2">
                    Confirm — Simulate
                  </button>
                  <button onClick={() => setStep('choose')}
                    className="px-4 py-3 rounded-xl border border-[var(--border)] text-[var(--ink-2)] text-sm font-medium hover:bg-[var(--surface-muted)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                    Back
                  </button>
                </div>
              </div>
            )}

            {/* Done */}
            {step === 'done' && pendingContribution && (
              <div className="bg-[#F0FDF4] rounded-xl border border-[#BBF7D0] p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <CheckCircle size={16} className="text-[#166534]" />
                  <span className="font-semibold text-[#166534] text-sm">Contribution simulated</span>
                </div>
                <p className="text-xs text-[#166534]">
                  Demo USDC {formatMicro(pendingContribution.amountMicro)} recorded for {pendingContribution.contributorLabel}.
                  This is a simulation — no real funds moved.
                </p>
                <button onClick={() => setStep('choose')}
                  className="mt-2 text-xs text-[#166534] underline focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                  Make another contribution
                </button>
              </div>
            )}

            {/* Organiser actions */}
            {role === 'organiser' && (
              <div className="space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-widest text-[var(--muted)]">Organiser Actions</h4>
                {transitionError && (
                  <p className="text-xs text-[var(--danger)] flex items-center gap-1 bg-[#FEE2E2] px-3 py-2 rounded-xl border border-[#FECACA]" role="alert">
                    <AlertCircle size={12} /> {transitionError}
                  </p>
                )}
                <div className="flex flex-wrap gap-2">
                  {canTransition(imp.status, 'funding') && (
                    <OrgButton onClick={() => handleTransition('funding')} label="Open for Funding" color="blue" />
                  )}
                  {canTransition(imp.status, 'ready') && (
                    <OrgButton onClick={() => handleTransition('ready')} label="Declare Service Ready" color="green"
                      note="This is an organiser declaration only — it does not constitute independent verification of delivery." />
                  )}
                  {canTransition(imp.status, 'cancelled') && (
                    <OrgButton onClick={() => handleTransition('cancelled')} label="Cancel Improvement" color="red" />
                  )}
                  {canTransition(imp.status, 'refunded') && (
                    <OrgButton onClick={handleRefundPreview} label="Preview and Process Refunds" color="orange" />
                  )}
                </div>

                {/* Delivery declaration note */}
                {imp.status === 'ready' && (
                  <div className="bg-[#DCFCE7] rounded-xl border border-[#BBF7D0] p-4 text-xs text-[#166534] space-y-1">
                    <p className="font-semibold">Service declared ready by organiser.</p>
                    <p>This declaration does not prove the service was delivered or certify accessibility. Independent verification has not been performed.</p>
                  </div>
                )}
              </div>
            )}

            {/* Refund preview */}
            {step === 'refund-preview' && (
              <div className="space-y-4">
                <div className="bg-[#FFF7ED] rounded-xl border border-[#FDE68A] p-4 space-y-3">
                  <h4 className="font-semibold text-[#92400E] text-sm">Refund Preview</h4>
                  <p className="text-xs text-[#B45309]">Each contribution will be returned exactly once. No double refunds. No cross-item balance mixing.</p>
                  {previewRefunds(imp.id, contributions).map((r, i) => (
                    <div key={i} className={`flex items-center justify-between text-xs rounded-lg px-3 py-2 border ${r.alreadyRefunded ? 'bg-[#F1F5F9] border-[var(--border)] opacity-50' : 'bg-white border-[#FDE68A]'}`}>
                      <span className="text-[var(--muted)]">{r.contributorLabel}</span>
                      <span className={`tabular-nums font-medium ${r.alreadyRefunded ? 'line-through text-[var(--muted)]' : 'text-[#92400E]'}`}>
                        Demo USDC {formatMicro(r.amountMicro)} {r.alreadyRefunded ? '(already refunded)' : ''}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => handleTransition('refunded')}
                    className="flex-1 py-3 rounded-xl bg-[#B45309] text-white font-semibold text-sm hover:bg-[#92400E] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-offset-2">
                    Confirm Refunds
                  </button>
                  <button onClick={() => setStep('choose')}
                    className="px-4 py-3 rounded-xl border border-[var(--border)] text-[var(--ink-2)] text-sm font-medium hover:bg-[var(--surface-muted)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                    Back
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Accountability report + reset */}
      <div className="flex flex-wrap gap-3">
        <button onClick={handleExportReport}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[var(--border)] bg-white text-sm font-medium text-[var(--ink-2)] hover:bg-[var(--surface-muted)] transition-colors shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
          <Download size={14} /> Export Accountability Report
        </button>
        {resetConfirm ? (
          <div className="flex items-center gap-2 bg-[#FEE2E2] rounded-xl border border-[#FECACA] px-4 py-2">
            <span className="text-xs text-[#991B1B]">Reset all demo data?</span>
            <button onClick={() => { window.location.reload(); }}
              className="text-xs font-semibold text-[#991B1B] underline focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">Confirm reset</button>
            <button onClick={() => setResetConfirm(false)}
              className="text-xs text-[var(--muted)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">Cancel</button>
          </div>
        ) : (
          <button onClick={() => setResetConfirm(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#FECACA] bg-white text-sm font-medium text-[#991B1B] hover:bg-[#FEE2E2] transition-colors shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
            <RefreshCw size={14} /> Reset Demo
          </button>
        )}
      </div>

      {/* Report modal */}
      {showReport && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true" aria-label="Accountability report">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border)]">
              <h3 className="font-semibold text-[var(--ink)] display">Accountability Report</h3>
              <button onClick={() => setShowReport(false)} aria-label="Close report"
                className="p-1.5 rounded-lg text-[var(--muted)] hover:bg-[var(--surface-muted)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                <X size={16} />
              </button>
            </div>
            <div className="p-4 bg-[#FFF7ED] border-b border-[#FDE68A] text-xs text-[#92400E] space-y-1">
              <p className="font-semibold">Limitations</p>
              <p>All participants, providers, and prices are fictional. Contributions are Demo USDC — no real funds. Organiser declarations do not prove delivery. This report does not certify accessibility.</p>
            </div>
            <div className="flex-1 overflow-auto">
              <pre className="p-5 text-xs text-[var(--ink-2)] font-mono leading-relaxed whitespace-pre-wrap break-all">{reportStr}</pre>
            </div>
            <div className="px-5 py-4 border-t border-[var(--border)] flex justify-end gap-3">
              <button onClick={downloadReport}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--accent)] text-white text-sm font-semibold hover:bg-[var(--accent-hover)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                <Download size={14} /> Download JSON
              </button>
              <button onClick={() => setShowReport(false)}
                className="px-4 py-2.5 rounded-xl border border-[var(--border)] text-[var(--ink-2)] text-sm font-medium hover:bg-[var(--surface-muted)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)]">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Future integration note */}
      <details className="bg-[#EFF6FF] rounded-2xl border border-[#BFDBFE] p-4">
        <summary className="flex items-center gap-2 cursor-pointer text-sm font-semibold text-[#1D4ED8] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] rounded">
          <ChevronDown size={15} />
          Planned: Arc Testnet Funding Integration
        </summary>
        <ul className="mt-3 space-y-1.5 text-xs text-[#1E40AF] list-disc list-inside">
          <li>On-chain escrow per improvement, funded with real USDC on Arc Testnet</li>
          <li>Wallet confirmation required for all funding and release actions</li>
          <li>Named resolver permissions: explicit role for delivery reviewer</li>
          <li>Immutable agreed terms stored at funding time</li>
          <li>Timeout: automatic refund if organiser does not confirm delivery by deadline</li>
          <li>Offchain private evidence (photos, logs) not stored on-chain or published</li>
          <li className="font-medium">A smart contract enforces fund rules. It cannot independently prove physical service delivery or certify accessibility.</li>
        </ul>
      </details>
    </div>
  );
}

function OrgButton({ onClick, label, color, note }: { onClick: () => void; label: string; color: 'blue' | 'green' | 'red' | 'orange'; note?: string }) {
  const colorCls = {
    blue:   'bg-[#EFF6FF] text-[#1D4ED8] border-[#BFDBFE] hover:bg-[#DBEAFE]',
    green:  'bg-[#F0FDF4] text-[#166534] border-[#BBF7D0] hover:bg-[#DCFCE7]',
    red:    'bg-[#FEE2E2] text-[#991B1B] border-[#FECACA] hover:bg-[#FECACA]',
    orange: 'bg-[#FFF7ED] text-[#92400E] border-[#FDE68A] hover:bg-[#FEF3C7]',
  }[color];
  return (
    <div>
      <button onClick={onClick}
        className={`px-4 py-2 rounded-xl border text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] ${colorCls}`}>
        {label}
      </button>
      {note && <p className="text-[10px] text-[var(--muted)] mt-1 max-w-xs">{note}</p>}
    </div>
  );
}
