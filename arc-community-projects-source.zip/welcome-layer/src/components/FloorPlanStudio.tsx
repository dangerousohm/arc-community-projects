interface Props {
  children?: React.ReactNode;
  className?: string;
}

export default function FloorPlanStudio({ children, className = '' }: Props) {
  return (
    <div className={`relative w-full ${className}`} style={{ aspectRatio: '4/3' }}>
      <svg
        viewBox="0 0 400 300"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
        role="img"
        aria-label="Floor plan of Old Library Studio Space showing performance studio, foyer, and backstage area"
      >
        <rect x="10" y="10" width="380" height="280" rx="6" fill="#FFF7F3" stroke="#FDBA74" strokeWidth="2" />
        {/* Studio */}
        <rect x="60" y="40" width="240" height="180" rx="6" fill="#FEF3E8" stroke="#FB923C" strokeWidth="2" />
        <text x="180" y="62" textAnchor="middle" fill="#9A3412" fontSize="11" fontFamily="DM Sans, sans-serif" fontWeight="600">STUDIO SPACE</text>
        {/* Stage */}
        <rect x="90" y="70" width="180" height="50" rx="4" fill="#FED7AA" stroke="#F97316" strokeWidth="1.5" />
        <text x="180" y="98" textAnchor="middle" fill="#9A3412" fontSize="10" fontFamily="DM Sans, sans-serif" fontWeight="600">STAGE</text>
        {/* Audience seating */}
        {[130, 145, 160, 175].map((y, i) => (
          <g key={i}>
            <rect x="80" y={y} width="200" height="10" rx="2" fill="#FDE8D0" />
            <text x="72" y={y + 8} textAnchor="end" fill="#94A3B8" fontSize="7" fontFamily="DM Sans, sans-serif">{String.fromCharCode(65 + i)}</text>
          </g>
        ))}
        <text x="180" y="200" textAnchor="middle" fill="#94A3B8" fontSize="7.5" fontFamily="DM Sans, sans-serif" fontStyle="italic">Capacity: 60 (demo)</text>
        {/* Foyer */}
        <rect x="60" y="230" width="140" height="50" rx="4" fill="#FFF7ED" stroke="#FCD34D" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="130" y="250" textAnchor="middle" fill="#78350F" fontSize="9" fontFamily="DM Sans, sans-serif" fontWeight="600">FOYER</text>
        <text x="130" y="261" textAnchor="middle" fill="#92400E" fontSize="7.5" fontFamily="DM Sans, sans-serif">Programmes / welcome</text>
        {/* Backstage */}
        <rect x="310" y="40" width="70" height="180" rx="4" fill="#F5F3FF" stroke="#C4B5FD" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="345" y="122" textAnchor="middle" fill="#6D28D9" fontSize="8.5" fontFamily="DM Sans, sans-serif" fontWeight="600">BACK-</text>
        <text x="345" y="132" textAnchor="middle" fill="#6D28D9" fontSize="8.5" fontFamily="DM Sans, sans-serif" fontWeight="600">STAGE</text>
        {/* Toilets */}
        <rect x="210" y="230" width="80" height="50" rx="4" fill="#F5F3FF" stroke="#C4B5FD" strokeWidth="1" strokeDasharray="3 2" />
        <text x="250" y="252" textAnchor="middle" fill="#6D28D9" fontSize="8" fontFamily="DM Sans, sans-serif" fontWeight="600">TOILETS</text>
        <text x="250" y="263" textAnchor="middle" fill="#8B5CF6" fontSize="7" fontFamily="DM Sans, sans-serif">(accessible)</text>
        {/* Chill-out area */}
        <rect x="300" y="230" width="80" height="50" rx="4" fill="#EFF6FF" stroke="#93C5FD" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="340" y="250" textAnchor="middle" fill="#1D4ED8" fontSize="8" fontFamily="DM Sans, sans-serif" fontWeight="600">CHILL-OUT</text>
        <text x="340" y="261" textAnchor="middle" fill="#1D4ED8" fontSize="7.5" fontFamily="DM Sans, sans-serif">Quiet area</text>
        <g transform="translate(378, 22)">
          <polygon points="0,-8 4,4 0,2 -4,4" fill="#64748B" />
          <text x="0" y="14" textAnchor="middle" fill="#64748B" fontSize="6" fontFamily="DM Sans, sans-serif">N</text>
        </g>
      </svg>
      {children}
    </div>
  );
}
