/**
 * Original SVG floor plan — Riverside Community Hall
 * All text labels, zones, and symbols included.
 * Markers are rendered as children (absolute-positioned overlays).
 */

interface Props {
  children?: React.ReactNode;
  className?: string;
}

export default function FloorPlanHall({ children, className = '' }: Props) {
  return (
    <div className={`relative w-full ${className}`} style={{ aspectRatio: '4/3' }}>
      <svg
        viewBox="0 0 400 300"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
        role="img"
        aria-label="Floor plan of Riverside Community Hall showing main screening area, lobby, entrance desk, and quiet side room"
      >
        {/* Outer walls */}
        <rect x="10" y="10" width="380" height="280" rx="6" fill="#F9F7F4" stroke="#C8BFB0" strokeWidth="2.5" />

        {/* Main hall area */}
        <rect x="30" y="30" width="260" height="200" rx="4" fill="#EDF2F7" stroke="#94A3B8" strokeWidth="1.5" />
        <text x="160" y="56" textAnchor="middle" fill="#475569" fontSize="11" fontFamily="DM Sans, sans-serif" fontWeight="600">MAIN SCREENING AREA</text>

        {/* Screen */}
        <rect x="60" y="65" width="200" height="14" rx="3" fill="#1A3C5E" />
        <text x="160" y="75.5" textAnchor="middle" fill="#E0F2FE" fontSize="8" fontFamily="DM Sans, sans-serif">SCREEN</text>

        {/* Seating rows — simplified */}
        {[95, 110, 125, 140, 155, 170, 185, 200].map((y, i) => (
          <g key={i}>
            <rect x="55" y={y} width="210" height="9" rx="2" fill="#CBD5E1" opacity="0.7" />
            <text x="48" y={y + 7} textAnchor="end" fill="#94A3B8" fontSize="7" fontFamily="DM Sans, sans-serif">{String.fromCharCode(65 + i)}</text>
          </g>
        ))}

        {/* Entrance desk zone */}
        <rect x="30" y="232" width="120" height="48" rx="4" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="90" y="252" textAnchor="middle" fill="#92400E" fontSize="9" fontFamily="DM Sans, sans-serif" fontWeight="600">ENTRANCE DESK</text>
        <rect x="50" y="258" width="80" height="14" rx="2" fill="#FDE68A" />
        <text x="90" y="267.5" textAnchor="middle" fill="#78350F" fontSize="7.5" fontFamily="DM Sans, sans-serif">Welcome / Programmes</text>

        {/* Lobby */}
        <rect x="160" y="232" width="130" height="48" rx="4" fill="#F0FDF4" stroke="#86EFAC" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="225" y="252" textAnchor="middle" fill="#166534" fontSize="9" fontFamily="DM Sans, sans-serif" fontWeight="600">LOBBY / ENTRANCE</text>
        {/* Door symbol */}
        <path d="M 200 268 A 20 20 0 0 1 220 280" fill="none" stroke="#4ADE80" strokeWidth="1.5" />
        <line x1="200" y1="268" x2="200" y2="280" stroke="#4ADE80" strokeWidth="1.5" />
        <text x="225" y="276" textAnchor="middle" fill="#15803D" fontSize="7" fontFamily="DM Sans, sans-serif">Main Doors</text>

        {/* Side room (quiet space) */}
        <rect x="300" y="110" width="80" height="120" rx="4" fill="#EFF6FF" stroke="#93C5FD" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="340" y="130" textAnchor="middle" fill="#1D4ED8" fontSize="8.5" fontFamily="DM Sans, sans-serif" fontWeight="600">QUIET</text>
        <text x="340" y="141" textAnchor="middle" fill="#1D4ED8" fontSize="8.5" fontFamily="DM Sans, sans-serif" fontWeight="600">SIDE ROOM</text>
        {/* Chair symbols */}
        {[155, 168, 181, 194, 207].map(y => (
          <rect key={y} x="315" y={y} width="50" height="8" rx="2" fill="#BFDBFE" />
        ))}

        {/* Toilets */}
        <rect x="300" y="30" width="80" height="70" rx="4" fill="#F5F3FF" stroke="#C4B5FD" strokeWidth="1" strokeDasharray="3 2" />
        <text x="340" y="62" textAnchor="middle" fill="#6D28D9" fontSize="8" fontFamily="DM Sans, sans-serif" fontWeight="600">TOILETS</text>
        <text x="340" y="72" textAnchor="middle" fill="#8B5CF6" fontSize="7" fontFamily="DM Sans, sans-serif">(accessible)</text>

        {/* Side screen area for captions */}
        <rect x="242" y="65" width="46" height="14" rx="3" fill="#FED7AA" stroke="#FB923C" strokeWidth="1" />
        <text x="265" y="75.5" textAnchor="middle" fill="#9A3412" fontSize="6.5" fontFamily="DM Sans, sans-serif">CAPTION</text>

        {/* Zone labels */}
        <text x="160" y="220" textAnchor="middle" fill="#94A3B8" fontSize="7.5" fontFamily="DM Sans, sans-serif" fontStyle="italic">Seating capacity: 80 (demo)</text>

        {/* North arrow */}
        <g transform="translate(372, 22)">
          <polygon points="0,-8 4,4 0,2 -4,4" fill="#64748B" />
          <text x="0" y="14" textAnchor="middle" fill="#64748B" fontSize="6" fontFamily="DM Sans, sans-serif">N</text>
        </g>
      </svg>
      {/* Overlay markers */}
      {children}
    </div>
  );
}
