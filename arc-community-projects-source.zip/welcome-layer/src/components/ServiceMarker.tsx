import type { Improvement } from '../types';

interface Props {
  improvement: Improvement;
  selected: boolean;
  onClick: () => void;
}

const STATUS_COLORS: Record<string, { ring: string; fill: string; dot: string }> = {
  draft:     { ring: '#94A3B8', fill: '#F1F5F9', dot: '#64748B' },
  funding:   { ring: '#F59E0B', fill: '#FEF3C7', dot: '#B45309' },
  funded:    { ring: '#38BDF8', fill: '#E0F2FE', dot: '#0369A1' },
  ready:     { ring: '#4ADE80', fill: '#DCFCE7', dot: '#166534' },
  cancelled: { ring: '#F87171', fill: '#FEE2E2', dot: '#991B1B' },
  refunded:  { ring: '#CBD5E1', fill: '#F1F5F9', dot: '#64748B' },
};

export default function ServiceMarker({ improvement, selected, onClick }: Props) {
  const colors = STATUS_COLORS[improvement.status] ?? STATUS_COLORS.draft;
  const shortTitle = improvement.title.length > 18
    ? improvement.title.slice(0, 16) + '…'
    : improvement.title;

  return (
    <button
      onClick={onClick}
      aria-label={`${improvement.title} — ${improvement.status}. Click to view details.`}
      aria-pressed={selected}
      className="absolute -translate-x-1/2 -translate-y-1/2 group focus:outline-none"
      style={{ left: `${improvement.floorX}%`, top: `${improvement.floorY}%` }}
    >
      {/* Pulse ring when selected */}
      {selected && (
        <span
          className="absolute inset-0 rounded-full animate-ping opacity-50"
          style={{ background: colors.ring, width: 36, height: 36, margin: -4 }}
          aria-hidden="true"
        />
      )}
      {/* Marker body */}
      <span
        className="relative flex items-center justify-center rounded-full transition-transform group-hover:scale-110 group-focus-visible:ring-2 group-focus-visible:ring-offset-1"
        style={{
          width: 28,
          height: 28,
          background: colors.fill,
          border: `2.5px solid ${colors.ring}`,
          boxShadow: selected ? `0 0 0 3px ${colors.ring}55` : '0 1px 4px rgba(0,0,0,0.15)',
        }}
        aria-hidden="true"
      >
        <span
          className="w-3 h-3 rounded-full"
          style={{ background: colors.dot }}
        />
      </span>
      {/* Tooltip label */}
      <span
        className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 whitespace-nowrap rounded-md px-2 py-1 text-[10px] font-medium shadow-md pointer-events-none opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-opacity"
        style={{
          background: '#122d45',
          color: '#fff',
          fontFamily: 'DM Sans, sans-serif',
          maxWidth: 160,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}
      >
        {shortTitle}
      </span>
    </button>
  );
}
