import type { ImprovementStatus } from '../types';

interface Props {
  status: ImprovementStatus;
  size?: 'sm' | 'md';
}

const CONFIG: Record<ImprovementStatus, { label: string; cls: string }> = {
  draft:     { label: 'Draft',             cls: 'bg-slate-100 text-slate-600 border-slate-200' },
  funding:   { label: 'Needs Funding',     cls: 'bg-[#FFF3E0] text-[#B45309] border-[#FDE68A]' },
  funded:    { label: 'Funded — Pending',  cls: 'bg-[#E0F2FE] text-[#0369A1] border-[#BAE6FD]' },
  ready:     { label: 'Organiser: Ready',  cls: 'bg-[#DCFCE7] text-[#166534] border-[#BBF7D0]' },
  cancelled: { label: 'Cancelled',         cls: 'bg-[#FEE2E2] text-[#991B1B] border-[#FECACA]' },
  refunded:  { label: 'Refunded',          cls: 'bg-[#F3F4F6] text-[#374151] border-[#E5E7EB]' },
};

export default function StatusBadge({ status, size = 'md' }: Props) {
  const { label, cls } = CONFIG[status];
  const sizeCls = size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-1';
  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border tracking-wide ${sizeCls} ${cls}`}
      style={{ letterSpacing: '0.04em' }}
    >
      {label}
    </span>
  );
}
