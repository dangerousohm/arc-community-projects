interface Props {
  children?: React.ReactNode;
  className?: string;
}

export default function FloorPlanPavilion({ children, className = '' }: Props) {
  return (
    <div className={`relative w-full ${className}`} style={{ aspectRatio: '4/3' }}>
      <svg
        viewBox="0 0 400 300"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
        role="img"
        aria-label="Floor plan of Meadow Park Pavilion showing welcome area, central exhibits, and outdoor access"
      >
        <rect x="10" y="10" width="380" height="280" rx="6" fill="#F0FDF4" stroke="#86EFAC" strokeWidth="2" />
        {/* Pavilion structure */}
        <rect x="60" y="40" width="280" height="180" rx="8" fill="#F9FFF9" stroke="#4ADE80" strokeWidth="2" />
        <text x="200" y="60" textAnchor="middle" fill="#166534" fontSize="11" fontFamily="DM Sans, sans-serif" fontWeight="600">MEADOW PARK PAVILION</text>
        {/* Welcome area */}
        <rect x="70" y="70" width="100" height="60" rx="4" fill="#ECFDF5" stroke="#6EE7B7" strokeWidth="1.5" strokeDasharray="4 2" />
        <text x="120" y="96" textAnchor="middle" fill="#065F46" fontSize="9" fontFamily="DM Sans, sans-serif" fontWeight="600">WELCOME AREA</text>
        <text x="120" y="107" textAnchor="middle" fill="#065F46" fontSize="7.5" fontFamily="DM Sans, sans-serif">Opening talk</text>
        {/* Central exhibits */}
        <rect x="130" y="110" width="160" height="80" rx="4" fill="#FEF9EE" stroke="#FCD34D" strokeWidth="1.5" />
        <text x="210" y="148" textAnchor="middle" fill="#78350F" fontSize="10" fontFamily="DM Sans, sans-serif" fontWeight="600">CENTRAL EXHIBITS</text>
        {[130, 155, 180].map((x, i) => (
          <g key={i}>
            <rect x={x + 5} y="125" width="40" height="25" rx="3" fill="#FDE68A" stroke="#F59E0B" strokeWidth="1" />
            <text x={x + 25} y="136" textAnchor="middle" fill="#92400E" fontSize="7" fontFamily="DM Sans, sans-serif" fontWeight="600">Exhibit {i + 1}</text>
          </g>
        ))}
        {/* Outdoor path */}
        <rect x="60" y="230" width="280" height="40" rx="4" fill="#DCFCE7" stroke="#86EFAC" strokeWidth="1" strokeDasharray="5 3" />
        <text x="200" y="250" textAnchor="middle" fill="#166534" fontSize="9" fontFamily="DM Sans, sans-serif">Outdoor path — step-free access</text>
        {/* Toilets */}
        <rect x="310" y="70" width="60" height="50" rx="4" fill="#F5F3FF" stroke="#C4B5FD" strokeWidth="1" strokeDasharray="3 2" />
        <text x="340" y="92" textAnchor="middle" fill="#6D28D9" fontSize="8" fontFamily="DM Sans, sans-serif" fontWeight="600">TOILETS</text>
        <text x="340" y="102" textAnchor="middle" fill="#8B5CF6" fontSize="7" fontFamily="DM Sans, sans-serif">(accessible)</text>
        {/* Seating */}
        <rect x="70" y="145" width="50" height="50" rx="4" fill="#ECFDF5" stroke="#6EE7B7" strokeWidth="1" strokeDasharray="3 2" />
        <text x="95" y="166" textAnchor="middle" fill="#065F46" fontSize="8" fontFamily="DM Sans, sans-serif">Seating</text>
        <text x="95" y="176" textAnchor="middle" fill="#065F46" fontSize="7" fontFamily="DM Sans, sans-serif">area</text>
        <g transform="translate(378, 22)">
          <polygon points="0,-8 4,4 0,2 -4,4" fill="#64748B" />
          <text x="0" y="14" textAnchor="middle" fill="#64748B" fontSize="6" fontFamily="DM Sans, sans-serif">N</text>
        </g>
      </svg>
      {children}
    </div>
  );
}
