import { useState, useEffect, useCallback } from 'react';
import { Map, Wrench, Heart } from 'lucide-react';
import type { WelcomeEvent, Contribution, ImprovementStatus, AppState } from './types';
import { SEED_EVENTS } from './data';
import { loadState, saveState, clearState, SCHEMA_VERSION } from './logic';
import EventPlan from './views/EventPlan';
import ImprovementBuilder from './views/ImprovementBuilder';
import SupportDelivery from './views/SupportDelivery';

// ─── Initial state ────────────────────────────────────────────────────────────

const INITIAL_STATE: AppState = {
  events: SEED_EVENTS,
  contributions: [
    // Seed a few demo contributions for the film evening captions
    {
      id: 'contrib-seed-1',
      improvementId: 'imp-captions',
      contributorLabel: 'Community Member A',
      amountMicro: 80_000_000,
      timestamp: '2026-10-10T10:00:00.000Z',
      status: 'active',
    },
    {
      id: 'contrib-seed-2',
      improvementId: 'imp-captions',
      contributorLabel: 'Community Member B',
      amountMicro: 50_000_000,
      timestamp: '2026-10-12T14:30:00.000Z',
      status: 'active',
    },
    // Seed: signage (fully funded)
    {
      id: 'contrib-seed-3',
      improvementId: 'imp-signage',
      contributorLabel: 'Community Fund Demo',
      amountMicro: 120_000_000,
      timestamp: '2026-10-08T09:00:00.000Z',
      status: 'active',
    },
    // Seed: quiet space (already ready)
    {
      id: 'contrib-seed-4',
      improvementId: 'imp-quiet-space',
      contributorLabel: 'Anonymous Supporter',
      amountMicro: 100_000_000,
      timestamp: '2026-10-05T11:00:00.000Z',
      status: 'active',
    },
    // Theatre: captioned booklets
    {
      id: 'contrib-seed-5',
      improvementId: 'imp-captioned-theatre',
      contributorLabel: 'Local Sponsor Demo',
      amountMicro: 40_000_000,
      timestamp: '2026-10-14T16:00:00.000Z',
      status: 'active',
    },
  ],
  draftEvents: [],
  schemaVersion: SCHEMA_VERSION,
};

type Tab = 'plan' | 'builder' | 'support';

const TABS: Array<{ id: Tab; label: string; icon: typeof Map }> = [
  { id: 'plan',    label: 'Event Plan',   icon: Map },
  { id: 'builder', label: 'Improvement Builder', icon: Wrench },
  { id: 'support', label: 'Support & Delivery',  icon: Heart },
];

export default function App() {
  const [state, setState] = useState<AppState>(() => loadState(INITIAL_STATE));
  const [tab, setTab] = useState<Tab>('plan');
  const [jumpImpId, setJumpImpId] = useState<string | null>(null);
  const [storageError, setStorageError] = useState<string | null>(null);

  // Persist on every state change
  useEffect(() => {
    const result = saveState(state);
    if (!result.ok) {
      setStorageError(`Storage: ${result.error}`);
    } else {
      setStorageError(null);
    }
  }, [state]);

  const handleContribute = useCallback((contribution: Contribution) => {
    setState(s => ({ ...s, contributions: [...s.contributions, contribution] }));
  }, []);

  const handleTransition = useCallback((
    eventId: string,
    impId: string,
    to: ImprovementStatus,
    updatedContributions?: Contribution[],
  ) => {
    setState(s => ({
      ...s,
      contributions: updatedContributions ?? s.contributions,
      events: s.events.map(ev => {
        if (ev.id !== eventId) return ev;
        return {
          ...ev,
          improvements: ev.improvements.map(imp => {
            if (imp.id !== impId) return imp;
            return { ...imp, status: to };
          }),
        };
      }),
      draftEvents: s.draftEvents.map(ev => {
        if (ev.id !== eventId) return ev;
        return {
          ...ev,
          improvements: ev.improvements.map(imp => {
            if (imp.id !== impId) return imp;
            return { ...imp, status: to };
          }),
        };
      }),
    }));
  }, []);

  const handleSaveDraft = useCallback((event: WelcomeEvent) => {
    setState(s => {
      const exists = s.draftEvents.some(e => e.id === event.id);
      return {
        ...s,
        draftEvents: exists
          ? s.draftEvents.map(e => e.id === event.id ? event : e)
          : [...s.draftEvents, event],
      };
    });
  }, []);

  const handleDeleteDraft = useCallback((eventId: string) => {
    setState(s => ({ ...s, draftEvents: s.draftEvents.filter(e => e.id !== eventId) }));
  }, []);

  function handleSelectImprovement(eventId: string, impId: string) {
    setJumpImpId(impId);
    setTab('support');
    // Find correct event for support view
    setState(s => s); // no-op to avoid stale closure
    // store the event selection via jumpImpId; SupportDelivery will pick it up
    void eventId; // used by SupportDelivery via jumpImpId lookup
  }

  function handleReset() {
    clearState();
    setState(INITIAL_STATE);
  }

  const allEvents = [...state.events, ...state.draftEvents];

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      {/* Skip link */}
      <a href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:bg-white focus:px-4 focus:py-2 focus:rounded-xl focus:text-[var(--accent)] focus:font-semibold focus:shadow-lg">
        Skip to main content
      </a>

      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-[var(--border)] shadow-sm">
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-bold text-[var(--ink)] display leading-tight">Welcome Layer</h1>
            <p className="text-xs text-[var(--muted)] leading-tight">Small changes. More people included.</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-widest bg-[#FEF3C7] text-[#92400E] border border-[#FDE68A]">
              Local Demo
            </span>
            <span className="hidden sm:inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-widest bg-[#EFF6FF] text-[#1D4ED8] border border-[#BFDBFE]">
              Demo USDC
            </span>
          </div>
        </div>
      </header>

      {/* Storage error banner */}
      {storageError && (
        <div className="bg-[#FEE2E2] border-b border-[#FECACA] px-4 py-2 text-xs text-[#991B1B] text-center" role="alert">
          Storage error — changes may not persist: {storageError}
        </div>
      )}

      {/* Nav tabs */}
      <nav aria-label="Main sections" className="sticky top-[57px] z-20 bg-white/80 backdrop-blur-md border-b border-[var(--border)]">
        <div className="max-w-3xl mx-auto px-4">
          <div className="flex" role="tablist">
            {TABS.map(t => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  role="tab"
                  aria-selected={tab === t.id}
                  aria-controls={`tabpanel-${t.id}`}
                  onClick={() => { setTab(t.id); if (t.id !== 'support') setJumpImpId(null); }}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-3 text-sm font-medium border-b-2 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] focus-visible:ring-inset ${
                    tab === t.id
                      ? 'border-[var(--cobalt)] text-[var(--cobalt)]'
                      : 'border-transparent text-[var(--muted)] hover:text-[var(--ink)] hover:border-[var(--border-strong)]'
                  }`}
                >
                  <Icon size={15} aria-hidden="true" />
                  <span className="hidden sm:inline">{t.label}</span>
                  <span className="sm:hidden text-xs">{t.label.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main id="main-content" className="max-w-3xl mx-auto px-4 py-6 pb-16">
        <div
          id="tabpanel-plan"
          role="tabpanel"
          aria-label="Event Plan"
          hidden={tab !== 'plan'}
        >
          {tab === 'plan' && (
            <EventPlan
              events={allEvents}
              contributions={state.contributions}
              onSelectImprovement={handleSelectImprovement}
            />
          )}
        </div>

        <div
          id="tabpanel-builder"
          role="tabpanel"
          aria-label="Improvement Builder"
          hidden={tab !== 'builder'}
        >
          {tab === 'builder' && (
            <ImprovementBuilder
              draftEvents={state.draftEvents}
              onSaveDraft={handleSaveDraft}
              onDeleteDraft={handleDeleteDraft}
            />
          )}
        </div>

        <div
          id="tabpanel-support"
          role="tabpanel"
          aria-label="Support and Delivery"
          hidden={tab !== 'support'}
        >
          {tab === 'support' && (
            <SupportDelivery
              events={allEvents}
              contributions={state.contributions}
              onContribute={handleContribute}
              onTransition={handleTransition}
              initialImpId={jumpImpId}
              fullState={state}
            />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[var(--border)] bg-white/60 py-6 px-4 text-center">
        <div className="max-w-3xl mx-auto space-y-2">
          <p className="text-xs text-[var(--muted)]">
            <strong>Welcome Layer</strong> — local browser prototype. All events, participants, providers, and prices are fictional demo data.
            All contributions are simulated Demo USDC. No real funds. No wallet connections. No accessibility certification.
          </p>
          <p className="text-xs text-[var(--subtle)]">
            This tool does not guarantee that any proposed service meets every person's needs. Funding, organiser declarations, independent checks, and financial settlement remain distinguishable.
          </p>
          <button
            onClick={handleReset}
            className="mt-2 text-xs text-[var(--muted)] underline hover:text-[var(--danger)] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus)] rounded"
          >
            Reset demo data
          </button>
        </div>
      </footer>
    </div>
  );
}
