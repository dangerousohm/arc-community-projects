/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        paper: { DEFAULT: '#f7f0dd', deep: '#ede2c4', edge: '#d9ccaa' },
        midnight: { DEFAULT: '#16294f', 800: '#0f2044', 900: '#0a1530', 950: '#060e22' },
        vermilion: { DEFAULT: '#d6432b', dark: '#a8321e' },
        rainblue: '#4f78a6',
        brass: '#b8862b',
        ink: '#172a4d',
      },
      fontFamily: {
        display: ['"Iowan Old Style"', '"Palatino Linotype"', 'Palatino', 'Georgia', 'serif'],
        body: ['"Avenir Next"', '"Gill Sans"', '"Segoe UI"', 'Candara', 'Trebuchet MS', 'sans-serif'],
        mono: ['"American Typewriter"', '"Courier New"', 'ui-monospace', 'monospace'],
      },
    },
  },
  plugins: [],
}
