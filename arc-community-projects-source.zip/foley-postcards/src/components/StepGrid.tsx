import { useRef, useState, type KeyboardEvent } from 'react'
import { Bell, CloudRain, Footprints, TrainFront } from 'lucide-react'
import { STEPS, VOICES, type Pattern } from '@/lib/postcard'

interface Props {
  pattern: Pattern
  /** Current playhead step, or -1 when stopped. */
  step: number
  onToggle: (voice: number, step: number) => void
}

const ICONS = [CloudRain, TrainFront, Bell, Footprints]
const TINTS = ['bg-rainblue', 'bg-midnight', 'bg-brass', 'bg-[#6b5645]']

/**
 * Keyboard-operable grid. One tab stop; arrow keys move between cells,
 * Home/End jump along a row, Ctrl+Home/End to the corners, Space or Enter toggles.
 */
export function StepGrid({ pattern, step, onToggle }: Props) {
  const [focus, setFocus] = useState({ v: 0, s: 0 })
  const cells = useRef<Array<Array<HTMLButtonElement | null>>>(VOICES.map(() => Array.from({ length: STEPS }, () => null)))

  const move = (v: number, s: number) => {
    const next = { v: Math.min(VOICES.length - 1, Math.max(0, v)), s: Math.min(STEPS - 1, Math.max(0, s)) }
    setFocus(next)
    cells.current[next.v][next.s]?.focus()
  }

  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    const { v, s } = focus
    const ctrl = e.ctrlKey || e.metaKey
    switch (e.key) {
      case 'ArrowRight':
        return e.preventDefault(), move(v, s + 1)
      case 'ArrowLeft':
        return e.preventDefault(), move(v, s - 1)
      case 'ArrowDown':
        return e.preventDefault(), move(v + 1, s)
      case 'ArrowUp':
        return e.preventDefault(), move(v - 1, s)
      case 'Home':
        return e.preventDefault(), move(ctrl ? 0 : v, 0)
      case 'End':
        return e.preventDefault(), move(ctrl ? VOICES.length - 1 : v, STEPS - 1)
      default:
    }
  }

  return (
    <div
      role="grid"
      aria-label="Score: four sounds across eight beats. Arrow keys move, Space or Enter toggles a beat."
      aria-rowcount={VOICES.length + 1}
      aria-colcount={STEPS + 1}
      onKeyDown={onKeyDown}
      className="space-y-1.5"
    >
      <div role="row" className="grid grid-cols-[3.25rem_repeat(8,minmax(0,1fr))] gap-1 sm:grid-cols-[6.5rem_repeat(8,minmax(0,1fr))] sm:gap-1.5">
        <div role="columnheader" className="sr-only">
          Sound
        </div>
        {Array.from({ length: STEPS }, (_, s) => (
          <div
            key={s}
            role="columnheader"
            className={`text-center font-mono text-xs font-bold tabular-nums ${step === s ? 'text-vermilion' : 'text-ink/60'}`}
          >
            <span className="sr-only">Beat </span>
            {s + 1}
          </div>
        ))}
      </div>

      {VOICES.map((voice, v) => {
        const Icon = ICONS[v]
        return (
          <div
            key={voice.id}
            role="row"
            className="grid grid-cols-[3.25rem_repeat(8,minmax(0,1fr))] items-center gap-1 sm:grid-cols-[6.5rem_repeat(8,minmax(0,1fr))] sm:gap-1.5"
          >
            <div role="rowheader" className="flex items-center gap-1.5 pr-1 text-[0.7rem] font-semibold text-ink sm:text-sm">
              <Icon aria-hidden className="h-4 w-4 shrink-0" strokeWidth={1.8} />
              <span className="truncate">{voice.label}</span>
            </div>
            {Array.from({ length: STEPS }, (_, s) => {
              const on = pattern[v][s]
              const playhead = step === s
              return (
                <div role="gridcell" key={s} className={`${s === 3 ? 'mr-0.5 sm:mr-1' : ''}`}>
                  <button
                    type="button"
                    ref={(el) => {
                      cells.current[v][s] = el
                    }}
                    tabIndex={focus.v === v && focus.s === s ? 0 : -1}
                    aria-pressed={on}
                    aria-label={`${voice.label}, beat ${s + 1}`}
                    onFocus={() => setFocus({ v, s })}
                    onClick={() => onToggle(v, s)}
                    className={`flex h-11 w-full items-center justify-center rounded-md border-[1.5px] transition-colors sm:h-12 ${
                      on ? `${TINTS[v]} border-midnight-900 text-paper` : 'border-ink/25 bg-paper-deep/60 text-ink/40 hover:bg-paper-deep'
                    } ${playhead ? 'ring-[3px] ring-vermilion ring-offset-1 ring-offset-paper' : ''}`}
                  >
                    {on ? <span aria-hidden className="h-3 w-3 rounded-full bg-paper" /> : <span aria-hidden className="h-0.5 w-2.5 rounded bg-current" />}
                  </button>
                </div>
              )
            })}
          </div>
        )
      })}
    </div>
  )
}
