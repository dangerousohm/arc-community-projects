interface Props {
  /** Increments each time a voice sounds; restarts that voice's animation. */
  pulses: number[]
  className?: string
}

/** Original inline railway scene: a night platform in the rain. Each voice lights part of it. */
export function RailwayArt({ pulses, className }: Props) {
  const [rain, rail, bell, steps] = pulses
  const sleepers = Array.from({ length: 24 }, (_, i) => 6 + i * 27)
  const feet = [70, 150, 230, 310, 390]

  return (
    <svg
      viewBox="0 0 640 300"
      className={className}
      role="img"
      aria-label="Illustration: a night train stopped at a rainy country station, with a lantern bell hanging by the platform."
    >
      <defs>
        <linearGradient id="fp-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#091634" />
          <stop offset="1" stopColor="#24427a" />
        </linearGradient>
        <radialGradient id="fp-glow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ffd98a" stopOpacity="0.95" />
          <stop offset="1" stopColor="#ffd98a" stopOpacity="0" />
        </radialGradient>
        <pattern id="fp-rain" width="30" height="46" patternUnits="userSpaceOnUse" patternTransform="rotate(14)">
          <path d="M7 0v15M21 22v16" stroke="#cfe0f2" strokeWidth="1.4" strokeLinecap="round" />
        </pattern>
      </defs>

      <rect width="640" height="300" fill="url(#fp-sky)" />
      {/* moon and stars */}
      <circle cx="540" cy="58" r="24" fill="#f4e9c8" />
      <circle cx="551" cy="52" r="21" fill="#1a3466" />
      <g fill="#f4e9c8" opacity="0.8">
        <circle cx="70" cy="40" r="1.6" />
        <circle cx="150" cy="70" r="1.2" />
        <circle cx="300" cy="32" r="1.5" />
        <circle cx="420" cy="62" r="1.2" />
        <circle cx="610" cy="120" r="1.3" />
        <circle cx="230" cy="24" r="1" />
      </g>
      {/* hills */}
      <path d="M0 170 Q90 108 190 150 T380 140 T560 136 T640 150 V260 H0Z" fill="#14305e" />
      <path d="M0 196 Q110 150 220 186 T440 176 T640 188 V260 H0Z" fill="#102650" />

      {/* station house */}
      <g>
        <rect x="452" y="128" width="170" height="124" fill="#0c1c3f" />
        <path d="M440 132 L537 98 L634 132Z" fill="#081330" />
        <rect x="440" y="130" width="194" height="6" fill="#f0e4c0" />
        <g fill="#f6d98c">
          <rect x="474" y="160" width="26" height="34" />
          <rect x="574" y="160" width="26" height="34" />
        </g>
        <rect x="524" y="176" width="30" height="76" fill="#06102a" />
        <rect x="524" y="176" width="30" height="76" fill="none" stroke="#f0e4c0" strokeWidth="1.5" />
        <circle cx="537" cy="148" r="9" fill="#f0e4c0" />
        <path d="M537 148v-6M537 148l4 3" stroke="#0a1530" strokeWidth="1.5" strokeLinecap="round" />
      </g>

      {/* station bell on its bracket */}
      <g>
        <path d="M452 166h-30" stroke="#f0e4c0" strokeWidth="3" strokeLinecap="round" />
        <circle key={`glow-${bell}`} cx="422" cy="190" r="34" fill="url(#fp-glow)" opacity="0" className={bell > 0 ? 'hit-glow' : undefined} />
        <g key={`bell-${bell}`} className={bell > 0 ? 'hit-bell' : undefined}>
          <path d="M422 168v8" stroke="#f0e4c0" strokeWidth="2" />
          <path d="M406 204c0-16 6-26 16-28 10 2 16 12 16 28z" fill="#d9a441" stroke="#f0e4c0" strokeWidth="1.5" />
          <rect x="403" y="203" width="38" height="5" rx="2.5" fill="#f0e4c0" />
          <circle cx="422" cy="214" r="3.5" fill="#d9a441" />
        </g>
      </g>

      {/* the train */}
      <g>
        <rect x="46" y="150" width="20" height="32" fill="#050c20" />
        <rect x="40" y="144" width="32" height="8" rx="2" fill="#050c20" />
        <rect x="64" y="172" width="150" height="52" rx="12" fill="#050c20" />
        <circle cx="124" cy="168" r="13" fill="#050c20" />
        <rect x="182" y="140" width="76" height="84" fill="#050c20" />
        <rect x="176" y="132" width="88" height="10" rx="2" fill="#050c20" />
        <rect x="194" y="152" width="24" height="26" fill="#f6d98c" />
        <rect x="226" y="152" width="20" height="26" fill="#f6d98c" opacity="0.85" />
        <rect x="64" y="208" width="194" height="6" fill="#d6432b" />
        <rect x="264" y="164" width="164" height="60" rx="4" fill="#050c20" />
        <g fill="#f6d98c" opacity="0.92">
          <rect x="278" y="176" width="28" height="22" />
          <rect x="320" y="176" width="28" height="22" />
          <rect x="362" y="176" width="28" height="22" />
        </g>
        <rect x="264" y="208" width="164" height="6" fill="#d6432b" />
        <rect x="256" y="196" width="10" height="4" fill="#050c20" />
        {[96, 150, 218, 300, 396].map((cx) => (
          <g key={cx}>
            <circle cx={cx} cy="226" r={cx < 230 && cx > 120 ? 14 : 11} fill="#050c20" stroke="#f0e4c0" strokeWidth="1.5" />
            <circle cx={cx} cy="226" r="2.5" fill="#f0e4c0" />
          </g>
        ))}
      </g>

      {/* rails, sparks and sleepers */}
      <rect x="0" y="240" width="640" height="4" fill="#cdd6e4" />
      <g fill="#07122b">
        {sleepers.map((x) => (
          <rect key={x} x={x} y="246" width="18" height="7" />
        ))}
      </g>
      <g key={`spark-${rail}`} className={rail > 0 ? 'hit-spark' : undefined} opacity="0" stroke="#ffe6a8" strokeWidth="2" strokeLinecap="round">
        <path d="M84 238l-8-8M100 238l6-9M286 238l-7-8M304 238l7-8M384 238l-6-8M408 238l7-8" />
      </g>

      {/* platform */}
      <rect x="0" y="262" width="640" height="38" fill="#10234b" />
      <rect x="0" y="262" width="640" height="4" fill="#f0e4c0" />
      <g key={`steps-${steps}`} className={steps > 0 ? 'hit-step' : undefined} fill="#f0e4c0" opacity="0.35">
        {feet.map((x, i) => (
          <g key={x} transform={`translate(${x} ${i % 2 ? 284 : 278})`}>
            <ellipse cx="0" cy="0" rx="7" ry="3.6" />
            <ellipse cx="14" cy="5" rx="7" ry="3.6" />
          </g>
        ))}
      </g>

      {/* rain over everything */}
      <rect width="640" height="262" fill="url(#fp-rain)" opacity="0.22" />
      <rect key={`rain-${rain}`} width="640" height="262" fill="url(#fp-rain)" opacity="0" className={rain > 0 ? 'hit-rain' : undefined} />
    </svg>
  )
}
