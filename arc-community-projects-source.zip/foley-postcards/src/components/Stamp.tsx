interface Props {
  notes: number
  /** Changes each time the postcard is saved, so the stamp presses down again. */
  saves: number
  className?: string
}

/** Vermilion postal stamp. Counts the sounds on the card and re-stamps on save. */
export function Stamp({ notes, saves, className }: Props) {
  return (
    <svg
      key={saves}
      viewBox="0 0 120 120"
      className={`${className ?? ''} ${saves > 0 ? 'stamp-down' : ''}`}
      style={{ mixBlendMode: 'multiply', transform: 'rotate(-8deg)', opacity: 0.94 }}
      role="img"
      aria-label={`Vermilion stamp: Foley Postcards field edition, ${notes} ${notes === 1 ? 'sound' : 'sounds'} on this card${saves > 0 ? ', freshly stamped' : ''}.`}
    >
      <defs>
        <filter id="fp-ink" x="-5%" y="-5%" width="110%" height="110%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="4" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="2.2" />
        </filter>
        <path id="fp-ring" d="M60 60m-41 0a41 41 0 1 1 82 0a41 41 0 1 1-82 0" />
      </defs>
      <g filter="url(#fp-ink)" fill="none" stroke="#d6432b" strokeWidth="3">
        <circle cx="60" cy="60" r="55" />
        <circle cx="60" cy="60" r="31" strokeWidth="1.6" />
        <text fill="#d6432b" stroke="none" fontFamily="'American Typewriter','Courier New',monospace" fontSize="10.5" fontWeight="700" letterSpacing="2.1">
          <textPath href="#fp-ring" startOffset="2">
            FOLEY POSTCARDS * FIELD EDITION *
          </textPath>
        </text>
        <text x="60" y="58" textAnchor="middle" fill="#d6432b" stroke="none" fontFamily="'Iowan Old Style',Georgia,serif" fontSize="25" fontWeight="700">
          {notes}
        </text>
        <text x="60" y="73" textAnchor="middle" fill="#d6432b" stroke="none" fontFamily="'American Typewriter','Courier New',monospace" fontSize="8.5" fontWeight="700" letterSpacing="1.4">
          {notes === 1 ? 'SOUND' : 'SOUNDS'}
        </text>
      </g>
    </svg>
  )
}
