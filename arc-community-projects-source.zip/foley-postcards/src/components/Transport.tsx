import { Pause, Play } from 'lucide-react'
import { MAX_BPM, MIN_BPM } from '@/lib/postcard'

interface Props {
  playing: boolean
  silent: boolean
  loop: boolean
  bpm: number
  onPlay: () => void
  onStop: () => void
  onSilent: (v: boolean) => void
  onLoop: (v: boolean) => void
  onBpm: (v: number) => void
}

export function Transport({ playing, silent, loop, bpm, onPlay, onStop, onSilent, onLoop, onBpm }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
      <div className="flex gap-2">
        <button type="button" onClick={onPlay} className="btn btn-primary min-w-28">
          <Play aria-hidden className="h-4 w-4" fill="currentColor" />
          {playing ? 'Restart' : 'Play'}
        </button>
        <button type="button" onClick={onStop} disabled={!playing} className="btn min-w-24 disabled:cursor-not-allowed disabled:opacity-45">
          <Pause aria-hidden className="h-4 w-4" fill="currentColor" />
          Stop
        </button>
      </div>

      <label className="flex min-h-11 items-center gap-2 text-sm font-medium">
        <input type="checkbox" checked={silent} onChange={(e) => onSilent(e.target.checked)} className="h-5 w-5 accent-midnight" />
        Silent visual playback
      </label>
      <label className="flex min-h-11 items-center gap-2 text-sm font-medium">
        <input type="checkbox" checked={loop} onChange={(e) => onLoop(e.target.checked)} className="h-5 w-5 accent-midnight" />
        Loop
      </label>

      <label className="flex min-h-11 items-center gap-3 text-sm font-medium">
        <span>
          Tempo <span className="font-mono tabular-nums">{bpm}</span> BPM
        </span>
        <input
          type="range"
          min={MIN_BPM}
          max={MAX_BPM}
          step={1}
          value={bpm}
          onChange={(e) => onBpm(Number(e.target.value))}
          aria-valuetext={`${bpm} beats per minute`}
          className="h-6 w-36 accent-midnight"
        />
      </label>
    </div>
  )
}
