import { useRef } from 'react'
import { FolderOpen, Stamp as StampIcon } from 'lucide-react'

interface Props {
  onSave: () => void
  onOpen: (file: File) => void
}

export function PostFile({ onSave, onOpen }: Props) {
  const input = useRef<HTMLInputElement>(null)
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={onSave} className="btn btn-primary">
          <StampIcon aria-hidden className="h-4 w-4" />
          Save postcard file
        </button>
        <button type="button" onClick={() => input.current?.click()} className="btn">
          <FolderOpen aria-hidden className="h-4 w-4" />
          Open postcard file
        </button>
        <input
          ref={input}
          type="file"
          accept=".json,application/json"
          className="sr-only"
          tabIndex={-1}
          aria-label="Choose a postcard file"
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) onOpen(file)
            e.target.value = ''
          }}
        />
      </div>
      <p className="mt-2 max-w-prose text-sm text-ink/70">
        A postcard is a tiny file you keep. Hand it to a friend and they can open it here to listen or remix. Nothing is recorded, and nothing leaves this device.
      </p>
    </div>
  )
}
