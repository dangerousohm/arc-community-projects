import { useId } from 'react'
import { PostFile } from '@/components/PostFile'
import { RailwayArt } from '@/components/RailwayArt'
import { Stamp } from '@/components/Stamp'
import { StepGrid } from '@/components/StepGrid'
import { Transport } from '@/components/Transport'
import { FILE_SCENE, useFoley } from '@/hooks/useFoley'
import { MAX_TITLE, SCENES, STEPS, countNotes } from '@/lib/postcard'

export default function App() {
  const f = useFoley()
  const titleId = useId()
  const sceneSelectId = useId()
  const notes = countNotes(f.pattern)

  return (
    <div className="min-h-dvh bg-midnight-950 bg-[radial-gradient(ellipse_at_top,#16294f_0%,#060e22_65%)] px-3 py-6 pb-24 sm:px-6 sm:py-10">
      <main className="paper mx-auto max-w-5xl rounded-sm border-t-[10px] border-vermilion p-4 shadow-[0_24px_60px_rgba(0,0,0,0.55)] sm:p-8 lg:p-10">
        <header className="mb-6 border-b border-ink/25 pb-5">
          <p className="kicker">Field recordings / Postal edition Nº 01</p>
          <h1 className="mt-2 font-display text-5xl font-bold leading-none tracking-tight text-midnight sm:text-7xl">Foley Postcards</h1>
          <p className="mt-3 max-w-prose text-pretty text-base text-ink/80">
            Compose a tiny place out of sound. Punch eight beats of rain, rail, bell and footsteps, then slip the score into a file you can send.
          </p>
        </header>

        <div className="grid gap-8 lg:grid-cols-[1.05fr_1fr] lg:gap-10">
          <section aria-labelledby="front-heading" className="lg:sticky lg:top-6 lg:self-start">
            <h2 id="front-heading" className="kicker mb-2">
              The postcard
            </h2>
            <figure className="relative rounded-sm border border-ink/20 bg-paper-edge/40 p-2 shadow-sm sm:p-3">
              <RailwayArt pulses={f.pulses} className="block w-full rounded-[2px]" />
              <Stamp notes={notes} saves={f.saves} className="absolute -right-2 -top-5 h-24 w-24 sm:-right-4 sm:-top-6 sm:h-28 sm:w-28" />
              <figcaption className="px-1 pb-1 pt-3">
                <label htmlFor={titleId} className="kicker !text-ink/70">
                  Postcard title
                </label>
                <input
                  id={titleId}
                  value={f.title}
                  onChange={(e) => f.setTitle(e.target.value)}
                  maxLength={MAX_TITLE}
                  autoComplete="off"
                  spellCheck={false}
                  className="mt-1 w-full border-0 border-b-2 border-ink/30 bg-transparent px-0 py-1 font-display text-2xl font-bold text-midnight placeholder:text-ink/40 focus:border-midnight focus:outline-none focus-visible:outline-none sm:text-3xl"
                  placeholder="Name this place"
                />
                <p className="mt-1 font-mono text-xs text-ink/65">
                  Scene: {f.sceneName} · {notes} {notes === 1 ? 'sound' : 'sounds'} · {STEPS} beats
                </p>
              </figcaption>
            </figure>
          </section>

          <div className="space-y-8">
            <section aria-labelledby="scene-heading">
              <h2 id="scene-heading" className="kicker mb-2">
                01 / Choose a scene
              </h2>
              <label htmlFor={sceneSelectId} className="block text-sm font-medium">
                Starting score (replaces the current one)
              </label>
              <select
                id={sceneSelectId}
                value={f.sceneId}
                onChange={(e) => f.chooseScene(e.target.value)}
                className="mt-1 min-h-11 w-full rounded-md border-[1.5px] border-midnight bg-paper px-3 text-base font-medium text-midnight"
              >
                {f.sceneId === FILE_SCENE && (
                  <option value={FILE_SCENE} disabled>
                    {f.sceneName}
                  </option>
                )}
                {SCENES.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </section>

            <section aria-labelledby="score-heading">
              <h2 id="score-heading" className="kicker mb-1">
                02 / Punch the score
              </h2>
              <p className="mb-3 text-sm text-ink/75">Each column is one beat. Tap a square to add or remove a sound.</p>
              <StepGrid pattern={f.pattern} step={f.step} onToggle={f.toggleCell} />
              <div className="mt-4">
                <Transport
                  playing={f.playing}
                  silent={f.silent}
                  loop={f.loop}
                  bpm={f.bpm}
                  onPlay={() => void f.play()}
                  onStop={f.stop}
                  onSilent={f.setSilent}
                  onLoop={f.setLoop}
                  onBpm={f.setBpm}
                />
              </div>
              <p className="mt-2 font-mono text-xs text-ink/65" aria-hidden>
                {f.playing ? `Beat ${f.step + 1} of ${STEPS}` : `${STEPS} beats, stopped`}
              </p>
            </section>

            <section aria-labelledby="post-heading">
              <h2 id="post-heading" className="kicker mb-2">
                03 / Post it
              </h2>
              <PostFile onSave={f.save} onOpen={(file) => void f.openFile(file)} />
            </section>

            <p
              role={f.notice.kind === 'error' ? 'alert' : 'status'}
              aria-live={f.notice.kind === 'error' ? 'assertive' : 'polite'}
              className={`min-h-6 border-l-4 py-1 pl-3 text-sm font-medium ${
                f.notice.kind === 'error' ? 'border-vermilion text-vermilion-dark' : f.notice.kind === 'ok' ? 'border-midnight text-midnight' : 'border-ink/30 text-ink/80'
              }`}
            >
              {f.notice.text}
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
