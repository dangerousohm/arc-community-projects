/** Four synthesized voices. Everything is generated in the browser; nothing is recorded or loaded. */

type Voice = (ctx: AudioContext, out: AudioNode, when: number, noise: AudioBuffer, track: (s: AudioScheduledSourceNode) => void) => void

function noiseSource(ctx: AudioContext, noise: AudioBuffer, when: number, dur: number, offset: number) {
  const src = ctx.createBufferSource()
  src.buffer = noise
  src.start(when, offset % Math.max(0.01, noise.duration - dur - 0.01), dur)
  return src
}

function envelope(ctx: AudioContext, when: number, peak: number, attack: number, decay: number) {
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, when)
  g.gain.exponentialRampToValueAtTime(peak, when + attack)
  g.gain.exponentialRampToValueAtTime(0.0001, when + attack + decay)
  return g
}

/** Rain: a patter of filtered noise drops on a window sill. */
const rain: Voice = (ctx, out, when, noise, track) => {
  const dur = 0.3
  const src = noiseSource(ctx, noise, when, dur, Math.random() * 1.5)
  const hp = ctx.createBiquadFilter()
  hp.type = 'highpass'
  hp.frequency.value = 2200
  const bp = ctx.createBiquadFilter()
  bp.type = 'bandpass'
  bp.frequency.value = 5200
  bp.Q.value = 0.6
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, when)
  for (let i = 0; i < 9; i++) {
    const t = when + (i / 9) * dur + Math.random() * 0.012
    g.gain.setValueAtTime(0.0001, t)
    g.gain.linearRampToValueAtTime(0.05 + Math.random() * 0.08, t + 0.004)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03)
  }
  src.connect(hp).connect(bp).connect(g).connect(out)
  track(src)
}

/** Rail: a double clack of wheels crossing a rail joint. */
const rail: Voice = (ctx, out, when, noise, track) => {
  ;[0, 0.115].forEach((delay, i) => {
    const t = when + delay
    const click = noiseSource(ctx, noise, t, 0.05, 0.7 + i)
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 1500 - i * 250
    bp.Q.value = 3
    click.connect(bp).connect(envelope(ctx, t, 0.22, 0.002, 0.04)).connect(out)
    const thump = ctx.createOscillator()
    thump.type = 'triangle'
    thump.frequency.setValueAtTime(190 - i * 30, t)
    thump.frequency.exponentialRampToValueAtTime(80, t + 0.07)
    thump.connect(envelope(ctx, t, 0.16, 0.002, 0.08)).connect(out)
    thump.start(t)
    thump.stop(t + 0.12)
    track(click)
    track(thump)
  })
}

/** Bell: an inharmonic station bell with a long ring. */
const bell: Voice = (ctx, out, when, _noise, track) => {
  const partials: Array<[number, number, number]> = [
    [770, 0.13, 1.3],
    [1540 * 1.38, 0.05, 0.8],
    [770 * 2.76, 0.04, 0.55],
    [770 * 5.4, 0.015, 0.3],
  ]
  for (const [freq, peak, decay] of partials) {
    const osc = ctx.createOscillator()
    osc.type = 'sine'
    osc.frequency.value = freq
    osc.connect(envelope(ctx, when, peak, 0.004, decay)).connect(out)
    osc.start(when)
    osc.stop(when + decay + 0.1)
    track(osc)
  }
}

/** Footsteps: a heel and a softer toe on a damp platform. */
const steps: Voice = (ctx, out, when, noise, track) => {
  ;[0, 0.1].forEach((delay, i) => {
    const t = when + delay
    const body = ctx.createOscillator()
    body.type = 'sine'
    body.frequency.setValueAtTime(130 - i * 20, t)
    body.frequency.exponentialRampToValueAtTime(42, t + 0.11)
    body.connect(envelope(ctx, t, i === 0 ? 0.3 : 0.16, 0.004, 0.11)).connect(out)
    body.start(t)
    body.stop(t + 0.16)
    const scuff = noiseSource(ctx, noise, t, 0.09, 2 + i)
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 650
    scuff.connect(lp).connect(envelope(ctx, t, i === 0 ? 0.14 : 0.07, 0.005, 0.07)).connect(out)
    track(body)
    track(scuff)
  })
}

const VOICE_FNS: readonly Voice[] = [rain, rail, bell, steps]

export class FoleyEngine {
  private ctx: AudioContext | null = null
  private bus: GainNode | null = null
  private compressor: DynamicsCompressorNode | null = null
  private noise: AudioBuffer | null = null
  private readonly live = new Set<AudioScheduledSourceNode>()

  get context(): AudioContext | null {
    return this.ctx
  }

  /** Create (once) and resume the audio context. Call from a user gesture. */
  async ensure(): Promise<AudioContext> {
    if (!this.ctx) {
      const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!Ctor) throw new Error('Web Audio is not available in this browser.')
      const ctx = new Ctor()
      const len = Math.floor(ctx.sampleRate * 3)
      const buf = ctx.createBuffer(1, len, ctx.sampleRate)
      const data = buf.getChannelData(0)
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
      this.noise = buf
      this.compressor = ctx.createDynamicsCompressor()
      this.compressor.connect(ctx.destination)
      this.ctx = ctx
      this.makeBus()
    }
    if (this.ctx.state !== 'running') await this.ctx.resume()
    if (this.ctx.state !== 'running') throw new Error('The browser kept audio paused.')
    return this.ctx
  }

  private makeBus() {
    if (!this.ctx || !this.compressor) return
    this.bus = this.ctx.createGain()
    this.bus.gain.value = 0.85
    this.bus.connect(this.compressor)
  }

  now(): number {
    return this.ctx?.currentTime ?? 0
  }

  trigger(voice: number, when: number): void {
    const fn = VOICE_FNS[voice]
    if (!fn || !this.ctx || !this.bus || !this.noise) return
    fn(this.ctx, this.bus, Math.max(when, this.ctx.currentTime), this.noise, (s) => {
      this.live.add(s)
      s.addEventListener('ended', () => this.live.delete(s), { once: true })
    })
  }

  /** Fade out and cut everything that is sounding or queued. */
  stopAll(): void {
    if (!this.ctx || !this.bus) return
    const old = this.bus
    const t = this.ctx.currentTime
    old.gain.cancelScheduledValues(t)
    old.gain.setTargetAtTime(0, t, 0.012)
    const sources = Array.from(this.live)
    this.live.clear()
    for (const s of sources) {
      try {
        s.stop(t + 0.08)
      } catch {
        /* already stopped */
      }
    }
    setTimeout(() => old.disconnect(), 150)
    this.makeBus()
  }
}
