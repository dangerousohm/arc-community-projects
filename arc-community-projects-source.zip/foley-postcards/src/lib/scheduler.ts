import { STEPS, type Pattern } from './postcard'

/**
 * Look-ahead step scheduler. A short timer wakes up every `interval` ms and
 * schedules every step that starts within the next `lookahead` seconds, using
 * the clock's own timeline (AudioContext time for sound, performance time for
 * silent mode). Timing never depends on the timer being exact.
 */
export interface SchedulerHooks {
  /** Current time in seconds on the timeline used for `trigger`. */
  now(): number
  getPattern(): Pattern
  getStepSeconds(): number
  /** Schedule a voice to sound at `when` (seconds on the same timeline). */
  trigger(voice: number, when: number): void
  /** Called when a step's start time is reached (drives the visual playhead). */
  onStep(step: number, hits: boolean[], when: number): void
  /** Called once when a non-looping run finishes its last step. */
  onDone(): void
  setTimer(fn: () => void, ms: number): unknown
  clearTimer(handle: unknown): void
}

export interface SchedulerOptions {
  lookahead?: number
  interval?: number
  startDelay?: number
  /** If the timer stalls by more than this many seconds, resync instead of bursting. */
  maxLag?: number
}

interface PendingStep {
  step: number
  hits: boolean[]
  when: number
}

export class StepScheduler {
  private running = false
  private loop = false
  private step = 0
  private nextTime = 0
  private endTime: number | null = null
  private timer: unknown = null
  private pending: PendingStep[] = []
  private readonly lookahead: number
  private readonly interval: number
  private readonly startDelay: number
  private readonly maxLag: number

  constructor(
    private readonly hooks: SchedulerHooks,
    options: SchedulerOptions = {},
  ) {
    this.lookahead = options.lookahead ?? 0.15
    this.interval = options.interval ?? 25
    this.startDelay = options.startDelay ?? 0.06
    this.maxLag = options.maxLag ?? 0.3
  }

  get isRunning(): boolean {
    return this.running
  }

  start(loop: boolean): void {
    this.stop()
    this.running = true
    this.loop = loop
    this.step = 0
    this.endTime = null
    this.pending = []
    this.nextTime = this.hooks.now() + this.startDelay
    this.tick()
  }

  setLoop(loop: boolean): void {
    this.loop = loop
  }

  stop(): void {
    this.running = false
    this.pending = []
    this.endTime = null
    if (this.timer !== null) this.hooks.clearTimer(this.timer)
    this.timer = null
  }

  tick(): void {
    if (!this.running) return
    this.timer = null
    const now = this.hooks.now()

    if (this.endTime === null && this.nextTime < now - this.maxLag) {
      this.nextTime = now
    }

    while (this.endTime === null && this.nextTime < now + this.lookahead) {
      const pattern = this.hooks.getPattern()
      const hits = pattern.map((row) => row[this.step] === true)
      hits.forEach((on, voice) => {
        if (on) this.hooks.trigger(voice, this.nextTime)
      })
      this.pending.push({ step: this.step, hits, when: this.nextTime })
      this.nextTime += this.hooks.getStepSeconds()
      this.step += 1
      if (this.step >= STEPS) {
        if (this.loop) this.step = 0
        else this.endTime = this.nextTime
      }
    }

    while (this.pending.length > 0 && this.pending[0].when <= now) {
      const due = this.pending.shift()!
      this.hooks.onStep(due.step, due.hits, due.when)
    }

    if (this.endTime !== null && this.pending.length === 0 && now >= this.endTime) {
      this.stop()
      this.hooks.onDone()
      return
    }

    this.timer = this.hooks.setTimer(() => this.tick(), this.interval)
  }
}
