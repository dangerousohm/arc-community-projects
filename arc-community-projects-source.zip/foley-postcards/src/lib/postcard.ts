/** Pure data model for a Foley postcard: pattern, scenes, and the file format. */

export const STEPS = 8
export const MIN_BPM = 50
export const MAX_BPM = 140
export const DEFAULT_BPM = 75
export const MAX_TITLE = 80
export const MAX_SCENE = 40
export const MAX_FILE_CHARS = 16_384
export const FILE_VERSION = 2

export const VOICES = [
  { id: 'rain', label: 'Rain' },
  { id: 'rail', label: 'Rail' },
  { id: 'bell', label: 'Bell' },
  { id: 'steps', label: 'Footsteps' },
] as const

export type VoiceId = (typeof VOICES)[number]['id']
/** pattern[voice][step] is true when that voice sounds on that step. */
export type Pattern = boolean[][]

export interface Postcard {
  title: string
  scene: string
  bpm: number
  pattern: Pattern
}

export interface Scene {
  id: string
  name: string
  bpm: number
  rows: readonly [string, string, string, string]
}

export const SCENES: readonly Scene[] = [
  { id: 'rain-station', name: 'Rain at the station', bpm: 75, rows: ['10111010', '01010101', '10000010', '00001001'] },
  { id: 'night-market', name: 'Night market closing', bpm: 84, rows: ['10001000', '11001100', '00100100', '10101010'] },
  { id: 'first-ferry', name: 'First ferry home', bpm: 66, rows: ['00010001', '10101010', '10001000', '01000010'] },
  { id: 'midnight-freight', name: 'Midnight freight', bpm: 92, rows: ['11011011', '10101110', '00000001', '01000100'] },
]

export const CUSTOM_SCENE = 'Opened from file'

export function emptyPattern(): Pattern {
  return VOICES.map(() => Array.from({ length: STEPS }, () => false))
}

export function patternFromStrings(rows: readonly string[]): Pattern {
  return rows.map((row) => Array.from(row, (ch) => ch === '1'))
}

export function patternToStrings(pattern: Pattern): string[] {
  return pattern.map((row) => row.map((on) => (on ? '1' : '0')).join(''))
}

export function clonePattern(pattern: Pattern): Pattern {
  return pattern.map((row) => row.slice())
}

export function togglePattern(pattern: Pattern, voice: number, step: number): Pattern {
  return pattern.map((row, v) => (v === voice ? row.map((on, s) => (s === step ? !on : on)) : row))
}

export function countNotes(pattern: Pattern): number {
  return pattern.reduce((sum, row) => sum + row.filter(Boolean).length, 0)
}

export function sceneToPostcard(scene: Scene): Postcard {
  return { title: scene.name, scene: scene.name, bpm: scene.bpm, pattern: patternFromStrings(scene.rows) }
}

/** Seconds per step. Each step is an eighth note. */
export function stepSeconds(bpm: number): number {
  return 60 / bpm / 2
}

export function clampBpm(bpm: number): number {
  if (!Number.isFinite(bpm)) return DEFAULT_BPM
  return Math.min(MAX_BPM, Math.max(MIN_BPM, Math.round(bpm)))
}

const CONTROL_CHARS = /[\u0000-\u001f\u007f]/g

export function cleanTitle(raw: string): string {
  return raw.replace(CONTROL_CHARS, ' ').trim()
}

export function isValidPattern(pattern: unknown): pattern is Pattern {
  return (
    Array.isArray(pattern) &&
    pattern.length === VOICES.length &&
    pattern.every((row) => Array.isArray(row) && row.length === STEPS && row.every((n) => typeof n === 'boolean'))
  )
}

export function serializePostcard(card: Postcard): string {
  const title = cleanTitle(card.title)
  if (title.length === 0) throw new Error('A postcard needs a title.')
  if (title.length > MAX_TITLE) throw new Error(`Titles can be at most ${MAX_TITLE} characters.`)
  if (!isValidPattern(card.pattern)) throw new Error('The pattern must be 4 rows of 8 beats.')
  const pattern: Record<string, string> = {}
  const strings = patternToStrings(card.pattern)
  VOICES.forEach((voice, i) => {
    pattern[voice.id] = strings[i]
  })
  return JSON.stringify(
    {
      format: 'foley-postcard',
      version: FILE_VERSION,
      title,
      scene: card.scene.slice(0, MAX_SCENE),
      bpm: clampBpm(card.bpm),
      pattern,
    },
    null,
    2,
  )
}

export type ParseResult = { ok: true; card: Postcard } | { ok: false; error: string }

const fail = (error: string): ParseResult => ({ ok: false, error })
const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

/** Accepts version 2 files and the original version 1 files (rows of booleans). */
export function parsePostcard(text: string): ParseResult {
  if (typeof text !== 'string' || text.length > MAX_FILE_CHARS) return fail('That file is too large to be a postcard.')
  let data: unknown
  try {
    data = JSON.parse(text)
  } catch {
    return fail('That file is not a postcard (it is not valid JSON).')
  }
  if (!isRecord(data)) return fail('That file is not a postcard.')
  if (data.version !== 1 && data.version !== 2) return fail('That postcard version is not supported.')

  if (typeof data.title !== 'string') return fail('The postcard has no title.')
  const title = cleanTitle(data.title)
  if (title.length === 0 || title.length > MAX_TITLE) return fail(`The title must be 1 to ${MAX_TITLE} characters.`)

  let pattern: Pattern
  let bpm = DEFAULT_BPM
  if (data.version === 1) {
    if (!isValidPattern(data.rows)) return fail('The pattern must be 4 rows of 8 beats.')
    pattern = clonePattern(data.rows)
  } else {
    const src = data.pattern
    if (!isRecord(src)) return fail('The pattern is missing.')
    const rows: string[] = []
    for (const voice of VOICES) {
      const row = src[voice.id]
      if (typeof row !== 'string' || !/^[01]{8}$/.test(row)) return fail(`The ${voice.label} row must be 8 beats.`)
      rows.push(row)
    }
    pattern = patternFromStrings(rows)
    if (typeof data.bpm !== 'number' || !Number.isInteger(data.bpm) || data.bpm < MIN_BPM || data.bpm > MAX_BPM) {
      return fail(`The tempo must be a whole number from ${MIN_BPM} to ${MAX_BPM}.`)
    }
    bpm = data.bpm
  }

  const scene = typeof data.scene === 'string' && data.scene.trim() ? cleanTitle(data.scene).slice(0, MAX_SCENE) : CUSTOM_SCENE
  return { ok: true, card: { title, scene, bpm, pattern } }
}

export function fileNameFor(title: string): string {
  const slug = cleanTitle(title)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40)
  return `foley-postcard-${slug || 'untitled'}.json`
}
