import { useCallback, useEffect, useRef, useState } from 'react'
import { FoleyEngine } from '@/lib/foley'
import {
  MAX_FILE_CHARS,
  MAX_TITLE,
  SCENES,
  VOICES,
  clampBpm,
  cleanTitle,
  fileNameFor,
  parsePostcard,
  sceneToPostcard,
  serializePostcard,
  stepSeconds,
  togglePattern,
  type Pattern,
  type Postcard,
} from '@/lib/postcard'
import { StepScheduler, type SchedulerHooks } from '@/lib/scheduler'

export interface Notice {
  kind: 'info' | 'ok' | 'error'
  text: string
}

const FILE_SCENE_ID = 'file'

export function useFoley() {
  const first = sceneToPostcard(SCENES[0])
  const [pattern, setPattern] = useState<Pattern>(first.pattern)
  const [title, setTitle] = useState(first.title)
  const [sceneId, setSceneId] = useState(SCENES[0].id)
  const [sceneName, setSceneName] = useState(first.scene)
  const [bpm, setBpmState] = useState(first.bpm)
  const [silent, setSilentState] = useState(false)
  const [loop, setLoopState] = useState(true)
  const [playing, setPlaying] = useState(false)
  const [step, setStep] = useState(-1)
  const [pulses, setPulses] = useState<number[]>(() => VOICES.map(() => 0))
  const [saves, setSaves] = useState(0)
  const [notice, setNotice] = useState<Notice>({ kind: 'info', text: 'Ready. Eight beats, four sounds.' })

  const patternRef = useRef(pattern)
  const bpmRef = useRef(bpm)
  const engineRef = useRef<FoleyEngine | null>(null)
  const schedulerRef = useRef<StepScheduler | null>(null)
  const runRef = useRef(0)

  useEffect(() => {
    patternRef.current = pattern
  }, [pattern])
  useEffect(() => {
    bpmRef.current = bpm
  }, [bpm])
  useEffect(() => {
    schedulerRef.current?.setLoop(loop)
  }, [loop])

  const engine = useCallback(() => (engineRef.current ??= new FoleyEngine()), [])

  const halt = useCallback(
    (message?: Notice) => {
      runRef.current += 1
      schedulerRef.current?.stop()
      schedulerRef.current = null
      engineRef.current?.stopAll()
      setPlaying(false)
      setStep(-1)
      if (message) setNotice(message)
    },
    [],
  )

  useEffect(() => () => halt(), [halt])

  const play = useCallback(async () => {
    halt()
    const run = runRef.current
    let audible = !silent
    let fallback = false
    if (audible) {
      try {
        await engine().ensure()
      } catch {
        audible = false
        fallback = true
      }
    }
    if (run !== runRef.current) return
    const eng = engine()
    const hooks: SchedulerHooks = {
      now: () => (audible ? eng.now() : performance.now() / 1000),
      getPattern: () => patternRef.current,
      getStepSeconds: () => stepSeconds(bpmRef.current),
      trigger: (voice, when) => {
        if (audible) eng.trigger(voice, when)
      },
      onStep: (s, hits) => {
        setStep(s)
        setPulses((prev) => prev.map((n, i) => (hits[i] ? n + 1 : n)))
      },
      onDone: () => {
        setPlaying(false)
        setStep(-1)
        setNotice({ kind: 'info', text: 'Postcard finished. Press Play to run it again.' })
      },
      setTimer: (fn, ms) => window.setTimeout(fn, ms),
      clearTimer: (h) => window.clearTimeout(h as number),
    }
    const scheduler = new StepScheduler(hooks)
    schedulerRef.current = scheduler
    setPlaying(true)
    setNotice({
      kind: fallback ? 'error' : 'info',
      text: fallback
        ? 'Sound is unavailable in this browser, so the postcard is playing silently.'
        : audible
          ? 'Playing.'
          : 'Playing silently. Watch the postcard and the grid.',
    })
    scheduler.start(loop)
  }, [engine, halt, loop, silent])

  const stop = useCallback(() => halt({ kind: 'info', text: 'Stopped.' }), [halt])

  const toggleCell = useCallback(
    (voice: number, s: number) => {
      const turningOn = !patternRef.current[voice][s]
      setPattern((p) => togglePattern(p, voice, s))
      if (turningOn && !silent) {
        const eng = engine()
        eng
          .ensure()
          .then(() => eng.trigger(voice, eng.now() + 0.005))
          .catch(() => undefined)
      }
    },
    [engine, silent],
  )

  const loadCard = useCallback((card: Postcard, id: string) => {
    setPattern(card.pattern)
    patternRef.current = card.pattern
    setTitle(card.title)
    setSceneName(card.scene)
    setSceneId(id)
    setBpmState(card.bpm)
    bpmRef.current = card.bpm
  }, [])

  const chooseScene = useCallback(
    (id: string) => {
      const scene = SCENES.find((s) => s.id === id)
      if (!scene) return
      halt()
      loadCard(sceneToPostcard(scene), id)
      setNotice({ kind: 'info', text: `Loaded the scene "${scene.name}".` })
    },
    [halt, loadCard],
  )

  const setBpm = useCallback((value: number) => {
    const next = clampBpm(value)
    bpmRef.current = next
    setBpmState(next)
  }, [])

  const setSilent = useCallback(
    (value: boolean) => {
      if (playing) halt({ kind: 'info', text: value ? 'Silent mode on. Press Play to watch it.' : 'Sound on. Press Play to listen.' })
      setSilentState(value)
    },
    [halt, playing],
  )

  const save = useCallback(() => {
    let text: string
    try {
      text = serializePostcard({ title, scene: sceneName, bpm, pattern })
    } catch (err) {
      const message = cleanTitle(title).length === 0 ? 'Give your postcard a title before saving.' : err instanceof Error ? err.message : 'Could not save.'
      setNotice({ kind: 'error', text: message })
      return false
    }
    const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }))
    const a = document.createElement('a')
    a.href = url
    a.download = fileNameFor(title)
    document.body.append(a)
    a.click()
    a.remove()
    window.setTimeout(() => URL.revokeObjectURL(url), 1000)
    setSaves((n) => n + 1)
    setNotice({ kind: 'ok', text: `Postcard saved as ${a.download}.` })
    return true
  }, [bpm, pattern, sceneName, title])

  const openFile = useCallback(
    async (file: File) => {
      try {
        if (file.size > MAX_FILE_CHARS) throw new Error('That file is too large to be a postcard.')
        const result = parsePostcard(await file.text())
        if (!result.ok) throw new Error(result.error)
        halt()
        loadCard(result.card, FILE_SCENE_ID)
        setNotice({ kind: 'ok', text: `Opened "${result.card.title}". It stays on this device.` })
      } catch (err) {
        setNotice({ kind: 'error', text: `${err instanceof Error ? err.message : 'Could not read that file.'} Your current score is unchanged.` })
      }
    },
    [halt, loadCard],
  )

  return {
    pattern,
    title,
    setTitle: (value: string) => setTitle(value.slice(0, MAX_TITLE)),
    sceneId,
    sceneName,
    bpm,
    setBpm,
    silent,
    setSilent,
    loop,
    setLoop: setLoopState,
    playing,
    step,
    pulses,
    saves,
    notice,
    play,
    stop,
    toggleCell,
    chooseScene,
    save,
    openFile,
  }
}

export const FILE_SCENE = FILE_SCENE_ID
