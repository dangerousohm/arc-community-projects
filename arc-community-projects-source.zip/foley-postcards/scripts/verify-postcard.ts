/**
 * Verifies pattern serialization and playback scheduling without a browser.
 * Run with: bun run verify
 */
import assert from 'node:assert/strict'
import {
  CUSTOM_SCENE,
  DEFAULT_BPM,
  MAX_BPM,
  SCENES,
  STEPS,
  emptyPattern,
  fileNameFor,
  parsePostcard,
  patternFromStrings,
  patternToStrings,
  sceneToPostcard,
  serializePostcard,
  stepSeconds,
  togglePattern,
  type Pattern,
} from '../src/lib/postcard'
import { StepScheduler, type SchedulerHooks } from '../src/lib/scheduler'

interface SavedFile {
  version: number
  title: string
  scene: string
  bpm: number
  pattern: Record<string, string>
}

let passed = 0
function test(name: string, fn: () => void) {
  try {
    fn()
    passed += 1
    console.log(`  ok  ${name}`)
  } catch (err) {
    console.error(`FAIL  ${name}`)
    throw err
  }
}

console.log('Serialization')

test('every scene round-trips through a file unchanged', () => {
  for (const scene of SCENES) {
    const card = sceneToPostcard(scene)
    const back = parsePostcard(serializePostcard(card))
    assert.ok(back.ok, scene.name)
    assert.deepEqual(back.card, card)
  }
})

test('a pattern survives toggling and a round trip', () => {
  let p: Pattern = emptyPattern()
  p = togglePattern(p, 2, 7)
  p = togglePattern(p, 0, 0)
  p = togglePattern(p, 0, 0)
  const back = parsePostcard(serializePostcard({ title: 'Test', scene: 'x', bpm: 100, pattern: p }))
  assert.ok(back.ok)
  assert.deepEqual(patternToStrings(back.card.pattern), ['00000000', '00000000', '00000001', '00000000'])
  assert.equal(back.card.bpm, 100)
})

test('toggle is immutable', () => {
  const p = emptyPattern()
  const q = togglePattern(p, 1, 3)
  assert.equal(p[1][3], false)
  assert.equal(q[1][3], true)
})

test('the file is plain JSON with named rows', () => {
  const json = JSON.parse(serializePostcard(sceneToPostcard(SCENES[0]))) as SavedFile
  assert.equal(json.version, 2)
  assert.deepEqual(Object.keys(json.pattern), ['rain', 'rail', 'bell', 'steps'])
  assert.equal(json.pattern.rain, '10111010')
})

test('title is trimmed and control characters removed', () => {
  const back = parsePostcard(serializePostcard({ title: '  Hello\u0007 world  ', scene: 's', bpm: 80, pattern: emptyPattern() }))
  assert.ok(back.ok)
  assert.equal(back.card.title, 'Hello  world')
})

test('original version 1 prototype files still open', () => {
  const v1 = JSON.stringify({ version: 1, title: 'Old card', rows: patternFromStrings(SCENES[0].rows) })
  const back = parsePostcard(v1)
  assert.ok(back.ok)
  assert.equal(back.card.bpm, DEFAULT_BPM)
  assert.equal(back.card.scene, CUSTOM_SCENE)
  assert.deepEqual(patternToStrings(back.card.pattern), [...SCENES[0].rows])
})

test('invalid files are rejected with a message', () => {
  const good = JSON.parse(serializePostcard(sceneToPostcard(SCENES[0]))) as SavedFile
  const bad: unknown[] = [
    'not json',
    '[]',
    'null',
    { ...good, version: 3 },
    { ...good, title: '   ' },
    { ...good, title: 'x'.repeat(81) },
    { ...good, title: 7 },
    { ...good, bpm: 10 },
    { ...good, bpm: MAX_BPM + 1 },
    { ...good, bpm: 80.5 },
    { ...good, pattern: undefined },
    { ...good, pattern: { ...good.pattern, rain: '1011' } },
    { ...good, pattern: { ...good.pattern, bell: '1011101x' } },
    { ...good, pattern: { rain: good.pattern.rain } },
    { version: 1, title: 'a', rows: [[true]] },
    { version: 1, title: 'a', rows: Array.from({ length: 4 }, () => Array.from({ length: 8 }, () => 1)) },
  ]
  for (const b of bad) {
    const r = parsePostcard(typeof b === 'string' ? b : JSON.stringify(b))
    assert.equal(r.ok, false, JSON.stringify(b))
    if (!r.ok) assert.ok(r.error.length > 0)
  }
  assert.equal(parsePostcard('x'.repeat(20_000)).ok, false)
})

test('serializing an invalid card throws', () => {
  assert.throws(() => serializePostcard({ title: '', scene: '', bpm: 80, pattern: emptyPattern() }))
  assert.throws(() => serializePostcard({ title: 'a', scene: '', bpm: 80, pattern: [[true]] }))
})

test('file names are safe', () => {
  assert.equal(fileNameFor('Rain at the station!'), 'foley-postcard-rain-at-the-station.json')
  assert.equal(fileNameFor('../../etc/passwd'), 'foley-postcard-etc-passwd.json')
  assert.equal(fileNameFor('???'), 'foley-postcard-untitled.json')
})

console.log('Scheduling')

interface Harness {
  hooks: SchedulerHooks
  clock: { t: number }
  triggers: Array<{ voice: number; when: number }>
  steps: Array<{ step: number; at: number; when: number }>
  done: { count: number }
  timers: Map<number, () => void>
  bpm: { value: number }
  pattern: { value: Pattern }
  advance(seconds: number, resolution?: number): void
}

function harness(rows: readonly string[] = SCENES[0].rows, bpm = 120): Harness {
  const clock = { t: 10 }
  const triggers: Harness['triggers'] = []
  const steps: Harness['steps'] = []
  const done = { count: 0 }
  const timers = new Map<number, () => void>()
  let nextId = 1
  const bpmRef = { value: bpm }
  const patternRef = { value: patternFromStrings(rows) }
  const hooks: SchedulerHooks = {
    now: () => clock.t,
    getPattern: () => patternRef.value,
    getStepSeconds: () => stepSeconds(bpmRef.value),
    trigger: (voice, when) => triggers.push({ voice, when }),
    onStep: (step, _hits, when) => steps.push({ step, at: clock.t, when }),
    onDone: () => {
      done.count += 1
    },
    setTimer: (fn) => {
      const id = nextId++
      timers.set(id, fn)
      return id
    },
    clearTimer: (h) => {
      timers.delete(h as number)
    },
  }
  return {
    hooks,
    clock,
    triggers,
    steps,
    done,
    timers,
    bpm: bpmRef,
    pattern: patternRef,
    advance(seconds, resolution = 0.025) {
      const end = clock.t + seconds
      while (clock.t < end - 1e-9) {
        clock.t = Math.min(end, clock.t + resolution)
        const pending = Array.from(timers.entries())
        timers.clear()
        for (const [, fn] of pending) fn()
      }
    },
  }
}

const near = (a: number, b: number, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} !~ ${b}`)

test('one pass schedules each active hit exactly once at the right time', () => {
  const h = harness()
  const s = new StepScheduler(h.hooks)
  const t0 = h.clock.t
  s.start(false)
  h.advance(6)
  const dur = stepSeconds(120)
  near(dur, 0.25)
  const expected: Array<{ voice: number; step: number }> = []
  SCENES[0].rows.forEach((row, voice) => {
    Array.from(row).forEach((ch, step) => {
      if (ch === '1') expected.push({ voice, step })
    })
  })
  assert.equal(h.triggers.length, expected.length)
  const first = t0 + 0.06
  for (const e of expected) {
    const hit = h.triggers.filter((t) => t.voice === e.voice && Math.abs(t.when - (first + e.step * dur)) < 1e-9)
    assert.equal(hit.length, 1, `voice ${e.voice} step ${e.step}`)
  }
})

test('steps are announced in order 0..7 once, never before their time, then done fires once', () => {
  const h = harness()
  const s = new StepScheduler(h.hooks)
  s.start(false)
  h.advance(6)
  assert.deepEqual(
    h.steps.map((x) => x.step),
    [0, 1, 2, 3, 4, 5, 6, 7],
  )
  for (const st of h.steps) {
    assert.ok(st.at >= st.when, 'visual step fired early')
    assert.ok(st.at - st.when <= 0.03, 'visual step fired late')
  }
  assert.equal(h.done.count, 1)
  assert.equal(s.isRunning, false)
  assert.equal(h.timers.size, 0, 'no timers left behind')
})

test('scheduling stays inside the look-ahead window', () => {
  const h = harness('11111111,11111111,11111111,11111111'.split(','))
  const s = new StepScheduler(h.hooks, { lookahead: 0.15 })
  s.start(true)
  for (let i = 0; i < 200; i++) {
    h.advance(0.025)
    const furthest = Math.max(...h.triggers.map((t) => t.when))
    assert.ok(furthest < h.clock.t + 0.15 + 1e-9, 'scheduled too far ahead')
  }
  s.stop()
})

test('looping wraps from step 7 to step 0 on a steady grid', () => {
  const h = harness()
  const s = new StepScheduler(h.hooks)
  s.start(true)
  h.advance(5)
  const order = h.steps.map((x) => x.step)
  assert.ok(order.length > STEPS + 2)
  order.forEach((st, i) => assert.equal(st, i % STEPS))
  for (let i = 1; i < h.steps.length; i++) near(h.steps[i].when - h.steps[i - 1].when, 0.25)
  assert.equal(h.done.count, 0)
  s.stop()
})

test('stop cancels the timer and nothing more is scheduled', () => {
  const h = harness()
  const s = new StepScheduler(h.hooks)
  s.start(true)
  h.advance(1)
  s.stop()
  const triggers = h.triggers.length
  const steps = h.steps.length
  assert.equal(h.timers.size, 0)
  h.advance(3)
  assert.equal(h.triggers.length, triggers)
  assert.equal(h.steps.length, steps)
  assert.equal(h.done.count, 0)
})

test('restarting begins again at step 0', () => {
  const h = harness()
  const s = new StepScheduler(h.hooks)
  s.start(true)
  h.advance(1)
  const before = h.steps.length
  s.start(true)
  h.advance(0.5)
  assert.ok(h.steps.length > before)
  assert.equal(h.steps[before].step, 0)
  s.stop()
})

test('edits during playback are heard on later steps', () => {
  const h = harness('00000000,00000000,00000000,00000000'.split(','))
  const s = new StepScheduler(h.hooks)
  s.start(true)
  h.advance(0.3)
  assert.equal(h.triggers.length, 0)
  h.pattern.value = togglePattern(h.pattern.value, 2, 5)
  h.advance(2)
  assert.ok(h.triggers.length >= 1)
  assert.ok(h.triggers.every((t) => t.voice === 2))
  s.stop()
})

test('tempo changes apply to following steps', () => {
  const h = harness(SCENES[0].rows, 60)
  const s = new StepScheduler(h.hooks)
  s.start(true)
  h.advance(1.2)
  h.bpm.value = 120
  h.advance(3)
  const gaps = h.steps.slice(1).map((x, i) => x.when - h.steps[i].when)
  assert.ok(gaps.some((g) => Math.abs(g - 0.5) < 1e-9))
  assert.ok(gaps.some((g) => Math.abs(g - 0.25) < 1e-9))
  s.stop()
})

test('a stalled timer resyncs instead of bursting a backlog', () => {
  const h = harness('11111111,11111111,11111111,11111111'.split(','))
  const s = new StepScheduler(h.hooks)
  s.start(true)
  h.advance(0.5)
  const before = h.triggers.length
  h.clock.t += 5 // tab was throttled for five seconds
  const pending = Array.from(h.timers.values())
  h.timers.clear()
  pending.forEach((fn) => fn())
  const burst = h.triggers.length - before
  assert.ok(burst <= 8, `burst of ${burst}`)
  assert.ok(h.triggers.slice(before).every((t) => t.when >= h.clock.t - 1e-9))
  s.stop()
})

test('silent mode uses the same schedule (no trigger needed)', () => {
  const h = harness()
  const silentHooks: SchedulerHooks = { ...h.hooks, trigger: () => {} }
  const s = new StepScheduler(silentHooks)
  s.start(false)
  h.advance(6)
  assert.deepEqual(
    h.steps.map((x) => x.step),
    [0, 1, 2, 3, 4, 5, 6, 7],
  )
  assert.equal(h.done.count, 1)
})

console.log(`\n${passed} checks passed`)
