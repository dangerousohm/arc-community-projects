# Foley Postcards

An intimate illustrated field recorder: compose a tiny place out of sound with an 8-step sequencer and four synthesized voices (rain, rail, bell, footsteps), then save the score as a small postcard file.

Built with [Arc Studio](https://studio.arc.io)

## Features

- Eight-beat grid with rain, rail, bell and footsteps, all synthesized in the browser
- Play, stop, loop and tempo controls
- Named starting scenes and an editable postcard title
- Save a postcard to a local file and open one again
- Silent visual playback: the grid playhead and the railway illustration animate without sound
- Keyboard-operable grid with labelled controls (arrow keys move, Space or Enter toggles)
- No microphone, uploads, wallets or payments

## Tech stack

React 18, TypeScript, Vite, Tailwind CSS, Web Audio API.

## Development

Prerequisites: [Bun](https://bun.sh).

```bash
bun install
bun run dev       # start the dev server
bun run build     # production build
bun run verify    # check postcard serialization and playback scheduling
bun run check     # lint and typecheck
```

### Environment variables

None.
