# Arc community projects

Six independent Arc Studio source snapshots. Open each project separately; package scripts and setup may differ. This collection is for source review and does not imply production readiness or a public deployment.

| Project | Purpose |
|---|---|
| foley-postcards | Compose and exchange an eight-beat sound postcard. |
| second-life-passport | Document an object's repair and transformation. |
| trust-bridge | Organize neighborhood equipment borrowing and lending. |
| reality-check | Record and repeat community experiments. |
| folded-worlds | Pass a story between players, one contribution at a time. |
| welcome-layer | Plan and simulate sponsorship of concrete event accessibility improvements. |

Four projects were retrieved from Arc Studio on November 4, 2026. Folded Worlds and Welcome Layer use the previously saved local snapshots. Credentials, local Arc Studio state and compiler outputs are excluded from Git. Dependencies and builds have not been revalidated together.
